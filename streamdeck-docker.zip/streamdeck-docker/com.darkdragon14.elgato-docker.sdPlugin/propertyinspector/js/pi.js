let websocket = null;
let globalSettings = {};
let pluginUUID = null;
let actionInfo = {};

function connectElgatoStreamDeckSocket(inPort, inPluginUUID, inRegisterEvent, inActionInfo, inApplicationInfo) {
    pluginUUID = inPluginUUID;
    actionInfo = JSON.parse(inActionInfo);

    websocket = new WebSocket("ws://127.0.0.1:" + inPort);

    websocket.onopen = function() {
        const json = {
            event: inRegisterEvent,
            uuid: inPluginUUID
        };
        websocket.send(JSON.stringify(json));
        
        // Request the global settings
        const getSettings = {
            event: "getGlobalSettings",
            context: pluginUUID
        };
        websocket.send(JSON.stringify(getSettings));
    };

    websocket.onmessage = function(evt) {
        const jsonObj = JSON.parse(evt.data);
        const event = jsonObj['event'];
        const payload = jsonObj['payload'];

        if (event === 'didReceiveGlobalSettings') {
            globalSettings = payload.settings;
            updateUI();
        }
    };
}

function updateUI() {
    // Update view type dropdown
    const viewTypeSelect = document.getElementById('viewType');
    if (viewTypeSelect && globalSettings.viewType) {
        viewTypeSelect.value = globalSettings.viewType;
    }

    // Update items per page
    const itemsPerPageInput = document.getElementById('itemsPerPage');
    if (itemsPerPageInput && globalSettings.itemsPerPage) {
        itemsPerPageInput.value = globalSettings.itemsPerPage;
    }

    // Update show all containers checkbox
    const showAllContainersCheckbox = document.getElementById('showAllContainers');
    if (showAllContainersCheckbox && globalSettings.showAllContainers !== undefined) {
        showAllContainersCheckbox.checked = globalSettings.showAllContainers;
    }
}

function updateSettings() {
    if (websocket && websocket.readyState === 1) {
        const payload = {
            event: "setGlobalSettings",
            context: pluginUUID,
            payload: globalSettings
        };
        websocket.send(JSON.stringify(payload));
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // View Type change handler
    const viewTypeSelect = document.getElementById('viewType');
    if (viewTypeSelect) {
        viewTypeSelect.addEventListener('change', function() {
            globalSettings.viewType = this.value;
            updateSettings();
        });
    }

    // Items Per Page change handler
    const itemsPerPageInput = document.getElementById('itemsPerPage');
    if (itemsPerPageInput) {
        itemsPerPageInput.addEventListener('change', function() {
            const value = parseInt(this.value);
            if (value >= 1 && value <= 15) {
                globalSettings.itemsPerPage = value;
                updateSettings();
            } else {
                this.value = globalSettings.itemsPerPage || 5;
            }
        });
    }

    // Show All Containers change handler
    const showAllContainersCheckbox = document.getElementById('showAllContainers');
    if (showAllContainersCheckbox) {
        showAllContainersCheckbox.addEventListener('change', function() {
            globalSettings.showAllContainers = this.checked;
            updateSettings();
        });
    }
}); 