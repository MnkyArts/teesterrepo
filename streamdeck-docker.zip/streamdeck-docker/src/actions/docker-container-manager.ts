import streamDeck, {
    action,
    WillAppearEvent,
    KeyDownEvent,
    SingletonAction,
    JsonObject,
    KeyAction,
} from "@elgato/streamdeck";
import { Docker } from "node-docker-api";

import { CONTAINER_STATUS_RUNNING } from "../constants/docker";
import { ContainerData, getContainersList, startContainer, stopContainer, restartContainer } from "../utils/containerOperations";

// Define settings interface that extends JsonObject to satisfy the constraint
interface ContainerManagerSettings extends JsonObject {
    currentPage: number;
    selectedContainerId?: string;
    viewMode: 'containers' | 'images' | 'container_images';
    [key: string]: any; // Add index signature to satisfy JsonObject constraint
}

const BUTTONS_PER_PAGE = 12; // 4x3 grid leaving room for navigation
const TOTAL_BUTTONS = 15; // 5x3 grid

@action({ UUID: "com.darkdragon14.elgato-docker.container-manager" })
export class DockerContainerManager extends SingletonAction<ContainerManagerSettings> {
    private containers: ContainerData[] = [];
    private docker: Docker;
    private updateInterval: NodeJS.Timeout | undefined;
    private currentButtonIndex: number = 0;
    private logger = streamDeck.logger.createScope("DockerContainerManager");

    constructor(docker: Docker) {
        super();
        this.docker = docker;
        this.logger.info("DockerContainerManager constructor called");
    }

    override async onWillAppear(ev: WillAppearEvent<ContainerManagerSettings>): Promise<void> {
        this.logger.info("onWillAppear called");
        try {
            // Initialize settings with defaults if not present
            const settings = await ev.action.getSettings() || {
                currentPage: 0,
                viewMode: 'containers',
                selectedContainerId: undefined
            };
            
            this.logger.info(`Initial settings: ${JSON.stringify(settings)}`);
            
            // Save settings to ensure they're available
            await ev.action.setSettings(settings);
            
            // Update containers list
            await this.updateContainersList();
            
            // Update this specific button
            if (ev.action.isKey()) {
                const coordinates = ev.action.coordinates;
                if (coordinates) {
                    const buttonIndex = coordinates.row * 5 + coordinates.column;
                    this.logger.info(`Button coordinates: row=${coordinates.row}, column=${coordinates.column}, index=${buttonIndex}`);
                    await this.updateSingleButton(ev.action, settings, buttonIndex);
                } else {
                    this.logger.error("No coordinates available for button");
                }
            }
            
            // Set up update interval
            if (this.updateInterval) {
                clearInterval(this.updateInterval);
            }
            
            // Store the action for use in the interval
            const action = ev.action;
            
            this.updateInterval = setInterval(async () => {
                this.logger.debug("Update interval triggered");
                await this.updateContainersList();
                
                // Get the current settings
                const currentSettings = await action.getSettings() as ContainerManagerSettings;
                this.logger.info(`Current settings in interval: ${JSON.stringify(currentSettings)}`);
                
                // Ensure settings have default values if they're undefined
                if (currentSettings.viewMode === undefined) {
                    currentSettings.viewMode = 'containers';
                }
                if (currentSettings.currentPage === undefined) {
                    currentSettings.currentPage = 0;
                }
                
                // Save the updated settings
                await action.setSettings(currentSettings);
                
                if (action.isKey()) {
                    const coordinates = action.coordinates;
                    if (coordinates) {
                        const buttonIndex = coordinates.row * 5 + coordinates.column;
                        await this.updateSingleButton(action, currentSettings, buttonIndex);
                    }
                }
            }, 5000);
        } catch (error) {
            this.logger.error(`Error in onWillAppear: ${error}`);
        }
    }

    override async onWillDisappear(): Promise<void> {
        this.logger.info("onWillDisappear called");
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
            this.logger.info("Update interval cleared");
        }
    }

    override async onKeyDown(ev: KeyDownEvent<ContainerManagerSettings>): Promise<void> {
        this.logger.info("onKeyDown called");
        try {
            const settings = await ev.action.getSettings() as ContainerManagerSettings;
            this.logger.info(`Current settings in onKeyDown: ${JSON.stringify(settings)}`);
            
            // Ensure settings have default values if they're undefined
            if (settings.viewMode === undefined) {
                settings.viewMode = 'containers';
            }
            if (settings.currentPage === undefined) {
                settings.currentPage = 0;
            }
            
            // Save the updated settings to ensure they're available for future updates
            await ev.action.setSettings(settings);
            
            // Since we don't have direct access to button coordinates or identifiers,
            // we'll use a simple approach: increment the button index on each key press
            this.currentButtonIndex = (this.currentButtonIndex + 1) % TOTAL_BUTTONS;
            this.logger.info(`Button index incremented to: ${this.currentButtonIndex}`);
            
            if (settings.viewMode === 'containers') {
                this.logger.info("Handling container button press");
                await this.handleContainerButtonPress(ev, this.currentButtonIndex);
            } else {
                this.logger.info("Handling image button press");
                await this.handleImageButtonPress(ev, this.currentButtonIndex);
            }
        } catch (error) {
            this.logger.error(`Error in onKeyDown: ${error}`);
        }
    }

    private async handleContainerButtonPress(ev: KeyDownEvent<ContainerManagerSettings>, buttonIndex: number): Promise<void> {
        this.logger.info(`handleContainerButtonPress called with buttonIndex: ${buttonIndex}`);
        try {
            const settings = await ev.action.getSettings() as ContainerManagerSettings;
            const startIndex = settings.currentPage * BUTTONS_PER_PAGE;
            this.logger.info(`startIndex: ${startIndex}, buttonIndex: ${buttonIndex}, total containers: ${this.containers.length}`);
            
            // Get unique container groups (e.g., easyrma5, aqua_terra_cms_wnm_systems)
            const containerGroups = this.getContainerGroups();
            this.logger.info(`Container groups: ${JSON.stringify(containerGroups)}`);
            
            const containerGroup = containerGroups[startIndex + buttonIndex];
            this.logger.info(`Container group at index ${startIndex + buttonIndex}: ${containerGroup ? containerGroup.name : "none"}`);

            if (containerGroup) {
                this.logger.info(`Selected container group: ${containerGroup.name}`);
                settings.selectedContainerId = containerGroup.id;
                settings.viewMode = 'images';
                settings.currentPage = 0;
                await ev.action.setSettings(settings);
                this.logger.info("Settings updated, updating buttons");
                await this.updateButtons(ev);
            } else if (buttonIndex >= 12) {
                // Handle navigation buttons
                this.logger.info(`Handling navigation button: ${buttonIndex}`);
                
                switch (buttonIndex) {
                    case 12: // Previous Page
                        if (settings.currentPage > 0) {
                            this.logger.info("Going to previous page");
                            settings.currentPage--;
                            await ev.action.setSettings(settings);
                            await this.updateButtons(ev);
                        } else {
                            this.logger.info("Already on first page");
                        }
                        break;
                    case 13: // Next Page
                        if ((settings.currentPage + 1) * BUTTONS_PER_PAGE < containerGroups.length) {
                            this.logger.info("Going to next page");
                            settings.currentPage++;
                            await ev.action.setSettings(settings);
                            await this.updateButtons(ev);
                        } else {
                            this.logger.info("Already on last page");
                        }
                        break;
                    case 14: // Back button (not used in containers view)
                        this.logger.info("Back button pressed in containers view");
                        break;
                }
            } else {
                this.logger.info("No container group at this index");
            }
        } catch (error) {
            this.logger.error(`Error in handleContainerButtonPress: ${error}`);
        }
    }

    private async handleImageButtonPress(ev: KeyDownEvent<ContainerManagerSettings>, buttonIndex: number): Promise<void> {
        this.logger.info(`handleImageButtonPress called with buttonIndex: ${buttonIndex}`);
        try {
            const settings = await ev.action.getSettings() as ContainerManagerSettings;
            this.logger.info(`Selected container ID: ${settings.selectedContainerId}`);
            
            if (!settings.selectedContainerId) {
                this.logger.info("No container ID selected, resetting to containers view");
                settings.viewMode = 'containers';
                settings.selectedContainerId = undefined;
                settings.currentPage = 0;
                await ev.action.setSettings(settings);
                await this.updateButtons(ev);
                return;
            }
            
            // Get containers in the selected group
            if (typeof settings.selectedContainerId !== 'string') {
                this.logger.error("No valid container ID selected");
                return;
            }
            const containersInGroup = this.getContainersInGroup(settings.selectedContainerId);
            this.logger.info(`Containers in group: ${JSON.stringify(containersInGroup)}`);
            
            const startIndex = settings.currentPage * BUTTONS_PER_PAGE;
            const container = containersInGroup[startIndex + buttonIndex];
            this.logger.info(`Container at index ${startIndex + buttonIndex}: ${container ? container.Names[0] : "none"}`);

            if (container) {
                this.logger.info(`Selected container: ${container.Names[0]} (${container.Id})`);
                
                // Handle container actions based on button index
                switch (buttonIndex) {
                    case 0: // Start button
                        if (container.State !== CONTAINER_STATUS_RUNNING) {
                            this.logger.info(`Starting container: ${container.Names[0]}`);
                            await startContainer(this.docker, container.Id);
                            await this.updateContainersList();
                            await this.updateButtons(ev);
                        } else {
                            this.logger.info(`Container ${container.Names[0]} is already running`);
                        }
                        break;
                    case 1: // Stop button
                        if (container.State === CONTAINER_STATUS_RUNNING) {
                            this.logger.info(`Stopping container: ${container.Names[0]}`);
                            await stopContainer(this.docker, container.Id);
                            await this.updateContainersList();
                            await this.updateButtons(ev);
                        } else {
                            this.logger.info(`Container ${container.Names[0]} is already stopped`);
                        }
                        break;
                    case 2: // Restart button
                        this.logger.info(`Restarting container: ${container.Names[0]}`);
                        await restartContainer(this.docker, container.Id);
                        await this.updateContainersList();
                        await this.updateButtons(ev);
                        break;
                    default:
                        this.logger.info(`Unhandled button index: ${buttonIndex}`);
                }
            } else if (buttonIndex >= 12) {
                // Handle navigation buttons
                this.logger.info(`Handling navigation button: ${buttonIndex}`);
                
                switch (buttonIndex) {
                    case 12: // Previous Page
                        if (settings.currentPage > 0) {
                            this.logger.info("Going to previous page");
                            settings.currentPage--;
                            await ev.action.setSettings(settings);
                            await this.updateButtons(ev);
                        } else {
                            this.logger.info("Already on first page");
                        }
                        break;
                    case 13: // Next Page
                        if ((settings.currentPage + 1) * BUTTONS_PER_PAGE < containersInGroup.length) {
                            this.logger.info("Going to next page");
                            settings.currentPage++;
                            await ev.action.setSettings(settings);
                            await this.updateButtons(ev);
                        } else {
                            this.logger.info("Already on last page");
                        }
                        break;
                    case 14: // Back button
                        this.logger.info("Going back to containers view");
                        settings.viewMode = 'containers';
                        settings.selectedContainerId = undefined;
                        settings.currentPage = 0;
                        await ev.action.setSettings(settings);
                        await this.updateButtons(ev);
                        break;
                }
            } else {
                this.logger.info("No container at this index");
            }
        } catch (error) {
            this.logger.error(`Error in handleImageButtonPress: ${error}`);
        }
    }

    private async updateContainersList(): Promise<void> {
        this.logger.info("updateContainersList called");
        try {
            this.containers = await getContainersList(this.docker);
            this.logger.info(`Updated containers list, found ${this.containers.length} containers`);
        } catch (error) {
            this.logger.error(`Error in updateContainersList: ${error}`);
        }
    }

    private async updateSingleButton(action: KeyAction, settings: ContainerManagerSettings, buttonIndex: number): Promise<void> {
        this.logger.info(`Updating button ${buttonIndex} with settings: ${JSON.stringify(settings)}`);
        
        try {
            // Clear current button state
            await action.setTitle("");
            await action.setImage("imgs/actions/docker-stopped/key");
            
            // Ensure settings have default values if they're undefined
            if (settings.viewMode === undefined) {
                settings.viewMode = 'containers';
            }
            if (settings.currentPage === undefined) {
                settings.currentPage = 0;
            }
            
            const startIndex = settings.currentPage * BUTTONS_PER_PAGE;
            this.logger.info(`Start index: ${startIndex}, buttonIndex: ${buttonIndex}, total containers: ${this.containers.length}`);
            
            if (settings.viewMode === 'containers') {
                // Get unique container groups (e.g., easyrma5, aqua_terra_cms_wnm_systems)
                const containerGroups = this.getContainerGroups();
                
                if (buttonIndex < BUTTONS_PER_PAGE) {
                    const containerGroup = containerGroups[startIndex + buttonIndex];
                    if (containerGroup) {
                        await action.setTitle(containerGroup.name);
                        await action.setImage("imgs/actions/docker-stopped/key");
                    }
                } else {
                    // Navigation buttons
                    switch (buttonIndex) {
                        case 12: // Previous Page
                            if (settings.currentPage > 0) {
                                await action.setTitle("← Prev");
                                await action.setImage("imgs/actions/docker-stopped/key");
                            }
                            break;
                        case 13: // Next Page
                            if ((settings.currentPage + 1) * BUTTONS_PER_PAGE < containerGroups.length) {
                                await action.setTitle("Next →");
                                await action.setImage("imgs/actions/docker-stopped/key");
                            }
                            break;
                        case 14: // Back button (not used in containers view)
                            await action.setTitle("");
                            await action.setImage("imgs/actions/docker-stopped/key");
                            break;
                    }
                }
            } else if (settings.viewMode === 'container_images') {
                // Get images for the selected container
                if (typeof settings.selectedContainerId !== 'string') {
                    this.logger.error("No valid container ID selected");
                    return;
                }
                
                const container = this.containers.find(c => c.Id === settings.selectedContainerId);
                if (!container) {
                    this.logger.error("Selected container not found");
                    return;
                }
                
                // Get all images for this container
                const images = await this.getContainerImages(container.Id);
                
                if (buttonIndex < BUTTONS_PER_PAGE) {
                    const image = images[startIndex + buttonIndex];
                    if (image) {
                        await action.setTitle(image.RepoTags ? image.RepoTags[0] : image.Id.substring(0, 12));
                        await action.setImage("imgs/actions/docker-stopped/key");
                    }
                } else {
                    // Navigation buttons
                    switch (buttonIndex) {
                        case 12: // Previous Page
                            if (settings.currentPage > 0) {
                                await action.setTitle("← Prev");
                                await action.setImage("imgs/actions/docker-stopped/key");
                            }
                            break;
                        case 13: // Next Page
                            if ((settings.currentPage + 1) * BUTTONS_PER_PAGE < images.length) {
                                await action.setTitle("Next →");
                                await action.setImage("imgs/actions/docker-stopped/key");
                            }
                            break;
                        case 14: // Back button
                            await action.setTitle("Back");
                            await action.setImage("imgs/actions/docker-stopped/key");
                            break;
                    }
                }
            } else {
                // Get containers in the selected group
                if (typeof settings.selectedContainerId !== 'string') {
                    this.logger.error("No valid container ID selected");
                    return;
                }
                const containersInGroup = this.getContainersInGroup(settings.selectedContainerId);
                
                if (buttonIndex < BUTTONS_PER_PAGE) {
                    const container = containersInGroup[startIndex + buttonIndex];
                    if (container) {
                        const name = container.Names[0].split('_').slice(1).join('_'); // Remove the group prefix
                        await action.setTitle(name);
                        await action.setImage(
                            container.State === CONTAINER_STATUS_RUNNING 
                                ? "imgs/actions/docker-running/key"
                                : "imgs/actions/docker-stopped/key"
                        );
                    }
                } else {
                    // Navigation buttons
                    switch (buttonIndex) {
                        case 12: // Previous Page
                            if (settings.currentPage > 0) {
                                await action.setTitle("← Prev");
                                await action.setImage("imgs/actions/docker-stopped/key");
                            }
                            break;
                        case 13: // Next Page
                            if ((settings.currentPage + 1) * BUTTONS_PER_PAGE < containersInGroup.length) {
                                await action.setTitle("Next →");
                                await action.setImage("imgs/actions/docker-stopped/key");
                            }
                            break;
                        case 14: // Back button
                            await action.setTitle("Back");
                            await action.setImage("imgs/actions/docker-stopped/key");
                            break;
                    }
                }
            }
        } catch (error) {
            this.logger.error(`Error updating button ${buttonIndex}: ${error}`);
        }
    }

    private async updateButtons(ev: WillAppearEvent<ContainerManagerSettings> | KeyDownEvent<ContainerManagerSettings>): Promise<void> {
        this.logger.info("updateButtons called");
        try {
            // Get settings from the action
            const settings = await ev.action.getSettings() as ContainerManagerSettings;
            this.logger.info(`Current settings: ${JSON.stringify(settings)}`);
            
            if (!settings) {
                this.logger.error("No settings available");
                return;
            }
            
            // Ensure settings have default values if they're undefined
            if (settings.viewMode === undefined) {
                settings.viewMode = 'containers';
            }
            if (settings.currentPage === undefined) {
                settings.currentPage = 0;
            }
            
            // Save the updated settings to ensure they're available for future updates
            await ev.action.setSettings(settings);
            
            // Log the current view mode and page
            this.logger.info(`Current view mode: ${settings.viewMode}, page: ${settings.currentPage}`);
            
            // Only update if we have a key action with coordinates
            if (ev.action.isKey()) {
                const coordinates = ev.action.coordinates;
                if (coordinates) {
                    const buttonIndex = coordinates.row * 5 + coordinates.column;
                    await this.updateSingleButton(ev.action, settings, buttonIndex);
                } else {
                    this.logger.error("No coordinates available for button");
                }
            }
        } catch (error) {
            this.logger.error(`Error in updateButtons: ${error}`);
        }
    }

    // Helper method to get unique container groups (e.g., easyrma5, aqua_terra_cms_wnm_systems)
    private getContainerGroups(): { name: string, id: string }[] {
        const groups = new Map<string, string>();
        
        for (const container of this.containers) {
            const name = container.Names[0].slice(1); // Remove leading slash
            const groupName = name.split('_')[0]; // Get the group name (e.g., easyrma5)
            
            if (!groups.has(groupName)) {
                groups.set(groupName, container.Id);
            }
        }
        
        return Array.from(groups.entries()).map(([name, id]) => ({ name, id }));
    }

    // Helper method to get containers in a specific group
    private getContainersInGroup(groupId: string): ContainerData[] {
        const container = this.containers.find(c => c.Id === groupId);
        if (!container || !container.Names || container.Names.length === 0) {
            return [];
        }
        
        const name = container.Names[0].slice(1); // Remove leading slash
        const groupName = name.split('_')[0]; // Get the group name (e.g., easyrma5)
        
        return this.containers.filter(c => {
            if (!c.Names || c.Names.length === 0) return false;
            const containerName = c.Names[0].slice(1);
            return containerName.startsWith(`${groupName}_`);
        });
    }

    private async getContainerImages(containerId: string): Promise<any[]> {
        try {
            // Get the container to find its image
            const container = this.containers.find(c => c.Id === containerId);
            if (!container || !container.Image) {
                this.logger.error(`Container ${containerId} not found or has no image`);
                return [];
            }
            
            // Get all images
            const images = await this.docker.image.list();
            
            // Filter images related to this container
            return images.filter(image => {
                // Check if this image is the one used by the container
                if (image.Id === container.Image) {
                    return true;
                }
                
                // Check if this image is a parent of the container's image
                if (image.RepoTags && image.RepoTags.some(tag => tag.includes(container.Image))) {
                    return true;
                }
                
                return false;
            });
        } catch (error) {
            this.logger.error(`Error getting container images: ${error}`);
            return [];
        }
    }
} 