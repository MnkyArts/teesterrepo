export const DOCKER_START_ERROR_STATE = 2;
export const CONTAINER_COUNT_ERROR_STATE = 1;

export const CONTAINER_LIST_ALL_STATUS = "all";
export const CONTAINER_STATUS_RUNNING = "running";

export const DOCKER_NOT_RUNNING_TITLE = "Please, launch Docker";
export const DOCKER_NOT_RUNNING_TITLE_FOR_DIALS = "Launch Docker";
