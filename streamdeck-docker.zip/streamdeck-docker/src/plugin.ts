import streamDeck, { LogLevel } from "@elgato/streamdeck";
import { Docker } from "node-docker-api";
import * as os from "os";

import { ContainersCount } from "./actions/containers-count";
import { DockerRunOrRm } from "./actions/docker-run-or-rm";
import { DockerSelectToggle } from "./actions/docker-select-toggle";
import { DockerStart } from "./actions/docker-start";
import { DockerContainerManager } from "./actions/docker-container-manager";

// Create a scoped logger for the plugin
const logger = streamDeck.logger.createScope("DockerPlugin");

logger.info("Plugin initialization started");

const socketPath = os.platform() === "win32" ? "//./pipe/docker_engine" : "/var/run/docker.sock";
logger.info(`Using Docker socket path: ${socketPath}`);

const docker = new Docker({ socketPath });
logger.info("Docker instance created");

// We can enable "trace" logging so that all messages between the Stream Deck, and the plugin are recorded. When storing sensitive information
streamDeck.logger.setLevel(LogLevel.TRACE);
logger.info("StreamDeck logger level set to TRACE");

// Register the increment action.
logger.info("Registering actions...");
streamDeck.actions.registerAction(new DockerRunOrRm(docker));
logger.info("DockerRunOrRm action registered");

streamDeck.actions.registerAction(new DockerStart(docker));
logger.info("DockerStart action registered");

streamDeck.actions.registerAction(new ContainersCount(docker));
logger.info("ContainersCount action registered");

streamDeck.actions.registerAction(new DockerSelectToggle(docker));
logger.info("DockerSelectToggle action registered");

const containerManager = new DockerContainerManager(docker);
logger.info("DockerContainerManager instance created");
streamDeck.actions.registerAction(containerManager);
logger.info("DockerContainerManager action registered");

// Finally, connect to the Stream Deck.
logger.info("Connecting to Stream Deck...");
streamDeck.logger.info("Hello world");
streamDeck.logger.debug("Debugging information");
streamDeck.logger.trace("Detailed messages");
streamDeck.connect();
logger.info("Connected to Stream Deck");
