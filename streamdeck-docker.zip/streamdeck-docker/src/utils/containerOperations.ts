import { Docker } from "node-docker-api";
import { CONTAINER_STATUS_RUNNING } from "../constants/docker";

export interface ContainerData {
    Id: string;
    Names: string[];
    State: string;
    Image: string;
}

export async function getContainerStatus(docker: Docker, containerId: string): Promise<boolean> {
    try {
        const container = await docker.container.get(containerId);
        const data = await container.data;
        return (data as any).State === CONTAINER_STATUS_RUNNING;
    } catch (error) {
        console.error("Failed to get container status:", error);
        return false;
    }
}

export async function startContainer(docker: Docker, containerId: string): Promise<boolean> {
    try {
        const container = await docker.container.get(containerId);
        await container.start();
        return true;
    } catch (error) {
        console.error("Failed to start container:", error);
        return false;
    }
}

export async function stopContainer(docker: Docker, containerId: string): Promise<boolean> {
    try {
        const container = await docker.container.get(containerId);
        await container.stop();
        return true;
    } catch (error) {
        console.error("Failed to stop container:", error);
        return false;
    }
}

export async function restartContainer(docker: Docker, containerId: string): Promise<boolean> {
    try {
        const container = await docker.container.get(containerId);
        await container.restart();
        return true;
    } catch (error) {
        console.error("Failed to restart container:", error);
        return false;
    }
}

export async function getContainersList(docker: Docker): Promise<ContainerData[]> {
    try {
        const containers = await docker.container.list({ all: true });
        return containers.map((c: any) => c.data as ContainerData);
    } catch (error) {
        console.error("Failed to get containers list:", error);
        return [];
    }
} 