<template>
  <div class="space-y-3">
    <div
      v-for="activity in displayActivities"
      :key="activity.id"
      class="flex items-start space-x-3"
    >
      <div class="flex-shrink-0">
        <div
          class="w-8 h-8 rounded-full flex items-center justify-center"
          :class="activityTypeColor(activity.action)"
        >
          <component :is="getActivityIcon(activity.action)" class="h-4 w-4" />
        </div>
      </div>
      
      <div class="flex-1 min-w-0">
        <p class="text-sm text-gray-900 dark:text-white">
          <span class="font-medium">{{ getUserName(activity) }}</span>
          {{ activity.description }}
        </p>
        <div class="mt-1 flex items-center space-x-2 text-xs text-gray-500 dark:text-gray-400">
          <span v-if="activity.project">{{ activity.project.name }}</span>
          <span v-if="activity.project">•</span>
          <span>{{ formatRelativeTime(activity.createdAt) }}</span>
        </div>
      </div>
    </div>

    <div v-if="activities.length === 0" class="text-center py-8">
      <ClockIcon class="mx-auto h-12 w-12 text-gray-400" />
      <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
        Keine Aktivitäten verfügbar
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import {
  CheckCircleIcon,
  ChatBubbleLeftIcon,
  PlusIcon,
  ClockIcon,
  PaperClipIcon
} from '@heroicons/vue/24/outline'

interface Activity {
  id: string
  action: string // z.B. "task_created", "status_changed"
  description: string
  createdAt: string | Date
  type?: string // for compatibility
  message?: string // for compatibility
  timestamp?: string | Date // for compatibility
  user: {
    id: string
    firstName: string
    lastName: string
    image?: string | null
  }
  project?: {
    id: string
    name: string
    key: string
  } | null
  task?: {
    id: string
    title: string
    key: string
  } | null
}

interface Props {
  activities: Activity[]
  maxItems?: number
}

const props = withDefaults(defineProps<Props>(), {
  maxItems: 5
})

const displayActivities = computed(() => 
  props.activities.slice(0, props.maxItems)
)

const getUserName = (activity: Activity) => {
  return `${activity.user.firstName} ${activity.user.lastName}`
}

const getActivityIcon = (action: string) => {
  const icons = {
    task_completed: CheckCircleIcon,
    task_created: PlusIcon,
    task_updated: ClockIcon,
    task_status_changed: ClockIcon,
    comment_added: ChatBubbleLeftIcon,
    status_changed: ClockIcon,
    project_created: PlusIcon,
    user_created: PlusIcon,
    TASK_UPDATED: ClockIcon,
    TASK_CREATED: PlusIcon,
    TASK_COMPLETED: CheckCircleIcon,
    ATTACHMENT_ADDED: PaperClipIcon,
    PROJECT_CREATED: PlusIcon
  }
  return icons[action as keyof typeof icons] || ClockIcon
}

const activityTypeColor = (action: string) => {
  const colors = {
    task_completed: 'bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-400',
    task_created: 'bg-purple-100 text-purple-600 dark:bg-purple-900 dark:text-purple-400',
    task_updated: 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900 dark:text-indigo-400',
    task_status_changed: 'bg-yellow-100 text-yellow-600 dark:bg-yellow-900 dark:text-yellow-400',
    comment_added: 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-400',
    status_changed: 'bg-yellow-100 text-yellow-600 dark:bg-yellow-900 dark:text-yellow-400',
    project_created: 'bg-purple-100 text-purple-600 dark:bg-purple-900 dark:text-purple-400',
    user_created: 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400',
    TASK_UPDATED: 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900 dark:text-indigo-400',
    TASK_CREATED: 'bg-purple-100 text-purple-600 dark:bg-purple-900 dark:text-purple-400',
    TASK_COMPLETED: 'bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-400',
    ATTACHMENT_ADDED: 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-400',
    PROJECT_CREATED: 'bg-purple-100 text-purple-600 dark:bg-purple-900 dark:text-purple-400'
  }
  return colors[action as keyof typeof colors] || 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400'
}

const formatRelativeTime = (date: string | Date) => {
  try {
    const now = new Date()
    const activityDate = new Date(date)
    
    // Check if date is valid
    if (isNaN(activityDate.getTime())) {
      return 'Unbekanntes Datum'
    }
    
    const diff = now.getTime() - activityDate.getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(diff / 3600000)
    const days = Math.floor(diff / 86400000)

    if (minutes < 1) return 'gerade eben'
    if (minutes < 60) return `vor ${minutes} Min`
    if (hours < 24) return `vor ${hours} Std`
    if (days < 7) return `vor ${days} Tag${days > 1 ? 'en' : ''}`
    
    return activityDate.toLocaleDateString('de-DE', {
      day: 'numeric',
      month: 'short'
    })
  } catch (error) {
    console.error('Error formatting date:', error, date)
    return 'Unbekanntes Datum'
  }
}
</script>
