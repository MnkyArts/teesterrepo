<template>
  <div class="card">
    <div class="p-6 border-b border-gray-200 dark:border-gray-700">
      <div class="flex items-center justify-between">
        <div class="flex items-center">
          <component :is="iconComponent" class="h-5 w-5 text-gray-400 mr-2" />
          <h3 class="text-lg font-medium text-gray-900 dark:text-white">
            {{ title }}
          </h3>
        </div>
        <NuxtLink
          v-if="action"
          :to="action.href"
          class="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400"
        >
          {{ action.label }}
        </NuxtLink>
      </div>
    </div>
    
    <div class="p-6">
      <slot />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import {
  ClipboardDocumentListIcon,
  FolderIcon,
  ClockIcon,
  PlayIcon,
  UsersIcon
} from '@heroicons/vue/24/outline'

interface Props {
  title: string
  icon: string
  action?: {
    label: string
    href: string
  }
}

const props = defineProps<Props>()

// Icon mapping
const iconMap = {
  ClipboardDocumentListIcon,
  FolderIcon,
  ClockIcon,
  PlayIcon,
  UsersIcon
}

const iconComponent = computed(() => iconMap[props.icon as keyof typeof iconMap])
</script>
