import { authClient } from "~/lib/auth-client";

export default defineNuxtRouteMiddleware(async (to, from) => {
	const { data: session } = await authClient.useSession(useFetch);
	
	// If no session, redirect to login for protected routes
	if (!session.value) {
		if (to.path === "/" || to.path === "/customer") {
			return navigateTo("/auth/login");
		}
		return; // Allow access to other routes (like /auth/login) when not authenticated
	}

	const user = session.value.user;
	const userRole = user.role;
	
	// Role-based route protection
	if (userRole === "customer") {
		// Customers can only access /customer/* routes
		if (!to.path.startsWith("/customer")) {
			return navigateTo("/customer");
		}
	} else if (userRole === "admin") {
		// Staff can access any route except /customer/*
		if (to.path.startsWith("/customer")) {
			return navigateTo("/"); // Redirect staff away from customer routes
		}
	}
	
	// If user has an unknown/broken role, redirect to login
	if (userRole !== "user" && userRole !== "admin") {
		return navigateTo("/auth/login");
	}
});