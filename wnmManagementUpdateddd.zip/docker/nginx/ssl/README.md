# SSL Certificate Setup

This directory is for SSL certificates when running the nginx container in production with HTTPS.

## Development Setup (No SSL)

For development, the nginx configuration is set up to work without SSL certificates. The HTTP server on port 80 will proxy directly to the Nuxt.js application.

## Production Setup (With SSL)

For production deployment with SSL certificates, you have several options:

### Option 1: Let's Encrypt with Certbot

1. **Generate certificates using certbot:**
   ```bash
   # Install certbot
   sudo apt-get update
   sudo apt-get install certbot
   
   # Generate certificates (replace your-domain.com with your actual domain)
   sudo certbot certonly --standalone -d your-domain.com -d www.your-domain.com
   
   # Copy certificates to this directory
   sudo cp /etc/letsencrypt/live/your-domain.com/fullchain.pem ./cert.pem
   sudo cp /etc/letsencrypt/live/your-domain.com/privkey.pem ./key.pem
   ```

2. **Set proper permissions:**
   ```bash
   sudo chown root:root cert.pem key.pem
   sudo chmod 644 cert.pem
   sudo chmod 600 key.pem
   ```

3. **Uncomment the HTTPS server block in nginx.conf and update the domain name**

### Option 2: Custom SSL Certificates

If you have your own SSL certificates:

1. **Copy your certificates to this directory:**
   ```bash
   # Copy your certificate file
   cp /path/to/your/certificate.crt ./cert.pem
   
   # Copy your private key
   cp /path/to/your/private.key ./key.pem
   ```

2. **Set proper permissions:**
   ```bash
   sudo chown root:root cert.pem key.pem
   sudo chmod 644 cert.pem
   sudo chmod 600 key.pem
   ```

3. **Uncomment the HTTPS server block in nginx.conf and update the domain name**

### Option 3: Self-Signed Certificates (Development/Testing Only)

For development or testing purposes, you can create self-signed certificates:

```bash
# Generate self-signed certificate
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout key.pem \
    -out cert.pem \
    -subj "/C=DE/ST=State/L=City/O=Organization/CN=localhost"

# Set permissions
chmod 644 cert.pem
chmod 600 key.pem
```

**Note:** Self-signed certificates will show security warnings in browsers and should not be used in production.

## Required Files

When using SSL, make sure these files exist in this directory:

- `cert.pem` - The SSL certificate file
- `key.pem` - The private key file

## Nginx Configuration

After setting up SSL certificates:

1. Edit `docker/nginx/nginx.conf`
2. Uncomment the HTTPS server block (lines starting with `# server {`)
3. Update the `server_name` directive with your actual domain name
4. Uncomment the HTTP to HTTPS redirect line if desired

## Security Best Practices

- Keep private keys secure and never commit them to version control
- Use strong encryption (RSA 2048-bit or higher)
- Regularly renew certificates (Let's Encrypt certificates expire every 90 days)
- Monitor certificate expiration dates
- Use HSTS headers for additional security

## Troubleshooting

### Certificate Permission Issues
```bash
# Check file permissions
ls -la docker/nginx/ssl/

# Fix permissions if needed
sudo chown root:root docker/nginx/ssl/*.pem
sudo chmod 644 docker/nginx/ssl/cert.pem
sudo chmod 600 docker/nginx/ssl/key.pem
```

### Certificate Validation
```bash
# Check certificate validity
openssl x509 -in docker/nginx/ssl/cert.pem -text -noout

# Check if certificate and key match
openssl x509 -noout -modulus -in docker/nginx/ssl/cert.pem | openssl md5
openssl rsa -noout -modulus -in docker/nginx/ssl/key.pem | openssl md5
```

### Nginx Configuration Test
```bash
# Test nginx configuration
docker run --rm -v $(pwd)/docker/nginx/nginx.conf:/etc/nginx/nginx.conf:ro nginx:alpine nginx -t
``` 