<template>
  <div class="min-h-screen bg-gray-50 dark:bg-gray-900">
    <!-- Customer Center Header -->
    <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 w-full">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-16">
          <!-- Logo and Navigation -->
          <div class="flex items-center space-x-8">
            <div class="flex-shrink-0">
              <h1 class="text-xl font-bold text-gray-900 dark:text-white">
                {{ $t('customerCenter.title') }}
              </h1>
            </div>
            <nav class="hidden md:flex space-x-8">
              <NuxtLink
                to="/customer"
                class="text-gray-600 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400 px-3 py-2 text-sm font-medium transition-colors"
                :class="{ 'text-blue-600 dark:text-blue-400': $route.path === '/customer' }"
              >
                {{ $t('navigation.dashboard') }}
              </NuxtLink>
              <NuxtLink
                to="/customer/tickets"
                class="text-gray-600 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400 px-3 py-2 text-sm font-medium transition-colors"
                :class="{ 'text-blue-600 dark:text-blue-400': $route.path.startsWith('/customer/tickets') }"
              >
                {{ $t('navigation.tickets') }}
              </NuxtLink>
              <NuxtLink
                to="/customer/invoices"
                class="text-gray-600 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400 px-3 py-2 text-sm font-medium transition-colors"
                :class="{ 'text-blue-600 dark:text-blue-400': $route.path.startsWith('/customer/invoices') }"
              >
                {{ $t('navigation.invoices') }}
              </NuxtLink>
              <NuxtLink
                to="/customer/payments"
                class="text-gray-600 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400 px-3 py-2 text-sm font-medium transition-colors"
                :class="{ 'text-blue-600 dark:text-blue-400': $route.path.startsWith('/customer/payments') }"
              >
                {{ $t('navigation.payments') }}
              </NuxtLink>
              <NuxtLink
                to="/customer/profile"
                class="text-gray-600 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400 px-3 py-2 text-sm font-medium transition-colors"
                :class="{ 'text-blue-600 dark:text-blue-400': $route.path.startsWith('/customer/profile') }"
              >
                {{ $t('navigation.profile') }}
              </NuxtLink>
            </nav>
          </div>

          <!-- User Menu and Theme Toggle -->
          <div class="flex items-center space-x-4">
            <ColorModeToggle />
            
            <!-- Customer Menu -->
            <div class="relative">
              <button
                @click="showUserMenu = !showUserMenu"
                class="flex items-center space-x-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
              >
                <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                  <span class="text-white text-sm font-medium">
                    {{ customerInitials }}
                  </span>
                </div>
                <span class="hidden md:block text-sm font-medium">{{ customerName }}</span>
                <Icon name="heroicons:chevron-down" class="w-4 h-4" />
              </button>

              <!-- User Dropdown -->
              <div
                v-if="showUserMenu"
                class="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg py-1 z-50 border border-gray-200 dark:border-gray-700"
                @click.outside="showUserMenu = false"
              >
                <NuxtLink
                  to="/customer/profile"
                  class="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                  @click="showUserMenu = false"
                >
                  {{ $t('userMenu.profile') }}
                </NuxtLink>
                <NuxtLink
                  to="/customer/payments"
                  class="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                  @click="showUserMenu = false"
                >
                  {{ $t('userMenu.paymentMethod') }}
                </NuxtLink>
                <hr class="my-1 border-gray-200 dark:border-gray-700">
                <button
                  @click="logout"
                  class="block w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  {{ $t('auth.logout') }}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Mobile Navigation -->
      <div class="md:hidden">
        <div class="px-2 pt-2 pb-3 space-y-1 sm:px-3 border-t border-gray-200 dark:border-gray-700">
          <NuxtLink
            to="/customer"
            class="block px-3 py-2 text-base font-medium text-gray-600 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400"
            :class="{ 'text-blue-600 dark:text-blue-400': $route.path === '/customer' }"
          >
            {{ $t('navigation.dashboard') }}
          </NuxtLink>
          <NuxtLink
            to="/customer/tickets"
            class="block px-3 py-2 text-base font-medium text-gray-600 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400"
            :class="{ 'text-blue-600 dark:text-blue-400': $route.path.startsWith('/customer/tickets') }"
          >
            {{ $t('navigation.tickets') }}
          </NuxtLink>
          <NuxtLink
            to="/customer/invoices"
            class="block px-3 py-2 text-base font-medium text-gray-600 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400"
            :class="{ 'text-blue-600 dark:text-blue-400': $route.path.startsWith('/customer/invoices') }"
          >
            {{ $t('navigation.invoices') }}
          </NuxtLink>
          <NuxtLink
            to="/customer/payments"
            class="block px-3 py-2 text-base font-medium text-gray-600 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400"
            :class="{ 'text-blue-600 dark:text-blue-400': $route.path.startsWith('/customer/payments') }"
          >
            {{ $t('navigation.payments') }}
          </NuxtLink>
          <NuxtLink
            to="/customer/profile"
            class="block px-3 py-2 text-base font-medium text-gray-600 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400"
            :class="{ 'text-blue-600 dark:text-blue-400': $route.path.startsWith('/customer/profile') }"
          >
            {{ $t('navigation.profile') }}
          </NuxtLink>
        </div>
      </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <slot />
    </main>

    <!-- Footer -->
    <footer class="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 mt-auto">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div class="text-center text-sm text-gray-500 dark:text-gray-400">
          <p>&copy; {{ new Date().getFullYear() }} wnm - {{ $t('customerCenter.footer') }}</p>
        </div>
      </div>
    </footer>
  </div>
</template>

<script setup>
const authStore = useAuthStore()
const { user } = storeToRefs(authStore)
const { logout } = authStore
const showUserMenu = ref(false)

// Customer-spezifische Daten
const customerName = computed(() => {
  if (!user.value) return ''
  return `${user.value.firstName} ${user.value.lastName}`
})

const customerInitials = computed(() => {
  if (!user.value) return 'K'
  const firstName = user.value.firstName || ''
  const lastName = user.value.lastName || ''
  return (firstName.charAt(0) + lastName.charAt(0)).toUpperCase()
})

// Redirect to login if not authenticated as customer
onMounted(() => {
  if (!user.value || user.value.role !== 'KUNDE') {
    navigateTo('/auth/login')
  }
})
</script>
