import { PrismaClient } from '@prisma/client'
import { betterAuth } from "better-auth"
import { prismaAdapter } from "better-auth/adapters/prisma"

const prisma = new PrismaClient()

// TypeScript interfaces for better type safety
interface UserCreationData {
  name: string
  firstName: string
  lastName: string
  role: string
}

interface BetterAuthSignUpResponse {
  user?: {
    id: string
    email: string
    name: string
    firstName?: string
    lastName?: string
    role?: string
  } | null
  error?: {
    message: string
    code?: string
  }
}

// Initialize Better Auth with the same configuration as in lib/auth.ts
const auth = betterAuth({
  database: prismaAdapter(prisma, {
    provider: "postgresql",
  }),
  
  baseURL: process.env.BETTER_AUTH_URL || process.env.APP_URL || "http://localhost:3000",
  
  emailAndPassword: {
    enabled: true,
    autoSignIn: true,
  },
  
  session: {
    cookieCache: {
      enabled: true,
      maxAge: 60 * 60 * 24 * 7, // 7 days
    },
  },
  
  // Map existing User fields to Better Auth requirements
  user: {
    modelName: "user",
    fields: {
      email: "email",
      name: "name",
      image: "image"
    },
    additionalFields: {
      firstName: {
        type: "string",
        required: true,
      },
      lastName: {
        type: "string", 
        required: true,
      },
      role: {
        type: "string",
        required: true,
        defaultValue: "ENTWICKLER",
      },
      image: {
        type: "string",
        required: false,
      },
      isActive: {
        type: "boolean",
        required: true,
        defaultValue: true,
      },
      lastLoginAt: {
        type: "date",
        required: false,
      },
    },
  },
})

async function createUserWithAuth(email: string, password: string, userData: UserCreationData) {
  try {
    console.log(`👤 Creating user: ${email}`)
    
    // Check if user already exists
    const existingUser = await prisma.user.findUnique({ where: { email } })
    if (existingUser) {
      console.log(`   User ${email} already exists, skipping...`)
      return existingUser
    }

    // Create user with Better Auth
    const result = await auth.api.signUpEmail({
      body: {
        email,
        password,
        name: userData.name,
        firstName: userData.firstName,
        lastName: userData.lastName,
        role: userData.role
      }
    }) as BetterAuthSignUpResponse

    if (!result.user) {
      const errorMessage = result.error?.message || 'Unknown error occurred'
      throw new Error(`Failed to create user ${email}: ${errorMessage}`)
    }

    console.log(`   ✅ Created user: ${email}`)
    return await prisma.user.findUnique({ where: { email } })

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error'
    console.error(`   ❌ Failed to create ${email}:`, errorMessage)
    throw error
  }
}

async function main(): Promise<void> {
  console.log('🌱 Seeding database with Better Auth...')

  try {
    // Create users using Better Auth's native signup
    const admin = await createUserWithAuth('admin@wnm.de', 'AdminPassword123!', {
      name: 'System Administrator',
      firstName: 'System',
      lastName: 'Administrator',
      role: 'admin'
    })

    const manager = await createUserWithAuth('manager@wnm.de', 'ManagerPassword123!', {
      name: 'Max Mustermann',
      firstName: 'Max',
      lastName: 'Mustermann',
      role: 'projectlead'
    })

    const developer = await createUserWithAuth('dev@wnm.de', 'DevPassword123!', {
      name: 'Anna Schmidt',
      firstName: 'Anna',
      lastName: 'Schmidt',
      role: 'developer'
    })

    // Create demo customer user for testing customer portal
    const customerUser = await createUserWithAuth('kunde@demo.de', 'KundePassword123!', {
      name: 'Maria Beispiel',
      firstName: 'Maria',
      lastName: 'Beispiel',
      role: 'customer'
    })

    if (!admin || !manager || !developer || !customerUser) {
      throw new Error('Failed to create all required users')
    }

    // Update users to set email as verified and additional fields
    console.log('🔧 Updating user verification status...')
    await prisma.user.updateMany({
      where: {
        email: {
          in: ['admin@wnm.de', 'manager@wnm.de', 'dev@wnm.de', 'kunde@demo.de']
        }
      },
      data: {
        emailVerified: true,
        emailVerifiedAt: new Date(),
        isActive: true
      }
    })

    // Create enum categories and values
    console.log('🏷️ Creating enum categories and values...')
    
    // Task Type Category
    const taskTypeCategory = await prisma.enumCategory.upsert({
      where: { name: 'task_type' },
      update: {},
      create: {
        name: 'task_type',
        label: 'Aufgabentyp',
        description: 'Verschiedene Aufgabentypen',
        isSystem: true,
        sortOrder: 1
      }
    })

    // Priority Category
    const priorityCategory = await prisma.enumCategory.upsert({
      where: { name: 'priority' },
      update: {},
      create: {
        name: 'priority',
        label: 'Priorität',
        description: 'Aufgaben- und Ticket-Prioritäten',
        isSystem: true,
        sortOrder: 2
      }
    })

    // Task Status Category
    const taskStatusCategory = await prisma.enumCategory.upsert({
      where: { name: 'task_status' },
      update: {},
      create: {
        name: 'task_status',
        label: 'Task Status',
        description: 'Verschiedene Aufgabenstatus',
        isSystem: true,
        sortOrder: 3
      }
    })

    // Ticket Status Category
    const ticketStatusCategory = await prisma.enumCategory.upsert({
      where: { name: 'ticket_status' },
      update: {},
      create: {
        name: 'ticket_status',
        label: 'Ticket Status',
        description: 'Verschiedene Ticketstatus',
        isSystem: true,
        sortOrder: 4
      }
    })

    // Ticket Type Category
    const ticketTypeCategory = await prisma.enumCategory.upsert({
      where: { name: 'ticket_type' },
      update: {},
      create: {
        name: 'ticket_type',
        label: 'Ticket-Typ',
        description: 'Verschiedene Ticket-Typen',
        isSystem: true,
        sortOrder: 5
      }
    })

    // Create enum values for task types
    const taskTypeAufgabe = await prisma.enumValue.findFirst({
      where: { 
        categoryId: taskTypeCategory.id,
        key: 'AUFGABE',
        projectId: null
      }
    }) || await prisma.enumValue.create({
      data: {
        categoryId: taskTypeCategory.id,
        key: 'AUFGABE',
        label: 'Aufgabe',
        description: 'Allgemeine Aufgabe',
        color: '#3b82f6',
        icon: 'task',
        isDefault: true,
        sortOrder: 1
      }
    })

    const taskTypeFeature = await prisma.enumValue.findFirst({
      where: { 
        categoryId: taskTypeCategory.id,
        key: 'FEATURE',
        projectId: null
      }
    }) || await prisma.enumValue.create({
      data: {
        categoryId: taskTypeCategory.id,
        key: 'FEATURE',
        label: 'Feature',
        description: 'Neue Funktionalität',
        color: '#10b981',
        icon: 'plus',
        isDefault: false,
        sortOrder: 2
      }
    })

    const taskTypeBug = await prisma.enumValue.findFirst({
      where: { 
        categoryId: taskTypeCategory.id,
        key: 'BUG',
        projectId: null
      }
    }) || await prisma.enumValue.create({
      data: {
        categoryId: taskTypeCategory.id,
        key: 'BUG',
        label: 'Bug',
        description: 'Fehlerbehebung',
        color: '#ef4444',
        icon: 'bug',
        isDefault: false,
        sortOrder: 3
      }
    })

    // Create enum values for priorities
    const priorityNiedrig = await prisma.enumValue.findFirst({
      where: { 
        categoryId: priorityCategory.id,
        key: 'NIEDRIG',
        projectId: null
      }
    }) || await prisma.enumValue.create({
      data: {
        categoryId: priorityCategory.id,
        key: 'NIEDRIG',
        label: 'Niedrig',
        description: 'Niedrige Priorität',
        color: '#6b7280',
        icon: 'arrow-down',
        isDefault: false,
        sortOrder: 1
      }
    })

    const priorityMittel = await prisma.enumValue.findFirst({
      where: { 
        categoryId: priorityCategory.id,
        key: 'MITTEL',
        projectId: null
      }
    }) || await prisma.enumValue.create({
      data: {
        categoryId: priorityCategory.id,
        key: 'MITTEL',
        label: 'Mittel',
        description: 'Mittlere Priorität',
        color: '#f59e0b',
        icon: 'minus',
        isDefault: true,
        sortOrder: 2
      }
    })

    const priorityHoch = await prisma.enumValue.findFirst({
      where: { 
        categoryId: priorityCategory.id,
        key: 'HOCH',
        projectId: null
      }
    }) || await prisma.enumValue.create({
      data: {
        categoryId: priorityCategory.id,
        key: 'HOCH',
        label: 'Hoch',
        description: 'Hohe Priorität',
        color: '#ef4444',
        icon: 'arrow-up',
        isDefault: false,
        sortOrder: 3
      }
    })

    // Create enum values for task status
    const statusOffen = await prisma.enumValue.findFirst({
      where: { 
        categoryId: taskStatusCategory.id,
        key: 'OFFEN',
        projectId: null
      }
    }) || await prisma.enumValue.create({
      data: {
        categoryId: taskStatusCategory.id,
        key: 'OFFEN',
        label: 'Offen',
        description: 'Neue Aufgabe',
        color: '#6b7280',
        icon: 'circle',
        isDefault: true,
        sortOrder: 1
      }
    })

    const statusInBearbeitung = await prisma.enumValue.findFirst({
      where: { 
        categoryId: taskStatusCategory.id,
        key: 'IN_BEARBEITUNG',
        projectId: null
      }
    }) || await prisma.enumValue.create({
      data: {
        categoryId: taskStatusCategory.id,
        key: 'IN_BEARBEITUNG',
        label: 'In Bearbeitung',
        description: 'Wird gerade bearbeitet',
        color: '#3b82f6',
        icon: 'play',
        isDefault: false,
        sortOrder: 2
      }
    })

    const statusErledigt = await prisma.enumValue.findFirst({
      where: { 
        categoryId: taskStatusCategory.id,
        key: 'ERLEDIGT',
        projectId: null
      }
    }) || await prisma.enumValue.create({
      data: {
        categoryId: taskStatusCategory.id,
        key: 'ERLEDIGT',
        label: 'Erledigt',
        description: 'Aufgabe abgeschlossen',
        color: '#10b981',
        icon: 'check',
        isDefault: false,
        sortOrder: 3
      }
    })

    console.log('✅ Database seeded successfully with Better Auth!')
    console.log('')
    console.log('👤 Users created:')
    console.log('   - admin@wnm.de (ADMINISTRATOR) - Password: AdminPassword123!')
    console.log('   - manager@wnm.de (PROJEKTLEITER) - Password: ManagerPassword123!')
    console.log('   - dev@wnm.de (ENTWICKLER) - Password: DevPassword123!')
    console.log('   - kunde@demo.de (KUNDE) - Password: KundePassword123!')
    console.log('')
    console.log('🏷️ Enum categories and values created')

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred'
    console.error('❌ Error seeding database:', errorMessage)
    throw error
  } finally {
    await prisma.$disconnect()
  }
}

main()
  .catch((error: unknown) => {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred'
    console.error('❌ Seeding failed:', errorMessage)
    process.exit(1)
  }) 