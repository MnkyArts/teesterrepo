import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

/**
 * Migration Script: Dynamische Enums für Tasks und Tickets
 * Migriert bestehende Task- und Ticket-Daten zu neuen dynamischen Enum-Referenzen
 */
async function migrateToynamicEnums() {
  console.log('🚀 Starte Migration zu dynamischen Enums...')

  try {
    // 1. Erstelle Mapping für alte zu neue Enum-Werte
    const enumMappings = {
      // Task Types
      taskType: {
        'BUG': 'task_type_bug',
        'FEATURE': 'task_type_feature', 
        'VERBESSERUNG': 'task_type_improvement',
        'AUFGABE': 'task_type_task',
        'STORY': 'task_type_story',
        'EPIC': 'task_type_epic'
      },
      // Priorities
      priority: {
        'NIEDRIG': 'priority_low',
        'NORMAL': 'priority_normal',
        'HOCH': 'priority_high',
        'KRITISCH': 'priority_critical',
        'BLOCKER': 'priority_blocker'
      },
      // Task Status
      taskStatus: {
        'GEPLANT': 'task_status_planned',
        'TECHNISCHES_DESIGN': 'task_status_design',
        'IN_BEARBEITUNG': 'task_status_progress',
        'REVIEW': 'task_status_review',
        'TESTING': 'task_status_testing',
        'ERLEDIGT': 'task_status_done',
        'GESCHLOSSEN': 'task_status_closed'
      },
      // Ticket Status
      ticketStatus: {
        'OFFEN': 'ticket_status_open',
        'IN_BEARBEITUNG': 'ticket_status_progress',
        'WARTEN_AUF_KUNDE': 'ticket_status_waiting',
        'GELOEST': 'ticket_status_resolved',
        'GESCHLOSSEN': 'ticket_status_closed'
      }
    }

    // 2. Migriere bestehende Tasks
    console.log('📋 Migriere Tasks...')
    const tasks = await prisma.$queryRaw`
      SELECT id, type, priority, status FROM tasks 
      WHERE type IS NOT NULL OR priority IS NOT NULL OR status IS NOT NULL
    ` as any[]

    let tasksMigrated = 0
    for (const task of tasks) {
      const updates: any = {}

      if (task.type && enumMappings.taskType[task.type as keyof typeof enumMappings.taskType]) {
        updates.typeId = enumMappings.taskType[task.type as keyof typeof enumMappings.taskType]
      }
      if (task.priority && enumMappings.priority[task.priority as keyof typeof enumMappings.priority]) {
        updates.priorityId = enumMappings.priority[task.priority as keyof typeof enumMappings.priority]
      }
      if (task.status && enumMappings.taskStatus[task.status as keyof typeof enumMappings.taskStatus]) {
        updates.statusId = enumMappings.taskStatus[task.status as keyof typeof enumMappings.taskStatus]
      }

      if (Object.keys(updates).length > 0) {
        await prisma.task.update({
          where: { id: task.id },
          data: updates
        })
        tasksMigrated++
      }
    }

    console.log(`✅ ${tasksMigrated} Tasks erfolgreich migriert`)

    // 3. Migriere bestehende Tickets
    console.log('🎫 Migriere Tickets...')
    const tickets = await prisma.$queryRaw`
      SELECT id, priority, status FROM tickets 
      WHERE priority IS NOT NULL OR status IS NOT NULL
    ` as any[]

    let ticketsMigrated = 0
    for (const ticket of tickets) {
      const updates: any = {}

      if (ticket.priority && enumMappings.priority[ticket.priority as keyof typeof enumMappings.priority]) {
        updates.priorityId = enumMappings.priority[ticket.priority as keyof typeof enumMappings.priority]
      }
      if (ticket.status && enumMappings.ticketStatus[ticket.status as keyof typeof enumMappings.ticketStatus]) {
        updates.statusId = enumMappings.ticketStatus[ticket.status as keyof typeof enumMappings.ticketStatus]
      }

      // Standard-Ticket-Typ setzen falls nicht vorhanden
      if (!ticket.type_id) {
        updates.typeId = 'ticket_type_support' // Standard Support-Anfrage
      }

      if (Object.keys(updates).length > 0) {
        await prisma.ticket.update({
          where: { id: ticket.id },
          data: updates
        })
        ticketsMigrated++
      }
    }

    console.log(`✅ ${ticketsMigrated} Tickets erfolgreich migriert`)

    // 4. Setze Standard-Werte für Tasks ohne Enum-Referenzen
    console.log('🔧 Setze Standard-Werte für Tasks ohne Enum-Referenzen...')
    
    const tasksWithoutType = await prisma.task.updateMany({
      where: { typeId: null },
      data: { typeId: 'task_type_task' } // Standard: Aufgabe
    })
    
    const tasksWithoutPriority = await prisma.task.updateMany({
      where: { priorityId: null },
      data: { priorityId: 'priority_normal' } // Standard: Normal
    })
    
    const tasksWithoutStatus = await prisma.task.updateMany({
      where: { statusId: null },
      data: { statusId: 'task_status_planned' } // Standard: Geplant
    })

    console.log(`📋 ${tasksWithoutType.count} Tasks mit Standard-Typ versehen`)
    console.log(`⭐ ${tasksWithoutPriority.count} Tasks mit Standard-Priorität versehen`) 
    console.log(`📊 ${tasksWithoutStatus.count} Tasks mit Standard-Status versehen`)

    // 5. Setze Standard-Werte für Tickets ohne Enum-Referenzen
    console.log('🔧 Setze Standard-Werte für Tickets ohne Enum-Referenzen...')
    
    const ticketsWithoutType = await prisma.ticket.updateMany({
      where: { typeId: null },
      data: { typeId: 'ticket_type_support' } // Standard: Support-Anfrage
    })
    
    const ticketsWithoutPriority = await prisma.ticket.updateMany({
      where: { priorityId: null },
      data: { priorityId: 'priority_normal' } // Standard: Normal
    })
    
    const ticketsWithoutStatus = await prisma.ticket.updateMany({
      where: { statusId: null },
      data: { statusId: 'ticket_status_open' } // Standard: Offen
    })

    console.log(`🎫 ${ticketsWithoutType.count} Tickets mit Standard-Typ versehen`)
    console.log(`⭐ ${ticketsWithoutPriority.count} Tickets mit Standard-Priorität versehen`)
    console.log(`📊 ${ticketsWithoutStatus.count} Tickets mit Standard-Status versehen`)

    // 6. Validierung: Prüfe ob alle Datensätze migriert wurden
    console.log('🔍 Validiere Migration...')
    
    const tasksWithoutEnums = await prisma.task.count({
      where: {
        OR: [
          { typeId: null },
          { priorityId: null },
          { statusId: null }
        ]
      }
    })

    const ticketsWithoutEnums = await prisma.ticket.count({
      where: {
        OR: [
          { typeId: null },
          { priorityId: null },
          { statusId: null }
        ]
      }
    })

    if (tasksWithoutEnums === 0 && ticketsWithoutEnums === 0) {
      console.log('✅ Migration erfolgreich abgeschlossen!')
      console.log('🎉 Alle Tasks und Tickets verwenden jetzt dynamische Enums')
    } else {
      console.log(`⚠️  Warnung: ${tasksWithoutEnums} Tasks und ${ticketsWithoutEnums} Tickets haben noch fehlende Enum-Referenzen`)
    }

    // 7. Statistiken anzeigen
    const enumStats = await prisma.enumValue.groupBy({
      by: ['categoryId'],
      _count: true
    })

    console.log('\n📊 Enum-Statistiken:')
    for (const stat of enumStats) {
      const category = await prisma.enumCategory.findUnique({
        where: { id: stat.categoryId }
      })
      console.log(`  - ${category?.label}: ${stat._count} Werte`)
    }

    const totalTasks = await prisma.task.count()
    const totalTickets = await prisma.ticket.count()
    
    console.log(`\n📈 Migrations-Übersicht:`)
    console.log(`  - Gesamt Tasks: ${totalTasks}`)
    console.log(`  - Gesamt Tickets: ${totalTickets}`)
    console.log(`  - Enum-Kategorien: ${enumStats.length}`)

  } catch (error) {
    console.error('❌ Fehler bei der Migration:', error)
    throw error
  }
}

// Hauptfunktion ausführen
async function main() {
  try {
    await migrateToynamicEnums()
  } catch (error) {
    console.error('Migration fehlgeschlagen:', error)
    process.exit(1)
  } finally {
    await prisma.$disconnect()
  }
}

// Script ausführen
main()

export { migrateToynamicEnums }
