#!/bin/bash

# wenoma Deployment Script für Linux Server
# Dieses Script bereitet den Server für das Deployment vor

set -e  # Exit bei Fehlern

# Farben für Output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging-Funktion
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
}

info() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')] INFO: $1${NC}"
}

# Konfiguration
APP_NAME="wenoma"
APP_DIR="/var/www/wenoma"
APP_USER="www-data"
NODE_VERSION="20"
PM2_APP_NAME="nuxt-app"

# Funktionen

check_requirements() {
    log "Überprüfe System-Anforderungen..."
    
    # Node.js überprüfen
    if ! command -v node &> /dev/null; then
        error "Node.js ist nicht installiert"
        exit 1
    fi
    
    local node_version=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$node_version" -lt "18" ]; then
        error "Node.js Version 18+ erforderlich. Aktuelle Version: $(node -v)"
        exit 1
    fi
    
    # Bun überprüfen und installieren (bevorzugt)
    if ! command -v bun &> /dev/null; then
        warn "Bun ist nicht installiert. Installiere Bun..."
        curl -fsSL https://bun.sh/install | bash
        export PATH="$HOME/.bun/bin:$PATH"
        
        # Bun global verfügbar machen
        echo 'export PATH="$HOME/.bun/bin:$PATH"' >> ~/.bashrc
        echo 'export PATH="$HOME/.bun/bin:$PATH"' >> ~/.profile
        
        # Für root auch verfügbar machen
        sudo ln -sf "$HOME/.bun/bin/bun" /usr/local/bin/bun 2>/dev/null || true
        
        log "Bun erfolgreich installiert ✓"
    else
        log "Bun bereits installiert: $(bun --version)"
    fi
    
    # npm als Fallback überprüfen
    if ! command -v npm &> /dev/null; then
        warn "npm ist nicht installiert (Fallback für Bun)"
    fi
    
    # PM2 überprüfen
    if ! command -v pm2 &> /dev/null; then
        warn "PM2 ist nicht installiert. Installiere PM2..."
        if command -v bun &> /dev/null; then
            bun install -g pm2
        else
            npm install -g pm2
        fi
    fi
    
    # Git überprüfen
    if ! command -v git &> /dev/null; then
        error "Git ist nicht installiert"
        exit 1
    fi
    
    log "System-Anforderungen erfüllt ✓"
}

setup_directories() {
    log "Richte Verzeichnisstruktur ein..."
    
    # App-Verzeichnis erstellen
    sudo mkdir -p "$APP_DIR"
    sudo mkdir -p "$APP_DIR/logs"
    sudo mkdir -p "$APP_DIR/uploads"
    sudo mkdir -p "$APP_DIR/backups"
    sudo mkdir -p "$APP_DIR/.bun-cache"
    
    # Berechtigungen setzen
    sudo chown -R $APP_USER:$APP_USER "$APP_DIR"
    sudo chmod -R 755 "$APP_DIR"
    
    log "Verzeichnisstruktur eingerichtet ✓"
}

setup_nginx() {
    log "Richte Nginx-Konfiguration ein..."
    
    # Nginx-Konfiguration erstellen
    sudo tee /etc/nginx/sites-available/wenoma > /dev/null <<EOF
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    
    # Redirect to HTTPS
    return 301 https://\$server_name\$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;
    
    # SSL-Konfiguration (SSL-Zertifikate müssen separat eingerichtet werden)
    # ssl_certificate /path/to/certificate.crt;
    # ssl_certificate_key /path/to/private.key;
    
    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
    
    # Gzip Compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private must-revalidate no_last_modified no_etag auth;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
    
    # Rate Limiting
    limit_req_zone \$binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone \$binary_remote_addr zone=login:10m rate=1r/s;
    
    # Static Assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        root $APP_DIR/.output/public;
        try_files \$uri =404;
    }
    
    # API Rate Limiting
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # Login/Auth Rate Limiting
    location /auth/ {
        limit_req zone=login burst=5 nodelay;
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
    
    # Main Application
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # File Upload Limits
    client_max_body_size 50M;
    
    # Error and Access Logs
    access_log /var/log/nginx/wenoma.access.log;
    error_log /var/log/nginx/wenoma.error.log;
}
EOF
    
    # Site aktivieren
    sudo ln -sf /etc/nginx/sites-available/wenoma /etc/nginx/sites-enabled/
    
    # Nginx-Konfiguration testen
    sudo nginx -t
    
    warn "Nginx-Konfiguration erstellt. Bitte Domain und SSL-Zertifikate anpassen!"
    log "Nginx-Konfiguration eingerichtet ✓"
}

setup_systemd() {
    log "Richte systemd Service ein..."
    
    # systemd Service für PM2 erstellen
    sudo tee /etc/systemd/system/wenoma.service > /dev/null <<EOF
[Unit]
Description=wenoma Nuxt.js Application
After=network.target

[Service]
Type=forking
User=$APP_USER
WorkingDirectory=$APP_DIR
Environment=NODE_ENV=production
ExecStart=/usr/bin/pm2 start ecosystem.config.js --env production
ExecReload=/usr/bin/pm2 reload ecosystem.config.js --env production
ExecStop=/usr/bin/pm2 stop ecosystem.config.js
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
    
    # Service aktivieren
    sudo systemctl daemon-reload
    sudo systemctl enable wenoma
    
    log "systemd Service eingerichtet ✓"
}

setup_firewall() {
    log "Richte Firewall ein..."
    
    # UFW installieren falls nicht vorhanden
    if ! command -v ufw &> /dev/null; then
        warn "UFW ist nicht installiert. Installiere UFW..."
        sudo apt-get update
        sudo apt-get install -y ufw
    fi
    
    # Firewall-Regeln
    sudo ufw default deny incoming
    sudo ufw default allow outgoing
    sudo ufw allow ssh
    sudo ufw allow 'Nginx Full'
    
    # UFW aktivieren (vorsichtig!)
    warn "UFW wird aktiviert. Stelle sicher, dass SSH-Zugang funktioniert!"
    sudo ufw --force enable
    
    log "Firewall eingerichtet ✓"
}

setup_logrotate() {
    log "Richte Log-Rotation ein..."
    
    # Logrotate-Konfiguration für Anwendung
    sudo tee /etc/logrotate.d/wenoma > /dev/null <<EOF
$APP_DIR/logs/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    copytruncate
    create 0644 $APP_USER $APP_USER
}
EOF
    
    log "Log-Rotation eingerichtet ✓"
}

create_env_template() {
    log "Erstelle Umgebungsvariablen-Template..."
    
    # .env Template erstellen
    cat > "$APP_DIR/.env.production" <<EOF
# wenoma Production Environment Variables
# Kopiere diese Datei und passe die Werte an

# Application
NODE_ENV=production
PORT=3000
HOST=0.0.0.0

# Package Manager (Bun preferred, npm as fallback)
BUN_INSTALL_CACHE_DIR="$APP_DIR/.bun-cache"

# Database
DATABASE_URL="postgresql://username:password@localhost:5432/wenoma_production"

# JWT
JWT_SECRET="your-super-secret-jwt-key-change-this"
NUXT_SECRET_KEY="your-super-secret-nuxt-key-change-this"

# URLs
NUXT_PUBLIC_API_BASE="https://your-domain.com"
NUXT_PUBLIC_APP_URL="https://your-domain.com"

# Email (optional)
SMTP_HOST="smtp.your-provider.com"
SMTP_PORT=587
SMTP_USER="your-email@your-domain.com"
SMTP_PASS="your-email-password"

# File Uploads
MAX_FILE_SIZE=52428800
UPLOAD_DIR="$APP_DIR/uploads"

# Logging
LOG_LEVEL="info"
LOG_FILE="$APP_DIR/logs/app.log"

# Security
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=900000

# GDPR/Privacy
PRIVACY_POLICY_URL="https://your-domain.com/privacy"
TERMS_OF_SERVICE_URL="https://your-domain.com/terms"
EOF
    
    warn "Umgebungsvariablen-Template erstellt in $APP_DIR/.env.production"
    warn "Bitte passe die Werte entsprechend an!"
    
    log "Umgebungsvariablen-Template erstellt ✓"
}

print_next_steps() {
    info "==================================="
    info "Deployment-Setup abgeschlossen!"
    info "==================================="
    echo ""
    info "Nächste Schritte:"
    echo "1. GitLab CI/CD Variablen konfigurieren:"
    echo "   - DEPLOY_SERVER: $(hostname -I | awk '{print $1}')"
    echo "   - DEPLOY_USER: $APP_USER"
    echo "   - DEPLOY_PATH: $APP_DIR"
    echo "   - DEPLOY_SSH_PRIVATE_KEY: [SSH Private Key]"
    echo ""
    echo "2. Umgebungsvariablen anpassen:"
    echo "   sudo nano $APP_DIR/.env.production"
    echo ""
    echo "3. Nginx-Konfiguration anpassen:"
    echo "   sudo nano /etc/nginx/sites-available/wenoma"
    echo ""
    echo "4. SSL-Zertifikat einrichten (Let's Encrypt empfohlen):"
    echo "   sudo certbot --nginx -d your-domain.com"
    echo ""
    echo "5. PostgreSQL-Datenbank einrichten und migrieren"
    echo ""
    echo "6. Nginx neu starten:"
    echo "   sudo systemctl restart nginx"
    echo ""
    echo "7. Bun für $APP_USER verfügbar machen:"
    echo "   sudo -u $APP_USER bash -c 'curl -fsSL https://bun.sh/install | bash'"
    echo "   sudo ln -sf /home/$APP_USER/.bun/bin/bun /usr/local/bin/bun"
    echo ""
    echo "8. Ersten Deployment von GitLab CI/CD starten"
    echo ""
    info "Package Manager Support:"
    echo "   ✓ Bun (bevorzugt): $(command -v bun && bun --version || echo 'Nicht installiert')"
    echo "   ✓ npm (Fallback): $(command -v npm && npm --version || echo 'Nicht installiert')"
    echo ""
    info "==================================="
}

# Hauptfunktion
main() {
    log "Starte wenoma Deployment-Setup..."
    
    # System aktualisieren
    log "Aktualisiere System..."
    sudo apt-get update
    sudo apt-get upgrade -y
    
    # Abhängigkeiten installieren
    log "Installiere System-Abhängigkeiten..."
    sudo apt-get install -y nginx postgresql postgresql-contrib certbot python3-certbot-nginx curl wget git build-essential unzip
    
    # Setup-Funktionen ausführen
    check_requirements
    setup_directories
    setup_nginx
    setup_systemd
    setup_firewall
    setup_logrotate
    create_env_template
    
    print_next_steps
    
    log "Deployment-Setup erfolgreich abgeschlossen!"
}

# Script ausführen
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
