import { PrismaClient } from '@prisma/client'
import { nanoid } from 'nanoid'

const prisma = new PrismaClient()

// Default permissions that should exist in the system
const DEFAULT_PERMISSIONS = [
  // Role management permissions
  { name: 'roles.create', displayName: 'Rollen erstellen', description: 'Neue Rollen erstellen', category: 'roles' },
  { name: 'roles.view', displayName: 'Rollen anzeigen', description: 'Rollen anzeigen und auflisten', category: 'roles' },
  { name: 'roles.update', displayName: 'Rollen bearbeiten', description: 'Bestehende Rollen bearbeiten', category: 'roles' },
  { name: 'roles.delete', displayName: 'Rollen löschen', description: 'Rollen löschen', category: 'roles' },
  { name: 'roles.manage-permissions', displayName: 'Rollen-Berechtigungen verwalten', description: 'Berechtigungen zu Rollen zuweisen', category: 'roles' },
  
  // Permission management permissions
  { name: 'permissions.create', displayName: 'Berechtigungen erstellen', description: 'Neue Berechtigungen erstellen', category: 'permissions' },
  { name: 'permissions.view', displayName: 'Berechtigungen anzeigen', description: 'Berechtigungen anzeigen und auflisten', category: 'permissions' },
  { name: 'permissions.update', displayName: 'Berechtigungen bearbeiten', description: 'Bestehende Berechtigungen bearbeiten', category: 'permissions' },
  { name: 'permissions.delete', displayName: 'Berechtigungen löschen', description: 'Berechtigungen löschen', category: 'permissions' },
  
  // User management permissions
  { name: 'users.view', displayName: 'Benutzer anzeigen', description: 'Benutzer anzeigen und auflisten', category: 'users' },
  { name: 'users.create', displayName: 'Benutzer erstellen', description: 'Neue Benutzer erstellen', category: 'users' },
  { name: 'users.update', displayName: 'Benutzer bearbeiten', description: 'Bestehende Benutzer bearbeiten', category: 'users' },
  { name: 'users.delete', displayName: 'Benutzer löschen', description: 'Benutzer löschen', category: 'users' },
  { name: 'users.manage-roles', displayName: 'Benutzer-Rollen verwalten', description: 'Rollen zu Benutzern zuweisen', category: 'users' },
  { name: 'users.view-permissions', displayName: 'Benutzer-Berechtigungen anzeigen', description: 'Berechtigungen anderer Benutzer anzeigen', category: 'users' },
  
  // Project management permissions
  { name: 'projects.view', displayName: 'Projekte anzeigen', description: 'Projekte anzeigen und auflisten', category: 'projects' },
  { name: 'projects.create', displayName: 'Projekte erstellen', description: 'Neue Projekte erstellen', category: 'projects' },
  { name: 'projects.update', displayName: 'Projekte bearbeiten', description: 'Bestehende Projekte bearbeiten', category: 'projects' },
  { name: 'projects.delete', displayName: 'Projekte löschen', description: 'Projekte löschen', category: 'projects' },
  { name: 'projects.manage-members', displayName: 'Projektmitglieder verwalten', description: 'Projektmitglieder hinzufügen/entfernen', category: 'projects' },
  
  // Task management permissions
  { name: 'tasks.view', displayName: 'Aufgaben anzeigen', description: 'Aufgaben anzeigen und auflisten', category: 'tasks' },
  { name: 'tasks.create', displayName: 'Aufgaben erstellen', description: 'Neue Aufgaben erstellen', category: 'tasks' },
  { name: 'tasks.update', displayName: 'Aufgaben bearbeiten', description: 'Bestehende Aufgaben bearbeiten', category: 'tasks' },
  { name: 'tasks.delete', displayName: 'Aufgaben löschen', description: 'Aufgaben löschen', category: 'tasks' },
  { name: 'tasks.assign', displayName: 'Aufgaben zuweisen', description: 'Aufgaben anderen Benutzern zuweisen', category: 'tasks' },
  
  // Customer management permissions
  { name: 'customers.view', displayName: 'Kunden anzeigen', description: 'Kunden anzeigen und auflisten', category: 'customers' },
  { name: 'customers.create', displayName: 'Kunden erstellen', description: 'Neue Kunden erstellen', category: 'customers' },
  { name: 'customers.update', displayName: 'Kunden bearbeiten', description: 'Bestehende Kunden bearbeiten', category: 'customers' },
  { name: 'customers.delete', displayName: 'Kunden löschen', description: 'Kunden löschen', category: 'customers' },
  
  // Invoice management permissions
  { name: 'invoices.view', displayName: 'Rechnungen anzeigen', description: 'Rechnungen anzeigen und auflisten', category: 'invoices' },
  { name: 'invoices.create', displayName: 'Rechnungen erstellen', description: 'Neue Rechnungen erstellen', category: 'invoices' },
  { name: 'invoices.update', displayName: 'Rechnungen bearbeiten', description: 'Bestehende Rechnungen bearbeiten', category: 'invoices' },
  { name: 'invoices.delete', displayName: 'Rechnungen löschen', description: 'Rechnungen löschen', category: 'invoices' },
  
  // Ticket management permissions
  { name: 'tickets.view', displayName: 'Tickets anzeigen', description: 'Tickets anzeigen und auflisten', category: 'tickets' },
  { name: 'tickets.create', displayName: 'Tickets erstellen', description: 'Neue Tickets erstellen', category: 'tickets' },
  { name: 'tickets.update', displayName: 'Tickets bearbeiten', description: 'Bestehende Tickets bearbeiten', category: 'tickets' },
  { name: 'tickets.delete', displayName: 'Tickets löschen', description: 'Tickets löschen', category: 'tickets' },
  { name: 'tickets.assign', displayName: 'Tickets zuweisen', description: 'Tickets anderen Benutzern zuweisen', category: 'tickets' },
  
  // System permissions
  { name: 'system.admin', displayName: 'System-Administrator', description: 'Vollzugriff auf alle Systemfunktionen', category: 'system' },
  { name: 'system.settings', displayName: 'System-Einstellungen', description: 'System-Einstellungen verwalten', category: 'system' },
  { name: 'system.logs', displayName: 'System-Logs', description: 'System-Logs anzeigen', category: 'system' },
]

// Default roles that should exist in the system
const DEFAULT_ROLES = [
  { name: 'super-admin', displayName: 'Super Administrator', description: 'Vollzugriff auf alle Funktionen', priority: 1000, isSystem: true },
  { name: 'admin', displayName: 'Administrator', description: 'Administrator mit erweiterten Rechten', priority: 900, isSystem: true },
  { name: 'project-manager', displayName: 'Projektmanager', description: 'Projektmanagement und Team-Koordination', priority: 800, isSystem: true },
  { name: 'developer', displayName: 'Entwickler', description: 'Entwicklung und technische Aufgaben', priority: 700, isSystem: true },
  { name: 'supporter', displayName: 'Support', description: 'Kundensupport und Ticket-Bearbeitung', priority: 600, isSystem: true },
  { name: 'user', displayName: 'Benutzer', description: 'Standard-Benutzer mit grundlegenden Rechten', priority: 500, isSystem: true },
  { name: 'customer', displayName: 'Kunde', description: 'Kunde mit Zugang zum Kundenportal', priority: 400, isSystem: true },
]

async function createPermissions() {
  console.log('🔐 Creating default permissions...')
  
  for (const permission of DEFAULT_PERMISSIONS) {
    await prisma.permission.upsert({
      where: { name: permission.name },
      update: {
        displayName: permission.displayName,
        description: permission.description,
        category: permission.category,
        updatedAt: new Date(),
      },
      create: {
        id: nanoid(),
        name: permission.name,
        displayName: permission.displayName,
        description: permission.description,
        category: permission.category,
        isSystem: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    })
  }
  
  console.log(`✅ Created/updated ${DEFAULT_PERMISSIONS.length} permissions`)
}

async function createRoles() {
  console.log('👥 Creating default roles...')
  
  for (const role of DEFAULT_ROLES) {
    await prisma.role.upsert({
      where: { name: role.name },
      update: {
        displayName: role.displayName,
        description: role.description,
        priority: role.priority,
        updatedAt: new Date(),
      },
      create: {
        id: nanoid(),
        name: role.name,
        displayName: role.displayName,
        description: role.description,
        priority: role.priority,
        isSystem: role.isSystem,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    })
  }
  
  console.log(`✅ Created/updated ${DEFAULT_ROLES.length} roles`)
}

async function assignPermissionsToRoles() {
  console.log('🔗 Assigning permissions to roles...')
  
  // Get all permissions and roles
  const permissions = await prisma.permission.findMany()
  const roles = await prisma.role.findMany()
  
  // Super Admin gets all permissions
  const superAdminRole = roles.find(r => r.name === 'super-admin')
  if (superAdminRole) {
    for (const permission of permissions) {
      // Check if relationship already exists
      const existingRelation = await prisma.rolePermission.findFirst({
        where: {
          roleId: superAdminRole.id,
          permissionId: permission.id,
        },
      })
      
      if (!existingRelation) {
        await prisma.rolePermission.create({
          data: {
            id: nanoid(),
            roleId: superAdminRole.id,
            permissionId: permission.id,
            granted: true,
            createdAt: new Date(),
          },
        })
      }
    }
    console.log(`✅ Assigned all permissions to super-admin role`)
  }
  
  // Admin gets most permissions (excluding super admin specific ones)
  const adminRole = roles.find(r => r.name === 'admin')
  if (adminRole) {
    const adminPermissions = permissions.filter(p => p.name !== 'system.admin')
    for (const permission of adminPermissions) {
      const existingRelation = await prisma.rolePermission.findFirst({
        where: {
          roleId: adminRole.id,
          permissionId: permission.id,
        },
      })
      
      if (!existingRelation) {
        await prisma.rolePermission.create({
          data: {
            id: nanoid(),
            roleId: adminRole.id,
            permissionId: permission.id,
            granted: true,
            createdAt: new Date(),
          },
        })
      }
    }
    console.log(`✅ Assigned ${adminPermissions.length} permissions to admin role`)
  }
  
  // Project Manager gets project and task related permissions
  const projectManagerRole = roles.find(r => r.name === 'project-manager')
  if (projectManagerRole) {
    const pmPermissions = permissions.filter(p => 
      p.category === 'projects' || 
      p.category === 'tasks' || 
      (p.category === 'users' && (p.name === 'users.view' || p.name === 'users.view-permissions')) ||
      (p.category === 'customers' && p.name === 'customers.view')
    )
    for (const permission of pmPermissions) {
      const existingRelation = await prisma.rolePermission.findFirst({
        where: {
          roleId: projectManagerRole.id,
          permissionId: permission.id,
        },
      })
      
      if (!existingRelation) {
        await prisma.rolePermission.create({
          data: {
            id: nanoid(),
            roleId: projectManagerRole.id,
            permissionId: permission.id,
            granted: true,
            createdAt: new Date(),
          },
        })
      }
    }
    console.log(`✅ Assigned ${pmPermissions.length} permissions to project-manager role`)
  }
  
  // Developer gets task related permissions
  const developerRole = roles.find(r => r.name === 'developer')
  if (developerRole) {
    const devPermissions = permissions.filter(p => 
      (p.category === 'tasks' && (p.name === 'tasks.view' || p.name === 'tasks.update')) ||
      (p.category === 'projects' && p.name === 'projects.view')
    )
    for (const permission of devPermissions) {
      const existingRelation = await prisma.rolePermission.findFirst({
        where: {
          roleId: developerRole.id,
          permissionId: permission.id,
        },
      })
      
      if (!existingRelation) {
        await prisma.rolePermission.create({
          data: {
            id: nanoid(),
            roleId: developerRole.id,
            permissionId: permission.id,
            granted: true,
            createdAt: new Date(),
          },
        })
      }
    }
    console.log(`✅ Assigned ${devPermissions.length} permissions to developer role`)
  }
  
  // Supporter gets ticket related permissions
  const supporterRole = roles.find(r => r.name === 'supporter')
  if (supporterRole) {
    const supportPermissions = permissions.filter(p => 
      p.category === 'tickets' ||
      (p.category === 'customers' && p.name === 'customers.view')
    )
    for (const permission of supportPermissions) {
      const existingRelation = await prisma.rolePermission.findFirst({
        where: {
          roleId: supporterRole.id,
          permissionId: permission.id,
        },
      })
      
      if (!existingRelation) {
        await prisma.rolePermission.create({
          data: {
            id: nanoid(),
            roleId: supporterRole.id,
            permissionId: permission.id,
            granted: true,
            createdAt: new Date(),
          },
        })
      }
    }
    console.log(`✅ Assigned ${supportPermissions.length} permissions to supporter role`)
  }
}

async function assignSuperAdminRole(userEmail: string) {
  console.log(`👤 Assigning super-admin role to ${userEmail}...`)
  
  const user = await prisma.user.findUnique({
    where: { email: userEmail },
  })
  
  if (!user) {
    throw new Error(`User with email ${userEmail} not found`)
  }
  
  const superAdminRole = await prisma.role.findUnique({
    where: { name: 'super-admin' },
  })
  
  if (!superAdminRole) {
    throw new Error('Super admin role not found')
  }
  
  // Check if user already has this role
  const existingUserRole = await prisma.userRole.findFirst({
    where: {
      userId: user.id,
      roleId: superAdminRole.id,
    },
  })
  
  if (existingUserRole) {
    console.log(`✅ User ${userEmail} already has super-admin role`)
    return
  }
  
  // Assign the role
  await prisma.userRole.create({
    data: {
      id: nanoid(),
      userId: user.id,
      roleId: superAdminRole.id,
      createdAt: new Date(),
    },
  })
  
  console.log(`✅ Assigned super-admin role to ${userEmail}`)
}

async function main() {
  console.log('🚀 Bootstrapping permissions system...')
  
  try {
    await createPermissions()
    await createRoles()
    await assignPermissionsToRoles()
    
    // Get user email from command line arguments or use default
    const userEmail = process.argv[2] || 'admin@wnm.de'
    await assignSuperAdminRole(userEmail)
    
    console.log('✅ Permissions system bootstrapped successfully!')
    console.log(`\n🔐 You now have super-admin privileges with the email: ${userEmail}`)
    console.log('You can now access all role and permission management features.')
    
  } catch (error) {
    console.error('❌ Error bootstrapping permissions:', error)
    throw error
  } finally {
    await prisma.$disconnect()
  }
}

// Run the script if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error) => {
    console.error(error)
    process.exit(1)
  })
}

export { main as bootstrapPermissions } 