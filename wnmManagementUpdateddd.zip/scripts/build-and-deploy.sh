#!/bin/bash

# wnmManagement Build and Deploy Script
# This script builds the Docker image and pushes it to GitLab Container Registry
# Usage: ./scripts/build-and-deploy.sh [environment] [version]

set -e  # Exit on any error

# Configuration
REGISTRY_URL="registry.gitlab.wnm.de"
PROJECT_NAME="ep/wenoma"
IMAGE_NAME="${REGISTRY_URL}/${PROJECT_NAME}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Parse arguments
ENVIRONMENT=${1:-"production"}
VERSION=${2:-$(date +%Y%m%d-%H%M%S)}
BRANCH=${CI_COMMIT_REF_NAME:-$(git rev-parse --abbrev-ref HEAD)}
COMMIT_SHA=${CI_COMMIT_SHA:-$(git rev-parse HEAD)}

log_info "Starting build process..."
log_info "Environment: $ENVIRONMENT"
log_info "Version: $VERSION"
log_info "Branch: $BRANCH"
log_info "Commit: $COMMIT_SHA"

# Validate environment
if [[ "$ENVIRONMENT" != "production" && "$ENVIRONMENT" != "staging" && "$ENVIRONMENT" != "development" ]]; then
    log_error "Invalid environment: $ENVIRONMENT. Must be 'production', 'staging', or 'development'"
    exit 1
fi

# Check if Docker is available
if ! command -v docker &> /dev/null; then
    log_error "Docker is not installed or not available in PATH"
    exit 1
fi

# Check if we're logged into GitLab registry
log_info "Checking GitLab registry authentication..."
if ! docker system info 2>/dev/null | grep -q "Username" && ! cat ~/.docker/config.json 2>/dev/null | grep -q "$REGISTRY_URL"; then
    log_warning "Not logged into Docker registry. Attempting login..."
    if [[ -n "$CI_REGISTRY_PASSWORD" ]]; then
        echo "$CI_REGISTRY_PASSWORD" | docker login "$REGISTRY_URL" -u "$CI_REGISTRY_USER" --password-stdin
    else
        log_error "Please login to GitLab container registry first:"
        log_error "docker login $REGISTRY_URL"
        exit 1
    fi
else
    log_info "Already authenticated with Docker registry"
fi

# Create .env file for build if it doesn't exist
if [[ ! -f ".env" ]]; then
    log_info "Creating .env file for build..."
    cat > .env << EOF
# Build-time environment variables
NODE_ENV=${ENVIRONMENT}
DATABASE_URL=postgresql://placeholder:placeholder@localhost:5432/placeholder
REDIS_URL=redis://localhost:6379
JWT_SECRET=build-time-secret
APP_URL=https://wnm-management.example.com
BETTER_AUTH_URL=https://wnm-management.example.com
EOF
fi

# Build tags
TAGS=(
    "${IMAGE_NAME}:${VERSION}"
    "${IMAGE_NAME}:${ENVIRONMENT}-latest"
)

if [[ "$BRANCH" == "main" || "$BRANCH" == "master" ]]; then
    TAGS+=("${IMAGE_NAME}:latest")
fi

if [[ "$ENVIRONMENT" == "production" ]]; then
    TAGS+=("${IMAGE_NAME}:stable")
fi

# Build Docker image
log_info "Building Docker image..."
BUILD_ARGS=(
    --build-arg NODE_ENV="$ENVIRONMENT"
    --build-arg BUILD_DATE="$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
    --build-arg VCS_REF="$COMMIT_SHA"
    --build-arg VERSION="$VERSION"
    --label "org.opencontainers.image.title=wnmManagement"
    --label "org.opencontainers.image.description=Nuxt3 Project Management System"
    --label "org.opencontainers.image.version=$VERSION"
    --label "org.opencontainers.image.created=$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
    --label "org.opencontainers.image.revision=$COMMIT_SHA"
    --label "org.opencontainers.image.source=https://gitlab.wnm.de/ep/wenoma"
    --platform linux/amd64
)

# Add tags to build command
for tag in "${TAGS[@]}"; do
    BUILD_ARGS+=(-t "$tag")
done

# Execute build
docker build "${BUILD_ARGS[@]}" .

if [[ $? -eq 0 ]]; then
    log_success "Docker image built successfully!"
else
    log_error "Docker build failed!"
    exit 1
fi

# Push images to registry
log_info "Pushing images to GitLab Container Registry..."
for tag in "${TAGS[@]}"; do
    log_info "Pushing $tag..."
    docker push "$tag"
    if [[ $? -eq 0 ]]; then
        log_success "Successfully pushed $tag"
    else
        log_error "Failed to push $tag"
        exit 1
    fi
done

# Clean up local images (optional, keep latest for caching)
log_info "Cleaning up old images..."
docker image prune -f

# Output summary
log_success "Build and deployment completed successfully!"
log_info "Images pushed:"
for tag in "${TAGS[@]}"; do
    log_info "  - $tag"
done

# Generate deployment commands
log_info "Deployment commands:"
log_info "  Production: docker run -d -p 3000:3000 --name wnm-management ${IMAGE_NAME}:${VERSION}"
log_info "  With environment: docker run -d -p 3000:3000 --env-file .env.production --name wnm-management ${IMAGE_NAME}:${VERSION}"

# Create deployment manifest (optional)
if [[ "$ENVIRONMENT" == "production" ]]; then
    log_info "Creating deployment manifest..."
    cat > "deployment-${VERSION}.yml" << EOF
version: '3.8'
services:
  wnm-management:
    image: ${IMAGE_NAME}:${VERSION}
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=\${DATABASE_URL}
      - REDIS_URL=\${REDIS_URL}
      - JWT_SECRET=\${JWT_SECRET}
      - APP_URL=\${APP_URL}
    restart: unless-stopped
    depends_on:
      - postgres
      - redis
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    volumes:
      - uploads:/app/uploads
    networks:
      - wnm_network

  postgres:
    image: postgres:15-alpine
    environment:
      - POSTGRES_DB=\${POSTGRES_DB}
      - POSTGRES_USER=\${POSTGRES_USER}
      - POSTGRES_PASSWORD=\${POSTGRES_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    networks:
      - wnm_network

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data
    networks:
      - wnm_network

volumes:
  postgres_data:
  redis_data:
  uploads:

networks:
  wnm_network:
    driver: bridge
EOF
    log_success "Deployment manifest created: deployment-${VERSION}.yml"
fi

log_success "Build script completed successfully!" 