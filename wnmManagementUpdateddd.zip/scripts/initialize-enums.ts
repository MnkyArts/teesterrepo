import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

/**
 * Initialisiert die Standard-Enum-Kategorien und -Werte
 */
async function initializeEnums() {
  console.log('🚀 Initialisiere Standard-Enum-Daten...')

  try {
    // 1. Erstelle Enum-Kategorien
    console.log('📁 Erstelle Enum-Kategorien...')
    
    const categories = [
      {
        id: 'task_type_cat',
        name: 'task_type',
        label: 'Aufgabentyp',
        description: 'Kategorien für Aufgabentypen',
        isSystem: true,
        sortOrder: 1
      },
      {
        id: 'priority_cat',
        name: 'priority',
        label: 'Priorität',
        description: 'Prioritätsstufen für Aufgaben und Tickets',
        isSystem: true,
        sortOrder: 2
      },
      {
        id: 'task_status_cat',
        name: 'task_status',
        label: 'Aufgaben-Status',
        description: 'Status-Stufen für Aufgaben',
        isSystem: true,
        sortOrder: 3
      },
      {
        id: 'ticket_type_cat',
        name: 'ticket_type',
        label: 'Ticket-Typ',
        description: 'Kategorien für Support-Tickets',
        isSystem: true,
        sortOrder: 4
      },
      {
        id: 'ticket_status_cat',
        name: 'ticket_status',
        label: 'Ticket-Status',
        description: 'Status-Stufen für Support-Tickets',
        isSystem: true,
        sortOrder: 5
      }
    ]

    for (const category of categories) {
      await prisma.enumCategory.upsert({
        where: { id: category.id },
        update: category,
        create: category
      })
    }

    console.log(`✅ ${categories.length} Kategorien erstellt/aktualisiert`)

    // 2. Erstelle Task-Typen
    console.log('📋 Erstelle Task-Typen...')
    
    const taskTypes = [
      { id: 'task_type_bug', key: 'BUG', label: 'Bug', description: 'Fehlerbehebung', color: '#ef4444', icon: 'bug-ant', isDefault: false, sortOrder: 1 },
      { id: 'task_type_feature', key: 'FEATURE', label: 'Feature', description: 'Neue Funktionalität', color: '#10b981', icon: 'sparkles', isDefault: true, sortOrder: 2 },
      { id: 'task_type_improvement', key: 'VERBESSERUNG', label: 'Verbesserung', description: 'Optimierung bestehender Features', color: '#3b82f6', icon: 'arrow-trending-up', isDefault: false, sortOrder: 3 },
      { id: 'task_type_task', key: 'AUFGABE', label: 'Aufgabe', description: 'Allgemeine Arbeitsaufgabe', color: '#6b7280', icon: 'clipboard-document-list', isDefault: false, sortOrder: 4 },
      { id: 'task_type_story', key: 'STORY', label: 'User Story', description: 'Benutzeranforderung', color: '#8b5cf6', icon: 'user', isDefault: false, sortOrder: 5 },
      { id: 'task_type_epic', key: 'EPIC', label: 'Epic', description: 'Große Anforderung mit Sub-Tasks', color: '#f59e0b', icon: 'flag', isDefault: false, sortOrder: 6 }
    ]

    for (const taskType of taskTypes) {
      await prisma.enumValue.upsert({
        where: { id: taskType.id },
        update: { ...taskType, categoryId: 'task_type_cat' },
        create: { ...taskType, categoryId: 'task_type_cat' }
      })
    }

    console.log(`✅ ${taskTypes.length} Task-Typen erstellt/aktualisiert`)

    // 3. Erstelle Prioritäten
    console.log('⭐ Erstelle Prioritäten...')
    
    const priorities = [
      { id: 'priority_low', key: 'NIEDRIG', label: 'Niedrig', description: 'Niedrige Priorität', color: '#6b7280', icon: 'arrow-down', isDefault: false, sortOrder: 1 },
      { id: 'priority_normal', key: 'NORMAL', label: 'Normal', description: 'Normale Priorität', color: '#3b82f6', icon: 'minus', isDefault: true, sortOrder: 2 },
      { id: 'priority_high', key: 'HOCH', label: 'Hoch', description: 'Hohe Priorität', color: '#f59e0b', icon: 'arrow-up', isDefault: false, sortOrder: 3 },
      { id: 'priority_critical', key: 'KRITISCH', label: 'Kritisch', description: 'Kritische Priorität', color: '#ef4444', icon: 'exclamation-triangle', isDefault: false, sortOrder: 4 },
      { id: 'priority_blocker', key: 'BLOCKER', label: 'Blocker', description: 'Blockierende Priorität', color: '#dc2626', icon: 'no-symbol', isDefault: false, sortOrder: 5 }
    ]

    for (const priority of priorities) {
      await prisma.enumValue.upsert({
        where: { id: priority.id },
        update: { ...priority, categoryId: 'priority_cat' },
        create: { ...priority, categoryId: 'priority_cat' }
      })
    }

    console.log(`✅ ${priorities.length} Prioritäten erstellt/aktualisiert`)

    // 4. Erstelle Task-Status
    console.log('📊 Erstelle Task-Status...')
    
    const taskStatuses = [
      { id: 'task_status_planned', key: 'GEPLANT', label: 'Geplant', description: 'Aufgabe ist geplant', color: '#6b7280', icon: 'clock', isDefault: true, sortOrder: 1 },
      { id: 'task_status_design', key: 'TECHNISCHES_DESIGN', label: 'Technisches Design', description: 'In der Designphase', color: '#8b5cf6', icon: 'pencil-square', isDefault: false, sortOrder: 2 },
      { id: 'task_status_progress', key: 'IN_BEARBEITUNG', label: 'In Bearbeitung', description: 'Wird aktiv bearbeitet', color: '#3b82f6', icon: 'play', isDefault: false, sortOrder: 3 },
      { id: 'task_status_review', key: 'REVIEW', label: 'Review', description: 'Zur Überprüfung', color: '#f59e0b', icon: 'eye', isDefault: false, sortOrder: 4 },
      { id: 'task_status_testing', key: 'TESTING', label: 'Testing', description: 'Wird getestet', color: '#06b6d4', icon: 'beaker', isDefault: false, sortOrder: 5 },
      { id: 'task_status_done', key: 'ERLEDIGT', label: 'Erledigt', description: 'Erfolgreich abgeschlossen', color: '#10b981', icon: 'check', isDefault: false, sortOrder: 6 },
      { id: 'task_status_closed', key: 'GESCHLOSSEN', label: 'Geschlossen', description: 'Aufgabe geschlossen', color: '#374151', icon: 'lock-closed', isDefault: false, sortOrder: 7 }
    ]

    for (const status of taskStatuses) {
      await prisma.enumValue.upsert({
        where: { id: status.id },
        update: { ...status, categoryId: 'task_status_cat' },
        create: { ...status, categoryId: 'task_status_cat' }
      })
    }

    console.log(`✅ ${taskStatuses.length} Task-Status erstellt/aktualisiert`)

    // 5. Erstelle Ticket-Typen
    console.log('🎫 Erstelle Ticket-Typen...')
    
    const ticketTypes = [
      { id: 'ticket_type_support', key: 'SUPPORT', label: 'Support-Anfrage', description: 'Allgemeine Support-Anfrage', color: '#3b82f6', icon: 'question-mark-circle', isDefault: true, sortOrder: 1 },
      { id: 'ticket_type_bug_report', key: 'BUG_REPORT', label: 'Fehlermeldung', description: 'Meldung eines Fehlers', color: '#ef4444', icon: 'exclamation-triangle', isDefault: false, sortOrder: 2 },
      { id: 'ticket_type_feature_request', key: 'FEATURE_REQUEST', label: 'Feature-Wunsch', description: 'Wunsch nach neuer Funktionalität', color: '#10b981', icon: 'light-bulb', isDefault: false, sortOrder: 3 },
      { id: 'ticket_type_billing', key: 'BILLING', label: 'Abrechnung', description: 'Fragen zur Rechnung oder Abrechnung', color: '#f59e0b', icon: 'credit-card', isDefault: false, sortOrder: 4 },
      { id: 'ticket_type_account', key: 'ACCOUNT', label: 'Konto-Verwaltung', description: 'Benutzerkonto und Zugangsdaten', color: '#8b5cf6', icon: 'user-circle', isDefault: false, sortOrder: 5 }
    ]

    for (const ticketType of ticketTypes) {
      await prisma.enumValue.upsert({
        where: { id: ticketType.id },
        update: { ...ticketType, categoryId: 'ticket_type_cat' },
        create: { ...ticketType, categoryId: 'ticket_type_cat' }
      })
    }

    console.log(`✅ ${ticketTypes.length} Ticket-Typen erstellt/aktualisiert`)

    // 6. Erstelle Ticket-Status
    console.log('📮 Erstelle Ticket-Status...')
    
    const ticketStatuses = [
      { id: 'ticket_status_open', key: 'OFFEN', label: 'Offen', description: 'Ticket wurde erstellt', color: '#ef4444', icon: 'exclamation-circle', isDefault: true, sortOrder: 1 },
      { id: 'ticket_status_progress', key: 'IN_BEARBEITUNG', label: 'In Bearbeitung', description: 'Ticket wird bearbeitet', color: '#3b82f6', icon: 'play', isDefault: false, sortOrder: 2 },
      { id: 'ticket_status_waiting', key: 'WARTEN_AUF_KUNDE', label: 'Warten auf Kunde', description: 'Warten auf Kunden-Feedback', color: '#f59e0b', icon: 'clock', isDefault: false, sortOrder: 3 },
      { id: 'ticket_status_resolved', key: 'GELOEST', label: 'Gelöst', description: 'Problem wurde behoben', color: '#10b981', icon: 'check-circle', isDefault: false, sortOrder: 4 },
      { id: 'ticket_status_closed', key: 'GESCHLOSSEN', label: 'Geschlossen', description: 'Ticket wurde geschlossen', color: '#6b7280', icon: 'x-circle', isDefault: false, sortOrder: 5 }
    ]

    for (const status of ticketStatuses) {
      await prisma.enumValue.upsert({
        where: { id: status.id },
        update: { ...status, categoryId: 'ticket_status_cat' },
        create: { ...status, categoryId: 'ticket_status_cat' }
      })
    }

    console.log(`✅ ${ticketStatuses.length} Ticket-Status erstellt/aktualisiert`)

    // 7. Setze Standard-Werte für existierende Tasks und Tickets
    console.log('🔧 Setze Standard-Werte für bestehende Datensätze...')
    
    const tasksUpdated = await prisma.task.updateMany({
      where: {
        OR: [
          { typeId: null },
          { priorityId: null },
          { statusId: null }
        ]
      },
      data: {
        typeId: 'task_type_feature', // Standard: Feature
        priorityId: 'priority_normal', // Standard: Normal
        statusId: 'task_status_planned' // Standard: Geplant
      }
    })

    const ticketsUpdated = await prisma.ticket.updateMany({
      where: {
        OR: [
          { typeId: null },
          { priorityId: null },
          { statusId: null }
        ]
      },
      data: {
        typeId: 'ticket_type_support', // Standard: Support-Anfrage
        priorityId: 'priority_normal', // Standard: Normal
        statusId: 'ticket_status_open' // Standard: Offen
      }
    })

    console.log(`📋 ${tasksUpdated.count} Tasks mit Standard-Werten versehen`)
    console.log(`🎫 ${ticketsUpdated.count} Tickets mit Standard-Werten versehen`)

    // 8. Statistiken
    console.log('\n📊 Enum-Initialisierung abgeschlossen:')
    const categoryCount = await prisma.enumCategory.count()
    const valueCount = await prisma.enumValue.count()
    const taskCount = await prisma.task.count()
    const ticketCount = await prisma.ticket.count()

    console.log(`  - Kategorien: ${categoryCount}`)
    console.log(`  - Enum-Werte: ${valueCount}`)
    console.log(`  - Tasks: ${taskCount}`)
    console.log(`  - Tickets: ${ticketCount}`)

    console.log('\n🎉 Dynamische Enums erfolgreich initialisiert!')

  } catch (error) {
    console.error('❌ Fehler bei der Enum-Initialisierung:', error)
    throw error
  }
}

// Hauptfunktion ausführen
async function main() {
  try {
    await initializeEnums()
  } catch (error) {
    console.error('Initialisierung fehlgeschlagen:', error)
    process.exit(1)
  } finally {
    await prisma.$disconnect()
  }
}

// Script ausführen
main()
