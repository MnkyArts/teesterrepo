// PM2 Ecosystem Configuration für wenoma Nuxt.js Application
module.exports = {
  apps: [
    {
      name: 'nuxt-app',
      script: '.output/server/index.mjs',
      
      // Instanzen
      instances: 1, // Anzahl der Instanzen (oder 'max' für alle CPU-Kerne)
      exec_mode: 'fork', // 'cluster' oder 'fork' - fork ist stabiler für einzelne Instanzen
      
      // Umgebungsvariablen
      env: {
        NODE_ENV: 'development',
        PORT: 3000,
        HOST: '0.0.0.0',
        APP_URL: 'http://localhost:3000',
        BETTER_AUTH_URL: 'http://localhost:3000'
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
        HOST: '0.0.0.0',
        NITRO_PORT: 3000,
        NITRO_HOST: '0.0.0.0',
        APP_URL: 'https://wenoma.wnm-intern.de/',
        BETTER_AUTH_URL: 'https://wenoma.wnm-intern.de/',
        
        // Redis Configuration
        REDIS_URL: 'redis://localhost:6379',
        
        // File Upload Configuration
        MAX_FILE_SIZE: '10485760',
        UPLOAD_DIR: './uploads',
        
        // Session Configuration
        SESSION_SECRET: 'your-super-secret-session-key-change-this-in-production'
      },
      
      // Performance und Monitoring
      max_memory_restart: '1G',
      log_file: './logs/combined.log',
      out_file: './logs/out.log',
      error_file: './logs/error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      
      // Auto-Restart Konfiguration
      watch: false, // In Produktion auf false
      ignore_watch: ['node_modules', 'logs'],
      
      // Graceful Shutdown
      kill_timeout: 5000,
      wait_ready: true,
      listen_timeout: 10000,
      
      // Health Check
      health_check_grace_period: 10000,
      
      // Advanced Settings
      node_args: '--max-old-space-size=1024',
      
      // Auto-restart bei Fehlern
      autorestart: true,
      max_restarts: 5,
      min_uptime: '10s',
      
      // Merge Logs
      merge_logs: true,
      
      // Time zone
      time: true
    }
  ],
  
  // Deployment Konfiguration (optional)
  deploy: {
    production: {
      user: 'node',
      host: 'wenoma.wnm-intern.de',
      ref: 'origin/main',
      repo: 'https://gitlab.wnm.de/EP/wenoma',
      path: '/var/www/production',
      'pre-deploy-local': '',
      'post-deploy': 'bun install && bun run build && pm2 reload ecosystem.config.cjs --env production',
      'pre-setup': ''
    }
  }
};
