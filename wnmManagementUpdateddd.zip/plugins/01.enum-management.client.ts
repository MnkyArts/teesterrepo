export default defineNuxtPlugin(async () => {
  const enumManagementStore = useEnumManagementStore()
  
  // Initialize enum data on app start with caching
  try {
    await enumManagementStore.fetchCategoriesIfNeeded(true) // Include values, with cache check
  } catch (error) {
    console.warn('Failed to initialize enum management data:', error)
    // Don't throw error to prevent app from failing to start
  }
})
