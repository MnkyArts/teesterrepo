import type { BetterAuthClientPlugin } from "better-auth/client";
import type { dynamicRoles } from "./dynamic-roles-server";
import type { BetterFetchOption } from "@better-fetch/fetch";
import type { Role, Permission } from "@prisma/client";
import { atom } from "nanostores";

export const dynamicRolesClient = () => {
  return {
    id: "dynamic-roles",
    $InferServerPlugin: {} as ReturnType<typeof dynamicRoles>,
    getActions: ($fetch) => {
      return {
        // Role management actions
        createRole: async (
          data: {
            name: string;
            displayName: string;
            description?: string;
            priority: number;
          },
          fetchOptions?: BetterFetchOption
        ) => {
          return $fetch("/dynamic-roles/create-role", {
            method: "POST",
            body: data,
            ...fetchOptions,
          });
        },

        updateRole: async (
          data: {
            roleId: string;
            displayName?: string;
            description?: string;
            priority?: number;
          },
          fetchOptions?: BetterFetchOption
        ) => {
          return $fetch("/dynamic-roles/update-role", {
            method: "POST",
            body: data,
            ...fetchOptions,
          });
        },

        deleteRole: async (
          data: { roleId: string },
          fetchOptions?: BetterFetchOption
        ) => {
          return $fetch("/dynamic-roles/delete-role", {
            method: "POST",
            body: data,
            ...fetchOptions,
          });
        },

        getRoles: async (fetchOptions?: BetterFetchOption) => {
          return $fetch("/dynamic-roles/get-roles", {
            method: "GET",
            ...fetchOptions,
          });
        },

        // Permission management actions
        createPermission: async (
          data: {
            name: string;
            displayName: string;
            description?: string;
            category: string;
          },
          fetchOptions?: BetterFetchOption
        ) => {
          return $fetch("/dynamic-roles/create-permission", {
            method: "POST",
            body: data,
            ...fetchOptions,
          });
        },

        getPermissions: async (fetchOptions?: BetterFetchOption) => {
          return $fetch("/dynamic-roles/get-permissions", {
            method: "GET",
            ...fetchOptions,
          });
        },

        // Role-Permission assignment
        assignPermissionToRole: async (
          data: {
            roleId: string;
            permissionId: string;
            granted: boolean;
            context?: string;
          },
          fetchOptions?: BetterFetchOption
        ) => {
          return $fetch("/dynamic-roles/assign-permission-to-role", {
            method: "POST",
            body: data,
            ...fetchOptions,
          });
        },

        // Get permissions assigned to a role
        getRolePermissions: async (
          data: { roleId: string },
          fetchOptions?: BetterFetchOption
        ) => {
          return $fetch("/dynamic-roles/get-role-permissions", {
            method: "GET",
            query: data,
            ...fetchOptions,
          });
        },

        // User-Role assignment
        assignRoleToUser: async (
          data: {
            userId: string;
            roleId: string;
            context?: string;
            expiresAt?: string;
          },
          fetchOptions?: BetterFetchOption
        ) => {
          return $fetch("/dynamic-roles/assign-role-to-user", {
            method: "POST",
            body: data,
            ...fetchOptions,
          });
        },

        // Permission checking
        checkUserPermission: async (
          data: {
            userId: string;
            permission: string;
            context?: string;
          },
          fetchOptions?: BetterFetchOption
        ) => {
          return $fetch("/dynamic-roles/check-user-permission", {
            method: "POST",
            body: data,
            ...fetchOptions,
          });
        },

        getUserPermissions: async (
          data: { userId: string },
          fetchOptions?: BetterFetchOption
        ) => {
          return $fetch("/dynamic-roles/get-user-permissions", {
            method: "GET",
            query: data,
            ...fetchOptions,
          });
        },

        // Get user roles
        getUserRoles: async (
          data: { userId: string },
          fetchOptions?: BetterFetchOption
        ) => {
          return $fetch("/dynamic-roles/get-user-roles", {
            method: "GET",
            query: data,
            ...fetchOptions,
          });
        },

        // Convenience method to check current user's permission
        hasPermission: async (
          permission: string,
          context?: string,
          fetchOptions?: BetterFetchOption
        ) => {
          return $fetch("/dynamic-roles/check-current-user-permission", {
            method: "POST",
            body: { permission, context },
            ...fetchOptions,
          });
        },

        // Refresh functions for updating atoms
        refreshUserPermissions: async (
          userId: string,
          fetchOptions?: BetterFetchOption
        ) => {
          try {
            const response = await $fetch("/dynamic-roles/get-user-permissions", {
              method: "GET",
              query: { userId },
              ...fetchOptions,
            }) as { permissions: string[] };
            
            return response;
          } catch (error) {
            console.error("Failed to refresh user permissions:", error);
            throw error;
          }
        },

        refreshAllRoles: async (fetchOptions?: BetterFetchOption) => {
          try {
            const response = await $fetch("/dynamic-roles/get-roles", {
              method: "GET",
              ...fetchOptions,
            }) as { roles: Role[] };
            
            return response;
          } catch (error) {
            console.error("Failed to refresh roles:", error);
            throw error;
          }
        },

        refreshAllPermissions: async (fetchOptions?: BetterFetchOption) => {
          try {
            const response = await $fetch("/dynamic-roles/get-permissions", {
              method: "GET",
              ...fetchOptions,
            }) as { permissions: Permission[] };
            
            return response;
          } catch (error) {
            console.error("Failed to refresh permissions:", error);
            throw error;
          }
        },
      };
    },
    getAtoms: ($fetch) => {
      // Atom for storing current user's permissions
      const userPermissionsAtom = atom<string[]>([]);
      
      // Atom for storing current user's roles
      const userRolesAtom = atom<Role[]>([]);
      
      // Atom for storing all available roles (for admin usage)
      const allRolesAtom = atom<Role[]>([]);
      
      // Atom for storing all available permissions (for admin usage)
      const allPermissionsAtom = atom<Permission[]>([]);

      return {
        userPermissions: userPermissionsAtom,
        userRoles: userRolesAtom,
        allRoles: allRolesAtom,
        allPermissions: allPermissionsAtom,
      };
    },
  } satisfies BetterAuthClientPlugin;
};