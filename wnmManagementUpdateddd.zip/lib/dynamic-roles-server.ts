import { createAuthEndpoint, sessionMiddleware } from "better-auth/api";
import type { BetterAuthPlugin } from "better-auth";
import { APIError } from "better-call";

interface DynamicRolesOptions {
  defaultRole?: string;
  superAdminRole?: string;
}

export const dynamicRoles = (options: DynamicRolesOptions = {}) => {
  const { defaultRole = "user", superAdminRole = "super-admin" } = options;

  return {
    id: "dynamic-roles",
    schema: {
      role: {
        fields: {
          name: {
            type: "string",
            required: true,
            unique: true,
          },
          displayName: {
            type: "string",
            required: true,
          },
          description: {
            type: "string",
          },
          priority: {
            type: "number",
            required: true,
          },
          isSystem: {
            type: "boolean",
            required: true,
          },
          createdAt: {
            type: "date",
            required: true,
          },
          updatedAt: {
            type: "date",
            required: true,
          },
        },
      },
      permission: {
        fields: {
          name: {
            type: "string",
            required: true,
            unique: true,
          },
          displayName: {
            type: "string",
            required: true,
          },
          description: {
            type: "string",
          },
          category: {
            type: "string",
            required: true,
          },
          isSystem: {
            type: "boolean",
            required: true,
          },
          createdAt: {
            type: "date",
            required: true,
          },
          updatedAt: {
            type: "date",
            required: true,
          },
        },
      },
      rolePermission: {
        fields: {
          roleId: {
            type: "string",
            required: true,
            references: {
              model: "role",
              field: "id",
              onDelete: "cascade",
            },
          },
          permissionId: {
            type: "string",
            required: true,
            references: {
              model: "permission",
              field: "id",
              onDelete: "cascade",
            },
          },
          granted: {
            type: "boolean",
            required: true,
          },
          context: {
            type: "string",
          },
          createdAt: {
            type: "date",
            required: true,
          },
        },
      },
      userRole: {
        fields: {
          userId: {
            type: "string",
            required: true,
            references: {
              model: "user",
              field: "id",
              onDelete: "cascade",
            },
          },
          roleId: {
            type: "string",
            required: true,
            references: {
              model: "role",
              field: "id",
              onDelete: "cascade",
            },
          },
          context: {
            type: "string",
          },
          expiresAt: {
            type: "date",
          },
          createdAt: {
            type: "date",
            required: true,
          },
        },
      },
      userPermission: {
        fields: {
          userId: {
            type: "string",
            required: true,
            references: {
              model: "user",
              field: "id",
              onDelete: "cascade",
            },
          },
          permissionId: {
            type: "string",
            required: true,
            references: {
              model: "permission",
              field: "id",
              onDelete: "cascade",
            },
          },
          granted: {
            type: "boolean",
            required: true,
          },
          context: {
            type: "string",
          },
          expiresAt: {
            type: "date",
          },
          createdAt: {
            type: "date",
            required: true,
          },
        },
      },
    },
    init: (ctx) => {
      // Store adapter reference for role assignment
      const adapter = ctx.adapter;
      
      return {
        context: {
          ...ctx,
          dynamicRoles: {
            assignDefaultRole: async (userId: string) => {
              const defaultRoleRecord = await adapter.findOne({
                model: "role",
                where: [{ field: "name", value: defaultRole }],
              });

              if (defaultRoleRecord) {
                await adapter.create({
                  model: "userRole",
                  data: {
                    userId,
                    roleId: (defaultRoleRecord as any).id,
                    createdAt: new Date(),
                  },
                });
              }
            }
          }
        }
      };
    },
    endpoints: {
      // Role management endpoints
      createRole: createAuthEndpoint("/dynamic-roles/create-role", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        const hasPermission = await checkPermission(ctx, session.user.id, "roles.create");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { name, displayName, description, priority } = ctx.body;
        
        const now = new Date();
        const role = await ctx.context.adapter.create({
          model: "role",
          data: {
            name,
            displayName,
            description,
            priority,
            isSystem: false,
            createdAt: now,
            updatedAt: now,
          },
        });

        return ctx.json({ role });
      }),

      updateRole: createAuthEndpoint("/dynamic-roles/update-role", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        const hasPermission = await checkPermission(ctx, session.user.id, "roles.update");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { roleId, displayName, description, priority } = ctx.body;
        
        const role = await ctx.context.adapter.update({
          model: "role",
          where: [{ field: "id", value: roleId }],
          update: {
            displayName,
            description,
            priority,
            updatedAt: new Date(),
          },
        });

        return ctx.json({ role });
      }),

      deleteRole: createAuthEndpoint("/dynamic-roles/delete-role", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        const hasPermission = await checkPermission(ctx, session.user.id, "roles.delete");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { roleId } = ctx.body;
        
        // Check if it's a system role
        const role = await ctx.context.adapter.findOne({
          model: "role",
          where: [{ field: "id", value: roleId }],
        });

        if (role && (role as any).isSystem) {
          throw new APIError("BAD_REQUEST", { message: "Cannot delete system role" });
        }

        await ctx.context.adapter.delete({
          model: "role",
          where: [{ field: "id", value: roleId }],
        });

        return ctx.json({ success: true });
      }),

      getRoles: createAuthEndpoint("/dynamic-roles/get-roles", {
        method: "GET",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        const hasPermission = await checkPermission(ctx, session.user.id, "roles.view");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const roles = await ctx.context.adapter.findMany({
          model: "role",
          sortBy: { field: "priority", direction: "desc" },
        });

        return ctx.json({ roles });
      }),

      // Permission management endpoints
      createPermission: createAuthEndpoint("/dynamic-roles/create-permission", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        const hasPermission = await checkPermission(ctx, session.user.id, "permissions.create");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { name, displayName, description, category } = ctx.body;
        
        const now = new Date();
        const permission = await ctx.context.adapter.create({
          model: "permission",
          data: {
            name,
            displayName,
            description,
            category,
            isSystem: false,
            createdAt: now,
            updatedAt: now,
          },
        });

        return ctx.json({ permission });
      }),

      getPermissions: createAuthEndpoint("/dynamic-roles/get-permissions", {
        method: "GET",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        const hasPermission = await checkPermission(ctx, session.user.id, "permissions.view");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const permissions = await ctx.context.adapter.findMany({
          model: "permission",
          sortBy: { field: "category", direction: "asc" },
        });

        return ctx.json({ permissions });
      }),

      // Role-Permission assignment
      assignPermissionToRole: createAuthEndpoint("/dynamic-roles/assign-permission-to-role", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        const hasPermission = await checkPermission(ctx, session.user.id, "roles.manage-permissions");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { roleId, permissionId, granted, context } = ctx.body;
        
        // Check if assignment already exists
        const existing = await ctx.context.adapter.findOne({
          model: "rolePermission",
          where: [
            { field: "roleId", value: roleId },
            { field: "permissionId", value: permissionId }
          ],
        });

        if (existing) {
          // Update existing assignment
          await ctx.context.adapter.update({
            model: "rolePermission",
            where: [{ field: "id", value: (existing as any).id }],
            update: { granted, context },
          });
        } else {
          // Create new assignment
          await ctx.context.adapter.create({
            model: "rolePermission",
            data: {
              roleId,
              permissionId,
              granted,
              context,
              createdAt: new Date(),
            },
          });
        }

        return ctx.json({ success: true });
      }),

      // User-Role assignment
      assignRoleToUser: createAuthEndpoint("/dynamic-roles/assign-role-to-user", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        const hasPermission = await checkPermission(ctx, session.user.id, "users.manage-roles");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { userId, roleId, context, expiresAt } = ctx.body;
        
        // Check if assignment already exists
        const existing = await ctx.context.adapter.findOne({
          model: "userRole",
          where: [
            { field: "userId", value: userId },
            { field: "roleId", value: roleId }
          ],
        });

        if (existing) {
          throw new APIError("BAD_REQUEST", { message: "User already has this role" });
        }

        await ctx.context.adapter.create({
          model: "userRole",
          data: {
            userId,
            roleId,
            context,
            expiresAt: expiresAt ? new Date(expiresAt) : undefined,
            createdAt: new Date(),
          },
        });

        return ctx.json({ success: true });
      }),

      // User permission check
      checkUserPermission: createAuthEndpoint("/dynamic-roles/check-user-permission", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        const { userId, permission, context } = ctx.body;
        
        // Only allow users to check their own permissions unless they have admin rights
        if (userId !== session.user.id) {
          const hasPermission = await checkPermission(ctx, session.user.id, "users.view-permissions");
          if (!hasPermission) {
            throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
          }
        }

        const hasPermission = await checkPermission(ctx, userId, permission, context);
        
        return ctx.json({ hasPermission });
      }),

      // Get user permissions
      getUserPermissions: createAuthEndpoint("/dynamic-roles/get-user-permissions", {
        method: "GET",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        const userId = ctx.query?.userId as string;
        
        // Only allow users to view their own permissions unless they have admin rights
        if (userId !== session.user.id) {
          const hasPermission = await checkPermission(ctx, session.user.id, "users.view-permissions");
          if (!hasPermission) {
            throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
          }
        }

        const permissions = await getUserPermissions(ctx, userId);
        
        return ctx.json({ permissions });
      }),

      // Get user roles
      getUserRoles: createAuthEndpoint("/dynamic-roles/get-user-roles", {
        method: "GET",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        const userId = ctx.query?.userId as string;
        
        // Only allow users to view their own roles unless they have admin rights
        if (userId !== session.user.id) {
          const hasPermission = await checkPermission(ctx, session.user.id, "users.view-roles");
          if (!hasPermission) {
            throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
          }
        }

        const roles = await getUserRoles(ctx, userId);
        
        return ctx.json({ roles });
      }),

      // Check current user's permission (convenience endpoint)
      checkCurrentUserPermission: createAuthEndpoint("/dynamic-roles/check-current-user-permission", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        const { permission, context } = ctx.body;
        
        const hasPermission = await checkPermission(ctx, session.user.id, permission, context);
        
        return ctx.json({ hasPermission });
      }),

      // Assign default role to user (internal endpoint)
      assignDefaultRole: createAuthEndpoint("/dynamic-roles/assign-default-role", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        // Only allow system/admin users to assign default roles
        const hasPermission = await checkPermission(ctx, session.user.id, "users.manage-roles");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { userId } = ctx.body;
        
        // Check if user already has roles
        const existingRoles = await ctx.context.adapter.findMany({
          model: "userRole",
          where: [{ field: "userId", value: userId }],
        });

        if (existingRoles.length > 0) {
          return ctx.json({ message: "User already has roles assigned" });
        }

        // Assign default role
        const defaultRoleRecord = await ctx.context.adapter.findOne({
          model: "role",
          where: [{ field: "name", value: defaultRole }],
        });

        if (defaultRoleRecord) {
          await ctx.context.adapter.create({
            model: "userRole",
            data: {
              userId,
              roleId: (defaultRoleRecord as any).id,
              createdAt: new Date(),
            },
          });
        }

        return ctx.json({ success: true });
      }),

      // Get permissions assigned to a role
      getRolePermissions: createAuthEndpoint("/dynamic-roles/get-role-permissions", {
        method: "GET",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Not authenticated" });
        }

        const hasPermission = await checkPermission(ctx, session.user.id, "roles.view");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const roleId = ctx.query?.roleId as string;
        
        // Get role permissions
        const rolePermissions = await ctx.context.adapter.findMany({
          model: "rolePermission",
          where: [
            { field: "roleId", value: roleId },
            { field: "granted", value: true }
          ],
        });

        // Get permission details
        const permissions = [];
        for (const rolePermission of rolePermissions) {
          const permission = await ctx.context.adapter.findOne({
            model: "permission",
            where: [{ field: "id", value: (rolePermission as any).permissionId }],
          });
          if (permission) {
            permissions.push(permission);
          }
        }

        return ctx.json({ permissions });
      }),
    },
  } satisfies BetterAuthPlugin;
};

// Helper function to check if user has permission
async function checkPermission(ctx: any, userId: string, permission: string, context?: string): Promise<boolean> {
  // Get user's roles (non-expired)
  const userRoles = await ctx.context.adapter.findMany({
    model: "userRole",
    where: [
      { field: "userId", value: userId },
      ...(context ? [{ field: "context", value: context }] : [])
    ],
  });

  // Filter out expired roles
  const now = new Date();
  const activeRoles = userRoles.filter((ur: any) => !ur.expiresAt || new Date(ur.expiresAt) > now);

  // Check direct user permissions first
  const directPermissions = await ctx.context.adapter.findMany({
    model: "userPermission",
    where: [
      { field: "userId", value: userId },
      ...(context ? [{ field: "context", value: context }] : [])
    ],
  });

  // Get permission record
  const permissionRecord = await ctx.context.adapter.findOne({
    model: "permission",
    where: [{ field: "name", value: permission }],
  });

  if (!permissionRecord) {
    return false;
  }

  // Check direct user permissions
  const directPermission = directPermissions.find((dp: any) => 
    dp.permissionId === (permissionRecord as any).id && 
    (!dp.expiresAt || new Date(dp.expiresAt) > now)
  );

  if (directPermission) {
    return directPermission.granted;
  }

  // Check permissions through roles
  for (const userRole of activeRoles) {
    const rolePermissions = await ctx.context.adapter.findMany({
      model: "rolePermission",
      where: [
        { field: "roleId", value: userRole.roleId },
        { field: "permissionId", value: (permissionRecord as any).id }
      ],
    });

    for (const rolePermission of rolePermissions) {
      if (rolePermission.granted) {
        return true;
      }
    }
  }

  return false;
}

// Helper function to get all user permissions
async function getUserPermissions(ctx: any, userId: string): Promise<string[]> {
  const permissions = new Set<string>();
  
  // Get user's roles (non-expired)
  const userRoles = await ctx.context.adapter.findMany({
    model: "userRole",
    where: [{ field: "userId", value: userId }],
  });

  // Filter out expired roles
  const now = new Date();
  const activeRoles = userRoles.filter((ur: any) => !ur.expiresAt || new Date(ur.expiresAt) > now);

  // Get permissions from roles
  for (const userRole of activeRoles) {
    const rolePermissions = await ctx.context.adapter.findMany({
      model: "rolePermission",
      where: [
        { field: "roleId", value: userRole.roleId },
        { field: "granted", value: true }
      ],
    });

    for (const rolePermission of rolePermissions) {
      const permission = await ctx.context.adapter.findOne({
        model: "permission",
        where: [{ field: "id", value: rolePermission.permissionId }],
      });
      if (permission) {
        permissions.add((permission as any).name);
      }
    }
  }

  // Get direct user permissions
  const directPermissions = await ctx.context.adapter.findMany({
    model: "userPermission",
    where: [
      { field: "userId", value: userId },
      { field: "granted", value: true }
    ],
  });

  const activeDirectPermissions = directPermissions.filter((up: any) => !up.expiresAt || new Date(up.expiresAt) > now);

  for (const userPermission of activeDirectPermissions) {
    const permission = await ctx.context.adapter.findOne({
      model: "permission",
      where: [{ field: "id", value: userPermission.permissionId }],
    });
    if (permission) {
      permissions.add((permission as any).name);
    }
  }

  return Array.from(permissions);
}

// Helper function to get all user roles
async function getUserRoles(ctx: any, userId: string): Promise<any[]> {
  // Get user's roles (non-expired)
  const userRoles = await ctx.context.adapter.findMany({
    model: "userRole",
    where: [{ field: "userId", value: userId }],
  });

  // Filter out expired roles
  const now = new Date();
  const activeUserRoles = userRoles.filter((ur: any) => !ur.expiresAt || new Date(ur.expiresAt) > now);

  // Get role details
  const roles = [];
  for (const userRole of activeUserRoles) {
    const role = await ctx.context.adapter.findOne({
      model: "role",
      where: [{ field: "id", value: userRole.roleId }],
    });
    if (role) {
      roles.push(role);
    }
  }

  return roles;
}