import { createAuthClient } from "better-auth/vue";
import { inferAdditionalFields } from "better-auth/client/plugins";
import { adminClient } from "better-auth/client/plugins";
import { customSessionClient } from "better-auth/client/plugins";
import type { auth } from "./auth";
import { dynamicRolesClient } from "./dynamic-roles-client";
import type { UserRole, UserPermission } from "@prisma/client";

export const authClient = createAuthClient({
    plugins: [
		inferAdditionalFields<typeof auth>(),
        adminClient(),
        customSessionClient<typeof auth>(),
        dynamicRolesClient()
    ]
})

export const {
	signIn,
	signOut,
	signUp,
	useSession,
	requestPasswordReset,
	resetPassword,
} = authClient;

export type Session = typeof authClient.$Infer.Session
export type User = Session['user'];