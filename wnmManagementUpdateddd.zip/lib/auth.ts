import { betterAuth } from "better-auth";
import type { BetterAuthOptions } from "better-auth";
import { admin } from "better-auth/plugins"
import { customSession } from "better-auth/plugins";
import { dynamicRoles } from "./dynamic-roles-server";
import { prismaAdapter } from "better-auth/adapters/prisma";
import { PrismaClient } from "@prisma/client";
import type { UserRole, UserPermission } from "@prisma/client";

const prisma = new PrismaClient();

// Define options first to enable proper type inference
const options = {
  database: prismaAdapter(prisma, {
    provider: "postgresql",
  }),

  plugins: [
      admin(),
      dynamicRoles({
        defaultRole: "user",
        superAdminRole: "super-admin",
      }),
  ],
  
  baseURL: process.env.BETTER_AUTH_URL || process.env.APP_URL || "http://localhost:3000",
  
  emailAndPassword: {
    enabled: true,
    autoSignIn: true,
  },

  session: {
      cookieCache: {
          enabled: true,
          maxAge: 5 * 60
      }
  },
  
  user: {
    modelName: "user",
    additionalFields: {
      firstName: {
        type: "string",
        required: true,
      },
      lastName: {
        type: "string", 
        required: true,
      },
      role: {
        type: "string",
        required: true,
        defaultValue: "user",
        input: false,
      },
      isActive: {
        type: "boolean",
        required: true,
        defaultValue: true,
      },
      lastLoginAt: {
        type: "date",
        required: false,
      },
    },
  },
} satisfies BetterAuthOptions;

export const auth = betterAuth({
  ...options,
  plugins: [
    ...(options.plugins ?? []),
    customSession(async ({ user, session }, ctx) => {
      if (!user?.id) {
        return { user, session };
      }

      try {
        // Get user roles (unique per user)
        const userRoles = await prisma.$queryRaw`
          SELECT DISTINCT
            r.id,
            r.name,
            r."displayName",
            r.description,
            r.priority,
            r."isSystem"
          FROM users u
          JOIN "userRole" ur ON u.id = ur."userId"
          JOIN role r ON ur."roleId" = r.id
          WHERE u.id = ${user.id}
        ` as Array<{
          id: string;
          name: string;
          displayName: string;
          description: string | null;
          priority: number;
          isSystem: boolean;
        }>;

        // Get all permissions (direct + role-based) in one query
        const userPermissions = await prisma.$queryRaw`
          SELECT DISTINCT p.name
          FROM users u
          LEFT JOIN "userRole" ur ON u.id = ur."userId"
          LEFT JOIN "rolePermission" rp ON ur."roleId" = rp."roleId" AND rp.granted = true
          LEFT JOIN permission p ON rp."permissionId" = p.id
          WHERE u.id = ${user.id}
          
          UNION
          
          SELECT DISTINCT p.name
          FROM users u
          JOIN "userPermission" up ON u.id = up."userId" AND up.granted = true
          JOIN permission p ON up."permissionId" = p.id
          WHERE u.id = ${user.id}
        ` as Array<{ name: string }>;

        return {
          user: {
            ...user,
            userroles: userRoles,
            userpermissions: userPermissions.map(p => p.name).filter(Boolean)
          },
          session
        };
      } catch (error) {
        console.error('Error enriching session:', error);
        return { user, session };
      }
    }, options),
  ],
});

export type Session = typeof auth.$Infer.Session;
export type User = Session['user'];