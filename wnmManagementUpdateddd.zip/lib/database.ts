import { PrismaClient } from '@prisma/client'

// Singleton pattern für Prisma Client
declare global {
  var __prisma: PrismaClient | undefined
}

let prisma: PrismaClient

if (process.env.NODE_ENV === 'production') {
  prisma = new PrismaClient()
} else {
  if (!global.__prisma) {
    global.__prisma = new PrismaClient({
      log: ['query', 'info', 'warn', 'error']
    })
  }
  prisma = global.__prisma
}

export { prisma }

// Helper-Funktionen für häufige Datenbankoperationen
export class DatabaseHelper {
  /**
   * Überprüft Datenbankverbindung
   */
  static async checkConnection(): Promise<boolean> {
    try {
      await prisma.$queryRaw`SELECT 1`
      return true
    } catch (error) {
      console.error('Datenbankverbindung fehlgeschlagen:', error)
      return false
    }
  }

  /**
   * Schließt Datenbankverbindung
   */
  static async disconnect(): Promise<void> {
    await prisma.$disconnect()
  }

  /**
   * Führt eine Transaktion aus
   */
  static async transaction<T>(fn: (prisma: Omit<PrismaClient, '$connect' | '$disconnect' | '$on' | '$transaction' | '$use' | '$extends'>) => Promise<T>): Promise<T> {
    return await prisma.$transaction(fn)
  }

  /**
   * Soft Delete für Benutzer (deaktiviert statt löscht)
   */
  static async softDeleteUser(userId: string): Promise<void> {
    await prisma.user.update({
      where: { id: userId },
      data: { isActive: false }
    })
  }

  /**
   * Aktiviert einen deaktivierten Benutzer
   */
  static async activateUser(userId: string): Promise<void> {
    await prisma.user.update({
      where: { id: userId },
      data: { isActive: true }
    })
  }

  /**
   * Holt aktive Benutzer mit Paginierung
   */
  static async getActiveUsers(page: number = 1, limit: number = 20) {
    const skip = (page - 1) * limit
    
    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where: { isActive: true },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          role: true,
          image: true,
          lastLoginAt: true,
          createdAt: true
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' }
      }),
      prisma.user.count({ where: { isActive: true } })
    ])

    return {
      users,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      }
    }
  }

  /**
   * Erstellt automatisch Projekt für neuen Kunden
   */
  static async createCustomerWithProject(customerData: {
    companyName: string
    contactName: string
    email: string
    phone?: string
    address?: string
    city?: string
    postalCode?: string
  }) {
    return await prisma.$transaction(async (tx) => {
      // Kunde erstellen
      const customer = await tx.customer.create({
        data: customerData
      })

      // Automatisches Projekt erstellen
      const projectKey = `CUST-${customer.id.slice(-6).toUpperCase()}`
      const project = await tx.project.create({
        data: {
          key: projectKey,
          name: `${customer.companyName} - Hauptprojekt`,
          description: `Automatisch erstelltes Projekt für Kunde ${customer.companyName}`,
          customerId: customer.id
        }
      })

      return { customer, project }
    })
  }

  /**
   * Generiert eindeutigen Task-Key
   */
  static async generateTaskKey(projectId: string): Promise<string> {
    const project = await prisma.project.findUnique({
      where: { id: projectId },
      select: { key: true }
    })

    if (!project) {
      throw new Error('Projekt nicht gefunden')
    }

    const taskCount = await prisma.task.count({
      where: { projectId }
    })

    return `${project.key}-${String(taskCount + 1).padStart(3, '0')}`
  }

  /**
   * Holt Dashboard-Statistiken
   */
  static async getDashboardStats(userId?: string) {
    const [
      totalProjects,
      activeProjects,
      totalTasks,
      myTasks,
      completedTasks,
      totalUsers
    ] = await Promise.all([
      prisma.project.count(),
      prisma.project.count({ where: { status: 'AKTIV' } }),
      prisma.task.count(),
      userId ? prisma.task.count({ 
        where: { 
          assigneeId: userId, 
          status: { 
            key: { not: 'ERLEDIGT' }
          } 
        } 
      }) : 0,
      prisma.task.count({ 
        where: { 
          status: { 
            key: 'ERLEDIGT' 
          } 
        } 
      }),
      prisma.user.count({ where: { isActive: true } })
    ])

    return {
      totalProjects,
      activeProjects,
      totalTasks,
      myTasks,
      completedTasks,
      totalUsers,
      completionRate: totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0
    }
  }
}
