# wenoma - Entwicklerhandbuch Konzept

## 1. Projektübersicht

**wenoma** ist eine intern entwickelte, umfassende Projektmanagement- und Issue-Tracking-Software, die als vollwertige Jira-Alternative konzipiert ist. Das System kombiniert ein internes Projektmanagement-Tool mit einem integrierten Kundencenter und bildet somit eine einheitliche Plattform für die gesamte Projektabwicklung.

### 1.1 Technologie-Stack
- **Frontend Framework**: Nuxt.js (Vue.js basiert)
- **CSS Framework**: TailwindCSS 4
- **Sprache**: Deutsch (vollständige Lokalisierung)
- **Architektur**: Modularer Aufbau mit klarer Trennung zwischen Projektmanagement und Kundencenter

## 2. Kernmodule des Systems

### 2.1 Projektmanagement-Modul (Interner Bereich)

#### 2.1.1 Aufgaben/Issues System
Das Herzstück des Systems bildet ein flexibles Aufgabenverwaltungssystem mit folgenden Eigenschaften:

**Aufgabenstruktur:**
- **Zusammenfassung**: Kurze, prägnante Beschreibung der Aufgabe
- **Beschreibung**: Detaillierte Aufgabenbeschreibung mit Rich-Text-Editor
- **Typ**: Dynamisch konfigurierbare Aufgabentypen (Bug, Feature, Verbesserung, etc.)
- **Priorität**: Anpassbare Prioritätsstufen (Niedrig, Normal, Hoch, Kritisch)
- **Anhänge**: Mehrfach-Datei-Upload mit Versionierung
- **Fälligkeitsdatum**: Terminplanung mit Kalenderintegration
- **Aufgabenverantwortlicher**: Zugewiesener Benutzer mit Benachrichtigungssystem
- **Ursprüngliche Schätzung**: Zeitaufwandsschätzung in Stunden/Tagen
- **Verbleibende Arbeit**: Dynamisch aktualisierbare Restarbeitszeit
- **Kommentare**: Threaded-Kommentarsystem mit @-Mentions
- **Team-Zuweisung**: Aufgaben können Teams oder Einzelpersonen zugewiesen werden

**Status-Management:**
- Vollständig konfigurierbare Workflow-Status
- Standard-Stati: "Geplant", "Technisches Design", "In Bearbeitung", "Review", "Testing", "Erledigt"
- Drag & Drop Status-Änderungen (Kanban-Board)
- Status-Übergangsbeschränkungen und Validierungen
- Automatische Benachrichtigungen bei Status-Änderungen

**Zeiterfassung:**
- Granulare Zeitbuchung mit Start/Stop-Timer
- Beschreibungsfeld für gebuchte Zeit
- Kategorisierung der Zeitbuchungen (Entwicklung, Testing, Meetings, etc.)
- Zeiterfassungsberichte und Auswertungen
- Integration mit Lohnabrechnung-Schnittstellen

#### 2.1.2 Aktivitätsverfolgung
Umfassendes Audit-Log-System für vollständige Nachverfolgbarkeit:
- Automatische Protokollierung aller Aktionen
- Zeitstempel mit Benutzerinformationen
- Änderungshistorie mit Vorher/Nachher-Vergleich
- Datei-Upload/Download-Tracking
- Kommentar- und Bearbeitungshistorie
- Export-/Import-Aktivitäten
- System-Events und automatische Aktionen

#### 2.1.3 Projekt-Management
Hierarchische Projektstruktur für optimale Organisation:

**Projektstruktur:**
- Automatische Projekterstellung für neue Kunden
- Naming-Convention: "{Kunden-ID} | {Kundenname}"
- Projekt-Dashboards mit KPI-Übersichten
- Projektspezifische Einstellungen und Workflows
- Team-Zuweisungen auf Projektebene
- Projektvorlagen für wiederkehrende Strukturen

**Projekt-Features:**
- Gantt-Charts für Projektplanung
- Meilenstein-Tracking
- Ressourcenplanung und -allokation
- Projekt-Budgetierung und Kostenverfolgung
- Projekt-Berichte und Analytics
- Archivierung abgeschlossener Projekte

### 2.2 Benutzerverwaltung und Rechtesystem

#### 2.2.1 Erweiterte Rechteverwaltung
Granulares, rollenbasiertes Berechtigungssystem durch Better Auth:

**Benutzergruppen:**
- **Administratoren**: Vollzugriff auf alle Systembereiche
- **Projektleiter**: Projektmanagement und Team-Koordination
- **Entwickler**: Aufgabenbearbeitung und Zeiterfassung
- **Supporter**: Kundencenter und Ticket-Bearbeitung
- **Viewer**: Nur-Lese-Zugriff für Stakeholder
- **Kunden**: Zugriff nur auf Kundencenter-Bereiche

**Rechteverwaltung:**
- Objektbasierte Berechtigungen (Projekt-, Aufgaben-, Kommentar-Ebene)
- Vererbung von Rechten durch Hierarchien
- Temporäre Rechte-Delegation
- Audit-Trail für Rechte-Änderungen
- Bulk-Rechteverwaltung für Teams
- Custom-Rollen für spezielle Anforderungen

#### 2.2.2 Benutzerprofile und -einstellungen
- Detaillierte Benutzerprofile mit Kontaktinformationen
- Personalisierte Dashboards und Ansichten
- Benachrichtigungseinstellungen (E-Mail, Browser, Slack-Integration)
- Arbeitszeitmodelle und Verfügbarkeitskalender
- Skill-Matrix und Kompetenz-Tracking
- Urlaubsplanung und Abwesenheitsverwaltung

### 2.3 Dashboard und Benutzeroberflächen

#### 2.3.1 Haupt-Dashboard
Zentrale Übersichtsseite für alle Benutzer:
- **Meine Aufgaben**: Zugewiesene Tasks mit Prioritäts-Sortierung
- **Kürzlich bearbeitet**: Letzte Aktivitäten des Benutzers
- **Team-Aktivitäten**: Live-Feed der Teamkollegen-Aktivitäten
- **Projekt-Übersicht**: Status aktiver Projekte
- **Zeiterfassung-Widget**: Schneller Zugriff auf Timer-Funktionen
- **Benachrichtigungen**: Wichtige Updates und Mentions
- **Kalender-Integration**: Anstehende Termine und Deadlines

#### 2.3.2 Tempo-ähnliche Zeiterfassungsansicht
Professionelle Zeitverwaltung nach Vorbild von Jira Tempo:
- **Wochenansicht**: Zeitbuchungen in Kalender-Format
- **Timesheets**: Detaillierte Stundenzettel mit Projektzuordnung
- **Berichte**: Verschiedene Zeiterfassungsauswertungen
- **Projektzeit-Tracking**: Aufschlüsselung nach Projekten und Kunden
- **Billable vs Non-Billable**: Unterscheidung abrechenbarer Stunden
- **Export-Funktionen**: CSV, PDF für Abrechnungszwecke
- **Genehmigungsworkflows**: Stundenzettel-Freigabeprozesse

#### 2.3.3 Anpassbare Ansichten
- Kanban-Boards mit Swim-Lanes
- Listenansichten mit erweiterten Filtern
- Gantt-Chart-Darstellungen
- Kalender-Ansichten für Termine und Deadlines
- Agile-Boards für Scrum/Kanban-Workflows
- Custom-Dashboards mit Widgets

## 3. Kundencenter-Modul

### 3.1 Kundenregistrierung und -verwaltung
Automatisierte Kundenaufnahme mit nahtloser Integration:

**Registrierungsprozess:**
- Self-Service-Registrierung mit E-Mail-Verifizierung
- Automatische Projekterstellung bei neuer Kundenregistrierung
- KYC-Prozess (Know Your Customer) mit Dokumenten-Upload
- Begrüßungs-E-Mails mit Zugangsdaten
- Onboarding-Checklisten und Tutorials

**Kundendatenmanagement:**
- Vollständige Kontaktinformationen mit Versionierung
- Firmen-Hierarchien und Ansprechpartner-Verwaltung
- Automatische Sync mit CRM-Systemen
- DSGVO-konforme Datenverarbeitung
- Kundengruppen und Segmentierung

### 3.2 Rechnungswesen-Integration

#### 3.2.1 Rechnungsmodul
Umfassende Rechnungsverwaltung für Kundentransparenz:
- **Rechnungsübersicht**: Chronologische Auflistung aller Rechnungen
- **PDF-Download**: Direkter Zugriff auf Rechnungs-PDFs
- **Zahlungsstatus**: Real-time Zahlungsstatusanzeige
- **Rechnungsdetails**: Aufschlüsselung nach Positionen und Leistungen
- **Mahnwesen**: Automatisierte Erinnerungen und Mahnungen
- **Steuerliche Dokumente**: Jahresübersichten und Steuerbescheinigungen

#### 3.2.2 SEPA-Mandatsverwaltung
Sichere Verwaltung von Zahlungsinformationen:
- **Mandatserfassung**: Benutzerfreundliche SEPA-Datenerfassung
- **Validierung**: Automatische IBAN-Prüfung und -Validierung
- **Verschlüsselung**: Sichere Speicherung sensibler Zahlungsdaten
- **Mandatshistorie**: Nachverfolgung von Änderungen und Kündigungen
- **Compliance**: SEPA-konforme Verarbeitung und Archivierung

### 3.3 Ticket-System für Kunden

#### 3.3.1 Ticket-Erstellung
Intuitive Ticket-Erstellung mit intelligenter Weiterleitung:
- **Abteilungsauswahl**: Dropdown mit verfügbaren Supportbereichen
- **Prioritätseinstufung**: Kundenseitige Prioritätsbewertung
- **Rich-Text-Editor**: Formatierte Beschreibungen mit Bildern
- **Datei-Anhänge**: Multiple File-Upload mit Virenscanning
- **Ticket-Vorlagen**: Häufige Anfragen als Vorlagen
- **Automatische Kategorisierung**: KI-basierte Ticket-Klassifizierung

#### 3.3.2 Ticket-Verfolgung
Transparente Kommunikation über Ticket-Status:
- **Status-Updates**: Real-time Benachrichtigungen über Änderungen
- **Kommentar-System**: Bidirektionale Kommunikation mit Support
- **Eskalations-Management**: Automatische Weiterleitung bei Überschreitungen
- **Zufriedenheitsbewertung**: Post-Resolution Feedback-System
- **Ticket-Historie**: Vollständige Nachverfolgung aller Aktivitäten

### 3.4 Rechtliche Compliance

#### 3.4.1 AV-Vertrag (Auftragsverarbeitungsvertrag)
DSGVO-konforme Datenverarbeitung:
- **Digitale Unterzeichnung**: Rechtsgültige elektronische Signaturen
- **Vertragsversionierung**: Nachverfolgung von Vertragsänderungen
- **Automatische Updates**: Benachrichtigung bei Vertragsanpassungen
- **Compliance-Dashboard**: Übersicht über alle rechtlichen Dokumente
- **Audit-Protokolle**: Dokumentation für Datenschutz-Audits

## 4. Systemintegration und Architektur

### 4.1 Nahtlose Integration
Bidirektionale Verbindung zwischen Projektmanagement und Kundencenter:

**Datenfluss:**
- Automatische Projekterstellung bei Kundenregistrierung
- Ticket-zu-Task-Konvertierung mit einem Klick
- Unified Customer View für interne Mitarbeiter
- Synchronisierte Kommunikationshistorie
- Cross-System-Benachrichtigungen
- Gemeinsame Dateiverwaltung

**API-Architektur:**
- RESTful API für alle Systemkomponenten
- GraphQL für komplexe Datenabfragen
- Webhook-System für Real-time-Updates
- OAuth 2.0 für sichere Authentifizierung
- Rate-Limiting und API-Versioning

### 4.2 Erweiterte Konfiguration

#### 4.2.1 Dynamische Systemanpassungen
Vollständig anpassbares System ohne Code-Änderungen:
- **Status-Management**: Drag & Drop Workflow-Designer
- **Feldkonfiguration**: Custom Fields für alle Objekttypen
- **Automatisierungsregeln**: If-Then-Else Regelwerk
- **Benachrichtigungsvorlagen**: HTML-E-Mail-Templates
- **Berichtsgenerator**: Drag & Drop Report-Builder
- **Dashboard-Widgets**: Konfigurierbare UI-Komponenten

#### 4.2.2 Import/Export-Funktionalitäten
- **Jira-Migration**: Automatischer Import bestehender Jira-Daten
- **CSV/Excel-Support**: Bulk-Import für Stammdaten
- **Backup/Restore**: Vollständige Systemsicherung
- **Data-Warehousing**: Integration mit BI-Tools
- **API-Exports**: Programmatischer Datenzugriff

## 5. Erweiterte Features und Zusatzmodule

### 5.1 Business Intelligence und Reporting

#### 5.1.1 Analytics Dashboard
- **KPI-Tracking**: Projekt-Performance-Metriken
- **Burndown-Charts**: Agile Projektfortschritt
- **Resource-Utilization**: Teammitglieder-Auslastung
- **Customer-Satisfaction**: Kundenzufriedenheits-Trends
- **Financial-Reporting**: Umsatz- und Kostenanalysen
- **Predictive Analytics**: Projektabschluss-Prognosen

#### 5.1.2 Erweiterte Berichte
- **Zeiterfassungsberichte**: Detaillierte Stundenauswertungen
- **Projektrentabilität**: ROI-Analysen pro Projekt
- **Team-Performance**: Individuelle und Gruppen-Statistiken
- **SLA-Monitoring**: Service-Level-Agreement Tracking
- **Trend-Analysen**: Historische Datenauswertungen

### 5.2 Kommunikation und Kollaboration

#### 5.2.1 Integrierte Kommunikation
- Benötigt keine

#### 5.2.2 Externe Integrationen
- Webhook Support

### 5.3 Mobile Unterstützung

#### 5.3.1 Progressive Web App (PWA)
- Vebötigt keine

## 6. Sicherheit und Compliance

### 6.1 Datenschutz und Sicherheit

#### 6.1.1 Technische Sicherheitsmaßnahmen
- **End-to-End-Verschlüsselung**: Für alle sensiblen Datenübertragungen
- **Multi-Factor-Authentication**: TOTP/SMS/Hardware-Token Support
- **Session-Management**: Sichere Session-Handling mit Timeout
- **SQL-Injection-Schutz**: Prepared Statements und Input-Validation
- **XSS-Protection**: Content Security Policy und Input-Sanitization
- **CSRF-Token**: Schutz vor Cross-Site Request Forgery

#### 6.1.2 DSGVO-Compliance
- **Right to be Forgotten**: Automatisierte Datenlöschung
- **Data Portability**: Export-Funktionen für persönliche Daten
- **Consent Management**: Granulare Einwilligungsverwaltung
- **Data Processing Records**: Vollständige Verarbeitungsdokumentation
- **Privacy by Design**: Datenschutz als Grundprinzip
- **Breach Notification**: Automatische Meldung von Datenschutzverletzungen

### 6.2 Systemsicherheit

#### 6.2.1 Infrastructure Security
- **Regular Security Updates**: Automatische Sicherheitspatches
- **Vulnerability Scanning**: Regelmäßige Sicherheitsüberprüfungen
- **Penetration Testing**: Externe Sicherheitsaudits
- **Access Logging**: Umfassende Zugriffsprotokolle
- **Firewall-Konfiguration**: Netzwerk-Level-Sicherheit
- **Backup-Verschlüsselung**: Sichere Datensicherung

## 7. Performance und Skalierbarkeit

### 7.1 Systemoptimierung

#### 7.1.1 Frontend-Performance
- **Code-Splitting**: Lazy Loading von Komponenten
- **Image-Optimization**: Automatische Bildkomprimierung
- **Caching-Strategien**: Browser- und CDN-Caching
- **Bundle-Optimization**: Minimale JavaScript-Payloads
- **Progressive Loading**: Prioritätsbasiertes Content-Loading

#### 7.1.2 Backend-Skalierung
- **Database-Indexing**: Optimierte Datenbankabfragen
- **Connection-Pooling**: Effiziente Datenbankverbindungen
- **Horizontal Scaling**: Load-Balancer-Unterstützung
- **Redis-Caching**: In-Memory-Caching für häufige Abfragen
- **Queue-System**: Asynchrone Verarbeitung zeitaufwändiger Tasks

### 7.2 Monitoring und Wartung

#### 7.2.1 System-Monitoring
- **Application Monitoring**: Performance-Metriken und Error-Tracking
- **Uptime-Monitoring**: 24/7 Verfügbarkeitsüberwachung
- **Resource-Monitoring**: CPU, Memory, Disk-Usage Tracking
- **User-Analytics**: Nutzungsstatistiken und Verhalten
- **Alert-System**: Proaktive Benachrichtigungen bei Problemen

## 8. Implementierungsplan und Phasen

### 8.1 Entwicklungsphasen

- Startet direkt

### 8.2 Technische Anforderungen

#### 8.2.1 Entwicklungsumgebung
- **Node.js**: Version 18+ für Nuxt.js
- **Database**: PostgreSQL 14+ oder MySQL 8+
- **Redis**: Für Caching und Session-Storage
- **Docker**: Containerisierung für Development und Production
- **Git**: Versionskontrolle mit Branching-Strategie

#### 8.2.2 Production Environment
- **Server**: Linux-basierte Infrastruktur
- **Web Server**: Nginx als Reverse Proxy
- **SSL/TLS**: Let's Encrypt oder Enterprise Certificates
- **Backup-Strategy**: Täglich automatisierte Backups
- **Monitoring**: Prometheus/Grafana Stack

## 9. Testing und Qualitätssicherung

### 9.1 Test-Strategien

#### 9.1.1 Automatisierte Tests
- **Unit Tests**: Jest für JavaScript/Vue-Komponenten
- **Integration Tests**: API-Endpunkt-Testing
- **E2E Tests**: Playwright für User-Journey-Tests
- **Performance Tests**: Load-Testing mit K6
- **Security Tests**: OWASP ZAP Integration

#### 9.1.2 Manuelle Tests
- **User Acceptance Testing**: Stakeholder-Feedback-Runden
- **Usability Testing**: UX-Evaluierung
- **Cross-Browser Testing**: Kompatibilitätsprüfung
- **Mobile Testing**: Responsive Design Verification
- **Penetration Testing**: Externe Sicherheitsüberprüfung

## 10. Wartung und Support

### 10.1 Ongoing Maintenance

#### 10.1.1 Regular Updates
- **Security Patches**: Monatliche Sicherheitsupdates
- **Feature Releases**: Quartalsweise neue Funktionen
- **Bug Fixes**: Wöchentliche Fehlerbehebungen
- **Performance Improvements**: Kontinuierliche Optimierung

#### 10.1.2 User Support
- **Documentation**: Umfassende Benutzerdokumentation
- **Training Materials**: Video-Tutorials und Handbücher
- **Help Desk**: Interner Support für Mitarbeiter
- **Change Management**: Begleitung bei System-Updates

Diese umfassende Spezifikation bildet die Grundlage für die Entwicklung von wenoma als vollwertiges, deutschsprachiges Projektmanagement-System mit integriertem Kundencenter. Das modulare Design ermöglicht eine schrittweise Implementierung und kontinuierliche Erweiterung entsprechend den Geschäftsanforderungen.