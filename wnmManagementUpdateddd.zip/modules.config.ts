// Module Configuration for WNM Management System
// This file defines which modules are enabled and their dependencies

export interface ModuleConfig {
  enabled: boolean
  dependencies?: string[]
  description: string
  layer: string
}

export interface ModulesConfig {
  [key: string]: ModuleConfig
}

// Define all available modules and their configuration
export const modulesConfig: ModulesConfig = {
  // Core module - always required
  core: {
    enabled: true,
    description: 'Core functionality, authentication, and shared components',
    layer: 'layers/core'
  },

  // Authentication & User Management
  auth: {
    enabled: true,
    dependencies: ['core'],
    description: 'Authentication and user management system',
    layer: 'layers/auth'
  },

  // Project Management
  projects: {
    enabled: true,
    dependencies: ['core', 'auth'],
    description: 'Project management functionality',
    layer: 'layers/projects'
  },

  // Task Management (can work independently of projects)
  tasks: {
    enabled: true,
    dependencies: ['core', 'auth', 'admin'],
    description: 'Task management system - works independently or with projects',
    layer: 'layers/tasks'
  },

  // Time Tracking
  timetracking: {
    enabled: true, // Temporarily disabled to demonstrate modular functionality
    dependencies: ['core', 'auth', 'tasks'],
    description: 'Time tracking and timesheets',
    layer: 'layers/timetracking'
  },

  // Customer Center/Portal
  customers: {
    enabled: true,
    dependencies: ['core', 'auth'],
    description: 'Customer portal and management',
    layer: 'layers/customers'
  },

  // Team Management
  team: {
    enabled: false,
    dependencies: ['core', 'auth', 'notifications'],
    description: 'Team management and collaboration tools',
    layer: 'layers/team'
  },

  // Reports & Analytics
  reports: {
    enabled: true,
    dependencies: ['core', 'auth'],
    description: 'Reporting and analytics dashboard',
    layer: 'layers/reports'
  },

  // Notifications System
  notifications: {
    enabled: true,
    dependencies: ['core', 'auth'],
    description: 'Notification and communication system',
    layer: 'layers/notifications'
  },

  // SEPA/Financial Management
  financial: {
    enabled: true,
    dependencies: ['core', 'auth'],
    description: 'SEPA payments and financial management',
    layer: 'layers/financial'
  },

  // Tickets/Support System
  tickets: {
    enabled: true,
    dependencies: ['core', 'auth'],
    description: 'Support ticket system',
    layer: 'layers/tickets'
  },

  // Admin Panel
  admin: {
    enabled: true,
    dependencies: ['core', 'auth'],
    description: 'Administrative interface and system management',
    layer: 'layers/admin'
  }
}

// Helper function to get enabled modules
export function getEnabledModules(): string[] {
  return Object.entries(modulesConfig)
    .filter(([_, config]) => config.enabled)
    .map(([name]) => name)
}

// Helper function to get enabled layers
export function getEnabledLayers(): string[] {
  return Object.entries(modulesConfig)
    .filter(([_, config]) => config.enabled)
    .map(([_, config]) => config.layer)
}

// Helper function to validate module dependencies
export function validateModuleDependencies(): string[] {
  const errors: string[] = []
  const enabledModules = getEnabledModules()

  for (const [moduleName, config] of Object.entries(modulesConfig)) {
    if (!config.enabled) continue

    if (config.dependencies) {
      for (const dependency of config.dependencies) {
        if (!enabledModules.includes(dependency)) {
          errors.push(`Module "${moduleName}" requires "${dependency}" but it's not enabled`)
        }
      }
    }
  }

  return errors
}

// Function to check if a specific module is enabled
export function isModuleEnabled(moduleName: string): boolean {
  return modulesConfig[moduleName]?.enabled || false
}
