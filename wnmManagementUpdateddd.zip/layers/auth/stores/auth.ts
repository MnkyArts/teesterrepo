import { defineStore } from 'pinia'
import { authClient } from '~/lib/auth-client'

export interface LoginCredentials {
  email: string
  password: string
}

export interface RegisterData {
  firstName: string
  lastName: string
  email: string
  password: string
}

export const useAuthStore = defineStore('auth', () => {
  const session = authClient.useSession()
  
  const isLoading = ref<boolean>(false)
  const permissionsLoading = ref<boolean>(false)

  const isLoggedIn = computed(() => !!session.value?.data?.user)
  const user = computed(() => session.value?.data?.user)
  
  const fullName = computed(() => {
    if (!user.value) return ''
    return `${user.value.firstName} ${user.value.lastName}`.trim()
  })

  const initials = computed(() => {
    if (!user.value) return ''
    const firstName = user.value.firstName || ''
    const lastName = user.value.lastName || ''
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
  })

  const refreshUserRolesAndPermissions = async () => {
    if (!user.value?.id) return
    permissionsLoading.value = true
    
    try {
      await authClient.getSession()
    } catch (error: any) {
      console.error('Error refreshing user roles and permissions:', error)
    } finally {
      permissionsLoading.value = false
    }
  }

  const login = async (credentials: LoginCredentials): Promise<boolean> => {
    try {
      const { data, error } = await authClient.signIn.email({
        email: credentials.email,
        password: credentials.password,
        callbackURL: "/"
      }, {
        onRequest: () => { isLoading.value = true },
        onSuccess: () => { isLoading.value = false },
        onError: () => { isLoading.value = false }
      })

      if (error) {
        throw new Error(error.message || 'Login fehlgeschlagen')
      }

      return !!data
    } catch (error: any) {
      isLoading.value = false
      throw error
    }
  }

  const register = async (userData: RegisterData): Promise<boolean> => {
    try {
      const { data, error } = await authClient.signUp.email({
        email: userData.email,
        password: userData.password,
        name: `${userData.firstName} ${userData.lastName}`,
        firstName: userData.firstName,
        lastName: userData.lastName,
        callbackURL: "/"
      }, {
        onRequest: () => { isLoading.value = true },
        onSuccess: () => { isLoading.value = false },
        onError: () => { isLoading.value = false }
      })

      if (error) {
        throw new Error(error.message || 'Registrierung fehlgeschlagen')
      }

      return !!data
    } catch (error: any) {
      isLoading.value = false
      throw error
    }
  }

  const logout = async (): Promise<void> => {
    try {
      await authClient.signOut()
    } catch (error: any) {
      console.error('Logout error:', error)
      throw error
    }
  }

  const changePassword = async (currentPassword: string, newPassword: string): Promise<boolean> => {
    try {
      isLoading.value = true
      
      const result = await authClient.changePassword({
        currentPassword,
        newPassword,
        revokeOtherSessions: true,
      })

      if (result.error) {
        throw new Error(result.error.message || 'Passwort-Änderung fehlgeschlagen')
      }

      return true
    } catch (error: any) {
      console.error('Change password error:', error)
      throw error
    } finally {
      isLoading.value = false
    }
  }

  const initialize = async () => {
    // Session automatically includes roles and permissions
  }

  return {
    isLoading,
    permissionsLoading,
    isLoggedIn,
    user,
    fullName,
    initials,
    login,
    register,
    logout,
    changePassword,
    refreshUserRolesAndPermissions,
    initialize
  }
})
