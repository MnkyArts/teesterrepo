<template>
  <div class="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
    <div class="text-center">
      <!-- Logo/Brand -->
      <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
          wenoma
        </h1>
      </div>
      
      <!-- Loading Spinner -->
      <div class="flex justify-center mb-4">
        <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
      
      <!-- Loading Text -->
      <p class="text-sm text-gray-500 dark:text-gray-400">
        Lädt...
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
// Minimal und schneller Ladescreen für Auth-Initialisierung
// Keine schweren Operationen oder API-Calls hier
</script>
