<template>
  <div class="fixed inset-0 bg-white dark:bg-gray-900 z-50 flex items-center justify-center">
    <div class="text-center">
      <!-- Minimal Brand -->
      <div class="mb-4">
        <h1 class="text-xl font-semibold text-gray-900 dark:text-white">
          wenoma
        </h1>
      </div>
      
      <!-- Fast Spinner -->
      <div class="flex justify-center mb-2">
        <div class="animate-spin rounded-full h-6 w-6 border-2 border-blue-600 border-t-transparent"></div>
      </div>
      
      <!-- Loading Text -->
      <p class="text-xs text-gray-500 dark:text-gray-400">
        Lade...
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
// Ultra-fast loading component für Auth-Checks
// Minimal DOM, sofortige Anzeige
</script>

<style scoped>
/* Hardware-beschleunigte Animation */
.animate-spin {
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
