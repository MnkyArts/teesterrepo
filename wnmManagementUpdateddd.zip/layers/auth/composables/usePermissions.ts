import { authClient } from '~/lib/auth-client'

/**
 * Composable for handling user permissions and roles
 */
export const usePermissions = () => {
  const authStore = useAuthStore()

  /**
   * Check if user has a specific role
   */
  const hasRole = (roleName: string): boolean => {
    const userRoles = (authStore.user as any)?.userroles || []
    return userRoles.some((role: any) => role.name === roleName)
  }

  /**
   * Check if user has any of the specified roles
   */
  const hasRoles = (roleNames: string[]): boolean => {
    return roleNames.some(roleName => hasRole(roleName))
  }

  /**
   * Check if user has a specific permission
   */
  const hasPermission = (permissionName: string): boolean => {
    const userPermissions = (authStore.user as any)?.userpermissions || []
    return userPermissions.includes(permissionName)
  }

  /**
   * Check if user has any of the specified permissions
   */
  const hasPermissions = (permissionNames: string[]): boolean => {
    return permissionNames.some(permissionName => hasPermission(permissionName))
  }

  /**
   * Check if user has ALL of the specified permissions
   */
  const hasAllPermissions = (permissionNames: string[]): boolean => {
    return permissionNames.every(permissionName => hasPermission(permissionName))
  }

  /**
   * Check if user is admin
   */
  const isAdmin = (): boolean => {
    return hasRole('admin') || hasRole('super-admin')
  }

  /**
   * Refresh user roles and permissions
   */
  const refreshPermissions = async (): Promise<void> => {
    await authStore.refreshUserRolesAndPermissions()
  }

  return {
    hasRole,
    hasRoles,
    hasPermission,
    hasPermissions,
    hasAllPermissions,
    isAdmin,
    refreshPermissions,
    
    // Reactive state from user
    userRoles: computed(() => (authStore.user as any)?.userroles || []),
    userPermissions: computed(() => (authStore.user as any)?.userpermissions || []),
    permissionsLoading: computed(() => authStore.permissionsLoading)
  }
} 