<template>
  <div class="h-full flex flex-col">
    <!-- Header -->
    <div class="flex-shrink-0 p-6 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900">
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-4">
          <button 
            @click="$router.back()" 
            class="btn-ghost p-2"
            title="Zurück zum Projekt"
          >
            <ArrowLeftIcon class="h-5 w-5" />
          </button>
          
          <div>
            <div class="flex items-center gap-2 mb-1">
              <span class="text-sm font-mono text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 px-2 py-1 rounded">
                {{ project?.id.slice(-8) }}
              </span>
            </div>
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
              {{ project?.name }} - Kanban Board
            </h1>
            <p v-if="project?.customer" class="text-gray-600 dark:text-gray-400">
              {{ project.customer.name }}
            </p>
          </div>
        </div>

        <div class="flex items-center gap-3">
          <NuxtLink
            :to="`/projects/${projectId}`"
            class="btn-secondary"
          >
            <EyeIcon class="h-5 w-5" />
            Projekt anzeigen
          </NuxtLink>
        </div>
      </div>
    </div>

    <!-- Kanban Board -->
    <div class="flex-1 overflow-hidden">
      <KanbanBoard 
        :project-id="projectId"
        :hide-project-filter="true" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ArrowLeftIcon, EyeIcon } from '@heroicons/vue/24/outline'

// Meta
definePageMeta({
  layout: 'default'
})

// Get project ID from route
const route = useRoute()
const projectId = route.params.id as string

// Stores
const projectsStore = useProjectsStore()

// Get project data
const project = computed(() => 
  projectsStore.projects.find(p => p.id === projectId)
)

// Load project if not in store
onMounted(async () => {
  if (!project.value) {
    await projectsStore.fetchProject(projectId)
  }
})

// SEO
useHead(() => ({
  title: `${project.value?.name || 'Projekt'} - Kanban Board - wenoma`,
  meta: [
    {
      name: 'description',
      content: `Kanban-Board für das Projekt ${project.value?.name || ''}`
    }
  ]
}))
</script>
