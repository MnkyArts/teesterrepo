<template>
  <div v-if="loading" class="p-6">
    <ProjectDetailSkeleton />
  </div>

  <div v-else-if="project" class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
      <div class="flex items-center gap-4">
        <button 
          @click="$router.back()" 
          class="btn-ghost p-2"
          :title="$t('common.back')"
        >
          <ArrowLeftIcon class="h-5 w-5" />
        </button>
        
        <div>
          <div class="flex items-center gap-2 mb-1">
            <span class="text-sm font-mono text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 px-2 py-1 rounded">
              {{ project.key }}
            </span>
            <ProjectStatusBadge :status="project.status as any" />
          </div>
          <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
            {{ project.name }}
          </h1>
          <p v-if="project.customer" class="text-gray-600 dark:text-gray-400">
            {{ project.customer.companyName }}
          </p>
        </div>
      </div>

      <div class="flex items-center gap-3">
        <button
          @click="refreshProject"
          :disabled="loading"
          class="btn-secondary"
        >
          <ArrowPathIcon class="h-5 w-5" :class="{ 'animate-spin': loading }" />
          {{ $t('common.refresh') }}
        </button>
        
        <button
          v-if="canEdit"
          @click="showEditModal = true"
          class="btn-primary"
        >
          <PencilIcon class="h-5 w-5" />
          {{ $t('common.edit') }}
        </button>

        <NuxtLink
          :to="`/projects/${project.id}/settings`"
          class="inline-flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
        >
          <CogIcon class="h-4 w-4" />
          Einstellungen
        </NuxtLink>
      </div>
    </div>

    <!-- Navigation Tabs -->
    <div class="border-b border-gray-200 dark:border-gray-700">
      <nav class="-mb-px flex space-x-8">
        <NuxtLink
          :to="`/projects/${project.id}`"
          class="border-indigo-500 text-indigo-600 dark:text-indigo-400 whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm"
          exact-active-class="border-indigo-500 text-indigo-600 dark:text-indigo-400"
          active-class="border-gray-300 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300"
        >
          Übersicht
        </NuxtLink>
        <NuxtLink
          :to="`/projects/${project.id}/kanban`"
          class="border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm"
          active-class="border-indigo-500 text-indigo-600 dark:text-indigo-400"
        >
          Kanban Board
        </NuxtLink>
        <NuxtLink
          :to="`/projects/${project.id}/settings`"
          class="border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm"
          active-class="border-indigo-500 text-indigo-600 dark:text-indigo-400"
        >
          Einstellungen
        </NuxtLink>
      </nav>
    </div>

    <!-- Project Info Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <StatCard
        :title="$t('projects.tasks')"
        :value="project._count.tasks"
        :icon="ClipboardDocumentListIcon"
        color="blue"
      />
      
      <StatCard
        :title="$t('projects.members')"
        :value="project._count.members"
        :icon="UsersIcon"
        color="green"
      />
      
      <StatCard
        :title="$t('projects.hours')"
        :value="formatHours(project.totalHours)"
        :icon="ClockIcon"
        color="purple"
      />
      
      <StatCard
        :title="$t('projects.progress')"
        :value="`${Math.round(project.progress)}%`"
        :icon="ChartBarIcon"
        :color="getProgressColor(project.progress)"
      />
    </div>

    <!-- Main Content Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <!-- Left Column -->
      <div class="lg:col-span-2 space-y-6">
        <!-- Project Description -->
        <div v-if="project.description" class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            {{ $t('projects.form.description') }}
          </h2>
          <p class="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
            {{ project.description }}
          </p>
        </div>

        <!-- Recent Tasks -->
        <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg font-semibold text-gray-900 dark:text-white">
              {{ $t('tasks.recent') }}
            </h2>
            <div class="flex items-center gap-3">
              <NuxtLink 
                :to="`/projects/${project.id}/kanban`"
                class="inline-flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
              >
                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2h2a2 2 0 002-2z" />
                </svg>
                Kanban Board
              </NuxtLink>
              <NuxtLink 
                :to="`/projects/${project.id}/tasks`"
                class="text-sm text-blue-600 dark:text-blue-400 hover:underline"
              >
                {{ $t('common.viewAll') }}
              </NuxtLink>
            </div>
          </div>
          
          <div v-if="project.tasks && project.tasks.length > 0" class="space-y-3">
            <div
              v-for="task in project.tasks"
              :key="task.id"
              class="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors cursor-pointer"
              @click="navigateTo(`/tasks/${task.id}`)"
            >
              <div class="flex items-center gap-3">
                <TaskStatusBadge :status="task.status" size="sm" />
                <div>
                  <h3 class="font-medium text-gray-900 dark:text-white">
                    {{ task.title }}
                  </h3>
                  <p v-if="task.key" class="text-sm text-gray-600 dark:text-gray-400">
                    {{ task.key }}
                  </p>
                </div>
              </div>
              
              <div class="flex items-center gap-2">
                <TaskPriorityBadge :priority="task.priority as any" size="sm" />
                <img
                  v-if="task.assignee"
                  :src="task.assignee.image || `/api/avatar/${task.assignee.id}`"
                  :alt="task.assignee.firstName"
                  :title="`${task.assignee.firstName} ${task.assignee.lastName}`"
                  class="h-6 w-6 rounded-full"
                />
              </div>
            </div>
          </div>
          
          <div v-else class="text-center py-8">
            <ClipboardDocumentListIcon class="mx-auto h-12 w-12 text-gray-400" />
            <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">
              {{ $t('tasks.empty') }}
            </h3>
            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {{ $t('tasks.createFirst') }}
            </p>
          </div>
        </div>
      </div>

      <!-- Right Column -->
      <div class="space-y-6">
        <!-- Project Details -->
        <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            {{ $t('projects.details') }}
          </h2>
          
          <div class="space-y-4">
            <div v-if="project.startDate">
              <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">
                {{ $t('projects.form.startDate') }}
              </dt>
              <dd class="text-sm text-gray-900 dark:text-white">
                {{ formatDate(project.startDate) }}
              </dd>
            </div>
            
            <div v-if="project.endDate">
              <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">
                {{ $t('projects.form.endDate') }}
              </dt>
              <dd class="text-sm text-gray-900 dark:text-white">
                {{ formatDate(project.endDate) }}
              </dd>
            </div>
            
            <div v-if="project.budget">
              <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">
                {{ $t('projects.form.budget') }}
              </dt>
              <dd class="text-sm text-gray-900 dark:text-white">
                {{ formatCurrency(project.budget) }}
              </dd>
            </div>
            
            <div>
              <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">
                {{ $t('common.createdAt') }}
              </dt>
              <dd class="text-sm text-gray-900 dark:text-white">
                {{ formatDate(project.createdAt) }}
              </dd>
            </div>
            
            <div>
              <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">
                {{ $t('common.updatedAt') }}
              </dt>
              <dd class="text-sm text-gray-900 dark:text-white">
                {{ formatDate(project.updatedAt) }}
              </dd>
            </div>
          </div>
        </div>

        <!-- Team Members -->
        <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            {{ $t('projects.team') }}
          </h2>
          
          <div v-if="project.members && project.members.length > 0" class="space-y-3">
            <div
              v-for="member in project.members"
              :key="member.id"
              class="flex items-center gap-3"
            >
              <img
                :src="member.user.image || `/api/avatar/${member.user.id}`"
                :alt="member.user.firstName"
                class="h-8 w-8 rounded-full"
              />
              <div class="flex-1">
                <h3 class="text-sm font-medium text-gray-900 dark:text-white">
                  {{ member.user.firstName }} {{ member.user.lastName }}
                </h3>
                <p class="text-xs text-gray-500 dark:text-gray-400">
                  {{ member.role }}
                </p>
              </div>
              <UserRoleBadge :role="(member.user.role || member.role) as any" size="sm" />
            </div>
          </div>
          
          <div v-else class="text-center py-4">
            <UsersIcon class="mx-auto h-8 w-8 text-gray-400" />
            <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
              {{ $t('projects.noMembers') }}
            </p>
          </div>
        </div>

        <!-- Task Status Distribution -->
        <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            {{ $t('tasks.statusDistribution') }}
          </h2>
          
          <div v-if="project.taskStats && project.taskStats.length > 0" class="space-y-3">
            <div
              v-for="stat in project.taskStats"
              :key="stat.status"
              class="flex items-center justify-between"
            >
              <div class="flex items-center gap-2">
                <TaskStatusBadge :status="stat.status" size="sm" />
                <span class="text-sm text-gray-700 dark:text-gray-300">
                  {{ getStatusLabel(stat.status) }}
                </span>
              </div>
              <span class="text-sm font-medium text-gray-900 dark:text-white">
                {{ stat._count }}
              </span>
            </div>
          </div>
          
          <div v-else class="text-center py-4">
            <ChartBarIcon class="mx-auto h-8 w-8 text-gray-400" />
            <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
              {{ $t('tasks.noStats') }}
            </p>
          </div>
        </div>
      </div>
    </div>

    <!-- Edit Modal -->
    <ProjectModal
      v-if="showEditModal"
      :project="project"
      @close="showEditModal = false"
      @saved="onProjectSaved"
    />
  </div>

  <div v-else class="p-6">
    <div class="text-center py-12">
      <FolderIcon class="mx-auto h-12 w-12 text-gray-400" />
      <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">
        {{ $t('projects.notFound') }}
      </h3>
      <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
        {{ $t('projects.notFoundDescription') }}
      </p>
      <div class="mt-6">
        <NuxtLink to="/projects" class="btn-primary">
          {{ $t('projects.backToList') }}
        </NuxtLink>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { 
  ArrowLeftIcon,
  ArrowPathIcon,
  PencilIcon,
  CogIcon,
  ClipboardDocumentListIcon,
  UsersIcon,
  ClockIcon,
  ChartBarIcon,
  FolderIcon
} from '@heroicons/vue/24/outline'

// Meta & Layout
definePageMeta({
  layout: 'default'
})

// Route params
const route = useRoute()
const projectId = route.params.id as string

// Stores
const authStore = useAuthStore()
const { user } = storeToRefs(authStore)

const notificationsStore = useNotificationsStore()
const { addNotification } = notificationsStore

// Project interface
interface ProjectDetail {
  id: string
  name: string
  key: string
  description?: string
  status: string
  progress: number
  totalHours: number
  startDate?: string
  endDate?: string
  budget?: number
  createdAt: string
  updatedAt: string
  isInternal: boolean
  customer?: {
    id: string
    companyName: string
    contactName: string
  }
  _count: {
    tasks: number
    members: number
  }
  tasks?: Array<{
    id: string
    title: string
    status: string
    priority: string
    key?: string
    assignee?: {
      id: string
      firstName: string
      lastName: string
      image?: string
    }
  }>
  members?: Array<{
    id: string
    user: {
      id: string
      firstName: string
      lastName: string
      image?: string
      role?: string
    }
    role: string
  }>
  taskStats?: Array<{
    status: string
    _count: number
  }>
}

// Reactive Data
const loading = ref(false)
const project = ref<ProjectDetail | null>(null)
const showEditModal = ref(false)

// Computed
const canEdit = computed(() => {
  return ['ADMINISTRATOR', 'PROJEKTLEITER'].includes(user.value?.role as string)
})

// Methods
async function loadProject() {
  try {
    loading.value = true
    const response = await $fetch(`/api/projects/${projectId}`) as any
    project.value = response.data || response
    
    // Update SEO
    const projectData = response.data || response
    if (projectData) {
      useSeoMeta({
        title: `${projectData.name} - wenoma`,
        description: projectData.description || `Projektdetails für ${projectData.name}`
      })
    }
  } catch (error) {
    console.error('Fehler beim Laden des Projekts:', error)
    addNotification({
      type: 'error',
      title: 'Fehler',
      message: 'Projekt konnte nicht geladen werden'
    })
  } finally {
    loading.value = false
  }
}

async function refreshProject() {
  await loadProject()
  addNotification({
    type: 'success',
    title: 'Aktualisiert',
    message: 'Projektdaten wurden aktualisiert'
  })
}

function onProjectSaved() {
  showEditModal.value = false
  loadProject()
}

// Utility functions
function formatHours(hours: number): string {
  if (!hours) return '0h'
  return `${Math.round(hours * 10) / 10}h`
}

function formatDate(date: string): string {
  return new Date(date).toLocaleDateString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  })
}

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('de-DE', {
    style: 'currency',
    currency: 'EUR'
  }).format(amount)
}

function getProgressColor(progress: number): 'blue' | 'green' | 'purple' | 'orange' | 'red' {
  if (progress >= 80) return 'green'
  if (progress >= 50) return 'orange'
  return 'red'
}

function getStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    'GEPLANT': 'Geplant',
    'TECHNISCHES_DESIGN': 'Technisches Design',
    'IN_BEARBEITUNG': 'In Bearbeitung',
    'REVIEW': 'Review',
    'TESTING': 'Testing',
    'ERLEDIGT': 'Erledigt'
  }
  return labels[status] || status
}

// Lifecycle
onMounted(() => {
  loadProject()
})
</script>
