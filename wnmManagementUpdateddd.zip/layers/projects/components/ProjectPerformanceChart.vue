<template>
  <div class="space-y-4">
    <!-- Chart Container -->
    <div class="h-64 w-full">
      <canvas ref="chartCanvas" class="w-full h-full"></canvas>
    </div>
    
    <!-- Legend -->
    <div class="flex flex-wrap gap-4 justify-center">
      <div class="flex items-center space-x-2">
        <div class="w-3 h-3 rounded-sm bg-blue-500"></div>
        <span class="text-sm text-gray-700 dark:text-gray-300">Geschätzte Zeit</span>
      </div>
      <div class="flex items-center space-x-2">
        <div class="w-3 h-3 rounded-sm bg-green-500"></div>
        <span class="text-sm text-gray-700 dark:text-gray-300">Tatsächliche Zeit</span>
      </div>
      <div class="flex items-center space-x-2">
        <div class="w-3 h-3 rounded-sm bg-red-500"></div>
        <span class="text-sm text-gray-700 dark:text-gray-300">Überschreitung</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick, watch } from 'vue'

interface ProjectPerformanceData {
  name: string
  estimatedHours: number
  actualHours: number
  efficiency: number
}

interface Props {
  data: ProjectPerformanceData[]
}

const props = defineProps<Props>()

const chartCanvas = ref<HTMLCanvasElement>()

const renderChart = async () => {
  await nextTick()
  
  if (!chartCanvas.value || !props.data.length) return
  
  const ctx = chartCanvas.value.getContext('2d')
  if (!ctx) return
  
  const { width, height } = chartCanvas.value
  
  ctx.clearRect(0, 0, width, height)
  
  // Chart dimensions
  const padding = 60
  const chartWidth = width - 2 * padding
  const chartHeight = height - 2 * padding
  
  // Find max value for scaling
  const maxHours = Math.max(...props.data.map(d => Math.max(d.estimatedHours, d.actualHours)))
  const scale = chartHeight / (maxHours * 1.1)
  
  // Bar width
  const barWidth = chartWidth / (props.data.length * 3)
  const groupWidth = barWidth * 2.5
  
  // Draw grid lines
  ctx.strokeStyle = '#E5E7EB'
  ctx.lineWidth = 1
  
  for (let i = 0; i <= 5; i++) {
    const y = padding + (chartHeight / 5) * i
    ctx.beginPath()
    ctx.moveTo(padding, y)
    ctx.lineTo(width - padding, y)
    ctx.stroke()
  }
  
  // Draw axes
  ctx.strokeStyle = '#374151'
  ctx.lineWidth = 2
  ctx.beginPath()
  ctx.moveTo(padding, padding)
  ctx.lineTo(padding, height - padding)
  ctx.lineTo(width - padding, height - padding)
  ctx.stroke()
  
  // Draw bars
  props.data.forEach((project, index) => {
    const x = padding + index * groupWidth + (chartWidth - props.data.length * groupWidth) / 2
    
    // Estimated hours bar
    const estimatedHeight = project.estimatedHours * scale
    ctx.fillStyle = '#3B82F6'
    ctx.fillRect(x, height - padding - estimatedHeight, barWidth, estimatedHeight)
    
    // Actual hours bar
    const actualHeight = project.actualHours * scale
    ctx.fillStyle = project.actualHours > project.estimatedHours ? '#EF4444' : '#10B981'
    ctx.fillRect(x + barWidth, height - padding - actualHeight, barWidth, actualHeight)
    
    // Project label
    ctx.fillStyle = '#374151'
    ctx.font = '10px system-ui'
    ctx.textAlign = 'center'
    ctx.save()
    ctx.translate(x + barWidth, height - padding + 15)
    ctx.rotate(-Math.PI / 4)
    ctx.fillText(project.name, 0, 0)
    ctx.restore()
  })
  
  // Y-axis labels
  ctx.fillStyle = '#374151'
  ctx.font = '12px system-ui'
  ctx.textAlign = 'right'
  
  for (let i = 0; i <= 5; i++) {
    const value = (maxHours * 1.1 / 5) * (5 - i)
    const y = padding + (chartHeight / 5) * i
    ctx.fillText(Math.round(value).toString() + 'h', padding - 10, y + 4)
  }
}

const resizeCanvas = () => {
  if (!chartCanvas.value) return
  
  const container = chartCanvas.value.parentElement
  if (!container) return
  
  chartCanvas.value.width = container.clientWidth
  chartCanvas.value.height = container.clientHeight
  
  renderChart()
}

watch(() => props.data, () => {
  renderChart()
}, { deep: true })

onMounted(() => {
  resizeCanvas()
  window.addEventListener('resize', resizeCanvas)
})
</script>
