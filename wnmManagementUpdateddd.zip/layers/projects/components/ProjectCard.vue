<template>
  <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
    <div class="p-6">
      <!-- Header -->
      <div class="flex items-start justify-between mb-4">
        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-2 mb-1">
            <span class="text-sm font-mono text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 px-2 py-1 rounded">
              {{ project.key }}
            </span>
            <ProjectStatusBadge :status="project.status" />
          </div>
          
          <h3 class="text-lg font-semibold text-gray-900 dark:text-white truncate">
            {{ project.name }}
          </h3>
          
          <p v-if="project.customer" class="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-1 mt-1">
            <BuildingOfficeIcon class="h-4 w-4" />
            {{ project.customer.companyName }}
          </p>
          
          <p v-else-if="project.isInternal" class="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-1 mt-1">
            <HomeIcon class="h-4 w-4" />
            {{ $t('projects.internalProject') }}
          </p>
        </div>

        <button 
            @click="$emit('view', project)"
            class="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-gray-100 dark:hover:bg-gray-700 p-2 rounded-lg transition-colors"
            :title="$t('common.view')"
          >
            <EyeIcon class="h-5 w-5" />
        </button>

        <!-- Actions Menu -->
        <Menu as="div" class="relative">
          <MenuButton class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 p-2 rounded-lg transition-colors">
            <EllipsisVerticalIcon class="h-5 w-5" />
          </MenuButton>
          
          <MenuItems class="absolute right-0 mt-2 w-48 origin-top-right bg-white dark:bg-gray-800 rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none z-50">
            <div class="py-1">
              <MenuItem v-if="canEdit">
                <button @click="$emit('edit', project)" class="block w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                  <div class="flex items-center">
                    <PencilIcon class="mr-3 h-4 w-4" />
                    {{ $t('common.edit') }}
                  </div>
                </button>
              </MenuItem>
              
              <MenuItem v-if="canDelete">
                <button @click="$emit('delete', project)" class="block w-full text-left px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700">
                  <div class="flex items-center">
                    <TrashIcon class="mr-3 h-4 w-4" />
                    {{ $t('common.delete') }}
                  </div>
                </button>
              </MenuItem>
            </div>
          </MenuItems>
        </Menu>
      </div>

      <!-- Description -->
      <p v-if="project.description" class="text-sm text-gray-600 dark:text-gray-400 mb-4 line-clamp-2">
        {{ project.description }}
      </p>

      <!-- Stats -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
        <div class="text-center">
          <div class="text-lg font-semibold text-gray-900 dark:text-white">
            {{ project._count?.tasks || 0 }}
          </div>
          <div class="text-xs text-gray-500 dark:text-gray-400">
            {{ $t('projects.tasks') }}
          </div>
        </div>
        
        <div class="text-center">
          <div class="text-lg font-semibold text-gray-900 dark:text-white">
            {{ project._count?.members || 0 }}
          </div>
          <div class="text-xs text-gray-500 dark:text-gray-400">
            {{ $t('projects.members') }}
          </div>
        </div>
        
        <div class="text-center">
          <div class="text-lg font-semibold text-gray-900 dark:text-white">
            {{ formatHours(project.totalHours) }}
          </div>
          <div class="text-xs text-gray-500 dark:text-gray-400">
            {{ $t('projects.hours') }}
          </div>
        </div>
        
        <div class="text-center">
          <div class="text-lg font-semibold" :class="getProgressColor(projectProgress)">
            {{ projectProgress }}%
          </div>
          <div class="text-xs text-gray-500 dark:text-gray-400">
            {{ $t('projects.progress') }}
          </div>
        </div>
      </div>

      <!-- Progress Bar -->
      <div class="mb-4">
        <div class="flex items-center justify-between text-xs text-gray-600 dark:text-gray-400 mb-1">
          <span>{{ $t('projects.progress') }}</span>
          <span>{{ projectProgress }}%</span>
        </div>
        <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
          <div 
            class="h-2 rounded-full transition-all duration-300"
            :class="getProgressBarColor(projectProgress)"
            :style="{ width: `${Math.min(100, projectProgress)}%` }"
          ></div>
        </div>
      </div>

      <!-- Team Members -->
      <div v-if="project.members && project.members.length > 0" class="flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="text-sm text-gray-600 dark:text-gray-400">{{ $t('projects.team') }}:</span>
          <div class="flex -space-x-2">
            <img
              v-for="member in project.members.slice(0, 4)"
              :key="member.id"
              :src="member.user.image || `/api/avatar/${member.user.id}`"
              :alt="member.user.firstName"
              :title="`${member.user.firstName} ${member.user.lastName}`"
              class="h-6 w-6 rounded-full border-2 border-white dark:border-gray-800"
            />
            <div 
              v-if="project.members.length > 4"
              class="h-6 w-6 rounded-full border-2 border-white dark:border-gray-800 bg-gray-100 dark:bg-gray-700 flex items-center justify-center"
            >
              <span class="text-xs text-gray-600 dark:text-gray-400">
                +{{ project.members.length - 4 }}
              </span>
            </div>
          </div>
        </div>
        
        <div class="text-xs text-gray-500 dark:text-gray-400">
          {{ formatDate(project.updatedAt) }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { 
  EllipsisVerticalIcon, 
  EyeIcon, 
  PencilIcon, 
  TrashIcon,
  BuildingOfficeIcon,
  HomeIcon
} from '@heroicons/vue/24/outline'
import { Menu, MenuButton, MenuItems, MenuItem } from '@headlessui/vue'

// Props
const props = defineProps<{
  project: any
}>()

// Emits
defineEmits(['view', 'edit', 'delete'])

// Composables
// Stores
const authStore = useAuthStore()

// Computed
const canEdit = computed(() => {
  return authStore.user?.role && ['ADMINISTRATOR', 'PROJEKTLEITER'].includes(authStore.user.role)
})

const canDelete = computed(() => {
  return authStore.user?.role && ['ADMINISTRATOR'].includes(authStore.user.role)
})

const projectProgress = computed(() => {
  const progress = props.project.progress
  if (typeof progress === 'number' && !isNaN(progress)) {
    return Math.round(Math.max(0, Math.min(100, progress)))
  }
  return 0
})

// Methods
function formatHours(hours: number): string {
  if (!hours) return '0h'
  return `${Math.round(hours * 10) / 10}h`
}

function formatDate(date: string): string {
  return new Date(date).toLocaleDateString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  })
}

function getProgressColor(progress: number): string {
  if (progress >= 80) return 'text-green-600 dark:text-green-400'
  if (progress >= 50) return 'text-yellow-600 dark:text-yellow-400'
  if (progress > 0) return 'text-red-600 dark:text-red-400'
  return 'text-gray-600 dark:text-gray-400'
}

function getProgressBarColor(progress: number): string {
  if (progress >= 80) return 'bg-green-500'
  if (progress >= 50) return 'bg-yellow-500'
  if (progress > 0) return 'bg-red-500'
  return 'bg-gray-300 dark:bg-gray-600'
}
</script>

<style scoped>
.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
