<template>
  <div class="space-y-4">
    <!-- Chart Container -->
    <div class="h-40 w-full">
      <canvas ref="chartCanvas" class="w-full h-full"></canvas>
    </div>
    
    <!-- Status Summary -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
      <div 
        v-for="status in statusSummary" 
        :key="status.name"
        class="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
        <div class="text-2xl font-bold" :style="{ color: status.color }">
          {{ status.count }}
        </div>
        <div class="text-xs text-gray-600 dark:text-gray-400">{{ status.name }}</div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, nextTick, watch } from 'vue'

interface ProjectStatusData {
  status: string
  count: number
  color: string
}

// Computed property to map status to display name
const statusDisplayNames: Record<string, string> = {
  'AKTIV': 'Aktiv',
  'PAUSIERT': 'Pausiert', 
  'ABGESCHLOSSEN': 'Abgeschlossen',
  'ARCHIVIERT': 'Archiviert'
}

interface Props {
  data: ProjectStatusData[]
}

const props = defineProps<Props>()

const chartCanvas = ref<HTMLCanvasElement>()

const statusSummary = computed(() => 
  props.data.map(status => ({
    ...status,
    name: statusDisplayNames[status.status] || status.status
  }))
)

const renderChart = async () => {
  await nextTick()
  
  if (!chartCanvas.value || !props.data.length) return
  
  const ctx = chartCanvas.value.getContext('2d')
  if (!ctx) return
  
  const { width, height } = chartCanvas.value
  
  ctx.clearRect(0, 0, width, height)
  
  // Chart dimensions
  const padding = 20
  const chartWidth = width - 2 * padding
  const chartHeight = height - 2 * padding
  
  // Calculate total
  const total = props.data.reduce((sum, item) => sum + item.count, 0)
  
  // Draw horizontal stacked bar
  let currentX = padding
  const barHeight = 40
  const barY = (height - barHeight) / 2
  
  props.data.forEach((item) => {
    const segmentWidth = (item.count / total) * chartWidth
    
    // Draw segment
    ctx.fillStyle = item.color
    ctx.fillRect(currentX, barY, segmentWidth, barHeight)
    
    // Add label if segment is wide enough
    if (segmentWidth > 30) {
      ctx.fillStyle = '#ffffff'
      ctx.font = '12px system-ui'
      ctx.textAlign = 'center'
      ctx.fillText(
        item.count.toString(),
        currentX + segmentWidth / 2,
        barY + barHeight / 2 + 4
      )
    }
    
    currentX += segmentWidth
  })
  
  // Draw border
  ctx.strokeStyle = '#D1D5DB'
  ctx.lineWidth = 1
  ctx.strokeRect(padding, barY, chartWidth, barHeight)
}

const resizeCanvas = () => {
  if (!chartCanvas.value) return
  
  const container = chartCanvas.value.parentElement
  if (!container) return
  
  chartCanvas.value.width = container.clientWidth
  chartCanvas.value.height = container.clientHeight
  
  renderChart()
}

watch(() => props.data, () => {
  renderChart()
}, { deep: true })

onMounted(() => {
  resizeCanvas()
  window.addEventListener('resize', resizeCanvas)
})
</script>
