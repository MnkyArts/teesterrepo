<template>
  <div class="fixed top-4 right-4 z-50 space-y-4 max-w-sm">
    <TransitionGroup
      name="notification"
      tag="div"
      class="space-y-4"
    >
      <div
        v-for="notification in visibleNotifications"
        :key="notification.id"
        class="bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 p-4 min-w-80"
        :class="notificationClasses(notification.type)"
      >
        <div class="flex items-start">
          <div class="flex-shrink-0">
            <component
              :is="getIcon(notification.type)"
              class="h-5 w-5"
              :class="iconClasses(notification.type)"
            />
          </div>
          
          <div class="ml-3 flex-1">
            <div class="text-sm font-medium" :class="titleClasses(notification.type)">
              {{ notification.title }}
            </div>
            <div class="mt-1 text-sm" :class="messageClasses(notification.type)">
              {{ notification.message }}
            </div>
            
            <!-- Actions -->
            <div v-if="notification.actions" class="mt-3 flex space-x-2">
              <button
                v-for="action in notification.actions"
                :key="action.label"
                @click="action.action"
                class="text-sm font-medium hover:underline"
                :class="actionClasses(notification.type)"
              >
                {{ action.label }}
              </button>
            </div>
          </div>
          
          <div class="ml-4 flex-shrink-0">
            <button
              @click="removeNotification(notification.id)"
              class="text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
            >
              <XMarkIcon class="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </TransitionGroup>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import {
  CheckCircleIcon,
  ExclamationTriangleIcon,
  XCircleIcon,
  InformationCircleIcon,
  XMarkIcon
} from '@heroicons/vue/24/outline'

// Composables
const notificationsStore = useNotificationsStore()
const { notifications, removeNotification } = notificationsStore

// Computed
const visibleNotifications = computed(() =>    notifications.slice(0, 5) // Show max 5 notifications
)

// Methods
const getIcon = (type: string) => {
  const icons = {
    success: CheckCircleIcon,
    warning: ExclamationTriangleIcon,
    error: XCircleIcon,
    info: InformationCircleIcon
  }
  return icons[type as keyof typeof icons] || InformationCircleIcon
}

const notificationClasses = (type: string) => {
  const classes = {
    success: 'border-l-4 border-green-500',
    warning: 'border-l-4 border-yellow-500',
    error: 'border-l-4 border-red-500',
    info: 'border-l-4 border-blue-500'
  }
  return classes[type as keyof typeof classes] || ''
}

const iconClasses = (type: string) => {
  const classes = {
    success: 'text-green-500',
    warning: 'text-yellow-500',
    error: 'text-red-500',
    info: 'text-blue-500'
  }
  return classes[type as keyof typeof classes] || 'text-gray-500'
}

const titleClasses = (type: string) => {
  const classes = {
    success: 'text-green-800 dark:text-green-200',
    warning: 'text-yellow-800 dark:text-yellow-200',
    error: 'text-red-800 dark:text-red-200',
    info: 'text-blue-800 dark:text-blue-200'
  }
  return classes[type as keyof typeof classes] || 'text-gray-800 dark:text-gray-200'
}

const messageClasses = (type: string) => {
  const classes = {
    success: 'text-green-700 dark:text-green-300',
    warning: 'text-yellow-700 dark:text-yellow-300',
    error: 'text-red-700 dark:text-red-300',
    info: 'text-blue-700 dark:text-blue-300'
  }
  return classes[type as keyof typeof classes] || 'text-gray-700 dark:text-gray-300'
}

const actionClasses = (type: string) => {
  const classes = {
    success: 'text-green-600 hover:text-green-500',
    warning: 'text-yellow-600 hover:text-yellow-500',
    error: 'text-red-600 hover:text-red-500',
    info: 'text-blue-600 hover:text-blue-500'
  }
  return classes[type as keyof typeof classes] || 'text-gray-600 hover:text-gray-500'
}
</script>

<style scoped>
.notification-enter-active,
.notification-leave-active {
  transition: all 0.3s ease;
}

.notification-enter-from {
  opacity: 0;
  transform: translateX(100%);
}

.notification-leave-to {
  opacity: 0;
  transform: translateX(100%);
}

.notification-move {
  transition: transform 0.3s ease;
}
</style>
