<template>
  <div class="p-6">
    <div class="mb-6">
      <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-2">
        {{ $t('timeTracking.timesheet') }} - {{ formatWeekRange(weekStart) }}
      </h3>
      <p class="text-sm text-gray-600 dark:text-gray-400">
        {{ $t('timeTracking.weekView') }}
      </p>
    </div>

    <!-- Week Grid -->
    <div class="overflow-x-auto">
      <table class="w-full border-collapse">
        <thead>
          <tr class="border-b border-gray-200 dark:border-gray-700">
            <th class="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">
              {{ $t('projects.project') }}
            </th>
            <th 
              v-for="day in weekDays" 
              :key="day.date"
              class="text-center py-3 px-2 font-medium text-gray-900 dark:text-white min-w-[100px]"
            >
              <div class="text-xs text-gray-500 dark:text-gray-400">
                {{ day.dayName }}
              </div>
              <div class="text-sm">{{ day.dateNumber }}</div>
            </th>
            <th class="text-center py-3 px-4 font-medium text-gray-900 dark:text-white">
              {{ $t('common.total') }}
            </th>
          </tr>
        </thead>
        <tbody>
          <!-- Loading State -->
          <tr v-if="isLoading">
            <td :colspan="weekDays.length + 2" class="text-center py-8">
              <div class="flex items-center justify-center">
                <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                <span class="ml-2 text-gray-600 dark:text-gray-400">{{ $t('common.loading') }}</span>
              </div>
            </td>
          </tr>

          <!-- Project Rows -->
          <template v-else>
            <tr 
              v-for="project in projectRows" 
              :key="project.id"
              class="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50"
            >
              <!-- Project Name -->
              <td class="py-3 px-4">
                <div class="flex items-center">
                  <div class="w-3 h-3 rounded-full mr-3" :style="{ backgroundColor: project.color }"></div>
                  <div>
                    <div class="text-sm font-medium text-gray-900 dark:text-white">
                      {{ project.name }}
                    </div>
                    <div class="text-xs text-gray-500 dark:text-gray-400">
                      {{ project.key }}
                    </div>
                  </div>
                </div>
              </td>

              <!-- Daily Hours -->
              <td 
                v-for="day in weekDays" 
                :key="`${project.id}-${day.date}`"
                class="py-3 px-2 text-center"
              >
                <button
                  @click="addEntryForDay(project, day.date)"
                  :class="[
                    'inline-flex items-center justify-center w-16 h-8 text-xs rounded border transition-colors',
                    project.dailyHours[day.date] > 0
                      ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/30'
                      : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-600 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-600'
                  ]"
                >
                  {{ project.dailyHours[day.date] > 0 ? formatHours(project.dailyHours[day.date]) : '+' }}
                </button>
              </td>

              <!-- Weekly Total -->
              <td class="py-3 px-4 text-center">
                <span class="text-sm font-medium text-gray-900 dark:text-white">
                  {{ formatHours(project.weeklyTotal) }}h
                </span>
              </td>
            </tr>

            <!-- Totals Row -->
            <tr class="bg-gray-50 dark:bg-gray-700 font-medium">
              <td class="py-3 px-4 text-gray-900 dark:text-white">
                {{ $t('common.total') }}
              </td>
              <td 
                v-for="day in weekDays" 
                :key="`total-${day.date}`"
                class="py-3 px-2 text-center text-gray-900 dark:text-white"
              >
                {{ formatHours(dailyTotals[day.date] || 0) }}h
              </td>
              <td class="py-3 px-4 text-center text-gray-900 dark:text-white">
                {{ formatHours(weeklyGrandTotal) }}h
              </td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>

    <!-- Empty State -->
    <div v-if="!isLoading && projectRows.length === 0" class="text-center py-12">
      <ClockIcon class="h-12 w-12 text-gray-400 mx-auto mb-4" />
      <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
        {{ $t('timeTracking.noTimeEntries') }}
      </h3>
      <p class="text-gray-500 dark:text-gray-400 mb-4">
        {{ $t('timeTracking.noTimeEntriesDescription') }}
      </p>
      <button
        @click="$emit('add-entry', { date: getTodayDate() })"
        class="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors"
      >
        <PlusIcon class="h-4 w-4 mr-2" />
        {{ $t('timeTracking.addTimeEntry') }}
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { ClockIcon, PlusIcon } from '@heroicons/vue/24/solid'

interface TimeEntry {
  id: string
  hours: number
  date: string
  project: {
    id: string
    name: string
    key: string
  }
}

// Props
const props = defineProps<{
  weekStart: Date
  entries: TimeEntry[]
  isLoading: boolean
}>()

// Emits
const emit = defineEmits<{
  'add-entry': [data: { projectId?: string, date: string }]
  'edit-entry': [entry: TimeEntry]
  'delete-entry': [entryId: string]
}>()

// Computed
const weekDays = computed(() => {
  const days = []
  for (let i = 0; i < 7; i++) {
    const date = new Date(props.weekStart)
    date.setDate(date.getDate() + i)
    
    days.push({
      date: date.toISOString().split('T')[0], // Use ISO format consistently
      dateNumber: date.getDate(),
      dayName: date.toLocaleDateString('de-DE', { weekday: 'short' })
    })
  }
  return days
})

const projectRows = computed(() => {
  const projectMap = new Map()

  // Group entries by project
  props.entries.forEach(entry => {
    const projectId = entry.project.id
    if (!projectMap.has(projectId)) {
      projectMap.set(projectId, {
        id: projectId,
        name: entry.project.name,
        key: entry.project.key,
        color: getProjectColor(projectId),
        dailyHours: {},
        weeklyTotal: 0
      })
    }

    const project = projectMap.get(projectId)
    // Convert entry date to local timezone and get date key
    const entryDate = new Date(entry.date)
    const localDate = new Date(entryDate.getFullYear(), entryDate.getMonth(), entryDate.getDate())
    const dateKey = localDate.toISOString().split('T')[0]
    
    project.dailyHours[dateKey] = (project.dailyHours[dateKey] || 0) + entry.hours
    project.weeklyTotal += entry.hours
  })

  return Array.from(projectMap.values())
})

const dailyTotals = computed(() => {
  const totals: Record<string, number> = {}
  
  props.entries.forEach(entry => {
    const date = entry.date.split('T')[0]
    totals[date] = (totals[date] || 0) + entry.hours
  })
  
  return totals
})

const weeklyGrandTotal = computed(() => {
  return props.entries.reduce((total, entry) => total + entry.hours, 0)
})

// Methods
const formatWeekRange = (startDate: Date) => {
  const endDate = new Date(startDate)
  endDate.setDate(startDate.getDate() + 6)
  
  const options: Intl.DateTimeFormatOptions = { 
    day: 'numeric', 
    month: 'short' 
  }
  
  return `${startDate.toLocaleDateString('de-DE', options)} - ${endDate.toLocaleDateString('de-DE', options)}`
}

const formatHours = (hours: number): string => {
  if (hours === 0) return '0'
  const h = Math.floor(hours)
  const m = Math.round((hours - h) * 60)
  if (m === 0) return h.toString()
  return `${h}:${m.toString().padStart(2, '0')}`
}

const getProjectColor = (projectId: string): string => {
  // Generate a consistent color for each project based on ID
  const colors = [
    '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6',
    '#06B6D4', '#84CC16', '#F97316', '#EC4899', '#6366F1'
  ]
  
  let hash = 0
  for (let i = 0; i < projectId.length; i++) {
    hash = projectId.charCodeAt(i) + ((hash << 5) - hash)
  }
  
  return colors[Math.abs(hash) % colors.length]
}

const getTodayDate = (): string => {
  return new Date().toISOString().split('T')[0]
}

const addEntryForDay = (project: any, date: string) => {
  emit('add-entry', { 
    projectId: project.id, 
    date 
  })
}
</script>
