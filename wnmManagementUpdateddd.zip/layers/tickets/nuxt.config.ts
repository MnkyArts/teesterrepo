// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  // Tickets layer configuration
  
  // Component auto-imports
  components: [
    {
      path: './components',
      pathPrefix: false,
    }
  ],

  // Auto-imports for stores and composables
  imports: {
    dirs: [
      './stores/**',
      './composables/**'
    ]
  },
  
  // Pages
  pages: true
})
