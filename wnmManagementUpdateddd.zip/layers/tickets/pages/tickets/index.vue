<template>
    <div class="space-y-8">
      <!-- Page Header -->
      <div class="flex items-center justify-between">
        <div>
          <h1 class="text-3xl font-bold text-gray-900 dark:text-white">
            {{ $t('tickets.management.title') }}
          </h1>
          <p class="mt-2 text-gray-600 dark:text-gray-400">
            {{ $t('tickets.management.description') }}
          </p>
        </div>
      </div>

      <!-- Stats Cards -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div class="flex items-center">
            <div class="flex-shrink-0">
              <div class="w-8 h-8 bg-yellow-100 dark:bg-yellow-900 rounded-md flex items-center justify-center">
                <Icon name="heroicons:ticket" class="w-5 h-5 text-yellow-600" />
              </div>
            </div>
            <div class="ml-4">
              <div class="text-sm font-medium text-gray-600 dark:text-gray-400">
                {{ $t('tickets.stats.open') }}
              </div>
              <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                {{ getStatCount('OFFEN') }}
              </div>
            </div>
          </div>
        </div>

        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div class="flex items-center">
            <div class="flex-shrink-0">
              <div class="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-md flex items-center justify-center">
                <Icon name="heroicons:cog-8-tooth" class="w-5 h-5 text-blue-600" />
              </div>
            </div>
            <div class="ml-4">
              <div class="text-sm font-medium text-gray-600 dark:text-gray-400">
                {{ $t('tickets.stats.inProgress') }}
              </div>
              <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                {{ getStatCount('IN_BEARBEITUNG') }}
              </div>
            </div>
          </div>
        </div>

        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div class="flex items-center">
            <div class="flex-shrink-0">
              <div class="w-8 h-8 bg-orange-100 dark:bg-orange-900 rounded-md flex items-center justify-center">
                <Icon name="heroicons:clock" class="w-5 h-5 text-orange-600" />
              </div>
            </div>
            <div class="ml-4">
              <div class="text-sm font-medium text-gray-600 dark:text-gray-400">
                {{ $t('tickets.stats.waitingForCustomer') }}
              </div>
              <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                {{ getStatCount('WARTEN_AUF_KUNDE') }}
              </div>
            </div>
          </div>
        </div>

        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div class="flex items-center">
            <div class="flex-shrink-0">
              <div class="w-8 h-8 bg-green-100 dark:bg-green-900 rounded-md flex items-center justify-center">
                <Icon name="heroicons:check-circle" class="w-5 h-5 text-green-600" />
              </div>
            </div>
            <div class="ml-4">
              <div class="text-sm font-medium text-gray-600 dark:text-gray-400">
                {{ $t('tickets.stats.resolved') }}
              </div>
              <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                {{ getStatCount('GELOEST') }}
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Filters and Search -->
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <div class="p-6">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <!-- Search -->
            <div class="md:col-span-2">
              <input
                v-model="searchQuery"
                type="text"
                :placeholder="$t('tickets.searchPlaceholder')"
                class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                @input="debouncedSearch"
              />
            </div>

            <!-- Status Filter -->
            <div>
              <select
                v-model="filters.status"
                @change="loadTickets(1)"
                class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">{{ $t('tickets.allStatuses') }}</option>
                <option value="OFFEN">{{ $t('tickets.statuses.offen') }}</option>
                <option value="IN_BEARBEITUNG">{{ $t('tickets.statuses.in_bearbeitung') }}</option>
                <option value="WARTEN_AUF_KUNDE">{{ $t('tickets.statuses.warten_auf_kunde') }}</option>
                <option value="GELOEST">{{ $t('tickets.statuses.geloest') }}</option>
                <option value="GESCHLOSSEN">{{ $t('tickets.statuses.geschlossen') }}</option>
              </select>
            </div>

            <!-- Department Filter -->
            <div>
              <select
                v-model="filters.department"
                @change="loadTickets(1)"
                class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">{{ $t('tickets.allDepartments') }}</option>
                <option value="Support">{{ $t('tickets.departments.Support') }}</option>
                <option value="Buchhaltung">{{ $t('tickets.departments.Buchhaltung') }}</option>
                <option value="Entwicklung">{{ $t('tickets.departments.Entwicklung') }}</option>
                <option value="Vertrieb">{{ $t('tickets.departments.Vertrieb') }}</option>
                <option value="Allgemein">{{ $t('tickets.departments.Allgemein') }}</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <!-- Tickets Table -->
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <div class="p-6">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">
            {{ $t('tickets.list') }}
          </h3>

          <div v-if="loading" class="text-center py-12">
            <Icon name="heroicons:arrow-path" class="w-8 h-8 text-gray-400 mx-auto mb-4 animate-spin" />
            <p class="text-gray-500 dark:text-gray-400">{{ $t('common.loading') }}</p>
          </div>

          <div v-else-if="tickets.length === 0" class="text-center py-12">
            <Icon name="heroicons:ticket" class="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p class="text-gray-500 dark:text-gray-400">{{ $t('tickets.noTickets') }}</p>
          </div>

          <div v-else class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead class="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {{ $t('tickets.ticket') }}
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {{ $t('tickets.customer') }}
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {{ $t('tickets.department') }}
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {{ $t('common.priority.label') }}
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Status
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {{ $t('tickets.createdAt') }}
                  </th>
                  <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Aktionen
                  </th>
                </tr>
              </thead>
              <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                <tr 
                  v-for="ticket in tickets" 
                  :key="ticket.id"
                  class="hover:bg-gray-50 dark:hover:bg-gray-700"
                >
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div class="text-sm font-medium text-gray-900 dark:text-white">
                        {{ ticket.title }}
                      </div>
                      <div class="text-sm text-gray-500 dark:text-gray-400 truncate max-w-xs">
                        {{ ticket.description }}
                      </div>
                    </div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="text-sm text-gray-900 dark:text-white">
                      {{ ticket.customer.companyName }}
                    </div>
                    <div class="text-sm text-gray-500 dark:text-gray-400">
                      {{ ticket.customer.contactName }}
                    </div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {{ $t(`tickets.departments.${ticket.department}`) }}
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <span 
                      class="inline-flex px-2 py-1 text-xs font-medium rounded-full"
                      :class="getPriorityBadgeClass(ticket.priority)"
                    >
                      {{ $t(`common.priority.${ticket.priority.toLowerCase()}`) }}
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <span 
                      class="inline-flex px-2 py-1 text-xs font-medium rounded-full"
                      :class="getStatusBadgeClass(ticket.status)"
                    >
                      {{ $t(`tickets.statuses.${ticket.status.toLowerCase()}`) }}
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {{ formatDate(ticket.createdAt) }}
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div class="flex justify-end space-x-2">
                      <button
                        @click="showConversionModal(ticket)"
                        :disabled="!canConvertTicket(ticket)"
                        class="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 disabled:text-gray-400 disabled:cursor-not-allowed"
                        :title="$t('tickets.conversion.convertToTask')"
                      >
                        <Icon name="heroicons:arrow-right" class="w-4 h-4" />
                      </button>
                      <NuxtLink
                        :to="`/tickets/${ticket.id}`"
                        class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-300"
                        :title="$t('tickets.viewDetails')"
                      >
                        <Icon name="heroicons:eye" class="w-4 h-4" />
                      </NuxtLink>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>

            <!-- Pagination -->
            <div class="flex items-center justify-between px-6 py-3 border-t border-gray-200 dark:border-gray-700">
              <div class="flex items-center text-sm text-gray-500 dark:text-gray-400">
                <span>
                  {{ $t('common.pagination.showing', { 
                    start: (pagination.page - 1) * pagination.limit + 1,
                    end: Math.min(pagination.page * pagination.limit, pagination.total),
                    total: pagination.total 
                  }) }}
                </span>
              </div>
              <div class="flex items-center space-x-1">
                <button
                  @click="changePage(pagination.page - 1)"
                  :disabled="pagination.page <= 1"
                  class="px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {{ $t('common.pagination.previous') }}
                </button>
                <span class="px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                  {{ $t('common.pagination.page', { page: pagination.page, pages: pagination.pages }) }}
                </span>
                <button
                  @click="changePage(pagination.page + 1)"
                  :disabled="pagination.page >= pagination.pages"
                  class="px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {{ $t('common.pagination.next') }}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Ticket Conversion Modal -->
      <TicketConversionModal
        :ticket="selectedTicketForConversion"
        :show-modal="showConversion"
        @close="closeConversionModal"
        @converted="onTicketConverted"
      />
    </div>
</template>

<script setup>
const { t } = useI18n()
const notificationsStore = useNotificationsStore()
const { addNotification } = notificationsStore

// State
const loading = ref(false)
const tickets = ref([])
const stats = ref([])
const searchQuery = ref('')
const selectedTicketForConversion = ref(null)
const showConversion = ref(false)

// Filters
const filters = ref({
  status: '',
  department: '',
  priority: ''
})

// Pagination
const pagination = ref({
  page: 1,
  limit: 20,
  total: 0,
  pages: 0
})

// Methods
const loadTickets = async (page = 1) => {
  try {
    loading.value = true

    const params = new URLSearchParams({
      page: page.toString(),
      limit: pagination.value.limit.toString(),
      ...(filters.value.status && { status: filters.value.status }),
      ...(filters.value.department && { department: filters.value.department }),
      ...(filters.value.priority && { priority: filters.value.priority }),
      ...(searchQuery.value && { search: searchQuery.value })
    })

    const response = await $fetch(`/api/tickets?${params}`)
    
    tickets.value = response.tickets
    stats.value = response.stats
    pagination.value = response.pagination

  } catch (error) {
    console.error('Failed to load tickets:', error)
    addNotification({
      type: 'error',
      title: 'Fehler',
      message: 'Tickets konnten nicht geladen werden.'
    })
  } finally {
    loading.value = false
  }
}

// Statistics helper
const getStatCount = (status) => {
  const stat = stats.value.find(s => s.status === status)
  return stat?._count?.status || 0
}

// Pagination
const changePage = (page) => {
  if (page >= 1 && page <= pagination.value.pages) {
    loadTickets(page)
  }
}

// Search debouncing
let searchTimeout
const debouncedSearch = () => {
  clearTimeout(searchTimeout)
  searchTimeout = setTimeout(() => {
    loadTickets(1)
  }, 500)
}

// Conversion Modal
const showConversionModal = (ticket) => {
  selectedTicketForConversion.value = ticket
  showConversion.value = true
}

const closeConversionModal = () => {
  showConversion.value = false
  selectedTicketForConversion.value = null
}

const onTicketConverted = (task) => {
  loadTickets(pagination.value.page) // Reload current page
  addNotification({
    type: 'success',
    title: 'Ticket konvertiert',
    message: `Task ${task.key} wurde erfolgreich erstellt`
  })
}

const canConvertTicket = (ticket) => {
  return ['OFFEN', 'IN_BEARBEITUNG'].includes(ticket.status)
}

// Badge Classes
const getStatusBadgeClass = (status) => {
  const classes = {
    'OFFEN': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
    'IN_BEARBEITUNG': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
    'WARTEN_AUF_KUNDE': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
    'GELOEST': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    'GESCHLOSSEN': 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
  }
  return classes[status] || 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
}

const getPriorityBadgeClass = (priority) => {
  const classes = {
    'NIEDRIG': 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300',
    'NORMAL': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
    'HOCH': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
    'KRITISCH': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
  }
  return classes[priority] || 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
}

const formatDate = (date) => {
  return new Date(date).toLocaleDateString('de-DE', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// Lifecycle
onMounted(() => {
  loadTickets()
})

// Page meta
definePageMeta({
  layout: 'default',
})

// SEO
useSeoMeta({
  title: () => t('tickets.management.title'),
  description: () => t('tickets.management.description')
})
</script>
