<template>
  <div class="space-y-6">
    <!-- Comments Header -->
    <div class="flex items-center justify-between">
      <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
        {{ $t('tickets.comments.title') }}
        <span v-if="comments.length > 0" class="text-sm font-normal text-gray-500 dark:text-gray-400">
          ({{ comments.length }})
        </span>
      </h3>
    </div>

    <!-- Comment Form -->
    <div v-if="canComment" class="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
      <form @submit.prevent="submitComment">
        <label for="comment-input" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          {{ $t('tickets.comments.yourComment') }}
        </label>
        <textarea
          id="comment-input"
          v-model="newComment"
          rows="3"
          :placeholder="$t('tickets.comments.placeholder')"
          class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white resize-none"
          required
        ></textarea>
        <div class="mt-3 flex justify-end space-x-3">
          <button
            type="button"
            @click="newComment = ''"
            class="px-4 py-2 text-sm text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 font-medium transition-colors"
          >
            {{ $t('tickets.comments.cancelComment') }}
          </button>
          <button
            type="submit"
            :disabled="submitting || !newComment.trim()"
            class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white text-sm font-medium rounded-md transition-colors"
          >
            <Icon v-if="submitting" name="heroicons:arrow-path" class="w-4 h-4 mr-2 animate-spin" />
            {{ submitting ? $t('tickets.comments.submittingComment') : $t('tickets.comments.submitComment') }}
          </button>
        </div>
      </form>
    </div>

    <!-- Comments List -->
    <div class="space-y-4">
      <!-- Loading State -->
      <div v-if="loading" class="space-y-4">
        <div v-for="i in 3" :key="i" class="animate-pulse">
          <div class="flex space-x-3">
            <div class="w-8 h-8 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
            <div class="flex-1 space-y-2">
              <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
              <div class="h-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- No Comments State -->
      <div v-else-if="comments.length === 0" class="text-center py-8">
        <Icon name="heroicons:chat-bubble-left" class="w-12 h-12 mx-auto mb-4 text-gray-300 dark:text-gray-600" />
        <p class="text-gray-600 dark:text-gray-400">
          {{ $t('tickets.comments.noComments') }}
        </p>
      </div>

      <!-- Comments -->
      <div v-else class="space-y-4">
        <div
          v-for="comment in comments"
          :key="comment.id"
          class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4"
          :class="{
            'border-l-4 border-l-blue-500': comment.author.role !== 'customer',
            'border-l-4 border-l-green-500': comment.author.role === 'customer'
          }"
        >
          <!-- Comment Header -->
          <div class="flex items-center justify-between mb-3">
            <div class="flex items-center space-x-3">
              <!-- Avatar -->
              <div 
                class="w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium text-white"
                :class="{
                  'bg-blue-500': comment.author.role !== 'customer',
                  'bg-green-500': comment.author.role === 'customer'
                }"
              >
                {{ getInitials(comment.author.firstName, comment.author.lastName) }}
              </div>
              
              <!-- Author Info -->
              <div>
                <div class="flex items-center space-x-2">
                  <span class="text-sm font-medium text-gray-900 dark:text-white">
                    {{ comment.author.firstName }} {{ comment.author.lastName }}
                  </span>
                  <span class="text-xs px-2 py-1 rounded-full" :class="{
                    'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300': comment.author.role !== 'KUNDE',
                    'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300': comment.author.role === 'KUNDE'
                  }">
                    {{ comment.author.role === 'KUNDE' ? $t('tickets.comments.customer') : $t('tickets.comments.staff') }}
                  </span>
                  <span v-if="comment.isInternal" class="text-xs px-2 py-1 bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300 rounded-full">
                    {{ $t('tickets.comments.internal') }}
                  </span>
                </div>
                <p class="text-xs text-gray-500 dark:text-gray-400">
                  {{ formatRelativeTime(comment.createdAt) }}
                </p>
              </div>
            </div>
          </div>

          <!-- Comment Content -->
          <div class="prose dark:prose-invert max-w-none">
            <p class="text-gray-700 dark:text-gray-300 whitespace-pre-wrap text-sm">{{ comment.content }}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
const props = defineProps({
  ticketId: {
    type: String,
    required: true
  },
  ticketStatus: {
    type: String,
    required: true
  }
})

const notificationsStore = useNotificationsStore()

// State
const loading = ref(false)
const submitting = ref(false)
const comments = ref([])
const newComment = ref('')

// Computed
const canComment = computed(() => {
  return props.ticketStatus !== 'GESCHLOSSEN'
})

// Methods
const loadComments = async () => {
  loading.value = true
  try {
    const response = await $fetch(`/api/customer/tickets/${props.ticketId}/comments`)
    comments.value = response
  } catch (error) {
    console.error('Failed to load comments:', error)
    notificationsStore.addNotification({
      type: 'error',
      title: 'Fehler',
      message: 'Kommentare konnten nicht geladen werden.'
    })
  } finally {
    loading.value = false
  }
}

const submitComment = async () => {
  if (!newComment.value.trim()) return

  submitting.value = true
  try {
    const response = await $fetch(`/api/customer/tickets/${props.ticketId}/comments`, {
      method: 'POST',
      body: {
        content: newComment.value.trim()
      }
    })

    // Add new comment to the list
    comments.value.push(response.comment)
    newComment.value = ''

    notificationsStore.addNotification({
      type: 'success',
      title: 'Erfolg',
      message: response.message
    })

    // Emit event to parent to refresh ticket data
    emit('commentAdded')

  } catch (error) {
    console.error('Failed to submit comment:', error)
    notificationsStore.addNotification({
      type: 'error',
      title: 'Fehler',
      message: error.data?.message || 'Kommentar konnte nicht hinzugefügt werden.'
    })
  } finally {
    submitting.value = false
  }
}

const getInitials = (firstName, lastName) => {
  return `${firstName?.charAt(0) || ''}${lastName?.charAt(0) || ''}`.toUpperCase()
}

const formatRelativeTime = (date) => {
  const now = new Date()
  const commentDate = new Date(date)
  const diffInMinutes = Math.floor((now - commentDate) / (1000 * 60))

  if (diffInMinutes < 1) {
    return 'gerade eben'
  } else if (diffInMinutes < 60) {
    return `vor ${diffInMinutes} Minuten`
  } else if (diffInMinutes < 1440) {
    const hours = Math.floor(diffInMinutes / 60)
    return `vor ${hours} Stunden`
  } else {
    const days = Math.floor(diffInMinutes / 1440)
    return `vor ${days} Tagen`
  }
}

// Events
const emit = defineEmits(['commentAdded'])

// Load comments on mount
onMounted(() => {
  loadComments()
})

// Expose methods for parent component
defineExpose({
  loadComments
})
</script>
