<template>
  <div class="group bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4 hover:shadow-md transition-shadow duration-200 cursor-pointer"
       @click="$emit('click', task)">
    <!-- Task Header -->
    <div class="flex items-start justify-between mb-3">
      <div class="flex items-center space-x-2">
        <span class="text-xs font-mono text-gray-500 dark:text-gray-400">{{ task.key }}</span>
        <TaskPropertyBadge :enum-value="task.status" size="sm" />
        <TaskPropertyBadge :enum-value="task.priority" size="sm" />
      </div>
      
      <!-- Task-Typ Icon -->
      <div class="flex-shrink-0">
        <TaskPropertyBadge 
          :enum-value="task.type" 
          size="sm" 
          :show-dot="false" 
          show-icon 
          class="bg-transparent border-0 p-0" />
      </div>
    </div>

    <!-- Task Title -->
    <h3 class="font-medium text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors line-clamp-2 mb-2">
      {{ task.title }}
    </h3>

    <!-- Task Description -->
    <p v-if="task.description" 
       class="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 mb-3">
      {{ task.description }}
    </p>

    <!-- Task Meta Information -->
    <div class="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 mb-3">
      <div class="flex items-center space-x-3">
        <!-- Projekt -->
        <div class="flex items-center space-x-1">
          <FolderIcon class="h-3 w-3" />
          <span>{{ task.project.name }}</span>
        </div>
        
        <!-- Fälligkeitsdatum -->
        <div v-if="task.dueDate" class="flex items-center space-x-1">
          <CalendarIcon class="h-3 w-3" />
          <span :class="{ 'text-red-600 dark:text-red-400': isOverdue(task.dueDate) }">
            {{ formatDate(task.dueDate) }}
          </span>
        </div>
      </div>

      <!-- Zeitschätzung -->
      <div v-if="task.estimatedHours" class="flex items-center space-x-1">
        <ClockIcon class="h-3 w-3" />
        <span>{{ task.estimatedHours }}h</span>
      </div>
    </div>

    <!-- Task Footer -->
    <div class="flex items-center justify-between">
      <!-- Assignee -->
      <div class="flex items-center space-x-2">
        <div v-if="task.assignee" class="flex items-center space-x-2">
          <img v-if="task.assignee.image" 
               :src="task.assignee.image" 
               :alt="`${task.assignee.firstName} ${task.assignee.lastName}`"
               class="h-6 w-6 rounded-full object-cover">
          <div v-else class="h-6 w-6 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center">
            <span class="text-xs font-medium text-gray-700 dark:text-gray-300">
              {{ task.assignee.firstName.charAt(0) }}{{ task.assignee.lastName.charAt(0) }}
            </span>
          </div>
          <span class="text-sm text-gray-600 dark:text-gray-400">
            {{ task.assignee.firstName }} {{ task.assignee.lastName }}
          </span>
        </div>
        <div v-else class="flex items-center space-x-2 text-gray-400 dark:text-gray-500">
          <UserIcon class="h-4 w-4" />
          <span class="text-sm">Nicht zugewiesen</span>
        </div>
      </div>

      <!-- Task Stats -->
      <div v-if="task._count" class="flex items-center space-x-3 text-xs text-gray-500 dark:text-gray-400">
        <div v-if="task._count.comments > 0" class="flex items-center space-x-1">
          <ChatBubbleLeftIcon class="h-3 w-3" />
          <span>{{ task._count.comments }}</span>
        </div>
        <div v-if="task._count.attachments > 0" class="flex items-center space-x-1">
          <PaperClipIcon class="h-3 w-3" />
          <span>{{ task._count.attachments }}</span>
        </div>
        <div v-if="task._count.timeEntries > 0" class="flex items-center space-x-1">
          <ClockIcon class="h-3 w-3" />
          <span>{{ task._count.timeEntries }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { 
  FolderIcon, 
  CalendarIcon, 
  ClockIcon, 
  UserIcon,
  ChatBubbleLeftIcon,
  PaperClipIcon,
  BugAntIcon,
  StarIcon,
  ArrowUpIcon,
  ClipboardDocumentListIcon,
  BookOpenIcon,
  FlagIcon
} from '@heroicons/vue/24/outline'
import type { TaskWithDetails } from '../stores/tasks'

interface Props {
  task: TaskWithDetails
}

const props = defineProps<Props>()

const emit = defineEmits<{
  click: [task: TaskWithDetails]
}>()

// Task-Typ-Icons
const getTaskTypeIcon = (type: string) => {
  const icons = {
    'BUG': BugAntIcon,
    'FEATURE': StarIcon,
    'VERBESSERUNG': ArrowUpIcon,
    'AUFGABE': ClipboardDocumentListIcon,
    'STORY': BookOpenIcon,
    'EPIC': FlagIcon
  }
  return icons[type as keyof typeof icons] || ClipboardDocumentListIcon
}

// Datum-Formatierung
const formatDate = (date: string | Date) => {
  return new Date(date).toLocaleDateString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  })
}

// Überprüfung ob Aufgabe überfällig ist
const isOverdue = (dueDate: string | Date) => {
  return new Date(dueDate) < new Date()
}
</script>

<style scoped>
.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
