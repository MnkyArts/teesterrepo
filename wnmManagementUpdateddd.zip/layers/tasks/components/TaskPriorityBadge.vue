<template>
  <span 
    class="inline-flex items-center gap-1 rounded-full text-xs font-medium"
    :class="[sizeClasses, priorityClasses]"
    :style="dynamicStyles"
  >
    <div 
      class="rounded-full" 
      :class="[dotSizeClasses, dotClasses]"
      :style="dotStyles"
    ></div>
    {{ priorityText }}
  </span>
</template>

<script setup lang="ts">
import type { EnumValue } from '@prisma/client'

// Props
const props = withDefaults(defineProps<{
  priority: string | EnumValue | 'NIEDRIG' | 'NORMAL' | 'HOCH' | 'KRITISCH' | 'BLOCKER'
  size?: 'sm' | 'md'
}>(), {
  size: 'md'
})

// Computed
const sizeClasses = computed(() => {
  return props.size === 'sm' ? 'px-2 py-0.5' : 'px-2 py-1'
})

const dotSizeClasses = computed(() => {
  return props.size === 'sm' ? 'h-1 w-1' : 'h-1.5 w-1.5'
})

// Helper to check if priority is an EnumValue object
const isEnumValue = (value: any): value is EnumValue => {
  return value && typeof value === 'object' && 'key' in value && 'label' in value
}

// Get the priority key for lookup (either from EnumValue.key or the string directly)
const priorityKey = computed(() => {
  if (isEnumValue(props.priority)) {
    return props.priority.key
  }
  return props.priority as string
})

// Get display text (either from EnumValue.label or fallback to key)
const priorityText = computed(() => {
  if (isEnumValue(props.priority)) {
    return props.priority.label
  }
  // Fallback for hardcoded priorities
  return priorityConfig.value.text
})

// Get dynamic color from EnumValue if available
const dynamicColor = computed(() => {
  if (isEnumValue(props.priority) && props.priority.color) {
    return props.priority.color
  }
  return null
})

const priorityConfig = computed(() => {
  const configs = {
    NIEDRIG: {
      text: 'Niedrig',
      classes: 'bg-green-50 text-green-700 border border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800',
      dotClasses: 'bg-green-500'
    },
    NORMAL: {
      text: 'Normal',
      classes: 'bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-900/30 dark:text-blue-400 dark:border-blue-800',
      dotClasses: 'bg-blue-500'
    },
    HOCH: {
      text: 'Hoch',
      classes: 'bg-orange-50 text-orange-700 border border-orange-200 dark:bg-orange-900/30 dark:text-orange-400 dark:border-orange-800',
      dotClasses: 'bg-orange-500'
    },
    KRITISCH: {
      text: 'Kritisch',
      classes: 'bg-red-50 text-red-700 border border-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800',
      dotClasses: 'bg-red-500'
    },
    BLOCKER: {
      text: 'Blocker',
      classes: 'bg-red-100 text-red-800 border border-red-300 dark:bg-red-900/50 dark:text-red-300 dark:border-red-700',
      dotClasses: 'bg-red-700'
    }
  }
  
  return configs[priorityKey.value as keyof typeof configs] || configs.NORMAL
})

const priorityClasses = computed(() => {
  if (dynamicColor.value) {
    // Use basic classes when we have dynamic color
    return 'border'
  }
  // Fall back to predefined classes
  return priorityConfig.value.classes
})

const dotClasses = computed(() => {
  if (dynamicColor.value) {
    return '' // No classes needed, will use styles
  }
  return priorityConfig.value.dotClasses
})

// Dynamic styles for custom colors
const dynamicStyles = computed(() => {
  if (!dynamicColor.value) return {}
  
  const color = dynamicColor.value
  // Convert hex to RGB for alpha values
  const hex = color.replace('#', '')
  const r = parseInt(hex.substr(0, 2), 16)
  const g = parseInt(hex.substr(2, 2), 16)
  const b = parseInt(hex.substr(4, 2), 16)
  
  return {
    backgroundColor: `rgba(${r}, ${g}, ${b}, 0.1)`,
    color: color, // Use the enum color directly for text
    borderColor: `rgba(${r}, ${g}, ${b}, 0.3)`
  }
})

const dotStyles = computed(() => {
  if (!dynamicColor.value) return {}
  
  return {
    backgroundColor: dynamicColor.value
  }
})
</script>
