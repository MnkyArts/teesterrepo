<template>
  <div 
    class="kanban-task-card bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4 cursor-pointer hover:shadow-md transition-shadow duration-200"
    @click="$emit('view', task)">
    
    <!-- Task Header -->
    <div class="flex items-start justify-between mb-3">
      <div class="flex items-center space-x-2">
        <TaskPropertyBadge :enum-value="task.priority" size="sm" />
        <span class="text-xs font-mono text-gray-500 dark:text-gray-400">
          {{ task.project.key }}-{{ task.id.slice(-4) }}
        </span>
      </div>
      
      <div class="flex items-center space-x-1">
        <button
          @click.stop="$emit('edit', task)"
          class="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded transition-colors duration-200">
          <PencilIcon class="h-4 w-4" />
        </button>
      </div>
    </div>

    <!-- Task Title -->
    <h4 class="font-medium text-gray-900 dark:text-white mb-2 leading-tight">
      {{ task.title }}
    </h4>

    <!-- Task Description (truncated) -->
    <p 
      v-if="task.description" 
      class="text-sm text-gray-600 dark:text-gray-400 mb-3 line-clamp-2">
      {{ task.description }}
    </p>

    <!-- Task Meta Information -->
    <div class="space-y-2">
      <!-- Project Info -->
      <div class="flex items-center space-x-2">
        <FolderIcon class="h-4 w-4 text-gray-400" />
        <span class="text-xs text-gray-600 dark:text-gray-400">{{ task.project.name }}</span>
      </div>

      <!-- Due Date -->
      <div 
        v-if="task.dueDate" 
        class="flex items-center space-x-2"
        :class="dueDateClass">
        <CalendarIcon class="h-4 w-4" />
        <span class="text-xs">{{ formatDate(task.dueDate) }}</span>
      </div>

      <!-- Time Estimation -->
      <div 
        v-if="task.estimatedHours" 
        class="flex items-center space-x-2">
        <ClockIcon class="h-4 w-4 text-gray-400" />
        <span class="text-xs text-gray-600 dark:text-gray-400">
          {{ task.estimatedHours }}h geschätzt
        </span>
      </div>

      <!-- Assignee -->
      <div 
        v-if="task.assignee" 
        class="flex items-center space-x-2">
        <div class="flex items-center space-x-2">
          <img
            v-if="task.assignee.image"
            :src="task.assignee.image"
            :alt="assigneeName"
            class="h-6 w-6 rounded-full">
          <div 
            v-else
            class="h-6 w-6 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center">
            <span class="text-xs font-medium text-gray-700 dark:text-gray-300">
              {{ getInitials(assigneeName) }}
            </span>
          </div>
          <span class="text-xs text-gray-600 dark:text-gray-400">{{ assigneeName }}</span>
        </div>
      </div>
    </div>

    <!-- Task Footer -->
    <div class="mt-3 pt-3 border-t border-gray-100 dark:border-gray-700 flex items-center justify-between">
      <!-- Task Type Badge -->
      <div class="flex items-center space-x-2">
        <TaskPropertyBadge 
          :enum-value="task.type" 
          size="sm" 
          class="text-xs" />
      </div>

      <!-- Comment Count -->
      <div 
        v-if="task._count?.comments && task._count.comments > 0"
        class="flex items-center space-x-1 text-gray-500 dark:text-gray-400">
        <ChatBubbleLeftIcon class="h-4 w-4" />
        <span class="text-xs">{{ task._count.comments }}</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { 
  PencilIcon, 
  FolderIcon, 
  CalendarIcon, 
  ClockIcon,
  ChatBubbleLeftIcon 
} from '@heroicons/vue/24/outline'
import type { TaskWithDetails } from '../stores/tasks'

interface Props {
  task: TaskWithDetails
}

interface Emits {
  (e: 'edit', task: TaskWithDetails): void
  (e: 'view', task: TaskWithDetails): void
}

const props = defineProps<Props>()
const emit = defineEmits<Emits>()

// Computed
const assigneeName = computed(() => {
  if (!props.task.assignee) return ''
  return `${props.task.assignee.firstName} ${props.task.assignee.lastName}`
})

const dueDateClass = computed(() => {
  if (!props.task.dueDate) return ''
  
  const dueDate = new Date(props.task.dueDate)
  const today = new Date()
  const diffDays = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
  
  if (diffDays < 0) {
    return 'text-red-600 dark:text-red-400' // Überfällig
  } else if (diffDays <= 3) {
    return 'text-orange-600 dark:text-orange-400' // Bald fällig
  } else {
    return 'text-gray-600 dark:text-gray-400' // Normal
  }
})

// Methods
const formatDate = (date: string | Date): string => {
  return new Date(date).toLocaleDateString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  })
}

const getInitials = (name: string): string => {
  return name
    .split(' ')
    .map(n => n.charAt(0))
    .join('')
    .toUpperCase()
    .substring(0, 2)
}

const getTypeLabel = (type: string): string => {
  const typeLabels: Record<string, string> = {
    BUG: 'Bug',
    FEATURE: 'Feature',
    VERBESSERUNG: 'Verbesserung',
    AUFGABE: 'Aufgabe',
    STORY: 'Story',
    EPIC: 'Epic'
  }
  return typeLabels[type] || type
}

const getTypeColorClass = (type: string): string => {
  const typeColors: Record<string, string> = {
    BUG: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
    FEATURE: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
    VERBESSERUNG: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    AUFGABE: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200',
    STORY: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
    EPIC: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200'
  }
  return typeColors[type] || 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
}
</script>

<style scoped>
.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.kanban-task-card {
  transition: all 0.2s ease-in-out;
}

.kanban-task-card:hover {
  transform: translateY(-2px);
}
</style>
