<template>
  <span 
    class="inline-flex items-center gap-1 rounded-full text-xs font-medium"
    :class="[sizeClasses, statusClasses]"
    :style="dynamicStyles"
  >
    <div 
      class="rounded-full" 
      :class="[dotSizeClasses, dotClasses]"
      :style="dotStyles"
    ></div>
    {{ statusText }}
  </span>
</template>

<script setup lang="ts">
import type { EnumValue } from '@prisma/client'

// Props
const props = withDefaults(defineProps<{
  status: string | EnumValue | 'GEPLANT' | 'TECHNISCHES_DESIGN' | 'IN_BEARBEITUNG' | 'REVIEW' | 'TESTING' | 'ERLEDIGT' | 'GESCHLOSSEN'
  size?: 'sm' | 'md'
}>(), {
  size: 'md'
})

// Computed
const sizeClasses = computed(() => {
  return props.size === 'sm' ? 'px-2 py-0.5' : 'px-2 py-1'
})

const dotSizeClasses = computed(() => {
  return props.size === 'sm' ? 'h-1 w-1' : 'h-1.5 w-1.5'
})

// Helper to check if status is an EnumValue object
const isEnumValue = (value: any): value is EnumValue => {
  return value && typeof value === 'object' && 'key' in value && 'label' in value
}

// Get the status key for lookup (either from EnumValue.key or the string directly)
const statusKey = computed(() => {
  if (isEnumValue(props.status)) {
    return props.status.key
  }
  return props.status as string
})

// Get display text (either from EnumValue.label or fallback to key)
const statusText = computed(() => {
  if (isEnumValue(props.status)) {
    return props.status.label
  }
  // Fallback for hardcoded statuses
  return statusConfig.value.text
})

// Get dynamic color from EnumValue if available
const dynamicColor = computed(() => {
  if (isEnumValue(props.status) && props.status.color) {
    return props.status.color
  }
  return null
})

const statusConfig = computed(() => {
  const configs = {
    GEPLANT: {
      text: 'Geplant',
      classes: 'bg-gray-50 text-gray-700 border border-gray-200 dark:bg-gray-900/30 dark:text-gray-400 dark:border-gray-800',
      dotClasses: 'bg-gray-500'
    },
    TECHNISCHES_DESIGN: {
      text: 'Design',
      classes: 'bg-purple-50 text-purple-700 border border-purple-200 dark:bg-purple-900/30 dark:text-purple-400 dark:border-purple-800',
      dotClasses: 'bg-purple-500'
    },
    IN_BEARBEITUNG: {
      text: 'In Bearbeitung',
      classes: 'bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-900/30 dark:text-blue-400 dark:border-blue-800',
      dotClasses: 'bg-blue-500'
    },
    REVIEW: {
      text: 'Review',
      classes: 'bg-yellow-50 text-yellow-700 border border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-400 dark:border-yellow-800',
      dotClasses: 'bg-yellow-500'
    },
    TESTING: {
      text: 'Testing',
      classes: 'bg-orange-50 text-orange-700 border border-orange-200 dark:bg-orange-900/30 dark:text-orange-400 dark:border-orange-800',
      dotClasses: 'bg-orange-500'
    },
    ERLEDIGT: {
      text: 'Erledigt',
      classes: 'bg-green-50 text-green-700 border border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800',
      dotClasses: 'bg-green-500'
    },
    GESCHLOSSEN: {
      text: 'Geschlossen',
      classes: 'bg-gray-50 text-gray-700 border border-gray-200 dark:bg-gray-900/30 dark:text-gray-400 dark:border-gray-800',
      dotClasses: 'bg-gray-600'
    }
  }
  
  return configs[statusKey.value as keyof typeof configs] || configs.GEPLANT
})

// Generate dynamic styles if we have a color from EnumValue
const statusClasses = computed(() => {
  if (dynamicColor.value) {
    // Use basic classes when we have dynamic color
    return 'border'
  }
  // Fall back to predefined classes
  return statusConfig.value.classes
})

const dotClasses = computed(() => {
  if (dynamicColor.value) {
    return '' // No classes needed, will use styles
  }
  return statusConfig.value.dotClasses
})

// Dynamic styles for custom colors
const dynamicStyles = computed(() => {
  if (!dynamicColor.value) return {}
  
  const color = dynamicColor.value
  // Convert hex to RGB for alpha values
  const hex = color.replace('#', '')
  const r = parseInt(hex.substr(0, 2), 16)
  const g = parseInt(hex.substr(2, 2), 16)
  const b = parseInt(hex.substr(4, 2), 16)
  
  return {
    backgroundColor: `rgba(${r}, ${g}, ${b}, 0.1)`,
    color: color, // Use the enum color directly for text
    borderColor: `rgba(${r}, ${g}, ${b}, 0.3)`
  }
})

const dotStyles = computed(() => {
  if (!dynamicColor.value) return {}
  
  return {
    backgroundColor: dynamicColor.value
  }
})

// Helper function to generate dynamic classes based on color (removed as we use styles now)
</script>
