import { defineStore } from 'pinia'
import type { Task, TaskComment, User, Project, EnumValue } from '@prisma/client'

// Extended Task-Type mit Includes
export interface TaskWithDetails extends Task {
  project: {
    id: string
    name: string
    key: string
    customer?: {
      id: string
      companyName: string
    }
  }
  assignee?: {
    id: string
    firstName: string
    lastName: string
    email: string
    image?: string
  }
  creator: {
    id: string
    firstName: string
    lastName: string
    email: string
  }
  comments?: TaskCommentWithAuthor[]
  type?: EnumValue
  priority?: EnumValue
  status?: EnumValue
  _count?: {
    comments: number
    timeEntries: number
    attachments: number
  }
}

export interface TaskCommentWithAuthor extends TaskComment {
  author: {
    id: string
    firstName: string
    lastName: string
    email: string
    image?: string
  }
}

export interface TaskFilters {
  projectId?: string
  assigneeId?: string
  statusId?: string | string[]
  typeId?: string
  priorityId?: string
  search?: string
}

export interface TaskListResponse {
  tasks: TaskWithDetails[]
  total: number
  page: number
  totalPages: number
  hasNext: boolean
  hasPrev: boolean
}

export interface CreateTaskData {
  title: string
  description?: string
  typeId?: string
  priorityId?: string
  statusId?: string
  projectId: string
  assigneeId?: string
  dueDate?: string
  estimatedHours?: number
  remainingHours?: number
}

export interface UpdateTaskData extends Partial<Omit<CreateTaskData, 'projectId'>> {}

export const useTasksStore = defineStore('tasks', () => {
  const notificationsStore = useNotificationsStore()
  const enumManagementStore = useEnumManagementStore()
  
  // State
  const tasks = ref<TaskWithDetails[]>([])
  const currentTask = ref<TaskWithDetails | null>(null)
  const loading = ref(false)
  const error = ref<string | null>(null)

  // Computed
  const tasksByProject = computed(() => {
    const grouped = new Map<string, TaskWithDetails[]>()
    tasks.value.forEach(task => {
      const projectId = task.projectId
      if (!grouped.has(projectId)) {
        grouped.set(projectId, [])
      }
      grouped.get(projectId)!.push(task)
    })
    return grouped
  })

  const tasksByStatus = computed(() => {
    const grouped = new Map<string, TaskWithDetails[]>()
    tasks.value.forEach(task => {
      const statusKey = typeof task.status === 'object' && task.status ? task.status.key : (task.status as unknown as string || 'GEPLANT')
      if (!grouped.has(statusKey)) {
        grouped.set(statusKey, [])
      }
      grouped.get(statusKey)!.push(task)
    })
    return grouped
  })

  const myTasks = computed(() => {
    // This will be implemented when auth store is available
    return tasks.value.filter(task => {
      // TODO: Filter by current user
      return true
    })
  })

  // Dynamic Task metadata from enum system
  const taskTypes = computed(() => 
    enumManagementStore.taskTypeValues.map(value => ({
      label: value.label,
      value: value.key,
      color: value.color,
      icon: value.icon,
      enumValue: value
    }))
  )

  const taskPriorities = computed(() => 
    enumManagementStore.priorityValues.map(value => ({
      label: value.label,
      value: value.key,
      color: value.color,
      icon: value.icon,
      enumValue: value
    }))
  )

  const taskStatuses = computed(() => 
    enumManagementStore.taskStatusValues.map(value => ({
      label: value.label,
      value: value.key,
      color: value.color,
      icon: value.icon,
      enumValue: value
    }))
  )

  // Comments handling
  const fetchComments = async (taskId: string) => {
    try {
      loading.value = true
      const comments = await $fetch<TaskCommentWithAuthor[]>(`/api/tasks/${taskId}/comments`)
      
      // Update the current task with comments
      if (currentTask.value && currentTask.value.id === taskId) {
        currentTask.value.comments = comments
      }
      
      return comments
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Laden der Kommentare'
      notificationsStore.addNotification({
        type: 'error',
        title: 'Fehler',
        message: 'Kommentare konnten nicht geladen werden'
      })
      throw err
    } finally {
      loading.value = false
    }
  }

  // Actions
  const fetchTasks = async (filters: TaskFilters = {}, page = 1, limit = 20) => {
    loading.value = true
    error.value = null

    try {
      const query = new URLSearchParams()
      
      if (filters.projectId) query.append('projectId', filters.projectId)
      if (filters.assigneeId) query.append('assigneeId', filters.assigneeId)
      if (filters.statusId) {
        // Handle both single status and array of statuses
        if (Array.isArray(filters.statusId)) {
          filters.statusId.forEach(status => query.append('status', status))
        } else {
          query.append('status', filters.statusId)
        }
      }
      if (filters.typeId) query.append('type', filters.typeId)
      if (filters.priorityId) query.append('priority', filters.priorityId)
      if (filters.search) query.append('search', filters.search)
      
      query.append('page', page.toString())
      query.append('limit', limit.toString())

      const response = await $fetch<TaskListResponse>(`/api/tasks?${query.toString()}`)
      
      if (page === 1) {
        tasks.value = response.tasks
      } else {
        tasks.value.push(...response.tasks)
      }

      return response
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Laden der Aufgaben'
      notificationsStore.error('Fehler', error.value || 'Ein unbekannter Fehler ist aufgetreten')
      throw err
    } finally {
      loading.value = false
    }
  }

  const fetchTask = async (taskId: string) => {
    loading.value = true
    error.value = null

    try {
      const task = await $fetch<TaskWithDetails>(`/api/tasks/${taskId}`)
      currentTask.value = task
      
      // Update task in list if it exists
      const index = tasks.value.findIndex(t => t.id === taskId)
      if (index !== -1) {
        tasks.value[index] = task
      }
      
      return task
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Laden der Aufgabe'
      notificationsStore.error('Fehler', error.value || 'Ein unbekannter Fehler ist aufgetreten')
      throw err
    } finally {
      loading.value = false
    }
  }

  const createTask = async (taskData: CreateTaskData) => {
    loading.value = true
    error.value = null

    try {
      const newTask = await $fetch<TaskWithDetails>('/api/tasks', {
        method: 'POST',
        body: taskData
      })

      tasks.value.unshift(newTask)
      
      notificationsStore.success('Erfolg', 'Aufgabe erfolgreich erstellt')

      return newTask
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Erstellen der Aufgabe'
      notificationsStore.error('Fehler', error.value || 'Ein unbekannter Fehler ist aufgetreten')
      throw err
    } finally {
      loading.value = false
    }
  }

  const updateTask = async (taskId: string, taskData: UpdateTaskData) => {
    loading.value = true
    error.value = null

    try {
      const updatedTask = await $fetch<TaskWithDetails>(`/api/tasks/${taskId}`, {
        method: 'PUT',
        body: taskData
      })

      // Task in der Liste aktualisieren
      const index = tasks.value.findIndex(t => t.id === taskId)
      if (index !== -1) {
        tasks.value[index] = updatedTask
      }

      // Aktuelle Task aktualisieren falls sie geladen ist
      if (currentTask.value?.id === taskId) {
        currentTask.value = updatedTask
      }

      notificationsStore.success('Erfolg', 'Aufgabe erfolgreich aktualisiert')

      return updatedTask
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Aktualisieren der Aufgabe'
      notificationsStore.error('Fehler', error.value || 'Ein unbekannter Fehler ist aufgetreten')
      throw err
    } finally {
      loading.value = false
    }
  }

  const deleteTask = async (taskId: string) => {
    loading.value = true
    error.value = null

    try {
      await $fetch(`/api/tasks/${taskId}`, {
        method: 'DELETE'
      })

      // Task aus der Liste entfernen
      tasks.value = tasks.value.filter(t => t.id !== taskId)

      // Aktuelle Task zurücksetzen falls sie gelöscht wurde
      if (currentTask.value?.id === taskId) {
        currentTask.value = null
      }

      notificationsStore.success('Erfolg', 'Aufgabe erfolgreich gelöscht')

      return true
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Löschen der Aufgabe'
      notificationsStore.error('Fehler', error.value || 'Ein unbekannter Fehler ist aufgetreten')
      throw err
    } finally {
      loading.value = false
    }
  }

  const addComment = async (taskId: string, content: string, isInternal = false) => {
    try {
      const newComment = await $fetch<TaskCommentWithAuthor>(`/api/tasks/${taskId}/comments`, {
        method: 'POST',
        body: { content, isInternal }
      })

      // Kommentar zur aktuellen Task hinzufügen
      if (currentTask.value?.id === taskId && currentTask.value.comments) {
        currentTask.value.comments.push(newComment)
      }

      notificationsStore.success('Erfolg', 'Kommentar hinzugefügt')

      return newComment
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Hinzufügen des Kommentars'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const updateComment = async (taskId: string, commentId: string, content: string) => {
    try {
      const updatedComment = await $fetch<TaskCommentWithAuthor>(`/api/tasks/${taskId}/comments/${commentId}`, {
        method: 'PUT',
        body: { content }
      })

      // Kommentar in der aktuellen Task aktualisieren
      if (currentTask.value?.id === taskId && currentTask.value.comments) {
        const index = currentTask.value.comments.findIndex(c => c.id === commentId)
        if (index !== -1) {
          currentTask.value.comments[index] = updatedComment
        }
      }

      notificationsStore.success('Erfolg', 'Kommentar aktualisiert')

      return updatedComment
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Aktualisieren des Kommentars'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const deleteComment = async (taskId: string, commentId: string) => {
    try {
      await $fetch(`/api/tasks/${taskId}/comments/${commentId}`, {
        method: 'DELETE'
      })

      // Kommentar aus der aktuellen Task entfernen
      if (currentTask.value?.id === taskId && currentTask.value.comments) {
        currentTask.value.comments = currentTask.value.comments.filter(c => c.id !== commentId)
      }

      notificationsStore.success('Erfolg', 'Kommentar gelöscht')

      return true
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Löschen des Kommentars'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const setCurrentTask = (task: TaskWithDetails | null) => {
    currentTask.value = task
  }

  const clearTasks = () => {
    tasks.value = []
    currentTask.value = null
    error.value = null
  }

  return {
    // State
    tasks: readonly(tasks),
    currentTask: readonly(currentTask),
    loading: readonly(loading),
    error: readonly(error),
    
    // Computed
    tasksByProject,
    tasksByStatus,
    myTasks,
    taskTypes,
    taskPriorities,
    taskStatuses,
    
    // Actions
    fetchTasks,
    fetchTask,
    createTask,
    updateTask,
    deleteTask,
    addComment,
    updateComment,
    deleteComment,
    fetchComments,
    setCurrentTask,
    clearTasks
  }
})
