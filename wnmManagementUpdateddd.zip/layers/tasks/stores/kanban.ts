import { defineStore } from 'pinia'
import type { TaskWithDetails, TaskFilters } from './tasks'

export interface KanbanColumn {
  id: string
  title: string
  color: string
  tasks: TaskWithDetails[]
  order: number
}

export interface KanbanBoard {
  columns: KanbanColumn[]
  projectId?: string
  assigneeId?: string
}

export interface KanbanFilters {
  projectId?: string
  assigneeId?: string
  priority?: string
  type?: string
  search?: string
}

export const useKanbanStore = defineStore('kanban', () => {
  const enumManagementStore = useEnumManagementStore()

  // State
  const board = ref<KanbanBoard>({ columns: [] })
  const isLoading = ref(false)
  const currentFilters = ref<KanbanFilters>({})

  // Helper function to get other stores
  const getTasksStore = () => useTasksStore()
  const getNotificationsStore = () => useNotificationsStore()

  // Computed - Dynamic status configuration from enum system
  const availableStatuses = computed(() => 
    enumManagementStore.taskStatusValues
      .filter(status => status.isActive)
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .map(status => ({
        id: status.id,
        key: status.key,
        status: status.key, // Keep for backward compatibility
        title: status.label,
        color: status.color || 'gray',
        order: status.sortOrder
      }))
  )

  const totalTasks = computed(() => 
    board.value.columns.reduce((total, column) => total + column.tasks.length, 0)
  )

  const tasksByStatus = computed(() => {
    const grouped = new Map<string, number>()
    board.value.columns.forEach(column => {
      grouped.set(column.id, column.tasks.length)
    })
    return grouped
  })

  // Actions
  const createKanbanBoard = (tasks: TaskWithDetails[], filters?: KanbanFilters): KanbanBoard => {
    const columns: KanbanColumn[] = availableStatuses.value.map(({ status, title, color, order }) => ({
      id: status,
      title,
      color,
      order,
      tasks: tasks.filter(task => {
        const taskStatus = task.status?.key || task.status
        return taskStatus === status
      })
    }))

    return {
      columns,
      projectId: filters?.projectId,
      assigneeId: filters?.assigneeId
    }
  }

  const fetchKanbanTasks = async (filters?: KanbanFilters): Promise<TaskWithDetails[]> => {
    isLoading.value = true
    currentFilters.value = filters || {}

    try {
      const taskFilters: TaskFilters = {
        projectId: filters?.projectId,
        assigneeId: filters?.assigneeId,
        priorityId: filters?.priority,
        typeId: filters?.type,
        search: filters?.search
      }

      const { fetchTasks } = getTasksStore()
      const response = await fetchTasks(taskFilters, 1, 100) // Get more tasks for Kanban
      return response.tasks
    } catch (error) {
      console.error('Error fetching Kanban tasks:', error)
      throw error
    } finally {
      isLoading.value = false
    }
  }

  const loadKanbanBoard = async (filters?: KanbanFilters) => {
    try {
      // Ensure enum categories are loaded
      await enumManagementStore.fetchCategoriesIfNeeded()
      
      const tasks = await fetchKanbanTasks(filters)
      board.value = createKanbanBoard(tasks, filters)
      return board.value
    } catch (error) {
      console.error('Error loading Kanban board:', error)
      throw error
    }
  }

  const moveTaskToColumn = async (taskId: string, newStatus: string): Promise<boolean> => {
    try {
      // Validate that we have a properly initialized board
      if (!board.value.columns || board.value.columns.length === 0) {
        throw new Error('Kanban Board ist nicht initialisiert')
      }
      
      // Find source and target columns
      const sourceColumn = board.value.columns.find(col => 
        col.tasks.some(task => task.id === taskId)
      )
      const targetColumn = board.value.columns.find(col => col.id === newStatus)
      
      if (!sourceColumn || !targetColumn) {
        console.error('Column not found:', { 
          sourceColumn: sourceColumn?.id, 
          targetColumn: targetColumn?.id, 
          newStatus,
          availableColumns: board.value.columns.map(col => ({ id: col.id, title: col.title }))
        })
        throw new Error('Spalte nicht gefunden')
      }

      const taskIndex = sourceColumn.tasks.findIndex(task => task.id === taskId)
      if (taskIndex === -1) {
        throw new Error('Task nicht gefunden')
      }

      const task = sourceColumn.tasks[taskIndex]
      
      // Remove from source column
      sourceColumn.tasks.splice(taskIndex, 1)
      
      // Add to target column (we don't update the task.status directly as it's an EnumValue)
      targetColumn.tasks.push(task)

      // Find the enum ID for the status key
      const statusEnum = availableStatuses.value.find(s => s.key === newStatus)
      if (!statusEnum) {
        throw new Error('Status-Enum nicht gefunden')
      }

      // Update task in the store
      const { updateTask } = getTasksStore()
      await updateTask(taskId, { statusId: statusEnum.id })

      const { success: notifySuccess } = getNotificationsStore()
      notifySuccess('Erfolg', `Task zu "${targetColumn.title}" verschoben`)
      
      return true
    } catch (error: any) {
      console.error('Error moving task:', error)
      const { error: notifyError } = getNotificationsStore()
      notifyError('Fehler', error.message || 'Task konnte nicht verschoben werden')
      
      // Reload board to revert optimistic update
      await loadKanbanBoard(currentFilters.value)
      
      return false
    }
  }

  const reorderTaskInColumn = async (taskId: string, newPosition: number): Promise<boolean> => {
    try {
      const column = board.value.columns.find(col => 
        col.tasks.some(task => task.id === taskId)
      )
      
      if (!column) {
        throw new Error('Spalte nicht gefunden')
      }

      const taskIndex = column.tasks.findIndex(task => task.id === taskId)
      if (taskIndex === -1) {
        throw new Error('Task nicht gefunden')
      }

      // Remove task from current position
      const [task] = column.tasks.splice(taskIndex, 1)
      
      // Insert at new position
      column.tasks.splice(newPosition, 0, task)

      // TODO: Implement API call to save task order
      // await $fetch(`/api/tasks/${taskId}/reorder`, {
      //   method: 'PATCH',
      //   body: { position: newPosition }
      // })

      return true
    } catch (error: any) {
      console.error('Error reordering task:', error)
      const { error: notifyError } = getNotificationsStore()
      notifyError('Fehler', error.message || 'Task konnte nicht neu sortiert werden')
      return false
    }
  }

  const getKanbanStats = (board: KanbanBoard) => {
    const totalTasks = board.columns.reduce((total, column) => total + column.tasks.length, 0)
    const completedTasks = board.columns
      .filter(col => col.id === 'ERLEDIGT' || col.id === 'GESCHLOSSEN')
      .reduce((total, column) => total + column.tasks.length, 0)
    
    const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0
    
    // Add inProgressTasks and completionRate
    const inProgressTasks = board.columns.find(c => c.id === 'IN_BEARBEITUNG')?.tasks.length || 0
    const completionRate = progress

    const statusDistribution = board.columns.map(column => ({
      status: column.id,
      title: column.title,
      count: column.tasks.length,
      percentage: totalTasks > 0 ? Math.round((column.tasks.length / totalTasks) * 100) : 0
    }))

    return {
      totalTasks,
      completedTasks,
      inProgressTasks,
      completionRate,
      progress,
      statusDistribution
    }
  }

  const getFilteredBoard = (board: KanbanBoard, searchTerm?: string) => {
    if (!searchTerm) return board

    const filteredColumns = board.columns.map(column => ({
      ...column,
      tasks: column.tasks.filter(task => 
        task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.project.name.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }))

    return {
      ...board,
      columns: filteredColumns
    }
  }

  const addTaskToBoard = (task: TaskWithDetails) => {
    const taskStatus = typeof task.status === 'object' && task.status ? task.status.key : (task.status as unknown as string || 'GEPLANT')
    const column = board.value.columns.find(col => col.id === taskStatus)
    if (column) {
      column.tasks.unshift(task)
    }
  }

  const removeTaskFromBoard = (taskId: string) => {
    board.value.columns.forEach(column => {
      const index = column.tasks.findIndex(task => task.id === taskId)
      if (index !== -1) {
        column.tasks.splice(index, 1)
      }
    })
  }

  const updateTaskInBoard = (updatedTask: TaskWithDetails) => {
    // Remove task from all columns first
    removeTaskFromBoard(updatedTask.id)
    
    // Add to correct column
    addTaskToBoard(updatedTask)
  }

  const refreshBoard = async () => {
    await loadKanbanBoard(currentFilters.value)
  }

  const clearBoard = () => {
    board.value = { columns: [] }
    currentFilters.value = {}
  }

  return {
    // State
    board: readonly(board),
    isLoading: readonly(isLoading),
    currentFilters: readonly(currentFilters),
    
    // Computed
    availableStatuses,
    totalTasks,
    tasksByStatus,
    
    // Actions
    createKanbanBoard,
    fetchKanbanTasks,
    loadKanbanBoard,
    moveTaskToColumn,
    reorderTaskInColumn,
    getKanbanStats,
    getFilteredBoard,
    addTaskToBoard,
    removeTaskFromBoard,
    updateTaskInBoard,
    refreshBoard,
    clearBoard
  }
})
