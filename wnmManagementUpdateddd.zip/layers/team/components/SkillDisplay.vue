<template>
  <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
    <div class="flex items-center justify-between mb-4">
      <h3 class="text-lg font-medium text-gray-900 dark:text-white">
        Skills & Kompetenzen
      </h3>
      <button
        v-if="canEdit"
        @click="openSkillModal"
        class="px-3 py-1 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
      >
        <PencilIcon class="h-4 w-4 inline mr-1" />
        Bearbeiten
      </button>
    </div>

    <!-- Loading State -->
    <div v-if="loading" class="space-y-2">
      <div v-for="i in 3" :key="i" class="animate-pulse">
        <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
        <div class="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
      </div>
    </div>

    <!-- Skills anzeigen -->
    <div v-else-if="groupedSkills && Object.keys(groupedSkills).length > 0" class="space-y-4">
      <div 
        v-for="(skills, category) in groupedSkills" 
        :key="category"
        class="space-y-2"
      >
        <h4 class="text-sm font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wide">
          {{ category }}
        </h4>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
          <div 
            v-for="skill in skills" 
            :key="skill.id"
            class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg"
          >
            <div class="flex-1">
              <div class="flex items-center space-x-2">
                <span class="font-medium text-gray-900 dark:text-white">
                  {{ skill.name }}
                </span>
                <SkillLevelBadge :level="skill.level" />
              </div>
              <p 
                v-if="skill.experience" 
                class="text-sm text-gray-600 dark:text-gray-400 mt-1"
              >
                {{ skill.experience }}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Keine Skills -->
    <div v-else class="text-center py-8">
      <AcademicCapIcon class="mx-auto h-12 w-12 text-gray-400" />
      <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">
        Keine Skills vorhanden
      </h3>
      <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
        {{ canEdit ? 'Fügen Sie Skills hinzu, um Kompetenzen zu dokumentieren.' : 'Für diesen Benutzer wurden noch keine Skills angelegt.' }}
      </p>
      <div v-if="canEdit" class="mt-6">
        <button
          @click="openSkillModal"
          class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          <PlusIcon class="h-4 w-4 mr-2" />
          Skills hinzufügen
        </button>
      </div>
    </div>

    <!-- Skill Modal -->
    <!-- Modal is now managed at page level to avoid z-index conflicts -->
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import {
  AcademicCapIcon,
  PencilIcon,
  PlusIcon
} from '@heroicons/vue/24/outline'

interface Skill {
  id: string
  name: string
  category: string
  level: number
  experience?: string
  verified: boolean
  verifiedBy?: string
  verifiedAt?: string
  createdAt: string
  updatedAt: string
}

interface Props {
  userId: string
  canEdit?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  canEdit: false
})

const emit = defineEmits<{
  'open-skill-modal': [userId: string, skills: Skill[]]
}>()

const loading = ref(false)
const skills = ref<Skill[]>([])

// Gruppierte Skills nach Kategorie
const groupedSkills = computed(() => {
  if (!skills.value.length) return {}
  
  return skills.value.reduce((groups, skill) => {
    const category = skill.category || 'Sonstiges'
    if (!groups[category]) {
      groups[category] = []
    }
    groups[category].push(skill)
    return groups
  }, {} as Record<string, Skill[]>)
})

// Skills laden
async function loadSkills() {
  loading.value = true
  try {
    const response = await $fetch<{ skills: Skill[] }>(`/api/users/${props.userId}/skills`)
    skills.value = response.skills || []
  } catch (error) {
    console.error('Fehler beim Laden der Skills:', error)
    skills.value = []
  } finally {
    loading.value = false
  }
}

function openSkillModal() {
  emit('open-skill-modal', props.userId, skills.value)
}

function refreshSkills() {
  loadSkills()
}

// Expose refresh function for external updates
defineExpose({
  refreshSkills
})

onMounted(() => {
  loadSkills()
})
</script>
