<template>
  <div class="overflow-x-auto">
    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
      <thead class="bg-gray-50 dark:bg-gray-800">
        <tr>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Team-Mitglied
          </th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Abgeschlossene Tasks
          </th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Stunden gearbeitet
          </th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Effizienz
          </th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Bewertung
          </th>
        </tr>
      </thead>
      <tbody class="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
        <tr 
          v-for="member in data" 
          :key="member.id"
          class="hover:bg-gray-50 dark:hover:bg-gray-800">
          <td class="px-6 py-4 whitespace-nowrap">
            <div class="flex items-center">
              <div class="flex-shrink-0 h-10 w-10">
                <img 
                  v-if="member.image"
                  class="h-10 w-10 rounded-full" 
                  :src="member.image" 
                  :alt="member.name">
                <div 
                  v-else
                  class="h-10 w-10 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center">
                  <span class="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {{ getInitials(member.name) }}
                  </span>
                </div>
              </div>
              <div class="ml-4">
                <div class="text-sm font-medium text-gray-900 dark:text-white">
                  {{ member.name }}
                </div>
                <div class="text-sm text-gray-500 dark:text-gray-400">
                  {{ member.role }}
                </div>
              </div>
            </div>
          </td>
          <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
            {{ member.completedTasks }}
          </td>
          <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
            {{ formatHours(member.hoursWorked) }}h
          </td>
          <td class="px-6 py-4 whitespace-nowrap">
            <div class="flex items-center">
              <div class="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mr-2">
                <div 
                  class="h-2 rounded-full transition-all duration-300"
                  :class="getEfficiencyColor(member.efficiency)"
                  :style="{ width: `${Math.min(member.efficiency, 100)}%` }">
                </div>
              </div>
              <span class="text-sm text-gray-900 dark:text-white">{{ member.efficiency }}%</span>
            </div>
          </td>
          <td class="px-6 py-4 whitespace-nowrap">
            <span 
              class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
              :class="getPerformanceColor(member.performance)">
              {{ getPerformanceLabel(member.performance) }}
            </span>
          </td>
        </tr>
      </tbody>
    </table>
    
    <!-- Empty State -->
    <div v-if="!data.length" class="text-center py-8">
      <UsersIcon class="mx-auto h-12 w-12 text-gray-400" />
      <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
        Keine Performance-Daten verfügbar
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { UsersIcon } from '@heroicons/vue/24/outline'

interface IndividualPerformanceData {
  id: string
  name: string
  role: string
  image?: string
  completedTasks: number
  hoursWorked: number
  efficiency: number
  performance: 'excellent' | 'good' | 'average' | 'below-average'
}

interface Props {
  data: IndividualPerformanceData[]
}

defineProps<Props>()

// Utility functions
const getInitials = (name: string): string => {
  return name
    .split(' ')
    .map(n => n.charAt(0))
    .join('')
    .toUpperCase()
    .substring(0, 2)
}

const formatHours = (hours: number): string => {
  return hours ? hours.toFixed(1) : '0.0'
}

const getEfficiencyColor = (efficiency: number): string => {
  if (efficiency >= 90) return 'bg-green-500'
  if (efficiency >= 70) return 'bg-yellow-500'
  if (efficiency >= 50) return 'bg-orange-500'
  return 'bg-red-500'
}

const getPerformanceColor = (performance: string): string => {
  const colors = {
    'excellent': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
    'good': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    'average': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
    'below-average': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
  }
  return colors[performance as keyof typeof colors] || colors.average
}

const getPerformanceLabel = (performance: string): string => {
  const labels = {
    'excellent': 'Exzellent',
    'good': 'Gut',
    'average': 'Durchschnitt',
    'below-average': 'Unterdurchschnitt'
  }
  return labels[performance as keyof typeof labels] || 'Unbekannt'
}
</script>
