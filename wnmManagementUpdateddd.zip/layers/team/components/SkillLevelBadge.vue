<template>
  <span :class="levelClasses" class="px-2 py-1 rounded-full text-xs font-medium">
    {{ levelText }}
  </span>
</template>

<script setup lang="ts">
import { computed } from 'vue'

interface Props {
  level: number
}

const props = defineProps<Props>()

const levelConfig = {
  1: { text: 'Anfänger', classes: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' },
  2: { text: 'Grundkenntnisse', classes: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200' },
  3: { text: 'Fortgeschritten', classes: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' },
  4: { text: 'Erfahren', classes: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' },
  5: { text: 'Experte', classes: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' }
}

const levelText = computed(() => {
  const config = levelConfig[props.level as keyof typeof levelConfig]
  return config ? config.text : `Level ${props.level}`
})

const levelClasses = computed(() => {
  const config = levelConfig[props.level as keyof typeof levelConfig]
  return config ? config.classes : 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
})
</script>
