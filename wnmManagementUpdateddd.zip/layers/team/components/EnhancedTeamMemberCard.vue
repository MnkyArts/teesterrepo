<template>
  <div class="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6 hover:border-primary-300 dark:hover:border-primary-600 transition-all duration-200">
    <!-- Selection Checkbox (wenn verfügbar) -->
    <div v-if="selectable" class="flex items-start justify-between mb-4">
      <input
        type="checkbox"
        :checked="isSelected"
        @change="handleSelection"
        class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 dark:border-gray-600 rounded mt-1"
      >
    </div>

    <!-- Mitarbeiter-Header -->
    <div class="flex items-start space-x-4 mb-4">
      <!-- Avatar -->
      <div class="flex-shrink-0">
        <img
          v-if="member.image"
          :src="member.image"
          :alt="`${member.firstName} ${member.lastName}`"
          class="h-12 w-12 rounded-full"
        >
        <div
          v-else
          class="h-12 w-12 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center text-lg font-medium text-gray-700 dark:text-gray-300"
        >
          {{ getInitials(member.firstName, member.lastName) }}
        </div>
      </div>

      <!-- Basisinformationen -->
      <div class="flex-grow min-w-0">
        <div class="flex items-center justify-between mb-1">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white truncate">
            {{ member.firstName }} {{ member.lastName }}
          </h3>
          
          <!-- Status Indicator -->
          <div class="flex items-center space-x-2">
            <div
              :class="[
                'w-2 h-2 rounded-full',
                member.isActive 
                  ? availabilityColors[member.availability || 'offline']
                  : 'bg-gray-400'
              ]"
              :title="getStatusTitle()"
            ></div>
            
            <span
              v-if="!member.isActive"
              class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
            >
              Inaktiv
            </span>
          </div>
        </div>
        
        <p class="text-sm text-gray-600 dark:text-gray-400 truncate">
          {{ member.email }}
        </p>
        
        <div class="flex items-center space-x-2 mt-2">
          <UserRoleBadge :role="member.role" />
          
          <span
            v-if="member.lastLoginAt"
            class="text-xs text-gray-500 dark:text-gray-400"
            :title="`Letzter Login: ${formatDate(member.lastLoginAt)}`"
          >
            {{ getLastLoginText() }}
          </span>
        </div>
      </div>
    </div>

    <!-- Skills Sektion -->
    <div v-if="member.skills && member.skills.length > 0" class="mb-4">
      <div class="flex items-center justify-between mb-2">
        <h4 class="text-sm font-medium text-gray-900 dark:text-white">
          Skills ({{ member.skills.length }})
        </h4>
        
        <button
          v-if="showSkillActions && canVerifySkills"
          @click="toggleSkillsExpanded"
          class="text-xs text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300"
        >
          {{ skillsExpanded ? 'Weniger' : 'Alle anzeigen' }}
        </button>
      </div>
      
      <!-- Kompakte Skills-Anzeige -->
      <div v-if="!skillsExpanded" class="flex flex-wrap gap-1">
        <div
          v-for="skill in member.skills.slice(0, 6)"
          :key="skill.id"
          class="inline-flex items-center space-x-1 px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded text-xs"
        >
          <span class="text-gray-700 dark:text-gray-300">{{ skill.name }}</span>
          <SkillLevelBadge :level="skill.level" size="xs" />
          <CheckBadgeIcon
            v-if="skill.verified"
            class="h-3 w-3 text-green-500"
            title="Verifiziert"
          />
        </div>
        
        <div
          v-if="member.skills.length > 6"
          class="inline-flex items-center px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded text-xs text-gray-500 dark:text-gray-400"
        >
          +{{ member.skills.length - 6 }}
        </div>
      </div>
      
      <!-- Erweiterte Skills-Anzeige -->
      <div v-else class="space-y-2">
        <div
          v-for="skill in member.skills"
          :key="skill.id"
          class="flex items-center justify-between p-2 border border-gray-200 dark:border-gray-600 rounded"
        >
          <div class="flex items-center space-x-2">
            <span class="text-sm font-medium text-gray-900 dark:text-white">
              {{ skill.name }}
            </span>
            <span class="text-xs text-gray-500 dark:text-gray-400">
              {{ skill.category }}
            </span>
          </div>
          
          <div class="flex items-center space-x-2">
            <SkillLevelBadge :level="skill.level" size="sm" />
            
            <div v-if="canVerifySkills" class="flex items-center space-x-1">
              <CheckBadgeIcon
                v-if="skill.verified"
                class="h-4 w-4 text-green-500"
                title="Verifiziert"
              />
              <button
                v-else
                @click="handleVerifySkill(skill, true)"
                class="text-gray-400 hover:text-green-500 transition-colors"
                title="Skill verifizieren"
              >
                <CheckIcon class="h-4 w-4" />
              </button>
              
              <button
                v-if="skill.verified"
                @click="handleVerifySkill(skill, false)"
                class="text-green-500 hover:text-gray-400 transition-colors"
                title="Verifizierung entfernen"
              >
                <XMarkIcon class="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Statistiken -->
    <div v-if="showStats" class="grid grid-cols-3 gap-4 mb-4">
      <div class="text-center">
        <div class="text-lg font-semibold text-gray-900 dark:text-white">
          {{ member.skills?.length || 0 }}
        </div>
        <div class="text-xs text-gray-500 dark:text-gray-400">Skills</div>
      </div>
      
      <div class="text-center">
        <div class="text-lg font-semibold text-gray-900 dark:text-white">
          {{ verifiedSkillsCount }}
        </div>
        <div class="text-xs text-gray-500 dark:text-gray-400">Verifiziert</div>
      </div>
      
      <div class="text-center">
        <div class="text-lg font-semibold text-gray-900 dark:text-white">
          {{ averageSkillLevel.toFixed(1) }}
        </div>
        <div class="text-xs text-gray-500 dark:text-gray-400">Ø Level</div>
      </div>
    </div>

    <!-- Aktionen -->
    <div class="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
      <div class="flex items-center space-x-2">
        <button
          @click="viewDetails"
          class="text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium"
        >
          Details
        </button>
        
        <button
          v-if="canEditUser"
          @click="editUser"
          class="text-sm text-gray-600 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
        >
          Bearbeiten
        </button>
      </div>
      
      <div class="flex items-center space-x-2">
        <button
          v-if="canToggleStatus"
          @click="toggleStatus"
          :class="[
            'text-xs px-2 py-1 rounded font-medium transition-colors',
            member.isActive
              ? 'text-red-600 hover:text-red-700 hover:bg-red-50 dark:text-red-400 dark:hover:text-red-300 dark:hover:bg-red-900'
              : 'text-green-600 hover:text-green-700 hover:bg-green-50 dark:text-green-400 dark:hover:text-green-300 dark:hover:bg-green-900'
          ]"
        >
          {{ member.isActive ? 'Deaktivieren' : 'Aktivieren' }}
        </button>
        
        <button
          @click="openSkillModal"
          class="text-xs px-2 py-1 text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 hover:bg-primary-50 dark:hover:bg-primary-900 rounded font-medium transition-colors"
        >
          Skills
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { 
  CheckBadgeIcon, 
  CheckIcon, 
  XMarkIcon 
} from '@heroicons/vue/24/outline'
import { format, formatDistanceToNow } from 'date-fns'
import { de } from 'date-fns/locale'

interface TeamMemberSkill {
  id: string
  name: string
  category: string
  level: 1 | 2 | 3 | 4 | 5
  verified: boolean
  verifiedBy?: string
  verifiedAt?: Date
  experience?: string
}

interface TeamMemberProps {
  id: string
  firstName: string
  lastName: string
  email: string
  role: 'ADMINISTRATOR' | 'PROJEKTLEITER' | 'ENTWICKLER' | 'SUPPORTER' | 'VIEWER' | 'KUNDE'
  image?: string
  isActive: boolean
  lastLoginAt?: Date
  availability?: 'available' | 'busy' | 'away' | 'offline'
  skills?: TeamMemberSkill[]
}

interface Props {
  member: TeamMemberProps
  selectable?: boolean
  isSelected?: boolean
  showStats?: boolean
  showSkillActions?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  selectable: false,
  isSelected: false,
  showStats: true,
  showSkillActions: true
})

const emit = defineEmits<{
  'selection-changed': [userId: string, selected: boolean]
  'view-details': [member: TeamMemberProps]
  'edit-user': [member: TeamMemberProps]
  'toggle-status': [member: TeamMemberProps]
  'open-skill-modal': [member: TeamMemberProps]
  'skill-verified': [skillId: string, verified: boolean]
}>()

const { hasPermission } = usePermissions()

const teamStore = useTeamManagementStore()
const { verifySkill } = teamStore

// State
const skillsExpanded = ref(false)

// Colors for availability status
const availabilityColors = {
  available: 'bg-green-400',
  busy: 'bg-yellow-400', 
  away: 'bg-gray-400',
  offline: 'bg-gray-300'
}

// Computed
const canEditUser = computed(() => hasPermission('users.update'))
const canToggleStatus = computed(() => hasPermission('users.manage-roles'))
const canVerifySkills = computed(() => hasPermission('users.update'))

const verifiedSkillsCount = computed(() => 
  props.member.skills?.filter(skill => skill.verified).length || 0
)

const averageSkillLevel = computed(() => {
  if (!props.member.skills || props.member.skills.length === 0) return 0
  const total = props.member.skills.reduce((sum, skill) => sum + skill.level, 0)
  return total / props.member.skills.length
})

// Methods
const getInitials = (firstName: string, lastName: string) => {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
}

const getStatusTitle = () => {
  if (!props.member.isActive) return 'Inaktiv'
  
  switch (props.member.availability) {
    case 'available': return 'Verfügbar'
    case 'busy': return 'Beschäftigt'
    case 'away': return 'Abwesend'
    default: return 'Offline'
  }
}

const getLastLoginText = () => {
  if (!props.member.lastLoginAt) return 'Nie angemeldet'
  
  try {
    return `vor ${formatDistanceToNow(new Date(props.member.lastLoginAt), { 
      locale: de,
      addSuffix: false
    })}`
  } catch {
    return 'Unbekannt'
  }
}

const formatDate = (date: Date | string) => {
  try {
    return format(new Date(date), 'dd.MM.yyyy HH:mm', { locale: de })
  } catch {
    return 'Unbekannt'
  }
}

const handleSelection = (event: Event) => {
  const target = event.target as HTMLInputElement
  emit('selection-changed', props.member.id, target.checked)
}

const toggleSkillsExpanded = () => {
  skillsExpanded.value = !skillsExpanded.value
}

const viewDetails = () => {
  emit('view-details', props.member)
}

const editUser = () => {
  emit('edit-user', props.member)
}

const toggleStatus = () => {
  emit('toggle-status', props.member)
}

const openSkillModal = () => {
  emit('open-skill-modal', props.member)
}

const handleVerifySkill = async (skill: TeamMemberSkill, verified: boolean) => {
  try {
    if (verified) {
      await verifySkill(props.member.id, skill.id)
    }
    emit('skill-verified', skill.id, verified)
  } catch (error) {
    console.error('Fehler bei der Skill-Verifizierung:', error)
  }
}
</script>
