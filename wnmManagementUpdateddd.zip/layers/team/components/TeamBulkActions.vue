<template>
  <div class="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
    <!-- Selection Header -->
    <div class="flex items-center justify-between mb-4">
      <div class="flex items-center space-x-3">
        <input
          type="checkbox"
          :checked="isAllSelected"
          :indeterminate="isSomeSelected"
          @change="handleSelectAll"
          class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 dark:border-gray-600 rounded"
        >
        <span class="text-sm font-medium text-gray-900 dark:text-white">
          {{ selectedCount }} von {{ totalCount }} ausgewählt
        </span>
      </div>
      
      <div v-if="selectedCount > 0" class="flex items-center space-x-2">
        <select
          v-model="selectedAction"
          class="text-sm border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:border-primary-500 focus:ring-primary-500 dark:bg-gray-700 dark:text-white"
        >
          <option value="">Aktion wählen...</option>
          <option value="activate">Aktivieren</option>
          <option value="deactivate">Deaktivieren</option>
          <option value="change_role">Rolle ändern</option>
        </select>
        
        <select
          v-if="selectedAction === 'change_role'"
          v-model="selectedRole"
          class="text-sm border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:border-primary-500 focus:ring-primary-500 dark:bg-gray-700 dark:text-white"
        >
          <option value="">Neue Rolle...</option>
          <option
            v-for="role in availableRoles"
            :key="role.value"
            :value="role.value"
          >
            {{ role.label }}
          </option>
        </select>
        
        <button
          @click="executeBulkAction"
          :disabled="!canExecuteAction || bulkActionLoading"
          class="inline-flex items-center px-3 py-2 bg-primary-600 hover:bg-primary-700 disabled:bg-gray-400 text-white text-sm font-medium rounded-md transition-colors"
        >
          <component
            :is="bulkActionLoading ? 'ArrowPathIcon' : 'CheckIcon'"
            class="h-4 w-4 mr-1.5"
            :class="{ 'animate-spin': bulkActionLoading }"
          />
          Ausführen
        </button>
        
        <button
          @click="clearSelection"
          class="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 text-sm font-medium rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
        >
          <XMarkIcon class="h-4 w-4 mr-1.5" />
          Abbrechen
        </button>
      </div>
    </div>

    <!-- Selected Users Preview -->
    <div v-if="selectedCount > 0" class="border-t border-gray-200 dark:border-gray-700 pt-4">
      <h4 class="text-sm font-medium text-gray-900 dark:text-white mb-3">
        Ausgewählte Benutzer:
      </h4>
      
      <div class="flex flex-wrap gap-2">
        <div
          v-for="user in selectedUsers.slice(0, 10)"
          :key="user.id"
          class="inline-flex items-center px-2 py-1 bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-200 text-xs font-medium rounded-md"
        >
          <img
            v-if="user.image"
            :src="user.image"
            :alt="`${user.firstName} ${user.lastName}`"
            class="h-4 w-4 rounded-full mr-1.5"
          >
          <div
            v-else
            class="h-4 w-4 bg-primary-200 dark:bg-primary-800 rounded-full flex items-center justify-center text-xs font-medium text-primary-700 dark:text-primary-300 mr-1.5"
          >
            {{ getInitials(user.firstName, user.lastName) }}
          </div>
          {{ user.firstName }} {{ user.lastName }}
        </div>
        
        <div
          v-if="selectedCount > 10"
          class="inline-flex items-center px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 text-xs font-medium rounded-md"
        >
          +{{ selectedCount - 10 }} weitere
        </div>
      </div>
    </div>

    <!-- Action Confirmation -->
    <div
      v-if="selectedAction && selectedCount > 0"
      class="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-700 rounded-md"
    >
      <div class="flex items-start">
        <ExclamationTriangleIcon class="h-5 w-5 text-yellow-400 mr-2 mt-0.5" />
        <div>
          <h4 class="text-sm font-medium text-yellow-800 dark:text-yellow-200">
            Bestätigung erforderlich
          </h4>
          <p class="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
            {{ getActionConfirmationText() }}
          </p>
        </div>
      </div>
    </div>
  </div>

  <!-- Confirmation Modal -->
  <ConfirmDialog
    :is-open="showConfirmModal"
    :title="confirmModalTitle"
    :message="confirmModalMessage"
    :confirm-text="confirmButtonText"
    :variant="confirmModalType"
    @confirm="handleConfirmAction"
    @cancel="showConfirmModal = false"
  />
</template>

<script setup lang="ts">
import { 
  CheckIcon, 
  XMarkIcon, 
  ArrowPathIcon,
  ExclamationTriangleIcon 
} from '@heroicons/vue/24/outline'

interface Props {
  users: Array<{
    id: string
    firstName: string
    lastName: string
    email: string
    role: string
    image?: string
    isActive: boolean
  }>
  selectedUserIds: string[]
}

const props = defineProps<Props>()

const emit = defineEmits<{
  'update:selectedUserIds': [value: string[]]
  'bulk-action-executed': []
}>()

const teamManagementStore = useTeamManagementStore()
const authStore = useAuthStore()

const { 
  userRoles,
  bulkActionLoading
} = storeToRefs(teamManagementStore)

const {
  executeBulkAction: executeTeamBulkAction
} = teamManagementStore

const { hasPermission } = usePermissions()

// State
const selectedAction = ref('')
const selectedRole = ref('')
const showConfirmModal = ref(false)
const confirmModalTitle = ref('')
const confirmModalMessage = ref('')
const confirmModalType = ref<'warning' | 'danger'>('warning')

// Computed
const selectedCount = computed(() => props.selectedUserIds.length)
const totalCount = computed(() => props.users.length)

const isAllSelected = computed(() => 
  props.users.length > 0 && props.selectedUserIds.length === props.users.length
)

const isSomeSelected = computed(() => 
  props.selectedUserIds.length > 0 && props.selectedUserIds.length < props.users.length
)

const selectedUsers = computed(() => 
  props.users.filter(user => props.selectedUserIds.includes(user.id))
)

const availableRoles = computed(() => 
  userRoles.value.filter((role: any) => role.value !== 'customer')
)

const canExecuteAction = computed(() => {
  if (!selectedAction.value || selectedCount.value === 0) return false
  if (selectedAction.value === 'change_role' && !selectedRole.value) return false
  return hasPermission('users.manage-roles')
})

const confirmButtonText = computed(() => {
  switch (selectedAction.value) {
    case 'activate': return 'Aktivieren'
    case 'deactivate': return 'Deaktivieren' 
    case 'change_role': return 'Rolle ändern'
    default: return 'Bestätigen'
  }
})

// Methods
const handleSelectAll = (event: Event) => {
  const target = event.target as HTMLInputElement
  if (target.checked) {
    emit('update:selectedUserIds', props.users.map(user => user.id))
  } else {
    emit('update:selectedUserIds', [])
  }
}

const clearSelection = () => {
  emit('update:selectedUserIds', [])
  selectedAction.value = ''
  selectedRole.value = ''
}

const getActionConfirmationText = () => {
  const count = selectedCount.value
  switch (selectedAction.value) {
    case 'activate':
      return `${count} Benutzer werden aktiviert.`
    case 'deactivate':
      return `${count} Benutzer werden deaktiviert und können sich nicht mehr anmelden.`
    case 'change_role':
      const roleLabel = availableRoles.value.find((r: any) => r.value === selectedRole.value)?.label
      return `Die Rolle von ${count} Benutzern wird zu "${roleLabel}" geändert.`
    default:
      return ''
  }
}

const executeBulkAction = () => {
  // Set up confirmation modal
  confirmModalType.value = selectedAction.value === 'deactivate' ? 'danger' : 'warning'
  
  switch (selectedAction.value) {
    case 'activate':
      confirmModalTitle.value = 'Benutzer aktivieren'
      confirmModalMessage.value = `Möchten Sie ${selectedCount.value} Benutzer aktivieren? Diese können sich danach wieder anmelden.`
      break
      
    case 'deactivate':
      confirmModalTitle.value = 'Benutzer deaktivieren'
      confirmModalMessage.value = `Möchten Sie ${selectedCount.value} Benutzer deaktivieren? Diese können sich danach nicht mehr anmelden.`
      break
      
    case 'change_role':
      const roleLabel = availableRoles.value.find((r: any) => r.value === selectedRole.value)?.label
      confirmModalTitle.value = 'Benutzerrollen ändern'
      confirmModalMessage.value = `Möchten Sie die Rolle von ${selectedCount.value} Benutzern zu "${roleLabel}" ändern?`
      break
  }
  
  showConfirmModal.value = true
}

const handleConfirmAction = async () => {
  try {
    const actionData: any = {}
    
    if (selectedAction.value === 'change_role') {
      actionData.role = selectedRole.value
    }
    
    await executeTeamBulkAction(
      selectedAction.value as any,
      props.selectedUserIds,
      Object.keys(actionData).length > 0 ? actionData : undefined
    )
    
    // Reset form
    clearSelection()
    
    // Emit success event
    emit('bulk-action-executed')
    
  } catch (error) {
    console.error('Fehler bei Bulk-Aktion:', error)
  }
}

const getInitials = (firstName: string, lastName: string) => {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
}
</script>
