<template>
  <div class="space-y-3">
    <div
      v-for="activity in displayActivities"
      :key="activity.id"
      class="flex items-center space-x-3"
    >
      <div class="w-8 h-8 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center">
        <span class="text-xs font-medium text-gray-600 dark:text-gray-400">
          {{ getUserInitials(activity.user.firstName, activity.user.lastName) }}
        </span>
      </div>
      
      <div class="flex-1 min-w-0">
        <p class="text-sm text-gray-900 dark:text-white">
          <span class="font-medium">{{ activity.user.firstName }} {{ activity.user.lastName }}</span>
        </p>
        <p class="text-xs text-gray-500 dark:text-gray-400 truncate">
          {{ activity.description }}
        </p>
        <p class="text-xs text-gray-400 dark:text-gray-500">
          {{ formatRelativeTime(activity.createdAt) }}
        </p>
      </div>
    </div>

    <div v-if="activities.length === 0" class="text-center py-8">
      <UsersIcon class="mx-auto h-12 w-12 text-gray-400" />
      <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
        Keine Team-Aktivitäten
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { UsersIcon } from '@heroicons/vue/24/outline'

interface TeamActivity {
  id: string
  description: string
  createdAt: string | Date
  type?: string // for compatibility
  message?: string // for compatibility
  timestamp?: string | Date // for compatibility
  user: {
    id: string
    firstName: string
    lastName: string
    image?: string | null
  }
  project?: {
    id: string
    name: string
    key: string
  } | null
}

interface Props {
  activities: TeamActivity[]
  maxItems?: number
}

const props = withDefaults(defineProps<Props>(), {
  maxItems: 5
})

const displayActivities = computed(() => 
  props.activities.slice(0, props.maxItems)
)

const getUserInitials = (firstName: string, lastName: string) => {
  return (firstName.charAt(0) + lastName.charAt(0)).toUpperCase()
}

const formatRelativeTime = (date: string | Date) => {
  const now = new Date()
  const activityDate = new Date(date)
  const diff = now.getTime() - activityDate.getTime()
  const minutes = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)

  if (minutes < 1) return 'gerade eben'
  if (minutes < 60) return `vor ${minutes} Min`
  if (hours < 24) return `vor ${hours} Std`
  
  return activityDate.toLocaleDateString('de-DE', {
    day: 'numeric',
    month: 'short'
  })
}
</script>
