<template>
  <span 
    class="inline-flex items-center rounded-full text-xs font-medium"
    :class="[sizeClasses, roleClasses]"
  >
    {{ roleText }}
  </span>
</template>

<script setup lang="ts">
// Props
const props = withDefaults(defineProps<{
  role: string
  size?: 'sm' | 'md'
}>(), {
  size: 'md'
})

// Computed
const sizeClasses = computed(() => {
  return props.size === 'sm' ? 'px-2 py-0.5' : 'px-2 py-1'
})

// Normalize role name to handle both old and new systems
const normalizedRole = computed(() => {
  const roleMapping: Record<string, string> = {
    'ADMINISTRATOR': 'admin',
    'PROJEKTLEITER': 'project-manager',
    'ENTWICKLER': 'developer',
    'SUPPORTER': 'support',
    'VIEWER': 'viewer',
    'KUNDE': 'customer'
  }
  
  return roleMapping[props.role] || props.role
})

const roleConfig = computed(() => {
  const configs: Record<string, { text: string; classes: string }> = {
    'admin': {
      text: 'Admin',
      classes: 'bg-red-50 text-red-700 border border-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800'
    },
    'project-manager': {
      text: 'Projektleiter',
      classes: 'bg-purple-50 text-purple-700 border border-purple-200 dark:bg-purple-900/30 dark:text-purple-400 dark:border-purple-800'
    },
    'developer': {
      text: 'Entwickler',
      classes: 'bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-900/30 dark:text-blue-400 dark:border-blue-800'
    },
    'support': {
      text: 'Support',
      classes: 'bg-green-50 text-green-700 border border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800'
    },
    'viewer': {
      text: 'Betrachter',
      classes: 'bg-gray-50 text-gray-700 border border-gray-200 dark:bg-gray-900/30 dark:text-gray-400 dark:border-gray-800'
    },
    'customer': {
      text: 'Kunde',
      classes: 'bg-yellow-50 text-yellow-700 border border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-400 dark:border-yellow-800'
    }
  }
  
  return configs[normalizedRole.value] || {
    text: normalizedRole.value,
    classes: 'bg-gray-50 text-gray-700 border border-gray-200 dark:bg-gray-900/30 dark:text-gray-400 dark:border-gray-800'
  }
})

const roleClasses = computed(() => roleConfig.value.classes)
const roleText = computed(() => roleConfig.value.text)
</script>
