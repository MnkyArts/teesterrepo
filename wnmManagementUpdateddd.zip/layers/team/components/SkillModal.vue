<template>
  <TransitionRoot appear :show="isOpen" as="template">
    <Dialog as="div" @close="closeModal" :class="`relative z-[${modalZIndex}]`">
      <TransitionChild
        as="template"
        enter="duration-300 ease-out"
        enter-from="opacity-0"
        enter-to="opacity-100"
        leave="duration-200 ease-in"
        leave-from="opacity-100"
        leave-to="opacity-0"
      >
        <div class="fixed inset-0 bg-black bg-opacity-25" />
      </TransitionChild>

      <div class="fixed inset-0 overflow-y-auto">
        <div class="flex min-h-full items-center justify-center p-4 text-center">
          <TransitionChild
            as="template"
            enter="duration-300 ease-out"
            enter-from="opacity-0 scale-95"
            enter-to="opacity-100 scale-100"
            leave="duration-200 ease-in"
            leave-from="opacity-100 scale-100"
            leave-to="opacity-0 scale-95"
          >
            <DialogPanel
              class="w-full max-w-2xl transform overflow-hidden rounded-2xl bg-white dark:bg-gray-800 p-6 text-left align-middle shadow-xl transition-all"
            >
              <DialogTitle
                as="h3"
                class="text-lg font-medium leading-6 text-gray-900 dark:text-white mb-4"
              >
                Skills bearbeiten
              </DialogTitle>

              <form @submit.prevent="saveSkills" class="space-y-6">
                <!-- Skill Liste -->
                <div class="space-y-4">
                  <div
                    v-for="(skill, index) in skillsData"
                    :key="index"
                    class="p-4 border border-gray-200 dark:border-gray-600 rounded-lg"
                  >
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Skill-Name *
                        </label>
                        <input
                          v-model="skill.name"
                          type="text"
                          required
                          class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="z.B. JavaScript, Vue.js"
                        />
                      </div>

                      <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Kategorie *
                        </label>
                        <select
                          v-model="skill.category"
                          required
                          class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        >
                          <option value="">Kategorie wählen</option>
                          <option value="Frontend">Frontend</option>
                          <option value="Backend">Backend</option>
                          <option value="Database">Database</option>
                          <option value="DevOps">DevOps</option>
                          <option value="Design">Design</option>
                          <option value="Project Management">Project Management</option>
                          <option value="Quality Assurance">Quality Assurance</option>
                          <option value="Other">Sonstiges</option>
                        </select>
                      </div>

                      <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Level (1-5) *
                        </label>
                        <select
                          v-model.number="skill.level"
                          required
                          class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        >
                          <option value="">Level wählen</option>
                          <option :value="1">1 - Anfänger</option>
                          <option :value="2">2 - Grundkenntnisse</option>
                          <option :value="3">3 - Fortgeschritten</option>
                          <option :value="4">4 - Erfahren</option>
                          <option :value="5">5 - Experte</option>
                        </select>
                      </div>

                      <div class="flex items-end">
                        <button
                          type="button"
                          @click="removeSkill(index)"
                          class="w-full px-3 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                        >
                          <TrashIcon class="h-4 w-4 mx-auto" />
                        </button>
                      </div>
                    </div>

                    <div class="mt-3">
                      <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Erfahrung/Beschreibung
                      </label>
                      <textarea
                        v-model="skill.experience"
                        rows="2"
                        class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="Beschreibung der Erfahrung mit diesem Skill..."
                      />
                    </div>
                  </div>
                </div>

                <!-- Neuen Skill hinzufügen -->
                <div class="border-t border-gray-200 dark:border-gray-600 pt-4">
                  <button
                    type="button"
                    @click="addSkill"
                    class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center justify-center"
                  >
                    <PlusIcon class="h-4 w-4 mr-2" />
                    Neuen Skill hinzufügen
                  </button>
                </div>

                <!-- Aktionen -->
                <div class="flex justify-end space-x-3 pt-4 border-t border-gray-200 dark:border-gray-600">
                  <button
                    type="button"
                    @click="closeModal"
                    class="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
                  >
                    Abbrechen
                  </button>
                  <button
                    type="submit"
                    :disabled="loading || skillsData.length === 0"
                    class="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center"
                  >
                    <ArrowPathIcon v-if="loading" class="animate-spin h-4 w-4 mr-2" />
                    Skills speichern
                  </button>
                </div>
              </form>
            </DialogPanel>
          </TransitionChild>
        </div>
      </div>
    </Dialog>
  </TransitionRoot>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import {
  Dialog,
  DialogPanel,
  DialogTitle,
  TransitionChild,
  TransitionRoot,
} from '@headlessui/vue'
import {
  PlusIcon,
  TrashIcon,
  ArrowPathIcon
} from '@heroicons/vue/24/outline'

interface Skill {
  name: string
  category: string
  level: number | ''
  experience?: string
}

interface Props {
  isOpen: boolean
  userId: string
  initialSkills?: Skill[]
}

interface Emits {
  (e: 'close'): void
  (e: 'saved'): void
}

const props = defineProps<Props>()
const emit = defineEmits<Emits>()

// Composables
const uiStore = useUIStore()
const { openModal, closeModal: closeModalFromStack, getModalZIndex } = uiStore

// Modal ID for stack management
const modalId = 'skill-modal'

// Reactive state
const loading = ref(false)
const skillsData = ref<Skill[]>([])

// Computed
const modalZIndex = computed(() => getModalZIndex(modalId))
// Watcher für initialSkills
watch(() => props.initialSkills, (newSkills) => {
  if (newSkills && newSkills.length > 0) {
    skillsData.value = [...newSkills]
  } else if (props.isOpen && skillsData.value.length === 0) {
    // Wenn Modal geöffnet wird aber keine Skills vorhanden sind, einen leeren Skill hinzufügen
    addSkill()
  }
}, { immediate: true })

// Watcher für Modal öffnen/schließen und Stack-Management
watch(() => props.isOpen, (isOpen) => {
  if (isOpen) {
    openModal(modalId)
    if (skillsData.value.length === 0) {
      addSkill()
    }
  } else {
    closeModalFromStack(modalId)
  }
}, { immediate: true })

function addSkill() {
  skillsData.value.push({
    name: '',
    category: '',
    level: '',
    experience: ''
  })
}

function removeSkill(index: number) {
  skillsData.value.splice(index, 1)
}

function closeModal() {
  closeModalFromStack(modalId)
  emit('close')
}

async function saveSkills() {
  if (loading.value) return

  // Validierung
  const validSkills = skillsData.value.filter(skill => 
    skill.name.trim() && skill.category && skill.level
  )

  if (validSkills.length === 0) {
    return
  }

  loading.value = true

  try {
    const response = await $fetch(`/api/users/${props.userId}/skills`, {
      method: 'POST',
      body: {
        skills: validSkills.map(skill => ({
          ...skill,
          level: Number(skill.level)
        }))
      }
    })

    emit('saved')
    closeModal()
  } catch (error: any) {
    console.error('Fehler beim Speichern der Skills:', error)
    // TODO: Fehlerbehandlung/Toast
  } finally {
    loading.value = false
  }
}
</script>
