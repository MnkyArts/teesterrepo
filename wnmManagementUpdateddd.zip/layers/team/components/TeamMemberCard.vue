<template>
  <div class="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-6 hover:shadow-lg transition-shadow">
    <!-- Header mit Avatar und Status -->
    <div class="flex items-start justify-between mb-4">
      <div class="flex items-center space-x-3">
        <div class="relative">
          <img
            v-if="member.image"
            :src="member.image"
            :alt="`${member.firstName} ${member.lastName}`"
            class="h-12 w-12 rounded-full object-cover"
          />
          <div
            v-else
            class="h-12 w-12 rounded-full bg-primary-500 flex items-center justify-center text-white font-medium"
          >
            {{ getInitials }}
          </div>
          
          <!-- Online Status Indicator -->
          <div 
            class="absolute -bottom-1 -right-1 h-4 w-4 rounded-full border-2 border-white dark:border-gray-900"
            :class="getStatusColor"
          ></div>
        </div>
        
        <div>
          <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
            {{ member.firstName }} {{ member.lastName }}
          </h3>
          <p class="text-sm text-gray-500 dark:text-gray-400">
            {{ member.email }}
          </p>
        </div>
      </div>
      
      <!-- Aktions-Menü -->
      <div class="flex items-center space-x-2">
        <button
          @click="$emit('view', member)"
          class="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
          title="Details anzeigen"
        >
          <EyeIcon class="h-4 w-4" />
        </button>
        
        <button
          v-if="canEdit"
          @click="$emit('edit', member)"
          class="p-2 text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
          title="Bearbeiten"
        >
          <PencilIcon class="h-4 w-4" />
        </button>
      </div>
    </div>
    
    <!-- Rolle und Status -->
    <div class="flex items-center justify-between mb-4">
      <UserRoleBadge :role="member.role" />
      
      <div class="flex items-center space-x-2">
        <span
          class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium"
          :class="member.isActive 
            ? 'bg-green-50 text-green-700 border border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800'
            : 'bg-red-50 text-red-700 border border-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800'
          "
        >
          {{ member.isActive ? 'Aktiv' : 'Inaktiv' }}
        </span>
      </div>
    </div>
    
    <!-- Aktivitäts-Informationen -->
    <div class="grid grid-cols-2 gap-4 mb-4">
      <div class="text-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
        <div class="text-lg font-semibold text-gray-900 dark:text-white">
          {{ member._count?.assignedTasks || 0 }}
        </div>
        <div class="text-xs text-gray-500 dark:text-gray-400">
          Zugewiesene Tasks
        </div>
      </div>
      
      <div class="text-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
        <div class="text-lg font-semibold text-gray-900 dark:text-white">
          {{ member._count?.projectMembers || 0 }}
        </div>
        <div class="text-xs text-gray-500 dark:text-gray-400">
          Projekte
        </div>
      </div>
    </div>
    
    <!-- Letzte Aktivität -->
    <div class="text-xs text-gray-500 dark:text-gray-400 mb-4">
      <span class="font-medium">Letzter Login:</span>
      {{ formatLastLogin }}
    </div>
    
    <!-- Skills Preview (wenn vorhanden) -->
    <div v-if="member.skills && member.skills.length > 0" class="mb-4">
      <div class="flex flex-wrap gap-1">
        <span
          v-for="skill in member.skills.slice(0, 3)"
          :key="skill.id"
          class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-primary-50 text-primary-700 dark:bg-primary-900/30 dark:text-primary-400"
        >
          {{ skill.name }}
          <span class="ml-1 text-primary-500">{{ skill.level }}/5</span>
        </span>
        
        <span
          v-if="member.skills.length > 3"
          class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400"
        >
          +{{ member.skills.length - 3 }} weitere
        </span>
      </div>
    </div>
    
    <!-- Aktionen -->
    <div class="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
      <button
        @click="$emit('view', member)"
        class="text-sm text-primary-600 hover:text-primary-700 dark:text-primary-400 dark:hover:text-primary-300 font-medium"
      >
        Details anzeigen
      </button>
      
      <div class="flex items-center space-x-2">
        <button
          v-if="canEdit && member.isActive"
          @click="$emit('toggle-status', member)"
          class="text-xs text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
          title="Deaktivieren"
        >
          Deaktivieren
        </button>
        
        <button
          v-else-if="canEdit && !member.isActive"
          @click="$emit('toggle-status', member)"
          class="text-xs text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300"
          title="Aktivieren"
        >
          Aktivieren
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { EyeIcon, PencilIcon } from '@heroicons/vue/24/outline'

interface Props {
  member: any
  canEdit: boolean
}

const props = defineProps<Props>()

defineEmits<{
  edit: [member: any]
  view: [member: any]
  'toggle-status': [member: any]
}>()

// Computed
const getInitials = computed(() => {
  return `${props.member.firstName[0]}${props.member.lastName[0]}`.toUpperCase()
})

const getStatusColor = computed(() => {
  // Simuliert Online-Status basierend auf letztem Login
  const lastLogin = props.member.lastLoginAt
  if (!lastLogin) return 'bg-gray-400'
  
  const hoursAgo = (Date.now() - new Date(lastLogin).getTime()) / (1000 * 60 * 60)
  
  if (hoursAgo < 1) return 'bg-green-500' // Online
  if (hoursAgo < 24) return 'bg-yellow-500' // Kürzlich aktiv
  return 'bg-gray-400' // Offline
})

const formatLastLogin = computed(() => {
  if (!props.member.lastLoginAt) return 'Nie'
  
  const lastLogin = new Date(props.member.lastLoginAt)
  const now = new Date()
  const diffMs = now.getTime() - lastLogin.getTime()
  const diffHours = diffMs / (1000 * 60 * 60)
  const diffDays = diffMs / (1000 * 60 * 60 * 24)
  
  if (diffHours < 1) return 'Vor weniger als einer Stunde'
  if (diffHours < 24) return `Vor ${Math.floor(diffHours)} Stunden`
  if (diffDays < 7) return `Vor ${Math.floor(diffDays)} Tagen`
  
  return lastLogin.toLocaleDateString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  })
})
</script>
