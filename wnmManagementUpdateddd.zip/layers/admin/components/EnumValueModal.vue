<template>
  <div
    v-if="show"
    class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
    @click="close"
  >
    <div
      class="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto"
      @click.stop
    >
      <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">
        {{ value ? 'Wert bearbeiten' : 'Neuen Wert erstellen' }}
        <span v-if="category" class="text-gray-500 dark:text-gray-400">
          in {{ category.label }}
        </span>
      </h3>

      <form @submit.prevent="save" class="space-y-4">
        <!-- Key (nur bei neuen Werten) -->
        <div v-if="!value">
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Schlüssel *
          </label>
          <input
            v-model="form.key"
            type="text"
            required
            placeholder="z.B. BUG"
            pattern="[A-Z_]+"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
          <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
            Nur Großbuchstaben und Unterstriche erlaubt
          </p>
        </div>

        <!-- Label -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Anzeigename *
          </label>
          <input
            v-model="form.label"
            type="text"
            required
            placeholder="z.B. Bug"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
        </div>

        <!-- Description -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Beschreibung
          </label>
          <textarea
            v-model="form.description"
            rows="3"
            placeholder="Optionale Beschreibung des Werts"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          ></textarea>
        </div>

        <!-- Color -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Farbe
          </label>
          <div class="flex items-center gap-3">
            <input
              v-model="form.color"
              type="color"
              class="w-12 h-10 border border-gray-300 dark:border-gray-600 rounded-lg"
            >
            <input
              v-model="form.color"
              type="text"
              placeholder="#3b82f6"
              pattern="^#[0-9a-fA-F]{6}$"
              class="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
          </div>
          <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
            Hex-Farbcode für die UI-Darstellung
          </p>
        </div>

        <!-- Icon -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Icon
          </label>
          <select
            v-model="form.icon"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Kein Icon</option>
            <option value="bug-ant">Bug</option>
            <option value="sparkles">Sparkles</option>
            <option value="arrow-trending-up">Trend Up</option>
            <option value="clipboard-document-list">Clipboard</option>
            <option value="user">User</option>
            <option value="flag">Flag</option>
            <option value="arrow-down">Arrow Down</option>
            <option value="minus">Minus</option>
            <option value="arrow-up">Arrow Up</option>
            <option value="exclamation-triangle">Warning</option>
            <option value="no-symbol">No Symbol</option>
            <option value="clock">Clock</option>
            <option value="pencil-square">Pencil</option>
            <option value="play">Play</option>
            <option value="eye">Eye</option>
            <option value="beaker">Beaker</option>
            <option value="check">Check</option>
            <option value="lock-closed">Lock</option>
            <option value="question-mark-circle">Question</option>
            <option value="light-bulb">Light Bulb</option>
            <option value="credit-card">Credit Card</option>
            <option value="user-circle">User Circle</option>
            <option value="exclamation-circle">Exclamation</option>
            <option value="check-circle">Check Circle</option>
            <option value="x-circle">X Circle</option>
          </select>
          <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
            Heroicon für die UI-Darstellung
          </p>
        </div>

        <!-- Sort Order -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Sortierreihenfolge
          </label>
          <input
            v-model.number="form.sortOrder"
            type="number"
            min="0"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
        </div>

        <!-- Flags -->
        <div class="space-y-3">
          <div class="flex items-center">
            <input
              v-model="form.isDefault"
              type="checkbox"
              id="isDefault"
              class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 focus:ring-2"
            >
            <label for="isDefault" class="ml-2 text-sm text-gray-700 dark:text-gray-300">
              Als Standard-Wert markieren
            </label>
          </div>

          <div class="flex items-center">
            <input
              v-model="form.isActive"
              type="checkbox"
              id="isActive"
              class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 focus:ring-2"
            >
            <label for="isActive" class="ml-2 text-sm text-gray-700 dark:text-gray-300">
              Aktiv (verfügbar für Auswahl)
            </label>
          </div>
        </div>

        <!-- Actions -->
        <div class="flex justify-end gap-3 pt-4">
          <button
            type="button"
            @click="close"
            class="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"
          >
            Abbrechen
          </button>
          <button
            type="submit"
            :disabled="loading"
            class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg disabled:opacity-50 flex items-center gap-2"
          >
            <div v-if="loading" class="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            {{ value ? 'Aktualisieren' : 'Erstellen' }}
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { EnumCategory, EnumValue } from '@prisma/client'

interface Props {
  show: boolean
  category?: EnumCategory | null
  value?: EnumValue | null
}

interface Emits {
  (e: 'update:show', value: boolean): void
  (e: 'created'): void
  (e: 'updated'): void
}

const props = withDefaults(defineProps<Props>(), {
  category: null,
  value: null
})

const emit = defineEmits<Emits>()

// Composables
const enumStore = useEnumManagementStore()

// State
const loading = ref(false)
const form = ref({
  key: '',
  label: '',
  description: '',
  color: '',
  icon: '',
  sortOrder: 0,
  isDefault: false,
  isActive: true
})

// Methods
const close = () => {
  emit('update:show', false)
  resetForm()
}

const resetForm = () => {
  if (props.value) {
    form.value = {
      key: props.value.key,
      label: props.value.label,
      description: props.value.description || '',
      color: props.value.color || '',
      icon: props.value.icon || '',
      sortOrder: props.value.sortOrder,
      isDefault: props.value.isDefault,
      isActive: props.value.isActive
    }
  } else {
    form.value = {
      key: '',
      label: '',
      description: '',
      color: '',
      icon: '',
      sortOrder: 0,
      isDefault: false,
      isActive: true
    }
  }
}

const save = async () => {
  if (!props.category) return

  loading.value = true
  
  try {
    if (props.value) {
      // Update existing value
      await enumStore.updateValue(props.value.id, {
        label: form.value.label,
        description: form.value.description || undefined,
        color: form.value.color || undefined,
        icon: form.value.icon || undefined,
        sortOrder: form.value.sortOrder,
        isDefault: form.value.isDefault,
        isActive: form.value.isActive
      })
      emit('updated')
    } else {
      // Create new value
      await enumStore.createValue({
        categoryId: props.category.id,
        key: form.value.key,
        label: form.value.label,
        description: form.value.description || undefined,
        color: form.value.color || undefined,
        icon: form.value.icon || undefined,
        sortOrder: form.value.sortOrder,
        isDefault: form.value.isDefault
      })
      emit('created')
    }
  } catch (error: any) {
    console.error('Error saving value:', error)
  } finally {
    loading.value = false
  }
}

// Watch for props changes
watch(() => props.show, (newShow) => {
  if (newShow) {
    resetForm()
  }
})

watch(() => [props.category, props.value], () => {
  if (props.show) {
    resetForm()
  }
})
</script>
