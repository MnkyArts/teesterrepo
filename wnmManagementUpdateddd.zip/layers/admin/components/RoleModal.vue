<template>
  <div
    v-if="show"
    class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
    @click="close"
  >
    <div
      class="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md"
      @click.stop
    >
      <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">
        {{ role ? 'Rolle bearbeiten' : 'Neue Rolle erstellen' }}
      </h3>

      <form @submit.prevent="save" class="space-y-4">
        <!-- Name (nur bei neuen Rollen) -->
        <div v-if="!role">
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Interner Name *
          </label>
          <input
            v-model="form.name"
            type="text"
            required
            placeholder="z.B. project-manager"
            pattern="[a-z-]+"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
          <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
            Nur Kleinbuchstaben und Bindestriche erlaubt
          </p>
        </div>

        <!-- Display Name -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Anzeigename *
          </label>
          <input
            v-model="form.displayName"
            type="text"
            required
            placeholder="z.B. Projektmanager"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
        </div>

        <!-- Description -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Beschreibung
          </label>
          <textarea
            v-model="form.description"
            rows="3"
            placeholder="Optionale Beschreibung der Rolle"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          ></textarea>
        </div>

        <!-- Priority -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Priorität
          </label>
          <input
            v-model.number="form.priority"
            type="number"
            min="0"
            max="100"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
          <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
            Höhere Zahlen = höhere Priorität (0-100)
          </p>
        </div>

        <!-- Actions -->
        <div class="flex justify-end gap-3 pt-4">
          <button
            type="button"
            @click="close"
            class="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"
          >
            Abbrechen
          </button>
          <button
            type="submit"
            :disabled="loading"
            class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg disabled:opacity-50 flex items-center gap-2"
          >
            <div v-if="loading" class="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            {{ role ? 'Aktualisieren' : 'Erstellen' }}
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { Role } from '@prisma/client'

interface Props {
  show: boolean
  role?: Role | null
}

interface Emits {
  (e: 'update:show', value: boolean): void
  (e: 'created'): void
  (e: 'updated'): void
}

const props = withDefaults(defineProps<Props>(), {
  role: null
})

const emit = defineEmits<Emits>()

// Store
const rolesStore = useRolesPermissionsStore()

// State
const loading = ref(false)
const form = ref({
  name: '',
  displayName: '',
  description: '',
  priority: 50
})

// Methods
const close = () => {
  emit('update:show', false)
  resetForm()
}

const resetForm = () => {
  if (props.role) {
    form.value = {
      name: props.role.name,
      displayName: props.role.displayName,
      description: props.role.description ?? '',
      priority: props.role.priority
    }
  } else {
    form.value = {
      name: '',
      displayName: '',
      description: '',
      priority: 50
    }
  }
}

const save = async () => {
  loading.value = true
  
  try {
    if (props.role) {
      // Update existing role
      await rolesStore.updateRole({
        roleId: props.role.id,
        displayName: form.value.displayName,
        description: form.value.description || undefined,
        priority: form.value.priority
      })
      emit('updated')
    } else {
      // Create new role
      await rolesStore.createRole({
        name: form.value.name,
        displayName: form.value.displayName,
        description: form.value.description || undefined,
        priority: form.value.priority
      })
      emit('created')
    }
    close()
  } catch (error: any) {
    console.error('Error saving role:', error)
  } finally {
    loading.value = false
  }
}

// Watch for props changes
watch(() => props.show, (newShow) => {
  if (newShow) {
    resetForm()
  }
})

watch(() => props.role, () => {
  if (props.show) {
    resetForm()
  }
})
</script> 