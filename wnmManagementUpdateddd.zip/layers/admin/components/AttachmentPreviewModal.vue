<template>
  <div class="fixed inset-0 z-50 overflow-y-auto">
    <!-- Backdrop -->
    <div 
      class="fixed inset-0 bg-black bg-opacity-75 transition-opacity"
      @click="$emit('close')"
    ></div>

    <!-- Modal -->
    <div class="flex min-h-full items-center justify-center p-4">
      <div class="relative bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        <!-- Header -->
        <div class="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div class="min-w-0 flex-1">
            <h3 class="text-lg font-medium text-gray-900 dark:text-white truncate">
              {{ attachment.originalName }}
            </h3>
            <div class="mt-1 flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
              <span>{{ formatFileSize(attachment.size) }}</span>
              <span>{{ getFileTypeLabel(attachment.mimeType) }}</span>
              <span>{{ formatDate(attachment.createdAt) }}</span>
            </div>
          </div>
          
          <div class="flex items-center space-x-2 ml-4">
            <!-- Download Button -->
            <button
              type="button"
              class="p-2 text-gray-400 hover:text-green-600 dark:hover:text-green-400 transition-colors rounded-md hover:bg-gray-100 dark:hover:bg-gray-700"
              :title="$t('attachments.download')"
              @click="downloadFile"
            >
              <ArrowDownTrayIcon class="h-5 w-5" />
            </button>
            
            <!-- Schließen Button -->
            <button
              type="button"
              class="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors rounded-md hover:bg-gray-100 dark:hover:bg-gray-700"
              @click="$emit('close')"
            >
              <XMarkIcon class="h-5 w-5" />
            </button>
          </div>
        </div>

        <!-- Content -->
        <div class="p-6 max-h-[calc(90vh-140px)] overflow-auto">
          <!-- Bild-Vorschau -->
          <div v-if="isImage(attachment.mimeType)" class="flex justify-center">
            <img
              :src="getDownloadUrl(taskId, attachment.id)"
              :alt="attachment.originalName"
              class="max-w-full max-h-full object-contain rounded-lg shadow-lg"
              @error="handleImageError"
            />
          </div>

          <!-- PDF-Vorschau -->
          <div v-else-if="attachment.mimeType === 'application/pdf'" class="w-full h-96">
            <iframe
              :src="getDownloadUrl(taskId, attachment.id)"
              class="w-full h-full border-0 rounded-lg"
              title="PDF-Vorschau"
            ></iframe>
          </div>

          <!-- Text-Vorschau -->
          <div v-else-if="attachment.mimeType.startsWith('text/')" class="w-full">
            <div class="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 font-mono text-sm">
              <div v-if="textContent" class="whitespace-pre-wrap">{{ textContent }}</div>
              <div v-else-if="isLoadingText" class="text-center py-4">
                <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-indigo-600 mx-auto"></div>
                <p class="mt-2 text-gray-500 dark:text-gray-400">{{ $t('attachments.loadingPreview') }}</p>
              </div>
              <div v-else class="text-center py-4 text-gray-500 dark:text-gray-400">
                {{ $t('attachments.previewNotAvailable') }}
              </div>
            </div>
          </div>

          <!-- Kein Vorschau verfügbar -->
          <div v-else class="text-center py-12">
            <component 
              :is="getIconComponent(attachment.mimeType)" 
              class="mx-auto h-16 w-16 text-gray-400"
            />
            <h3 class="mt-4 text-lg font-medium text-gray-900 dark:text-white">
              {{ $t('attachments.noPreviewAvailable') }}
            </h3>
            <p class="mt-2 text-gray-500 dark:text-gray-400">
              {{ $t('attachments.noPreviewDescription') }}
            </p>
            <button
              type="button"
              class="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              @click="downloadFile"
            >
              <ArrowDownTrayIcon class="h-4 w-4 mr-2" />
              {{ $t('attachments.downloadFile') }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { 
  XMarkIcon, 
  ArrowDownTrayIcon,
  DocumentIcon,
  DocumentTextIcon,
  PhotoIcon,
  TableCellsIcon,
  ArchiveBoxIcon
} from '@heroicons/vue/24/outline'

import type { TaskAttachment } from '@prisma/client'

interface Props {
  attachment: TaskAttachment
  taskId: string
}

interface Emits {
  (e: 'close'): void
}

const props = defineProps<Props>()
const emit = defineEmits<Emits>()

// Composables
// Stores
const attachmentsStore = useAttachmentsStore()
const { 
  getDownloadUrl, 
  formatFileSize, 
  isImage,
  getFileIcon 
} = attachmentsStore

// Refs
const textContent = ref<string>('')
const isLoadingText = ref(false)

// Datei herunterladen
const downloadFile = () => {
  const url = getDownloadUrl(props.taskId, props.attachment.id)
  const link = document.createElement('a')
  link.href = url
  link.download = props.attachment.originalName
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

// Text-Inhalt laden
const loadTextContent = async () => {
  if (!props.attachment.mimeType.startsWith('text/')) return
  
  isLoadingText.value = true
  try {
    const response = await fetch(getDownloadUrl(props.taskId, props.attachment.id))
    if (response.ok) {
      const content = await response.text()
      // Begrenzen auf erste 5000 Zeichen für Performance
      textContent.value = content.length > 5000 
        ? content.substring(0, 5000) + '\n\n... (Inhalt gekürzt, bitte herunterladen für vollständige Datei)'
        : content
    }
  } catch (error) {
    console.error('Fehler beim Laden des Text-Inhalts:', error)
  } finally {
    isLoadingText.value = false
  }
}

// Bild-Fehler behandeln
const handleImageError = (event: Event) => {
  const img = event.target as HTMLImageElement
  img.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkJpbGQgbmljaHQgdmVyZsO8Z2JhcjwvdGV4dD48L3N2Zz4='
}

// Icon-Komponente basierend auf Dateityp
const getIconComponent = (mimeType: string) => {
  const iconName = getFileIcon(mimeType)
  
  switch (iconName) {
    case '🖼️': return PhotoIcon
    case '📄': return DocumentTextIcon
    case '📝': return DocumentTextIcon
    case '📊': return TableCellsIcon
    case '🗜️': return ArchiveBoxIcon
    case '📎': return DocumentIcon
    default: return DocumentIcon
  }
}

// Dateityp-Label
const getFileTypeLabel = (mimeType: string) => {
  if (mimeType.startsWith('image/')) return 'Bild'
  if (mimeType === 'application/pdf') return 'PDF'
  if (mimeType.includes('word') || mimeType.includes('document')) return 'Word-Dokument'
  if (mimeType.includes('excel') || mimeType.includes('sheet')) return 'Excel-Tabelle'
  if (mimeType.startsWith('text/')) return 'Text-Datei'
  if (mimeType.includes('zip')) return 'ZIP-Archiv'
  if (mimeType.includes('rar')) return 'RAR-Archiv'
  return 'Datei'
}

// Datum formatieren
const formatDate = (date: Date | string) => {
  const dateObj = typeof date === 'string' ? new Date(date) : date
  return dateObj.toLocaleDateString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// ESC-Taste zum Schließen
const handleKeydown = (event: KeyboardEvent) => {
  if (event.key === 'Escape') {
    emit('close')
  }
}

onMounted(() => {
  document.addEventListener('keydown', handleKeydown)
  loadTextContent()
})

onUnmounted(() => {
  document.removeEventListener('keydown', handleKeydown)
})
</script>
