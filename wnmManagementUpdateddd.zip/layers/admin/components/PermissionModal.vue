<template>
  <div
    v-if="show"
    class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
    @click="close"
  >
    <div
      class="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md"
      @click.stop
    >
      <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">
        Neue Berechtigung erstellen
      </h3>

      <form @submit.prevent="save" class="space-y-4">
        <!-- Name -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Interner Name *
          </label>
          <input
            v-model="form.name"
            type="text"
            required
            placeholder="z.B. projects.create"
            pattern="[a-z.]+"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
          <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
            Nur Kleinbuchstaben und Punkte erlaubt (z.B. projects.create)
          </p>
        </div>

        <!-- Display Name -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Anzeigename *
          </label>
          <input
            v-model="form.displayName"
            type="text"
            required
            placeholder="z.B. Projekte erstellen"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
        </div>

        <!-- Description -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Beschreibung
          </label>
          <textarea
            v-model="form.description"
            rows="3"
            placeholder="Optionale Beschreibung der Berechtigung"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          ></textarea>
        </div>

        <!-- Category -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Kategorie *
          </label>
          <select
            v-model="form.category"
            required
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Kategorie wählen</option>
            <option value="projects">Projekte</option>
            <option value="tasks">Aufgaben</option>
            <option value="tickets">Tickets</option>
            <option value="users">Benutzer</option>
            <option value="roles">Rollen</option>
            <option value="permissions">Berechtigungen</option>
            <option value="system">System</option>
            <option value="reports">Berichte</option>
            <option value="settings">Einstellungen</option>
          </select>
        </div>

        <!-- Actions -->
        <div class="flex justify-end gap-3 pt-4">
          <button
            type="button"
            @click="close"
            class="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"
          >
            Abbrechen
          </button>
          <button
            type="submit"
            :disabled="loading"
            class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg disabled:opacity-50 flex items-center gap-2"
          >
            <div v-if="loading" class="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            Erstellen
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup lang="ts">
interface Props {
  show: boolean
}

interface Emits {
  (e: 'update:show', value: boolean): void
  (e: 'created'): void
}

const props = defineProps<Props>()
const emit = defineEmits<Emits>()

// Store
const rolesStore = useRolesPermissionsStore()

// State
const loading = ref(false)
const form = ref({
  name: '',
  displayName: '',
  description: '',
  category: ''
})

// Methods
const close = () => {
  emit('update:show', false)
  resetForm()
}

const resetForm = () => {
  form.value = {
    name: '',
    displayName: '',
    description: '',
    category: ''
  }
}

const save = async () => {
  loading.value = true
  
  try {
    await rolesStore.createPermission({
      name: form.value.name,
      displayName: form.value.displayName,
      description: form.value.description || undefined,
      category: form.value.category
    })
    emit('created')
    close()
  } catch (error: any) {
    console.error('Error saving permission:', error)
  } finally {
    loading.value = false
  }
}

// Watch for props changes
watch(() => props.show, (newShow) => {
  if (newShow) {
    resetForm()
  }
})
</script> 