<template>
  <div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
      <div>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
          Rollen & Berechtigungen
        </h1>
        <p class="text-gray-600 dark:text-gray-400 mt-1">
          Verwalte Benutzerrollen und deren Berechtigungen
        </p>
      </div>

      <div class="flex items-center gap-3">
        <button
          @click="refreshData"
          :disabled="rolesStore.loading"
          class="btn-secondary"
        >
          <ArrowPathIcon class="h-5 w-5" :class="{ 'animate-spin': rolesStore.loading }" />
          Aktualisieren
        </button>
        
        <button
          @click="showCreatePermissionModal = true"
          class="btn-secondary"
        >
          <KeyIcon class="h-5 w-5" />
          Neue Berechtigung
        </button>
        
        <button
          @click="showCreateRoleModal = true"
          class="btn-primary"
        >
          <PlusIcon class="h-5 w-5" />
          Neue Rolle
        </button>
      </div>
    </div>

    <!-- Loading State -->
    <div v-if="rolesStore.loading" class="flex items-center justify-center py-12">
      <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
    </div>

    <!-- Error State -->
    <div v-else-if="rolesStore.error" class="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-6">
      <div class="flex items-center gap-2 text-red-800 dark:text-red-200 mb-2">
        <ExclamationTriangleIcon class="w-5 h-5" />
        <span class="font-medium">Fehler beim Laden der Daten</span>
      </div>
      <p class="text-red-600 dark:text-red-400">{{ rolesStore.error }}</p>
    </div>

    <!-- Main Content -->
    <div v-else class="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
      <!-- Roles List -->
      <div class="lg:col-span-1 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 flex flex-col">
        <div class="p-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
          <div class="flex items-center justify-between mb-3">
            <h2 class="text-lg font-semibold text-gray-900 dark:text-white">
              Rollen
            </h2>
            <span class="text-sm text-gray-500 dark:text-gray-400">
              {{ filteredRoles.length }} Rollen
            </span>
          </div>
          
          <!-- Search -->
          <div class="relative">
            <MagnifyingGlassIcon class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              v-model="searchQuery"
              type="text"
              placeholder="Rollen durchsuchen..."
              class="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
          </div>
        </div>

        <div class="flex-1 overflow-y-auto">
          <div class="p-3 space-y-2">
            <div
              v-for="role in filteredRoles"
              :key="role.id"
              @click="selectRole(role)"
              class="flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors border"
              :class="selectedRole?.id === role.id 
                ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800' 
                : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'"
            >
              <div class="flex items-center gap-3 flex-1 min-w-0">
                <div class="flex-shrink-0">
                  <UserGroupIcon class="w-5 h-5 text-gray-500 dark:text-gray-400" />
                </div>
                <div class="flex-1 min-w-0">
                  <h3 class="font-medium text-gray-900 dark:text-white text-sm">
                    {{ role.displayName }}
                  </h3>
                  <p class="text-xs text-gray-500 dark:text-gray-400">
                    {{ role.name }}
                  </p>
                  <div class="flex items-center gap-2 mt-1">
                    <span class="text-xs px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 rounded">
                      P: {{ role.priority }}
                    </span>
                    <span 
                      v-if="role.isSystem"
                      class="text-xs px-2 py-1 bg-orange-100 dark:bg-orange-900 text-orange-600 dark:text-orange-300 rounded"
                    >
                      System
                    </span>
                  </div>
                </div>
              </div>
              <div class="flex items-center gap-1 ml-2">
                <button
                  v-if="!role.isSystem"
                  @click.stop="editRole(role)"
                  class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 p-1 rounded"
                  title="Bearbeiten"
                >
                  <PencilIcon class="w-4 h-4" />
                </button>
                <button
                  v-if="!role.isSystem"
                  @click.stop="deleteRole(role)"
                  class="text-red-400 hover:text-red-600 p-1 rounded"
                  title="Löschen"
                >
                  <TrashIcon class="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Role Details / Permission Management -->
      <div class="lg:col-span-2 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 flex flex-col">
        <!-- No Role Selected -->
        <div v-if="!selectedRole" class="flex items-center justify-center flex-1">
          <div class="text-center">
            <UserGroupIcon class="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
            <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
              Keine Rolle ausgewählt
            </h3>
            <p class="text-gray-500 dark:text-gray-400">
              Wählen Sie eine Rolle aus der Liste aus, um deren Berechtigungen zu verwalten.
            </p>
          </div>
        </div>

        <!-- Role Details -->
        <div v-else class="flex flex-col flex-1">
          <!-- Header -->
          <div class="p-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
            <div class="flex items-center justify-between">
              <div>
                <h2 class="text-lg font-bold text-gray-900 dark:text-white">
                  {{ selectedRole.displayName }}
                </h2>
                <p class="text-sm text-gray-500 dark:text-gray-400">
                  {{ selectedRole.name }}
                </p>
                <p v-if="selectedRole.description" class="text-sm text-gray-600 dark:text-gray-300 mt-1">
                  {{ selectedRole.description }}
                </p>
              </div>
              <div class="flex items-center gap-2">
                <span class="text-xs px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 rounded">
                  Priorität: {{ selectedRole.priority }}
                </span>
                <span 
                  v-if="selectedRole.isSystem"
                  class="text-xs px-2 py-1 bg-orange-100 dark:bg-orange-900 text-orange-600 dark:text-orange-300 rounded"
                >
                  System-Rolle
                </span>
              </div>
            </div>
          </div>

          <!-- Permission Management -->
          <div class="flex-1 p-4 overflow-hidden">
            <RolePermissionManager 
              :role="selectedRole"
              :permissions="rolesStore.permissions"
              :loading="permissionsLoading"
            />
          </div>
        </div>
      </div>
    </div>

    <!-- Modals -->
    <RoleModal
      v-model:show="showCreateRoleModal"
      @created="handleRoleCreated"
    />

    <RoleModal
      v-model:show="showEditRoleModal"
      :role="editingRole"
      @updated="handleRoleUpdated"
    />

    <PermissionModal
      v-model:show="showCreatePermissionModal"
      @created="handlePermissionCreated"
    />

    <ConfirmDialog
      :isOpen="showDeleteConfirm"
      :title="`Rolle '${deleteTarget?.displayName}' löschen`"
      :message="`Möchten Sie die Rolle '${deleteTarget?.displayName}' wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden.`"
      variant="danger"
      @confirm="confirmDelete"
      @cancel="showDeleteConfirm = false"
    />
  </div>
</template>

<script setup lang="ts">
import { 
  PlusIcon, 
  PencilIcon, 
  TrashIcon,
  ExclamationTriangleIcon,
  UserGroupIcon,
  MagnifyingGlassIcon,
  ArrowPathIcon,
  KeyIcon
} from '@heroicons/vue/24/outline'
import type { Role } from '@prisma/client'

// Store
const rolesStore = useRolesPermissionsStore()

// State
const selectedRole = ref<Role | null>(null)
const searchQuery = ref('')
const permissionsLoading = ref(false)

const showCreateRoleModal = ref(false)
const showEditRoleModal = ref(false)
const showCreatePermissionModal = ref(false)
const showDeleteConfirm = ref(false)

const editingRole = ref<Role | null>(null)
const deleteTarget = ref<Role | null>(null)

// Computed
const filteredRoles = computed(() => {
  if (!searchQuery.value) return rolesStore.rolesByPriority
  
  const query = searchQuery.value.toLowerCase()
  return rolesStore.rolesByPriority.filter(role => 
    role.name.toLowerCase().includes(query) ||
    role.displayName.toLowerCase().includes(query) ||
    role.description?.toLowerCase().includes(query)
  )
})

// Methods
const selectRole = (role: Role) => {
  selectedRole.value = role
}

const editRole = (role: Role) => {
  editingRole.value = role
  showEditRoleModal.value = true
}

const deleteRole = (role: Role) => {
  deleteTarget.value = role
  showDeleteConfirm.value = true
}

const refreshData = async () => {
  await rolesStore.refreshAll()
}

const handleRoleCreated = async () => {
  showCreateRoleModal.value = false
  await rolesStore.refreshAll()
}

const handleRoleUpdated = async () => {
  const editedRoleId = editingRole.value?.id
  showEditRoleModal.value = false
  editingRole.value = null
  await rolesStore.refreshAll()
  
  // Update selected role if it was the one being edited
  if (selectedRole.value && editedRoleId && editedRoleId === selectedRole.value.id) {
    const updatedRole = rolesStore.getRoleById(selectedRole.value.id)
    if (updatedRole) {
      selectedRole.value = updatedRole
    } else {
      selectedRole.value = null
    }
  }
}

const handlePermissionCreated = async () => {
  showCreatePermissionModal.value = false
  await rolesStore.refreshAll()
}

const confirmDelete = async () => {
  if (!deleteTarget.value) return

  try {
    await rolesStore.deleteRole(deleteTarget.value.id)
    
    // Clear selection if deleted role was selected
    if (selectedRole.value?.id === deleteTarget.value.id) {
      selectedRole.value = null
    }
  } catch (error: any) {
    console.error('Error deleting role:', error)
  } finally {
    showDeleteConfirm.value = false
    deleteTarget.value = null
  }
}

// Lifecycle
onMounted(async () => {
  await rolesStore.initialize()
})
</script> 