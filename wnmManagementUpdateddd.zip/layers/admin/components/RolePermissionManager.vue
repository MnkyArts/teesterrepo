<template>
  <div class="space-y-6">
    <!-- Search and Filter -->
    <div class="flex items-center gap-4">
      <div class="relative flex-1">
        <MagnifyingGlassIcon class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          v-model="searchQuery"
          type="text"
          placeholder="Berechtigungen suchen..."
          class="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
      </div>
      
      <div class="flex items-center gap-2">
        <button
          @click="showOnlyAssigned = !showOnlyAssigned"
          class="px-3 py-2 text-sm font-medium rounded-lg transition-colors"
          :class="showOnlyAssigned 
            ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300' 
            : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'"
        >
          <CheckIcon v-if="showOnlyAssigned" class="w-4 h-4 mr-1" />
          <EyeIcon v-else class="w-4 h-4 mr-1" />
          Nur Zugewiesene
        </button>
        
        <span class="text-sm text-gray-500 dark:text-gray-400">
          {{ assignedPermissions.length }} / {{ permissions.length }}
        </span>
      </div>
    </div>

    <!-- Loading State -->
    <div v-if="loadingAssigned" class="flex justify-center py-8">
      <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
    </div>

    <!-- Permissions List -->
    <div v-else class="space-y-4">
      <div
        v-for="[category, permissions] in groupedFilteredPermissions"
        :key="category"
        class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden"
      >
        <!-- Category Header -->
        <div class="px-4 py-3 bg-gray-50 dark:bg-gray-700 border-b border-gray-200 dark:border-gray-600">
          <div class="flex items-center justify-between">
            <div>
              <h3 class="font-medium text-gray-900 dark:text-white capitalize">
                {{ category }}
              </h3>
              <p class="text-xs text-gray-500 dark:text-gray-400">
                {{ getAssignedCount(permissions) }} von {{ permissions.length }} zugewiesen
              </p>
            </div>
            
            <!-- Category Actions -->
            <div class="flex items-center gap-2">
                              <button
                  @click="() => toggleCategoryAll(permissions, true)"
                  :disabled="loading || areAllAssigned(permissions)"
                  class="text-xs px-2 py-1 bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 rounded hover:bg-green-200 dark:hover:bg-green-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Alle zuweisen
                </button>
                <button
                  @click="() => toggleCategoryAll(permissions, false)"
                  :disabled="loading || areAllUnassigned(permissions)"
                  class="text-xs px-2 py-1 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 rounded hover:bg-red-200 dark:hover:bg-red-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Alle entfernen
                </button>
            </div>
          </div>
        </div>

        <!-- Permissions in Category -->
        <div class="divide-y divide-gray-200 dark:divide-gray-700">
          <div
            v-for="permission in permissions"
            :key="permission.id"
            class="px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-3 flex-1 min-w-0">
                <!-- Checkbox -->
                <label class="flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    :checked="isAssigned(permission)"
                    @change="togglePermission(permission)"
                    :disabled="loading"
                    class="h-4 w-4 text-blue-600 border-gray-300 dark:border-gray-600 rounded focus:ring-blue-500 disabled:opacity-50"
                  >
                  <span class="sr-only">{{ permission.displayName }}</span>
                </label>

                <!-- Permission Info -->
                <div class="flex-1 min-w-0">
                  <div class="flex items-center gap-2">
                    <h4 class="font-medium text-gray-900 dark:text-white text-sm">
                      {{ permission.displayName }}
                    </h4>
                    <span 
                      v-if="permission.isSystem"
                      class="px-2 py-1 text-xs bg-orange-100 dark:bg-orange-900 text-orange-600 dark:text-orange-300 rounded"
                    >
                      System
                    </span>
                  </div>
                  <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    {{ permission.name }}
                  </p>
                  <p v-if="permission.description" class="text-xs text-gray-400 dark:text-gray-500 mt-1">
                    {{ permission.description }}
                  </p>
                </div>
              </div>

              <!-- Status Indicator -->
              <div class="flex items-center gap-2 ml-3">
                <div
                  v-if="isAssigned(permission)"
                  class="flex items-center gap-1 px-2 py-1 bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 rounded-full text-xs"
                >
                  <CheckIcon class="w-3 h-3" />
                  Zugewiesen
                </div>
                <div
                  v-else
                  class="flex items-center gap-1 px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-full text-xs"
                >
                  <XMarkIcon class="w-3 h-3" />
                  Verfügbar
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Empty State -->
      <div v-if="groupedFilteredPermissions.size === 0" class="text-center py-12">
        <KeyIcon class="mx-auto h-12 w-12 text-gray-300 dark:text-gray-600 mb-4" />
        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
          Keine Berechtigungen gefunden
        </h3>
        <p class="text-gray-500 dark:text-gray-400">
          Versuchen Sie einen anderen Suchbegriff oder ändern Sie den Filter.
        </p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { 
  KeyIcon, 
  MagnifyingGlassIcon,
  CheckIcon,
  XMarkIcon,
  EyeIcon
} from '@heroicons/vue/24/outline'
import type { Role, Permission } from '@prisma/client'

interface Props {
  role: Role
  permissions: Permission[]
  loading?: boolean
}

interface Emits {
  (e: 'refresh'): void
}

const props = withDefaults(defineProps<Props>(), {
  loading: false
})

const emit = defineEmits<Emits>()

// Store
const rolesStore = useRolesPermissionsStore()

// State
const assignedPermissions = ref<Permission[]>([])
const loadingAssigned = ref(false)
const searchQuery = ref('')
const showOnlyAssigned = ref(false)

// Computed
const filteredPermissions = computed(() => {
  let filtered = props.permissions

  // Filter by search query
  if (searchQuery.value) {
    const query = searchQuery.value.toLowerCase()
    filtered = filtered.filter(permission => 
      permission.name.toLowerCase().includes(query) ||
      permission.displayName.toLowerCase().includes(query) ||
      permission.description?.toLowerCase().includes(query) ||
      permission.category.toLowerCase().includes(query)
    )
  }

  // Filter by assigned status
  if (showOnlyAssigned.value) {
    const assignedIds = new Set(assignedPermissions.value.map(p => p.id))
    filtered = filtered.filter(p => assignedIds.has(p.id))
  }

  return filtered
})

const groupedFilteredPermissions = computed(() => {
  const grouped = new Map<string, Permission[]>()
  filteredPermissions.value.forEach(permission => {
    if (!grouped.has(permission.category)) {
      grouped.set(permission.category, [])
    }
    grouped.get(permission.category)!.push(permission)
  })
  
  // Sort categories and permissions within each category
  const sortedMap = new Map()
  Array.from(grouped.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .forEach(([category, permissions]) => {
      sortedMap.set(category, permissions.sort((a, b) => a.displayName.localeCompare(b.displayName)))
    })
  
  return sortedMap
})

// Methods
const loadRolePermissions = async () => {
  if (!props.role) return
  
  loadingAssigned.value = true
  try {
    const rolePermissions = await rolesStore.getPermissionsByRole(props.role.id)
    assignedPermissions.value = rolePermissions
  } catch (error) {
    console.error('Error loading role permissions:', error)
  } finally {
    loadingAssigned.value = false
  }
}

const isAssigned = (permission: Permission): boolean => {
  return assignedPermissions.value.some(p => p.id === permission.id)
}

const togglePermission = async (permission: Permission) => {
  if (!props.role) return
  
  const isCurrentlyAssigned = isAssigned(permission)
  
  // Optimistic update - update UI immediately
  if (isCurrentlyAssigned) {
    // Remove from assigned permissions
    assignedPermissions.value = assignedPermissions.value.filter(p => p.id !== permission.id)
  } else {
    // Add to assigned permissions
    assignedPermissions.value.push(permission)
  }
  
  try {
    await rolesStore.assignPermissionToRole({
      roleId: props.role.id,
      permissionId: permission.id,
      granted: !isCurrentlyAssigned
    })
    
    // Success - the optimistic update was correct, no need to do anything
  } catch (error) {
    console.error('Error toggling permission:', error)
    
    // Revert optimistic update on error
    if (isCurrentlyAssigned) {
      // Re-add the permission that we removed
      assignedPermissions.value.push(permission)
    } else {
      // Remove the permission that we added
      assignedPermissions.value = assignedPermissions.value.filter(p => p.id !== permission.id)
    }
  }
}

const getAssignedCount = (permissions: Permission[]): number => {
  return permissions.filter(p => isAssigned(p)).length
}

const areAllAssigned = (permissions: Permission[]): boolean => {
  return permissions.every(p => isAssigned(p))
}

const areAllUnassigned = (permissions: Permission[]): boolean => {
  return permissions.every(p => !isAssigned(p))
}

const toggleCategoryAll = async (permissions: Permission[], assign: boolean) => {
  if (!props.role) return
  
  const permissionsToToggle = permissions.filter(p => isAssigned(p) !== assign)
  
  // Optimistic update - update UI immediately
  if (assign) {
    // Add permissions that weren't already assigned
    const newPermissions = permissionsToToggle.filter(p => !isAssigned(p))
    assignedPermissions.value.push(...newPermissions)
  } else {
    // Remove permissions that were assigned
    const idsToRemove = new Set(permissionsToToggle.map(p => p.id))
    assignedPermissions.value = assignedPermissions.value.filter(p => !idsToRemove.has(p.id))
  }
  
  try {
    // Process all permissions in the category
    await Promise.all(
      permissionsToToggle.map(permission =>
        rolesStore.assignPermissionToRole({
          roleId: props.role.id,
          permissionId: permission.id,
          granted: assign
        })
      )
    )
    
    // Success - the optimistic update was correct, no need to do anything
  } catch (error) {
    console.error('Error toggling category permissions:', error)
    
    // Revert optimistic update on error
    if (assign) {
      // Remove permissions that we added
      const idsToRemove = new Set(permissionsToToggle.map(p => p.id))
      assignedPermissions.value = assignedPermissions.value.filter(p => !idsToRemove.has(p.id))
    } else {
      // Re-add permissions that we removed
      const permissionsToReAdd = permissionsToToggle.filter(p => !isAssigned(p))
      assignedPermissions.value.push(...permissionsToReAdd)
    }
  }
}

// Watchers
watch(() => props.role, (newRole) => {
  if (newRole) {
    loadRolePermissions()
    // Reset filters when role changes
    searchQuery.value = ''
    showOnlyAssigned.value = false
  }
}, { immediate: true })

watch(() => props.permissions, () => {
  // Refresh assigned permissions when permissions list changes
  if (props.role) {
    loadRolePermissions()
  }
})
</script> 