import { defineStore } from 'pinia'
import { authClient } from '~/lib/auth-client'
import type { Role, Permission, RolePermission, UserRole } from '@prisma/client'

interface CreateRoleData {
  name: string
  displayName: string
  description?: string
  priority: number
}

interface UpdateRoleData {
  roleId: string
  displayName?: string
  description?: string
  priority?: number
}

interface CreatePermissionData {
  name: string
  displayName: string
  description?: string
  category: string
}

interface AssignPermissionToRoleData {
  roleId: string
  permissionId: string
  granted: boolean
  context?: string
}

interface AssignRoleToUserData {
  userId: string
  roleId: string
  context?: string
  expiresAt?: string
}

export const useRolesPermissionsStore = defineStore('rolesPermissions', () => {
  // State
  const roles = ref<Role[]>([])
  const permissions = ref<Permission[]>([])
  const userPermissions = ref<string[]>([])
  const loading = ref(false)
  const error = ref<string | null>(null)

  // Computed
  const rolesByPriority = computed(() => {
    return [...roles.value].sort((a, b) => b.priority - a.priority)
  })

  const permissionsByCategory = computed(() => {
    const grouped = new Map<string, Permission[]>()
    permissions.value.forEach(permission => {
      if (!grouped.has(permission.category)) {
        grouped.set(permission.category, [])
      }
      grouped.get(permission.category)!.push(permission)
    })
    return grouped
  })

  const systemRoles = computed(() => {
    return roles.value.filter(role => role.isSystem)
  })

  const customRoles = computed(() => {
    return roles.value.filter(role => !role.isSystem)
  })

  const systemPermissions = computed(() => {
    return permissions.value.filter(permission => permission.isSystem)
  })

  const customPermissions = computed(() => {
    return permissions.value.filter(permission => !permission.isSystem)
  })

  // Actions
  const fetchRoles = async () => {
    loading.value = true
    error.value = null

    try {
      const response = await authClient.getRoles()
      const data = response.data as { roles: Role[] }
      roles.value = data.roles.map((role: any) => ({
        ...role,
        createdAt: new Date(role.createdAt),
        updatedAt: new Date(role.updatedAt)
      }))
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Laden der Rollen'
      console.error('Error fetching roles:', err)
    } finally {
      loading.value = false
    }
  }

  const fetchPermissions = async () => {
    loading.value = true
    error.value = null

    try {
      const response = await authClient.getPermissions()
      const data = response.data as { permissions: Permission[] }
      permissions.value = data.permissions.map((permission: any) => ({
        ...permission,
        createdAt: new Date(permission.createdAt),
        updatedAt: new Date(permission.updatedAt)
      }))
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Laden der Berechtigungen'
      console.error('Error fetching permissions:', err)
    } finally {
      loading.value = false
    }
  }

  const fetchUserPermissions = async (userId: string) => {
    loading.value = true
    error.value = null

    try {
      const response = await authClient.getUserPermissions({ userId })
      const data = response.data as { permissions: string[] }
      userPermissions.value = data.permissions
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Laden der Benutzerberechtigungen'
      console.error('Error fetching user permissions:', err)
    } finally {
      loading.value = false
    }
  }

  const createRole = async (data: CreateRoleData) => {
    loading.value = true
    error.value = null

    try {
      const response = await authClient.createRole(data)
      const result = response.data as { role: Role }
      const newRole = {
        ...result.role,
        createdAt: new Date(result.role.createdAt),
        updatedAt: new Date(result.role.updatedAt)
      }
      roles.value.push(newRole)
      return newRole
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Erstellen der Rolle'
      console.error('Error creating role:', err)
      throw err
    } finally {
      loading.value = false
    }
  }

  const updateRole = async (data: UpdateRoleData) => {
    loading.value = true
    error.value = null

    try {
      const response = await authClient.updateRole(data)
      const result = response.data as { role: Role }
      const updatedRole = {
        ...result.role,
        createdAt: new Date(result.role.createdAt),
        updatedAt: new Date(result.role.updatedAt)
      }
      
      const index = roles.value.findIndex(r => r.id === data.roleId)
      if (index !== -1) {
        roles.value[index] = updatedRole
      }
      return updatedRole
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Aktualisieren der Rolle'
      console.error('Error updating role:', err)
      throw err
    } finally {
      loading.value = false
    }
  }

  const deleteRole = async (roleId: string) => {
    loading.value = true
    error.value = null

    try {
      await authClient.deleteRole({ roleId })
      roles.value = roles.value.filter(r => r.id !== roleId)
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Löschen der Rolle'
      console.error('Error deleting role:', err)
      throw err
    } finally {
      loading.value = false
    }
  }

  const createPermission = async (data: CreatePermissionData) => {
    loading.value = true
    error.value = null

    try {
      const response = await authClient.createPermission(data)
      const result = response.data as { permission: Permission }
      const newPermission = {
        ...result.permission,
        createdAt: new Date(result.permission.createdAt),
        updatedAt: new Date(result.permission.updatedAt)
      }
      permissions.value.push(newPermission)
      return newPermission
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Erstellen der Berechtigung'
      console.error('Error creating permission:', err)
      throw err
    } finally {
      loading.value = false
    }
  }

  const assignPermissionToRole = async (data: AssignPermissionToRoleData) => {
    try {
      await authClient.assignPermissionToRole(data)
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Zuweisen der Berechtigung zur Rolle'
      console.error('Error assigning permission to role:', err)
      throw err
    }
  }

  const assignRoleToUser = async (data: AssignRoleToUserData) => {
    loading.value = true
    error.value = null

    try {
      await authClient.assignRoleToUser(data)
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Zuweisen der Rolle zum Benutzer'
      console.error('Error assigning role to user:', err)
      throw err
    } finally {
      loading.value = false
    }
  }

  const checkUserPermission = async (userId: string, permission: string, context?: string) => {
    try {
      const response = await authClient.checkUserPermission({
        userId,
        permission,
        context
      })
      const result = response.data as { hasPermission: boolean }
      return result.hasPermission
    } catch (err: any) {
      console.error('Error checking user permission:', err)
      return false
    }
  }

  const checkCurrentUserPermission = async (permission: string, context?: string) => {
    try {
      const response = await authClient.hasPermission(permission, context)
      const result = response.data as { hasPermission: boolean }
      return result.hasPermission
    } catch (err: any) {
      console.error('Error checking current user permission:', err)
      return false
    }
  }

  const refreshAll = async () => {
    await Promise.all([
      fetchRoles(),
      fetchPermissions()
    ])
  }

  const clearError = () => {
    error.value = null
  }

  const resetState = () => {
    roles.value = []
    permissions.value = []
    userPermissions.value = []
    error.value = null
    loading.value = false
  }

  const initialize = async () => {
    await refreshAll()
  }

  // Utility functions
  const getRoleById = (roleId: string): Role | undefined => {
    return roles.value.find(role => role.id === roleId)
  }

  const getPermissionById = (permissionId: string): Permission | undefined => {
    return permissions.value.find(permission => permission.id === permissionId)
  }

  const getRolesByUser = (userId: string): Role[] => {
    // This would need to be implemented based on your user-role relationships
    // For now, return empty array
    return []
  }

  const getPermissionsByRole = async (roleId: string): Promise<Permission[]> => {
    try {
      const response = await authClient.getRolePermissions({ roleId })
      const data = response.data as { permissions: Permission[] }
      return data.permissions.map((permission: any) => ({
        ...permission,
        createdAt: new Date(permission.createdAt),
        updatedAt: new Date(permission.updatedAt)
      }))
    } catch (err: any) {
      console.error('Error fetching role permissions:', err)
      return []
    }
  }

  return {
    // State
    roles,
    permissions,
    userPermissions,
    loading,
    error,

    // Computed
    rolesByPriority,
    permissionsByCategory,
    systemRoles,
    customRoles,
    systemPermissions,
    customPermissions,

    // Actions
    fetchRoles,
    fetchPermissions,
    fetchUserPermissions,
    createRole,
    updateRole,
    deleteRole,
    createPermission,
    assignPermissionToRole,
    assignRoleToUser,
    checkUserPermission,
    checkCurrentUserPermission,
    refreshAll,
    clearError,
    resetState,
    initialize,

    // Utility functions
    getRoleById,
    getPermissionById,
    getRolesByUser,
    getPermissionsByRole
  }
}) 