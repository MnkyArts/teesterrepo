import { defineStore } from 'pinia'
import type { TaskAttachment } from '@prisma/client'

interface UploadProgress {
  loaded: number
  total: number
  percentage: number
}

export const useAttachmentsStore = defineStore('attachments', () => {
  const notificationsStore = useNotificationsStore()
  
  // State
  const attachments = ref<TaskAttachment[]>([])
  const currentTaskAttachments = ref<TaskAttachment[]>([])
  const isLoading = ref(false)
  const isUploading = ref(false)
  const uploadProgress = ref<UploadProgress | null>(null)

  // Computed
  const attachmentsByTask = computed(() => {
    const grouped = new Map<string, TaskAttachment[]>()
    attachments.value.forEach(attachment => {
      if (!grouped.has(attachment.taskId)) {
        grouped.set(attachment.taskId, [])
      }
      grouped.get(attachment.taskId)!.push(attachment)
    })
    return grouped
  })

  const totalAttachmentsSize = computed(() => {
    return attachments.value.reduce((total, attachment) => total + attachment.size, 0)
  })

  // Actions
  const fetchAttachments = async (taskId: string) => {
    if (!taskId) {
      throw new Error('Task-ID ist erforderlich')
    }
    
    isLoading.value = true
    
    try {
      const data = await $fetch<TaskAttachment[]>(`/api/tasks/${taskId}/attachments`)
      
      const processedAttachments = data.map(attachment => ({
        ...attachment,
        createdAt: new Date(attachment.createdAt)
      }))
      
      currentTaskAttachments.value = processedAttachments
      
      // Update in global attachments list
      attachments.value = attachments.value.filter(a => a.taskId !== taskId)
      attachments.value.push(...processedAttachments)
      
      return processedAttachments
    } catch (error: any) {
      console.error('Error fetching attachments:', error)
      notificationsStore.error('Fehler', 'Anhänge konnten nicht geladen werden')
      throw error
    } finally {
      isLoading.value = false
    }
  }

  const uploadFile = async (taskId: string, file: File): Promise<TaskAttachment | null> => {
    if (!taskId || !file) {
      notificationsStore.error('Fehler', 'Task-ID und Datei sind erforderlich')
      return null
    }
    
    // File size validation (10MB max)
    const maxSize = 10 * 1024 * 1024
    if (file.size > maxSize) {
      notificationsStore.error('Fehler', 'Datei ist zu groß. Maximale Größe: 10MB')
      return null
    }

    // MIME type validation
    const allowedTypes = [
      'image/jpeg', 'image/png', 'image/gif', 'image/webp',
      'application/pdf', 'application/msword', 
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/plain', 'text/csv', 'application/zip', 'application/x-rar-compressed'
    ]
    
    if (!allowedTypes.includes(file.type)) {
      notificationsStore.error('Fehler', 'Dateityp nicht unterstützt')
      return null
    }

    isUploading.value = true
    uploadProgress.value = { loaded: 0, total: file.size, percentage: 0 }

    try {
      const formData = new FormData()
      formData.append('file', file)

      const response = await $fetch<TaskAttachment>(`/api/tasks/${taskId}/attachments`, {
        method: 'POST',
        body: formData
      })

      const newAttachment = {
        ...response,
        createdAt: new Date(response.createdAt)
      }

      // Add to attachments list
      attachments.value.unshift(newAttachment)
      
      // Add to current task attachments if it's the same task
      currentTaskAttachments.value.unshift(newAttachment)

      notificationsStore.success('Erfolg', `Datei "${file.name}" wurde hochgeladen`)

      return newAttachment
    } catch (error: any) {
      console.error('Upload error:', error)
      const errorMessage = error.data?.message || 'Fehler beim Hochladen der Datei'
      notificationsStore.error('Fehler', errorMessage)
      return null
    } finally {
      isUploading.value = false
      uploadProgress.value = null
    }
  }

  const deleteAttachment = async (taskId: string, attachmentId: string) => {
    try {
      await $fetch(`/api/tasks/${taskId}/attachment/${attachmentId}`, {
        method: 'DELETE'
      })

      // Remove from attachments list
      attachments.value = attachments.value.filter(a => a.id !== attachmentId)
      
      // Remove from current task attachments
      currentTaskAttachments.value = currentTaskAttachments.value.filter(a => a.id !== attachmentId)

      notificationsStore.success('Erfolg', 'Anhang wurde gelöscht')

      return true
    } catch (error: any) {
      console.error('Delete error:', error)
      const errorMessage = error.data?.message || 'Fehler beim Löschen des Anhangs'
      notificationsStore.error('Fehler', errorMessage)
      throw error
    }
  }

  const getDownloadUrl = (taskId: string, attachmentId: string) => {
    return `/api/tasks/${taskId}/attachment/${attachmentId}`
  }

  const getPreviewUrl = (taskId: string, attachmentId: string) => {
    return `/api/tasks/${taskId}/attachment/${attachmentId}`
  }

  // Utility functions
  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith('image/')) return '🖼️'
    if (mimeType === 'application/pdf') return '📄'
    if (mimeType.includes('word') || mimeType.includes('document')) return '📝'
    if (mimeType.includes('excel') || mimeType.includes('spreadsheet')) return '📊'
    if (mimeType.includes('zip') || mimeType.includes('rar')) return '🗜️'
    if (mimeType.startsWith('text/')) return '📄'
    return '📎'
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const isImage = (mimeType: string) => {
    return mimeType.startsWith('image/')
  }

  const canPreview = (mimeType: string) => {
    const previewableTypes = [
      'image/jpeg', 'image/png', 'image/gif', 'image/webp',
      'application/pdf',
      'text/plain'
    ]
    return previewableTypes.includes(mimeType)
  }

  const getFileCategory = (mimeType: string) => {
    if (mimeType.startsWith('image/')) return 'image'
    if (mimeType === 'application/pdf') return 'pdf'
    if (mimeType.includes('word') || mimeType.includes('document')) return 'document'
    if (mimeType.includes('excel') || mimeType.includes('spreadsheet')) return 'spreadsheet'
    if (mimeType.includes('zip') || mimeType.includes('rar')) return 'archive'
    if (mimeType.startsWith('text/')) return 'text'
    return 'other'
  }

  const setCurrentTaskAttachments = (taskId: string) => {
    currentTaskAttachments.value = attachments.value.filter(a => a.taskId === taskId)
  }

  const clearAttachments = () => {
    attachments.value = []
    currentTaskAttachments.value = []
    uploadProgress.value = null
  }

  return {
    // State
    attachments: readonly(attachments),
    currentTaskAttachments: readonly(currentTaskAttachments),
    isLoading: readonly(isLoading),
    isUploading: readonly(isUploading),
    uploadProgress: readonly(uploadProgress),
    
    // Computed
    attachmentsByTask,
    totalAttachmentsSize,
    
    // Actions
    fetchAttachments,
    uploadFile,
    deleteAttachment,
    setCurrentTaskAttachments,
    clearAttachments,
    
    // Utility functions
    getDownloadUrl,
    getPreviewUrl,
    getFileIcon,
    formatFileSize,
    isImage,
    canPreview,
    getFileCategory
  }
})
