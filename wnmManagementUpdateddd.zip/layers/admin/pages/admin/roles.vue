<template>
  <div>
    <RolesPermissionsManagement />
  </div>
</template>

<script setup lang="ts">
// Meta
definePageMeta({
  title: 'Rollen & Berechtigungen',
  description: 'Verwalte Benutzerrollen und deren Berechtigungen',
  layout: 'default'
})

// SEO
useHead({
  title: 'Rollen & Berechtigungen - wenoma',
  meta: [
    {
      name: 'description',
      content: 'Verwalte Benutzerrollen und deren Berechtigungen im wenoma System'
    }
  ]
})
</script> 