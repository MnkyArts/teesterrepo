<template>
  <div class="space-y-6">
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
          Module Configuration
        </h1>
        <button
          @click="validateAndReload"
          class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Validate & Apply Changes
        </button>
      </div>

      <!-- Dependency Validation Results -->
      <div v-if="validationErrors.length > 0" class="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
        <h3 class="text-lg font-semibold text-red-800 dark:text-red-200 mb-2">
          Dependency Validation Errors
        </h3>
        <ul class="list-disc list-inside space-y-1">
          <li v-for="error in validationErrors" :key="error" class="text-red-700 dark:text-red-300">
            {{ error }}
          </li>
        </ul>
      </div>

      <!-- Module List -->
      <div class="grid gap-4">
        <div
          v-for="(config, moduleName) in modulesConfig"
          :key="moduleName"
          class="border border-gray-200 dark:border-gray-700 rounded-lg p-4"
          :class="{
            'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800': config.enabled,
            'bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700': !config.enabled
          }"
        >
          <div class="flex items-start justify-between">
            <div class="flex-1">
              <div class="flex items-center gap-3 mb-2">
                <h3 class="text-lg font-semibold capitalize" :class="{
                  'text-green-800 dark:text-green-200': config.enabled,
                  'text-gray-500 dark:text-gray-400': !config.enabled
                }">
                  {{ moduleName }}
                </h3>
                <span class="px-2 py-1 text-xs rounded-full" :class="{
                  'bg-green-100 dark:bg-green-800 text-green-800 dark:text-green-200': config.enabled,
                  'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400': !config.enabled
                }">
                  {{ config.enabled ? 'Enabled' : 'Disabled' }}
                </span>
              </div>
              
              <p class="text-gray-600 dark:text-gray-300 mb-2">
                {{ config.description }}
              </p>
              
              <div class="text-sm text-gray-500 dark:text-gray-400">
                <strong>Layer:</strong> {{ config.layer }}
              </div>
              
              <div v-if="config.dependencies" class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                <strong>Dependencies:</strong> 
                <span class="inline-flex gap-1 ml-1">
                  <span
                    v-for="dep in config.dependencies"
                    :key="dep"
                    class="px-2 py-0.5 bg-gray-100 dark:bg-gray-700 rounded text-xs"
                    :class="{
                      'text-green-600 dark:text-green-400': isModuleEnabled(dep),
                      'text-red-600 dark:text-red-400': !isModuleEnabled(dep)
                    }"
                  >
                    {{ dep }}
                  </span>
                </span>
              </div>
            </div>
            
            <div class="ml-4">
              <label class="flex items-center">
                <input
                  v-model="config.enabled"
                  type="checkbox"
                  class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                  :disabled="moduleName === 'core'"
                  @change="validateDependencies"
                >
                <span class="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">
                  {{ config.enabled ? 'Enabled' : 'Disabled' }}
                </span>
              </label>
            </div>
          </div>
        </div>
      </div>

      <!-- Module Statistics -->
      <div class="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
          <div class="text-2xl font-bold text-blue-600 dark:text-blue-400">
            {{ enabledModulesCount }}
          </div>
          <div class="text-sm text-blue-600 dark:text-blue-400">
            Enabled Modules
          </div>
        </div>
        
        <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
          <div class="text-2xl font-bold text-gray-600 dark:text-gray-400">
            {{ totalModulesCount }}
          </div>
          <div class="text-sm text-gray-600 dark:text-gray-400">
            Total Modules
          </div>
        </div>
        
        <div class="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
          <div class="text-2xl font-bold text-green-600 dark:text-green-400">
            {{ validationErrors.length === 0 ? '✓' : '✗' }}
          </div>
          <div class="text-sm text-green-600 dark:text-green-400">
            Dependencies Valid
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref, onMounted } from 'vue'

// Page metadata
definePageMeta({
  title: 'Module Configuration',
  layout: 'default'
})

// Module system composable
const { modulesConfig, validateModuleDependencies, isModuleEnabled, getEnabledModules } = useModules()

// Reactive state
const validationErrors = ref<string[]>([])

// Computed properties
const enabledModulesCount = computed(() => getEnabledModules().length)
const totalModulesCount = computed(() => Object.keys(modulesConfig).length)

// Methods
const validateDependencies = () => {
  validationErrors.value = validateModuleDependencies()
}

const validateAndReload = async () => {
  validateDependencies()
  
  if (validationErrors.value.length === 0) {
    // Show success message
    alert('Configuration valid! The changes will take effect after restart.')
  } else {
    alert('Please fix dependency errors before applying changes.')
  }
}

// Initialize
onMounted(() => {
  validateDependencies()
})
</script>
