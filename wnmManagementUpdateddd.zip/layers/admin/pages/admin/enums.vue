<template>
  <div>
    <EnumManagement />
  </div>
</template>

<script setup lang="ts">
// Meta
definePageMeta({
  title: 'Enum-Verwaltung',
  description: 'Verwalte dynamische Aufgaben- und Ticket-Eigenschaften',
  layout: 'default'
})

// SEO
useHead({
  title: 'Enum-Verwaltung - wenoma',
  meta: [
    {
      name: 'description',
      content: 'Verwalte dynamische Aufgaben- und Ticket-Eigenschaften im wenoma System'
    }
  ]
})
</script>
