<template>
    <div class="space-y-8">
      <!-- Page Header -->
      <div>
        <h1 class="text-3xl font-bold text-gray-900 dark:text-white">
          {{ $t('payments.title') }}
        </h1>
        <p class="mt-2 text-gray-600 dark:text-gray-400">
          {{ $t('payments.description') }}
        </p>
      </div>

      <!-- SEPA Management Component -->
      <SepaManagement />

      <!-- Payment History (Placeholder for future implementation) -->
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <div class="p-6">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">
            {{ $t('payments.history.title') }}
          </h3>
          <div class="text-center py-12">
            <Icon name="heroicons:credit-card" class="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p class="text-gray-500 dark:text-gray-400">
              {{ $t('payments.history.coming_soon') }}
            </p>
          </div>
        </div>
      </div>
    </div>
</template>

<script setup>
const { t } = useI18n()

// Page meta
definePageMeta({
  layout: 'customer',
})

// SEO
useSeoMeta({
  title: () => t('payments.title'),
  description: () => t('payments.description')
})
</script>
