<template>
    <div class="space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between">
        <div>
          <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
            {{ $t('tickets.title') }}
          </h1>
          <p class="text-gray-600 dark:text-gray-400">
            Verwalten Sie Ihre Support-Anfragen und verfolgen Sie den Status
          </p>
        </div>
        <NuxtLink
          to="/customer/tickets/new"
          class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
        >
          <Icon name="heroicons:plus" class="w-4 h-4 mr-2" />
          {{ $t('tickets.newTicket') }}
        </NuxtLink>
      </div>

      <!-- Filters -->
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
        <div class="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0 md:space-x-4">
          <!-- Status Filter -->
          <div class="flex-1">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('tickets.status') }}
            </label>
            <select
              v-model="filters.status"
              @change="loadTickets"
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            >
              <option value="">{{ $t('invoices.allStatuses') }}</option>
              <option value="OFFEN">{{ $t('tickets.statuses.offen') }}</option>
              <option value="IN_BEARBEITUNG">{{ $t('tickets.statuses.in_bearbeitung') }}</option>
              <option value="WARTEN_AUF_KUNDE">{{ $t('tickets.statuses.warten_auf_kunde') }}</option>
              <option value="GELOEST">{{ $t('tickets.statuses.geloest') }}</option>
              <option value="GESCHLOSSEN">{{ $t('tickets.statuses.geschlossen') }}</option>
            </select>
          </div>

          <!-- Department Filter -->
          <div class="flex-1">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('tickets.department') }}
            </label>
            <select
              v-model="filters.department"
              @change="loadTickets"
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            >
              <option value="">Alle Abteilungen</option>
              <option value="Support">{{ $t('tickets.departments.Support') }}</option>
              <option value="Buchhaltung">{{ $t('tickets.departments.Buchhaltung') }}</option>
              <option value="Entwicklung">{{ $t('tickets.departments.Entwicklung') }}</option>
              <option value="Vertrieb">{{ $t('tickets.departments.Vertrieb') }}</option>
              <option value="Allgemein">{{ $t('tickets.departments.Allgemein') }}</option>
            </select>
          </div>

          <!-- Search -->
          <div class="flex-1">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Suche
            </label>
            <div class="relative">
              <input
                v-model="searchQuery"
                @input="debouncedSearch"
                type="text"
                placeholder="Titel oder Beschreibung suchen..."
                class="w-full px-3 py-2 pl-10 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
              >
              <Icon name="heroicons:magnifying-glass" class="w-5 h-5 text-gray-400 absolute left-3 top-2.5" />
            </div>
          </div>
        </div>
      </div>

      <!-- Tickets List -->
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <!-- Loading State -->
        <div v-if="loading" class="p-6">
          <div class="space-y-4">
            <div v-for="i in 3" :key="i" class="animate-pulse">
              <div class="flex items-center space-x-4">
                <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
                <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/6"></div>
                <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Empty State -->
        <div v-else-if="tickets.length === 0" class="p-12 text-center">
          <Icon name="heroicons:ticket" class="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-600" />
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
            {{ $t('tickets.noTickets') }}
          </h3>
          <p class="text-gray-600 dark:text-gray-400 mb-6">
            {{ $t('tickets.createFirstTicket') }}
          </p>
          <NuxtLink
            to="/customer/tickets/new"
            class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
          >
            <Icon name="heroicons:plus" class="w-4 h-4 mr-2" />
            {{ $t('tickets.newTicket') }}
          </NuxtLink>
        </div>

        <!-- Tickets Table -->
        <div v-else class="overflow-hidden">
          <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead class="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  {{ $t('tickets.subject') }}
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  {{ $t('tickets.department') }}
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  {{ $t('tickets.priority') }}
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Status
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  {{ $t('tickets.createdAt') }}
                </th>
                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Aktionen
                </th>
              </tr>
            </thead>
            <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              <tr 
                v-for="ticket in tickets" 
                :key="ticket.id"
                class="hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer"
                @click="viewTicket(ticket.id)"
              >
                <td class="px-6 py-4 whitespace-nowrap">
                  <div>
                    <div class="text-sm font-medium text-gray-900 dark:text-white">
                      {{ ticket.title }}
                    </div>
                    <div class="text-sm text-gray-500 dark:text-gray-400 truncate max-w-xs">
                      {{ ticket.description }}
                    </div>
                  </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                  {{ $t(`tickets.departments.${ticket.department}`) }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <span 
                    class="inline-flex px-2 py-1 text-xs font-medium rounded-full"
                    :class="getPriorityBadgeClass(ticket.priority)"
                  >
                    {{ $t(`common.priority.${ticket.priority.toLowerCase()}`) }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <span 
                    class="inline-flex px-2 py-1 text-xs font-medium rounded-full"
                    :class="getStatusBadgeClass(ticket.status)"
                  >
                    {{ $t(`tickets.statuses.${ticket.status.toLowerCase()}`) }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                  {{ formatDate(ticket.createdAt) }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <NuxtLink
                    :to="`/customer/tickets/${ticket.id}`"
                    class="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300"
                    @click.stop
                  >
                    Details
                  </NuxtLink>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <div v-if="pagination.pages > 1" class="px-6 py-4 border-t border-gray-200 dark:border-gray-700">
          <div class="flex items-center justify-between">
            <div class="text-sm text-gray-700 dark:text-gray-300">
              Zeige {{ (pagination.page - 1) * pagination.limit + 1 }} bis 
              {{ Math.min(pagination.page * pagination.limit, pagination.total) }} von 
              {{ pagination.total }} Tickets
            </div>
            <div class="flex items-center space-x-2">
              <button
                @click="changePage(pagination.page - 1)"
                :disabled="pagination.page <= 1"
                class="px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Zurück
              </button>
              <span class="px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Seite {{ pagination.page }} von {{ pagination.pages }}
              </span>
              <button
                @click="changePage(pagination.page + 1)"
                :disabled="pagination.page >= pagination.pages"
                class="px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Weiter
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script setup>
definePageMeta({
  layout: 'customer',
})

const notificationsStore = useNotificationsStore()
const { addNotification } = notificationsStore

// State
const loading = ref(false)
const tickets = ref([])
const searchQuery = ref('')
const filters = ref({
  status: '',
  department: ''
})

const pagination = ref({
  page: 1,
  limit: 10,
  total: 0,
  pages: 0
})

// Load tickets
const loadTickets = async (page = 1) => {
  loading.value = true
  try {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: pagination.value.limit.toString(),
      ...(filters.value.status && { status: filters.value.status }),
      ...(filters.value.department && { department: filters.value.department }),
      ...(searchQuery.value && { search: searchQuery.value })
    })

    const response = await $fetch(`/api/customer/tickets?${params}`)
    
    tickets.value = response.tickets
    pagination.value = response.pagination

  } catch (error) {
    console.error('Failed to load tickets:', error)
    addNotification({
      type: 'error',
      title: 'Fehler',
      message: 'Tickets konnten nicht geladen werden.'
    })
  } finally {
    loading.value = false
  }
}

// Pagination
const changePage = (page) => {
  if (page >= 1 && page <= pagination.value.pages) {
    loadTickets(page)
  }
}

// Search debouncing
let searchTimeout
const debouncedSearch = () => {
  clearTimeout(searchTimeout)
  searchTimeout = setTimeout(() => {
    loadTickets(1)
  }, 500)
}

// Navigation
const viewTicket = (ticketId) => {
  navigateTo(`/customer/tickets/${ticketId}`)
}

// Utility functions
const formatDate = (date) => {
  return new Date(date).toLocaleDateString('de-DE', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

const getStatusBadgeClass = (status) => {
  const classes = {
    'OFFEN': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
    'IN_BEARBEITUNG': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
    'WARTEN_AUF_KUNDE': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
    'GELOEST': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    'GESCHLOSSEN': 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
  }
  return classes[status] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
}

const getPriorityBadgeClass = (priority) => {
  const classes = {
    'NIEDRIG': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    'NORMAL': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
    'HOCH': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
    'KRITISCH': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
  }
  return classes[priority] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
}

// Load initial data
onMounted(() => {
  loadTickets()
})
</script>
