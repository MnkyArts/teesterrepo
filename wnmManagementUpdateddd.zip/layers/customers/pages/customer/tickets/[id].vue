<template>
    <div>
      <!-- Loading State -->
      <div v-if="loading" class="space-y-6">
        <div class="animate-pulse">
          <div class="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-4"></div>
          <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3 mb-6"></div>
          <div class="bg-white dark:bg-gray-800 rounded-lg p-6">
            <div class="space-y-4">
              <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
              <div class="h-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Ticket Content -->
      <div v-else-if="ticket" class="space-y-6">
        <!-- Header -->
        <div>
          <div class="flex items-center space-x-4 mb-4">
            <NuxtLink
              to="/customer/tickets"
              class="inline-flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
            >
              <Icon name="heroicons:arrow-left" class="w-4 h-4 mr-2" />
              Zurück zu Tickets
            </NuxtLink>
          </div>
          
          <div class="flex items-start justify-between">
            <div class="flex-1">
              <h1 class="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                {{ ticket.title }}
              </h1>
              <div class="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
                <span>Ticket #{{ ticket.id.slice(-8) }}</span>
                <span>•</span>
                <span>{{ $t(`tickets.departments.${ticket.department}`) }}</span>
                <span>•</span>
                <span>{{ formatDate(ticket.createdAt) }}</span>
              </div>
            </div>
            
            <div class="flex items-center space-x-3">
              <span 
                class="inline-flex px-3 py-1 text-sm font-medium rounded-full"
                :class="getPriorityBadgeClass(ticket.priority)"
              >
                {{ $t(`common.priority.${ticket.priority.toLowerCase()}`) }}
              </span>
              <span 
                class="inline-flex px-3 py-1 text-sm font-medium rounded-full"
                :class="getStatusBadgeClass(ticket.status)"
              >
                {{ $t(`tickets.statuses.${ticket.status.toLowerCase()}`) }}
              </span>
            </div>
          </div>
        </div>

        <!-- Ticket Details -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
          <div class="p-6">
            <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {{ $t('tickets.description') }}
            </h2>
            <div class="prose dark:prose-invert max-w-none">
              <p class="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{{ ticket.description }}</p>
            </div>
          </div>
        </div>

        <!-- Resolution (if resolved) -->
        <div v-if="ticket.resolution" class="bg-green-50 dark:bg-green-900/50 rounded-lg border border-green-200 dark:border-green-800">
          <div class="p-6">
            <div class="flex items-center mb-4">
              <Icon name="heroicons:check-circle" class="w-6 h-6 text-green-600 mr-3" />
              <h2 class="text-lg font-semibold text-green-900 dark:text-green-100">
                {{ $t('tickets.resolution') }}
              </h2>
            </div>
            <div class="prose dark:prose-invert max-w-none">
              <p class="text-green-800 dark:text-green-200 whitespace-pre-wrap">{{ ticket.resolution }}</p>
            </div>
          </div>
        </div>

        <!-- Action Buttons -->
        <div v-if="ticket.status !== 'GESCHLOSSEN'" class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
          <div class="p-6">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {{ $t('tickets.actions.title') }}
            </h3>
            <div class="flex flex-col sm:flex-row gap-4">
              <!-- Close Ticket Button (if resolved) -->
              <button
                v-if="ticket.status === 'GELOEST'"
                @click="showCloseConfirm = true"
                class="inline-flex items-center px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white font-medium rounded-lg transition-colors"
              >
                <Icon name="heroicons:x-circle" class="w-4 h-4 mr-2" />
                {{ $t('tickets.actions.closeTicket') }}
              </button>
            </div>
          </div>
        </div>

        <!-- Timeline/Comments -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
          <div class="p-6">
            <TicketComments 
              :ticket-id="ticket.id" 
              :ticket-status="ticket.status"
              @comment-added="onCommentAdded"
            />
          </div>
        </div>
      </div>

      <!-- Error State -->
      <div v-else class="text-center py-12">
        <Icon name="heroicons:exclamation-triangle" class="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-600" />
        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
          Ticket nicht gefunden
        </h3>
        <p class="text-gray-600 dark:text-gray-400 mb-6">
          Das angeforderte Ticket existiert nicht oder Sie haben keine Berechtigung darauf zuzugreifen.
        </p>
        <NuxtLink
          to="/customer/tickets"
          class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
        >
          <Icon name="heroicons:arrow-left" class="w-4 h-4 mr-2" />
          Zurück zu Tickets
        </NuxtLink>
      </div>
    </div>

    <!-- Close Confirmation Modal -->
    <ConfirmDialog
      v-if="showCloseConfirm"
      :title="$t('tickets.actions.closeTicket')"
      :message="$t('tickets.actions.closeConfirmMessage')"
      :confirm-text="$t('tickets.actions.closeTicket')"
      cancel-text="Abbrechen"
      @confirm="closeTicket"
      @cancel="showCloseConfirm = false"
    />
</template>

<script setup>
definePageMeta({
  layout: 'customer',
})

const route = useRoute()
const { addNotification } = useNotifications()

// State
const loading = ref(true)
const ticket = ref(null)
const showCloseConfirm = ref(false)

// Load ticket data
const loadTicket = async () => {
  loading.value = true
  try {
    const response = await $fetch(`/api/customer/tickets/${route.params.id}`)
    ticket.value = response

  } catch (error) {
    console.error('Failed to load ticket:', error)
    ticket.value = null
    
    if (error.statusCode !== 404) {
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: 'Ticket konnte nicht geladen werden.'
      })
    }
  } finally {
    loading.value = false
  }
}

// Handle comment added event
const onCommentAdded = () => {
  // Reload ticket data to get updated status if it changed
  loadTicket()
}

// Close ticket (placeholder for future feature)
const closeTicket = async () => {
  try {
    // This would be implemented in the future
    addNotification({
      type: 'info',
      title: 'Feature in Entwicklung',
      message: 'Ticket-Schließung wird in einer zukünftigen Version verfügbar sein.'
    })
    
    showCloseConfirm.value = false
  } catch (error) {
    addNotification({
      type: 'error',
      title: 'Fehler',
      message: 'Ticket konnte nicht geschlossen werden.'
    })
  }
}

// Utility functions
const formatDate = (date) => {
  return new Date(date).toLocaleDateString('de-DE', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

const getStatusBadgeClass = (status) => {
  const classes = {
    'OFFEN': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
    'IN_BEARBEITUNG': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
    'WARTEN_AUF_KUNDE': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
    'GELOEST': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    'GESCHLOSSEN': 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
  }
  return classes[status] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
}

const getPriorityBadgeClass = (priority) => {
  const classes = {
    'NIEDRIG': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    'NORMAL': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
    'HOCH': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
    'KRITISCH': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
  }
  return classes[priority] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
}

// Load ticket on mount
onMounted(() => {
  loadTicket()
})
</script>
