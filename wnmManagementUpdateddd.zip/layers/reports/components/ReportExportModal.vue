<template>
  <TransitionRoot :show="isOpen" as="template">
    <Dialog as="div" class="relative z-50" @close="$emit('close')">
      <TransitionChild
        as="template"
        enter="ease-out duration-300"
        enter-from="opacity-0"
        enter-to="opacity-100"
        leave="ease-in duration-200"
        leave-from="opacity-100"
        leave-to="opacity-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
      </TransitionChild>

      <div class="fixed inset-0 z-10 overflow-y-auto">
        <div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
          <TransitionChild
            as="template"
            enter="ease-out duration-300"
            enter-from="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            enter-to="opacity-100 translate-y-0 sm:scale-100"
            leave="ease-in duration-200"
            leave-from="opacity-100 translate-y-0 sm:scale-100"
            leave-to="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95">
            <DialogPanel class="relative transform overflow-hidden rounded-lg bg-white dark:bg-gray-800 px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:p-6">
              
              <!-- Header -->
              <div class="mb-6">
                <div class="flex items-center justify-between">
                  <DialogTitle as="h3" class="text-lg font-semibold leading-6 text-gray-900 dark:text-white">
                    Bericht exportieren
                  </DialogTitle>
                  <button
                    type="button"
                    class="rounded-md text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    @click="$emit('close')">
                    <XMarkIcon class="h-6 w-6" />
                  </button>
                </div>
              </div>

              <form @submit.prevent="handleExport" class="space-y-6">
                <!-- Export Format -->
                <div>
                  <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Format
                  </label>
                  <div class="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      @click="selectedFormat = 'pdf'"
                      :class="[
                        'relative rounded-lg p-4 text-left transition-all duration-200 border-2',
                        selectedFormat === 'pdf'
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                          : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                      ]">
                      <div class="flex items-center">
                        <DocumentTextIcon class="h-6 w-6 text-red-600 mr-3" />
                        <div>
                          <h4 class="text-sm font-medium text-gray-900 dark:text-white">PDF</h4>
                          <p class="text-xs text-gray-500 dark:text-gray-400">Druckfertig</p>
                        </div>
                      </div>
                    </button>
                    <button
                      type="button"
                      @click="selectedFormat = 'excel'"
                      :class="[
                        'relative rounded-lg p-4 text-left transition-all duration-200 border-2',
                        selectedFormat === 'excel'
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                          : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                      ]">
                      <div class="flex items-center">
                        <TableCellsIcon class="h-6 w-6 text-green-600 mr-3" />
                        <div>
                          <h4 class="text-sm font-medium text-gray-900 dark:text-white">Excel</h4>
                          <p class="text-xs text-gray-500 dark:text-gray-400">Für Analysen</p>
                        </div>
                      </div>
                    </button>
                  </div>
                </div>

                <!-- Include Options -->
                <div>
                  <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                    Inhalte einschließen
                  </label>
                  <div class="space-y-2">
                    <label class="flex items-center">
                      <input
                        v-model="options.includeCharts"
                        type="checkbox"
                        class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                      <span class="ml-2 text-sm text-gray-700 dark:text-gray-300">
                        Diagramme und Grafiken
                      </span>
                    </label>
                    <label class="flex items-center">
                      <input
                        v-model="options.includeRawData"
                        type="checkbox"
                        class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                      <span class="ml-2 text-sm text-gray-700 dark:text-gray-300">
                        Rohdaten-Tabellen
                      </span>
                    </label>
                    <label class="flex items-center">
                      <input
                        v-model="options.includeSummary"
                        type="checkbox"
                        class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                      <span class="ml-2 text-sm text-gray-700 dark:text-gray-300">
                        Zusammenfassung
                      </span>
                    </label>
                  </div>
                </div>

                <!-- Date Range Display -->
                <div class="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                  <h4 class="text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Berichtszeitraum
                  </h4>
                  <p class="text-sm text-gray-600 dark:text-gray-400">
                    {{ formatDateRange() }}
                  </p>
                  <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    {{ getReportTypeLabel() }}
                  </p>
                </div>

                <!-- Actions -->
                <div class="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200 dark:border-gray-700">
                  <button
                    type="button"
                    @click="$emit('close')"
                    class="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    Abbrechen
                  </button>
                  <button
                    type="submit"
                    :disabled="loading"
                    class="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed">
                    <span v-if="loading" class="flex items-center">
                      <ArrowPathIcon class="animate-spin -ml-1 mr-2 h-4 w-4" />
                      Exportiere...
                    </span>
                    <span v-else class="flex items-center">
                      <DocumentArrowDownIcon class="-ml-1 mr-2 h-4 w-4" />
                      Exportieren
                    </span>
                  </button>
                </div>
              </form>
            </DialogPanel>
          </TransitionChild>
        </div>
      </div>
    </Dialog>
  </TransitionRoot>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { Dialog, DialogPanel, DialogTitle, TransitionChild, TransitionRoot } from '@headlessui/vue'
import {
  XMarkIcon,
  DocumentTextIcon,
  TableCellsIcon,
  DocumentArrowDownIcon,
  ArrowPathIcon
} from '@heroicons/vue/24/outline'

interface Props {
  isOpen: boolean
  reportType: string
  dateRange: {
    start: string
    end: string
  }
  reportData: any
}

const props = defineProps<Props>()

const emit = defineEmits<{
  close: []
  export: [format: string, options: any]
}>()

const loading = ref(false)
const selectedFormat = ref('pdf')

const options = reactive({
  includeCharts: true,
  includeRawData: true,
  includeSummary: true
})

const handleExport = async () => {
  loading.value = true
  try {
    emit('export', selectedFormat.value, { ...options })
  } finally {
    loading.value = false
  }
}

const formatDateRange = (): string => {
  const start = new Date(props.dateRange.start).toLocaleDateString('de-DE')
  const end = new Date(props.dateRange.end).toLocaleDateString('de-DE')
  return `${start} - ${end}`
}

const getReportTypeLabel = (): string => {
  const labels = {
    time: 'Zeiterfassungsbericht',
    projects: 'Projektbericht',
    team: 'Team-Performance-Bericht',
    financial: 'Finanzbericht'
  }
  return labels[props.reportType as keyof typeof labels] || 'Bericht'
}
</script>
