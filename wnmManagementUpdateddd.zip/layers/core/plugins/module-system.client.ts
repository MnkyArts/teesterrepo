export default defineNuxtPlugin(() => {
  // Import modules configuration
  const { validateModuleDependencies, getEnabledModules } = useModules()

  // Validate module dependencies during app startup
  const dependencyErrors = validateModuleDependencies()
  if (dependencyErrors.length > 0) {
    console.error('Module dependency validation failed:', dependencyErrors)
    // You might want to show a user-friendly error or fallback
  }

  // Log enabled modules for debugging
  if (process.dev) {
    const enabledModules = getEnabledModules()
    console.log('Enabled modules:', enabledModules)
  }

  return {
    provide: {
      moduleSystem: {
        validateDependencies: validateModuleDependencies,
        getEnabledModules
      }
    }
  }
})
