<template>
  <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50 w-full">
    <div class="flex items-center justify-between h-16 px-4 sm:px-6 lg:px-8">
      <!-- Logo und Navigation Toggle -->
      <div class="flex items-center">
        <button
          v-if="showSidebarToggle"
          @click="toggleSidebar"
          class="p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 lg:hidden"
        >
          <Bars3Icon class="h-6 w-6" />
        </button>
        
        <NuxtLink to="/" class="flex items-center ml-2 lg:ml-0">
          <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <span class="text-white font-bold text-sm">W</span>
          </div>
          <span class="ml-3 text-xl font-semibold text-gray-900 dark:text-white hidden sm:block">
            wenoma
          </span>
        </NuxtLink>
      </div>

      <!-- Zentrale Suche -->
      <div class="flex-1 max-w-lg mx-8 hidden md:block">
        <div class="relative">
          <MagnifyingGlassIcon class="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            :placeholder="$t('common.search')"
            class="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
            v-model="searchQuery"
            @keyup.enter="performSearch"
          />
        </div>
      </div>

      <!-- Header Actions -->
      <div class="flex items-center space-x-4">
        <!-- Benachrichtigungen -->
        <button
          class="p-2 text-gray-400 hover:text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full relative"
          @click="showNotifications = !showNotifications"
        >
          <BellIcon class="h-6 w-6" />
          <span
            v-if="unreadNotifications > 0"
            class="absolute -top-1 -right-1 h-4 w-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center"
          >
            {{ unreadNotifications > 9 ? '9+' : unreadNotifications }}
          </span>
        </button>

        <!-- Theme Toggle -->
        <ClientOnly>
          <ColorModeToggle />
        </ClientOnly>

        <!-- User Menu -->
        <UserMenu v-if="isLoggedIn" />
        
        <!-- Login Button für nicht authentifizierte Benutzer -->
        <NuxtLink
          v-else
          to="/auth/login"
          class="btn-primary text-sm"
        >
          {{ $t('auth.login') }}
        </NuxtLink>
      </div>
    </div>

    <!-- Mobile Search -->
    <div v-if="showMobileSearch" class="md:hidden border-t border-gray-200 dark:border-gray-700 p-4">
      <div class="relative">
        <MagnifyingGlassIcon class="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
        <input
          type="text"
          :placeholder="$t('common.search')"
          class="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
          v-model="searchQuery"
          @keyup.enter="performSearch"
        />
      </div>
    </div>

    <!-- Notifications Dropdown -->
    <NotificationsDropdown 
      v-if="showNotifications"
      @close="showNotifications = false"
    />
  </header>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { 
  Bars3Icon, 
  MagnifyingGlassIcon, 
  BellIcon 
} from '@heroicons/vue/24/outline'

// Reactive state
const searchQuery = ref('')
const showNotifications = ref(false)
const showMobileSearch = ref(false)

// Stores
const authStore = useAuthStore()
const { isLoggedIn } = storeToRefs(authStore)

const uiStore = useUIStore()
const { toggleSidebar } = uiStore

const notificationsStore = useNotificationsStore()
const { notifications, unreadCount: unreadNotifications } = storeToRefs(notificationsStore)

// Computed properties
const showSidebarToggle = computed(() => isLoggedIn.value)

// Methods
const performSearch = () => {
  if (searchQuery.value.trim()) {
    navigateTo(`/search?q=${encodeURIComponent(searchQuery.value.trim())}`)
  }
}

// Keyboard shortcuts
onMounted(() => {
  const handleKeydown = (event: KeyboardEvent) => {
    // Cmd/Ctrl + K für Suche
    if ((event.metaKey || event.ctrlKey) && event.key === 'k') {
      event.preventDefault()
      // Focus search input
      const searchInput = document.querySelector('input[type="text"]') as HTMLInputElement
      if (searchInput) {
        searchInput.focus()
      }
    }
  }
  
  document.addEventListener('keydown', handleKeydown)
  
  onUnmounted(() => {
    document.removeEventListener('keydown', handleKeydown)
  })
})
</script>
