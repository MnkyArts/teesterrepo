<template>
  <aside class="fixed left-0 top-16 h-[calc(100vh-4rem)] w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 overflow-y-auto transition-transform duration-300 ease-in-out z-40"
         :class="{ '-translate-x-full': !uiStore.sidebarOpen, 'translate-x-0': uiStore.sidebarOpen }"
  >
    <nav class="p-4">
      <!-- Hauptnavigation -->
      <div class="space-y-2">
        <SidebarItem
          v-for="item in filteredMainNavigation"
          :key="item.name"
          :item="item"
        />
      </div>

      <!-- Trennlinie -->
      <div class="my-6 border-t border-gray-200 dark:border-gray-700"></div>

      <!-- Projektnavigation -->
      <div v-if="projectsStore.userProjects.length > 0 && isModuleEnabled('projects')">
        <h3 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">
          {{ $t('navigation.projects') }}
        </h3>
        <div class="space-y-1">
          <SidebarProjectItem
            v-for="project in projectsStore.userProjects"
            :key="project.id"
            :project="project"
          />
        </div>
      </div>

      <!-- Administration (nur für Admins und wenn Admin-Modul aktiviert ist) -->
      <div v-if="permissions.isAdmin() && isModuleEnabled('admin')" class="mt-6">
        <div class="pt-6">
          <h3 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">
            {{ $t('navigation.administration') }}
          </h3>
          <div class="space-y-2">
            <SidebarItem
              v-for="item in filteredAdminNavigation"
              :key="item.name"
              :item="item"
            />
          </div>
        </div>
      </div>
    </nav>
  </aside>

  <!-- Mobile Overlay -->
  <div
    v-if="uiStore.sidebarOpen && uiStore.isMobile"
    class="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
    @click="uiStore.closeSidebar"
  ></div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import {
  HomeIcon,
  FolderIcon,
  ClipboardDocumentListIcon,
  ClockIcon,
  UsersIcon,
  TicketIcon,
  ChartBarIcon,
  CogIcon,
  UserGroupIcon,
  DocumentTextIcon,
  ShieldCheckIcon,
  Squares2X2Icon
} from '@heroicons/vue/24/outline'
import { usePermissions } from '~/layers/auth/composables/usePermissions'

// Stores
const uiStore = useUIStore()
const projectsStore = useProjectsStore()

// Composables
const { isModuleEnabled } = useModules()
const permissions = usePermissions()

// Navigation Items
const mainNavigation = computed(() => [
  {
    name: 'dashboard',
    label: 'Dashboard',
    icon: HomeIcon,
    href: '/',
    active: true,
    module: 'core'
  },
  {
    name: 'projects',
    label: 'Projekte',
    icon: FolderIcon,
    href: '/projects',
    badge: projectsStore.userProjects.length || undefined,
    module: 'projects'
  },
  {
    name: 'tasks',
    label: 'Aufgaben',
    icon: ClipboardDocumentListIcon,
    href: '/tasks',
    badge: 5, // TODO: Get from API
    module: 'tasks'
  },
  {
    name: 'timeTracking',
    label: 'Zeiterfassung',
    icon: ClockIcon,
    href: '/time-tracking',
    module: 'timetracking'
  },
  {
    name: 'team',
    label: 'Team',
    icon: UsersIcon,
    href: '/team',
    permissions: ['users.view', 'users.manage-roles'],
    module: 'team'
  },
  {
    name: 'customers',
    label: 'Kunden',
    icon: UserGroupIcon,
    href: '/customers',
    permissions: ['customers.view', 'customers.manage'],
    module: 'customers'
  },
  {
    name: 'tickets',
    label: 'Tickets',
    icon: TicketIcon,
    href: '/tickets',
    permissions: ['tickets.view', 'tickets.manage'],
    module: 'tickets'
  },
  {
    name: 'reports',
    label: 'Berichte',
    icon: ChartBarIcon,
    href: '/reports',
    permissions: ['reports.view', 'reports.generate'],
    module: 'reports'
  }
])

const adminNavigation = computed(() => [
  {
    name: 'users',
    label: 'Benutzerverwaltung',
    icon: UserGroupIcon,
    href: '/admin/users',
    permissions: ['users.view', 'admin.users'],
    module: 'admin'
  },
  {
    name: 'system',
    label: 'Systemeinstellungen',
    icon: CogIcon,
    href: '/admin/system',
    permissions: ['system.manage', 'admin.system'],
    module: 'admin'
  },
  {
    name: 'audit',
    label: 'Audit-Protokolle',
    icon: DocumentTextIcon,
    href: '/admin/audit',
    permissions: ['audit.view', 'admin.audit'],
    module: 'admin'
  },
  {
    name: 'security',
    label: 'Sicherheit',
    icon: ShieldCheckIcon,
    href: '/admin/security',
    permissions: ['security.manage', 'admin.security'],
    module: 'admin'
  }
])

// Filter main navigation items based on user permissions and module status
const filteredMainNavigation = computed(() => {
  return mainNavigation.value.filter(item => {
    // Check if module is enabled
    if (item.module && !isModuleEnabled(item.module)) {
      return false
    }
    
    // Check user permissions (if any are specified)
    if (!item.permissions || item.permissions.length === 0) {
      return true
    }
    
    // User needs at least one of the specified permissions
    return permissions.hasPermissions(item.permissions)
  })
})

// Filter admin navigation items based on user permissions and module status
const filteredAdminNavigation = computed(() => {
  return adminNavigation.value.filter(item => {
    // Check if module is enabled
    if (item.module && !isModuleEnabled(item.module)) {
      return false
    }
    
    // Check user permissions (if any are specified)
    if (!item.permissions || item.permissions.length === 0) {
      return true
    }
    
    // User needs at least one of the specified permissions
    return permissions.hasPermissions(item.permissions)
  })
})
</script>
