<template>
  <Menu as="div" class="relative">
    <MenuButton class="flex items-center text-gray-400 hover:text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full p-2 transition-colors duration-200">
      <img
        v-if="authStore.user?.image"
        :src="authStore.user.image"
        :alt="authStore.fullName"
        class="w-8 h-8 rounded-full"
      />
      <div
        v-else
        class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center"
      >
        <span class="text-white text-sm font-medium">
          {{ authStore.initials }}
        </span>
      </div>
    </MenuButton>

    <transition
      enter-active-class="transition ease-out duration-100"
      enter-from-class="transform opacity-0 scale-95"
      enter-to-class="transform opacity-100 scale-100"
      leave-active-class="transition ease-in duration-75"
      leave-from-class="transform opacity-100 scale-100"
      leave-to-class="transform opacity-0 scale-95"
    >
      <MenuItems class="absolute right-0 mt-2 w-56 origin-top-right bg-white dark:bg-gray-800 rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none z-50">
        <div class="p-4 border-b border-gray-200 dark:border-gray-700">
          <div class="text-sm font-medium text-gray-900 dark:text-white">
            {{ authStore.fullName }}
          </div>
          <div class="text-sm text-gray-500 dark:text-gray-400">
            {{ authStore.user?.email }}
          </div>
          <div class="text-xs text-blue-600 dark:text-blue-400 mt-1 capitalize">
            {{ $t(`roles.${authStore.user?.role?.toLowerCase()}`) }}
          </div>
        </div>

        <div class="py-1">
          <MenuItem v-slot="{ active }">
            <NuxtLink
              to="/profile"
              :class="[
                active ? 'bg-gray-100 dark:bg-gray-700' : '',
                'block px-4 py-2 text-sm text-gray-700 dark:text-gray-300'
              ]"
            >
              <div class="flex items-center">
                <UserIcon class="mr-3 h-4 w-4" />
                {{ $t('navigation.profile') }}
              </div>
            </NuxtLink>
          </MenuItem>

          <MenuItem v-slot="{ active }">
            <NuxtLink
              to="/settings"
              :class="[
                active ? 'bg-gray-100 dark:bg-gray-700' : '',
                'block px-4 py-2 text-sm text-gray-700 dark:text-gray-300'
              ]"
            >
              <div class="flex items-center">
                <CogIcon class="mr-3 h-4 w-4" />
                {{ $t('navigation.settings') }}
              </div>
            </NuxtLink>
          </MenuItem>

          <div class="border-t border-gray-200 dark:border-gray-700 my-1"></div>

          <MenuItem v-slot="{ active }">
            <button
              @click="handleLogout"
              :class="[
                active ? 'bg-gray-100 dark:bg-gray-700' : '',
                'block w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300'
              ]"
            >
              <div class="flex items-center">
                <ArrowRightOnRectangleIcon class="mr-3 h-4 w-4" />
                {{ $t('auth.logout') }}
              </div>
            </button>
          </MenuItem>
        </div>
      </MenuItems>
    </transition>
  </Menu>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { Menu, MenuButton, MenuItems, MenuItem } from '@headlessui/vue'
import { 
  UserIcon, 
  CogIcon, 
  ArrowRightOnRectangleIcon 
} from '@heroicons/vue/24/outline'

// Stores
const authStore = useAuthStore()

// Methods
const handleLogout = async () => {
  await authStore.logout()
}
</script>
