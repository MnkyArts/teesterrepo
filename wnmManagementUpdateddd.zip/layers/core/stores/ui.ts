import { defineStore } from 'pinia'
import { useWindowSize } from '@vueuse/core'

export const useUIStore = defineStore('ui', () => {
  // Detect mobile breakpoint
  const { width } = useWindowSize()
  const isMobile = computed(() => width.value < 1024) // lg breakpoint

  // Sidebar state
  const sidebarOpen = ref(true)
  
  // Modal stack state
  const modalStack = ref<string[]>([])
  
  // Global loading state
  const globalLoading = ref(false)
  const loadingMessage = ref('')

  // Computed
  const hasOpenModals = computed(() => modalStack.value.length > 0)
  const topModal = computed(() => modalStack.value[modalStack.value.length - 1] || null)

  // Auto-close sidebar on mobile
  watch(isMobile, (newIsMobile) => {
    if (newIsMobile) {
      sidebarOpen.value = false
    } else {
      sidebarOpen.value = true
    }
  }, { immediate: true })

  // Sidebar actions
  const toggleSidebar = () => {
    sidebarOpen.value = !sidebarOpen.value
  }

  const openSidebar = () => {
    sidebarOpen.value = true
  }

  const closeSidebar = () => {
    sidebarOpen.value = false
  }

  // Modal stack actions
  const openModal = (modalId: string) => {
    if (!modalStack.value.includes(modalId)) {
      modalStack.value.push(modalId)
    }
    updateBodyOverflow()
  }

  const closeModal = (modalId: string) => {
    const index = modalStack.value.indexOf(modalId)
    if (index > -1) {
      modalStack.value.splice(index, 1)
    }
    updateBodyOverflow()
  }

  const closeTopModal = () => {
    if (modalStack.value.length > 0) {
      const topModal = modalStack.value.pop()
      updateBodyOverflow()
      return topModal
    }
    return null
  }

  const closeAllModals = () => {
    modalStack.value = []
    updateBodyOverflow()
  }

  const getModalZIndex = (modalId: string) => {
    const index = modalStack.value.indexOf(modalId)
    return index >= 0 ? 50 + index * 10 : 50
  }

  const isTopModal = (modalId: string) => {
    return modalStack.value[modalStack.value.length - 1] === modalId
  }

  const updateBodyOverflow = () => {
    if (process.client) {
      document.body.style.overflow = modalStack.value.length > 0 ? 'hidden' : ''
    }
  }

  // Global loading actions
  const setGlobalLoading = (loading: boolean, message = '') => {
    globalLoading.value = loading
    loadingMessage.value = message
  }

  const startGlobalLoading = (message = 'Lädt...') => {
    setGlobalLoading(true, message)
  }

  const stopGlobalLoading = () => {
    setGlobalLoading(false, '')
  }

  // Handle ESC key for modals
  if (process.client) {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && modalStack.value.length > 0) {
        closeTopModal()
      }
    }

    onMounted(() => {
      document.addEventListener('keydown', handleEscape)
    })

    onUnmounted(() => {
      document.removeEventListener('keydown', handleEscape)
      closeAllModals()
    })
  }

  return {
    // Sidebar state
    sidebarOpen: readonly(sidebarOpen),
    isMobile,
    
    // Modal state
    modalStack: readonly(modalStack),
    hasOpenModals,
    topModal,
    
    // Loading state
    globalLoading: readonly(globalLoading),
    loadingMessage: readonly(loadingMessage),
    
    // Sidebar actions
    toggleSidebar,
    openSidebar,
    closeSidebar,
    
    // Modal actions
    openModal,
    closeModal,
    closeTopModal,
    closeAllModals,
    getModalZIndex,
    isTopModal,
    
    // Loading actions
    setGlobalLoading,
    startGlobalLoading,
    stopGlobalLoading
  }
})
