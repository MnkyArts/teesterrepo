# wnmManagement Deployment Guide

This guide explains how to build and deploy the wnmManagement Nuxt3 application using Docker and GitLab CI/CD.

## 🚀 Quick Start

### 1. Manual Build and Push

```bash
# Login to GitLab Container Registry
docker login registry.gitlab.wnm.de

# Build and push using the build script
npm run build:docker

# Or specify environment and version
./scripts/build-and-deploy.sh production v1.0.0
```

### 2. Using GitLab CI/CD

The application automatically builds and deploys when you push to specific branches:

- **main branch**: Builds production image with tag `latest`
- **develop branch**: Builds staging image with tag `develop`
- **feature branches**: Builds development images with branch name as tag

## 📦 Docker Images

### Available Tags

- `registry.gitlab.wnm.de/ep/wenoma:latest` - Latest production build
- `registry.gitlab.wnm.de/ep/wenoma:stable` - Stable production release
- `registry.gitlab.wnm.de/ep/wenoma:develop` - Latest staging build
- `registry.gitlab.wnm.de/ep/wenoma:COMMIT_SHA` - Specific commit build

### Image Features

- **Multi-stage build** for optimized production image
- **Non-root user** for security
- **Health checks** built-in
- **Alpine Linux** base for minimal size
- **Prisma client** pre-generated
- **Upload directory** with proper permissions

## 🔧 Environment Setup

### 1. Create Environment File

```bash
# Copy the template
cp env.production.template .env.production

# Edit with your actual values
nano .env.production
```

### 2. Required Environment Variables

```env
# Application
NODE_ENV=production
APP_URL=https://your-domain.com
BETTER_AUTH_URL=https://your-domain.com

# Database
DATABASE_URL=postgresql://username:password@postgres:5432/wnm_management
POSTGRES_DB=wnm_management
POSTGRES_USER=wnm_user
POSTGRES_PASSWORD=your_secure_password

# Redis
REDIS_URL=redis://:password@redis:6379
REDIS_PASSWORD=your_redis_password

# Security
JWT_SECRET=your_jwt_secret_at_least_32_characters_long
SESSION_SECRET=your_session_secret

# Email
SMTP_HOST=smtp.your-provider.com
SMTP_PORT=587
SMTP_USER=your_email@domain.com
SMTP_PASS=your_email_password
```

## 🚀 Deployment Options

### Option 1: Docker Compose (Recommended)

```bash
# Production deployment
docker-compose -f docker-compose.prod.yml up -d

# With custom environment file
docker-compose -f docker-compose.prod.yml --env-file .env.production up -d

# View logs
docker-compose -f docker-compose.prod.yml logs -f

# Stop services
docker-compose -f docker-compose.prod.yml down
```

### Option 2: Direct Docker Run

```bash
# Run the application
docker run -d \
  --name wnm-management \
  -p 3000:3000 \
  --env-file .env.production \
  registry.gitlab.wnm.de/ep/wenoma:latest

# Run with PostgreSQL and Redis
docker network create wnm_network

docker run -d \
  --name wnm-postgres \
  --network wnm_network \
  -e POSTGRES_DB=wnm_management \
  -e POSTGRES_USER=wnm_user \
  -e POSTGRES_PASSWORD=your_password \
  -v postgres_data:/var/lib/postgresql/data \
  postgres:15-alpine

docker run -d \
  --name wnm-redis \
  --network wnm_network \
  -v redis_data:/data \
  redis:7-alpine

docker run -d \
  --name wnm-management \
  --network wnm_network \
  -p 3000:3000 \
  --env-file .env.production \
  registry.gitlab.wnm.de/ep/wenoma:latest
```

### Option 3: Kubernetes (Advanced)

```yaml
# Example Kubernetes deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: wnm-management
spec:
  replicas: 3
  selector:
    matchLabels:
      app: wnm-management
  template:
    metadata:
      labels:
        app: wnm-management
    spec:
      containers:
      - name: wnm-management
        image: registry.gitlab.wnm.de/ep/wenoma:latest
        ports:
        - containerPort: 3000
        env:
        - name: NODE_ENV
          value: "production"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: wnm-secrets
              key: database-url
        # ... other environment variables
```

## 🔄 Database Migrations

### Automatic Migrations (Recommended)

The Docker image includes Prisma and can run migrations automatically:

```bash
# Run migrations in production
docker run --rm \
  --network wnm_network \
  --env-file .env.production \
  registry.gitlab.wnm.de/ep/wenoma:latest \
  npx prisma migrate deploy
```

### Manual Migrations

```bash
# Connect to running container
docker exec -it wnm-management sh

# Run migrations
npx prisma migrate deploy

# Generate Prisma client (if needed)
npx prisma generate

# Seed database (if needed)
npm run db:seed
```

## 📊 Monitoring and Health Checks

### Health Check Endpoint

The application provides a health check endpoint at `/api/health`:

```bash
# Check application health
curl http://localhost:3000/api/health

# Expected response
{
  "status": "healthy",
  "timestamp": "2024-01-01T12:00:00.000Z",
  "uptime": 3600,
  "environment": "production",
  "version": "1.0.0",
  "database": "connected",
  "redis": "connected"
}
```

### Docker Health Checks

The Docker image includes built-in health checks:

```bash
# Check container health
docker ps

# View health check logs
docker inspect wnm-management | grep -A 10 Health
```

### Monitoring with Prometheus and Grafana

```bash
# Start monitoring stack
docker-compose -f docker-compose.prod.yml --profile monitoring up -d

# Access Grafana
open http://localhost:3001
# Username: admin
# Password: (set in GRAFANA_PASSWORD env var)

# Access Prometheus
open http://localhost:9090
```

## 🔐 Security Considerations

### 1. Environment Variables

- Never commit `.env` files to version control
- Use Docker secrets or Kubernetes secrets for sensitive data
- Rotate secrets regularly

### 2. Network Security

- Use internal networks for database connections
- Don't expose database ports to host in production
- Use SSL/TLS for all external connections

### 3. Container Security

- Images run as non-root user
- Minimal Alpine Linux base
- Regular security updates

## 🛠️ Troubleshooting

### Common Issues

1. **Container won't start**
   ```bash
   # Check logs
   docker logs wnm-management
   
   # Check health
   docker exec wnm-management wget -O- http://localhost:3000/api/health
   ```

2. **Database connection failed**
   ```bash
   # Check database container
   docker logs wnm-postgres
   
   # Test connection
   docker exec wnm-postgres pg_isready -U wnm_user -d wnm_management
   ```

3. **Build failures**
   ```bash
   # Check build logs
   docker build --no-cache -t wnm-management .
   
   # Check disk space
   docker system df
   
   # Clean up
   docker system prune -a
   ```

### Performance Optimization

1. **Database Performance**
   - Monitor connection pool usage
   - Optimize Prisma queries
   - Use database indexes

2. **Application Performance**
   - Monitor memory usage
   - Use Redis for caching
   - Optimize bundle size

3. **Container Performance**
   - Set appropriate resource limits
   - Use multi-stage builds
   - Optimize layer caching

## 📋 Deployment Checklist

- [ ] Environment variables configured
- [ ] Database migrations applied
- [ ] SSL certificates installed
- [ ] Health checks working
- [ ] Monitoring configured
- [ ] Backup strategy implemented
- [ ] Security scanning completed
- [ ] Load testing performed
- [ ] Documentation updated
- [ ] Team notified

## 🔄 Rollback Strategy

### Quick Rollback

```bash
# Rollback to previous version
docker-compose -f docker-compose.prod.yml down
docker pull registry.gitlab.wnm.de/ep/wenoma:previous-tag
docker-compose -f docker-compose.prod.yml up -d
```

### Database Rollback

```bash
# Rollback database migrations (if needed)
docker exec wnm-management npx prisma migrate resolve --rolled-back MIGRATION_ID
```

## 📞 Support

For deployment issues:

1. Check the [troubleshooting section](#troubleshooting)
2. Review container logs
3. Check health endpoints
4. Contact the development team

## 🔗 Useful Commands

```bash
# View running containers
docker ps

# View all images
docker images

# Clean up unused resources
docker system prune -a

# View container resource usage
docker stats

# Export container filesystem
docker export wnm-management > wnm-management.tar

# Import container filesystem
docker import wnm-management.tar
``` 