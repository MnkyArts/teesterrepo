// https://nuxt.com/docs/api/configuration/nuxt-config
import { getEnabledLayers } from './modules.config'

export default defineNuxtConfig({
  compatibilityDate: '2025-05-15',
  devtools: { enabled: true },

  // Dynamic layer loading based on module configuration
  extends: getEnabledLayers(),
  
  modules: [
    '@pinia/nuxt',
    '@nuxt/eslint',
    '@nuxt/image',
    '@nuxt/icon',
    '@nuxtjs/tailwindcss',
    '@vueuse/nuxt',
    '@nuxtjs/i18n',
    '@nuxtjs/color-mode'
  ],

  // Deutsche Lokalisierung
  i18n: {
    locales: [
      {
        code: 'de',
        iso: 'de-DE',
        name: 'Deutsch',
        file: 'de.json'
      }
    ],
    defaultLocale: 'de',
    langDir: 'locales/',
    strategy: 'no_prefix',
    lazy: false,
    bundle: {
      optimizeTranslationDirective: false
    }
  },

  // TailwindCSS Konfiguration
  tailwindcss: {
    exposeConfig: true,
    viewer: true
  },

  // Color Mode für Dark/Light Theme
  colorMode: {
    preference: 'system',
    fallback: 'light',
    hid: 'nuxt-color-mode-script',
    globalName: '__NUXT_COLOR_MODE__',
    componentName: 'ColorScheme',
    classPrefix: '',
    classSuffix: '',
    storageKey: 'nuxt-color-mode'
  },

  // CSS Framework
  css: ['~/assets/css/main.css'],

  // TypeScript Konfiguration
  typescript: {
    strict: true,
    typeCheck: true
  },

  // Runtime Config für Umgebungsvariablen
  runtimeConfig: {
    // Server-only keys
    jwtSecret: process.env.JWT_SECRET,
    databaseUrl: process.env.DATABASE_URL,
    redisUrl: process.env.REDIS_URL,
    smtpHost: process.env.SMTP_HOST,
    smtpPort: process.env.SMTP_PORT,
    smtpUser: process.env.SMTP_USER,
    smtpPass: process.env.SMTP_PASS,
    
    // Client-exposed keys
    public: {
      appName: 'wnmManagement',
      appVersion: '1.0.0',
      appUrl: process.env.APP_URL || 'http://localhost:3000',
      betterAuthUrl: process.env.BETTER_AUTH_URL || process.env.APP_URL || 'http://localhost:3000'
    }
  },

  // Server-side rendering mit optimierter Auth-Behandlung
  ssr: true,
  
  // Optimierungen für bessere Performance
  experimental: {
    payloadExtraction: false // Reduziert Initial-Load-Zeit
  },

  // API Konfiguration
  nitro: {
    experimental: {
      wasm: true
    }
  },

  // Route Rules für optimierte Auth-Performance
  routeRules: {
    // Dashboard und geschützte Routen: SPA-Modus für bessere Auth-Performance
    '/': { ssr: false, prerender: false },
    '/projects/**': { ssr: false, prerender: false },
    '/tasks/**': { ssr: false, prerender: false },
    '/team/**': { ssr: false, prerender: false },
    '/tickets/**': { ssr: false, prerender: false },
    '/time-tracking': { ssr: false, prerender: false },
    '/admin/**': { ssr: false, prerender: false },
    
    // Auth-Seiten: Optimiert für schnellen Login
    '/auth/**': { ssr: false, prerender: false },
    
    // Customer-Bereich: SPA für bessere Performance
    '/customer/**': { ssr: false, prerender: false }
  }
})