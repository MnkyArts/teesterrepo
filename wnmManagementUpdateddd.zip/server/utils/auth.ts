import { auth } from '~/lib/auth'
import type { EventHandler } from 'h3'
import { PrismaClient } from '@prisma/client'
import type { Session } from '~/lib/auth'

/**
 * Server-side Authentication and Authorization Utilities
 * 
 * Usage Examples:
 * 
 * 1. Basic authentication (any logged-in user):
 *    const user = await requireAuth()(event)
 * 
 * 2. Role-based access:
 *    const user = await requireAuth("admin")(event)
 *    const user = await requireAuth({ role: "admin" })(event)
 *    const user = await requireAuth({ roles: ["admin", "moderator"] })(event)
 * 
 * 3. Permission-based access:
 *    const user = await requireAuth({ permission: "users.create" })(event)
 *    const user = await requireAuth({ permissions: ["users.create", "users.edit"] })(event)
 *    const user = await requireAuth({ permissions: ["users.create", "users.edit"], requireAll: true })(event)
 * 
 * 4. Combined role and permission checks:
 *    const user = await requireAuth({ role: "admin", permission: "users.delete" })(event)
 * 
 * 5. Using convenience functions:
 *    const user = await requirePermission("users.create")(event)
 *    const user = await requireRole("admin")(event)
 *    const user = await requireAnyPermission(["users.create", "users.edit"])(event)
 * 
 * 6. Manual session checks:
 *    const session = getCurrentSession(event)
 *    if (hasPermission(session, "users.create")) { ... }
 *    if (hasRole(session, "admin")) { ... }
 */

const prisma = new PrismaClient()

/**
 * Get user with customer relation included
 */
export async function getUserWithCustomer(userId: string) {
  return await prisma.user.findUnique({
    where: { id: userId },
    include: {
      customer: {
        select: {
          id: true,
          companyName: true,
          email: true,
          contactName: true,
          phone: true,
          isActive: true
        }
      }
    }
  })
}

/**
 * Check if user has specific permission (from session)
 */
export function hasPermission(session: Session, permission: string): boolean {
  const userPermissions = (session?.user as any)?.userpermissions || []
  return userPermissions.includes(permission)
}

/**
 * Check if user has any of the specified permissions (from session)
 */
export function hasAnyPermission(session: Session, permissions: string[]): boolean {
  const userPermissions = (session?.user as any)?.userpermissions || []
  return permissions.some(permission => userPermissions.includes(permission))
}

/**
 * Check if user has all of the specified permissions (from session)
 */
export function hasAllPermissions(session: Session, permissions: string[]): boolean {
  const userPermissions = (session?.user as any)?.userpermissions || []
  return permissions.every(permission => userPermissions.includes(permission))
}

/**
 * Check if user has specific role (from session)
 */
export function hasRole(session: Session, roleName: string): boolean {
  const userRoles = (session?.user as any)?.userroles || []
  return userRoles.some((role: { name: string }) => role.name === roleName)
}

/**
 * Check if user has any of the specified roles (from session)
 */
export function hasAnyRole(session: Session, roleNames: string[]): boolean {
  const userRoles = (session?.user as any)?.userroles || []
  return roleNames.some(roleName => 
    userRoles.some((role: { name: string }) => role.name === roleName)
  )
}

/**
 * Middleware zur Better Auth Authentifizierung mit Permission/Role-Unterstützung
 */
export function requireAuth(requiredRole?: string): EventHandler
export function requireAuth(options?: { 
  role?: string; 
  roles?: string[];
  permission?: string; 
  permissions?: string[];
  requireAll?: boolean; // for permissions - true = ALL, false = ANY (default)
}): EventHandler
export function requireAuth(roleOrOptions?: string | { 
  role?: string; 
  roles?: string[];
  permission?: string; 
  permissions?: string[];
  requireAll?: boolean;
}): EventHandler {
  return async (event) => {
    try {
      const session = await auth.api.getSession({
        headers: event.headers || {}
      })

      if (!session?.user) {
        throw createError({
          statusCode: 401,
          statusMessage: 'Authentifizierung erforderlich'
        })
      }

      // Get user with customer relationship if user is a customer
      const userWithCustomer = await getUserWithCustomer(session.user.id)

      if (!userWithCustomer) {
        throw createError({
          statusCode: 401,
          statusMessage: 'Benutzer nicht gefunden'
        })
      }

      // Handle legacy string parameter (role only)
      if (typeof roleOrOptions === 'string') {
        const requiredRole = roleOrOptions
        if (requiredRole && !hasRole(session, requiredRole)) {
          throw createError({
            statusCode: 403,
            statusMessage: 'Unzureichende Berechtigung'
          })
        }
      } else if (roleOrOptions && typeof roleOrOptions === 'object') {
        const { role, roles, permission, permissions, requireAll = false } = roleOrOptions

        // Check single role if specified
        if (role && !hasRole(session, role)) {
          throw createError({
            statusCode: 403,
            statusMessage: 'Unzureichende Berechtigung'
          })
        }

        // Check multiple roles if specified (user needs ANY of them)
        if (roles && roles.length > 0 && !hasAnyRole(session, roles)) {
          throw createError({
            statusCode: 403,
            statusMessage: 'Unzureichende Berechtigung'
          })
        }

        // Check single permission if specified
        if (permission && !hasPermission(session, permission)) {
          throw createError({
            statusCode: 403,
            statusMessage: 'Unzureichende Berechtigung'
          })
        }

        // Check multiple permissions if specified
        if (permissions && permissions.length > 0) {
          const hasRequiredPermissions = requireAll 
            ? hasAllPermissions(session, permissions)
            : hasAnyPermission(session, permissions)
          
          if (!hasRequiredPermissions) {
            throw createError({
              statusCode: 403,
              statusMessage: 'Unzureichende Berechtigung'
            })
          }
        }
      }

      // Benutzer an Event-Context anhängen
      event.context.user = userWithCustomer
      event.context.session = session

      return userWithCustomer
    } catch (error: any) {
      if (error.statusCode) {
        throw error
      }
      throw createError({
        statusCode: 401,
        statusMessage: 'Authentifizierung fehlgeschlagen'
      })
    }
  }
}

/**
 * Convenience function to require specific permission
 */
export function requirePermission(permission: string): EventHandler {
  return requireAuth({ permission })
}

/**
 * Convenience function to require any of multiple permissions
 */
export function requireAnyPermission(permissions: string[]): EventHandler {
  return requireAuth({ permissions, requireAll: false })
}

/**
 * Convenience function to require all of multiple permissions
 */
export function requireAllPermissions(permissions: string[]): EventHandler {
  return requireAuth({ permissions, requireAll: true })
}

/**
 * Convenience function to require specific role
 */
export function requireRole(role: string): EventHandler {
  return requireAuth({ role })
}

/**
 * Convenience function to require any of multiple roles
 */
export function requireAnyRole(roles: string[]): EventHandler {
  return requireAuth({ roles })
}

/**
 * Hilfsfunktion zur Extraktion des Benutzers aus dem Event-Context
 */
export function getCurrentUser(event: any) {
  return event.context.user
}

/**
 * Hilfsfunktion zur Extraktion der Session aus dem Event-Context
 */
export function getCurrentSession(event: any): Session {
  return event.context.session
}
