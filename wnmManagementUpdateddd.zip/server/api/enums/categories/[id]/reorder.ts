import { z } from 'zod'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

// Validation schema
const reorderSchema = z.object({
  valueIds: z.array(z.string()).min(1)
})

export default defineEventHandler(async (event) => {
  try {
    const method = getMethod(event)
    const categoryId = getRouterParam(event, 'id')

    if (!categoryId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Kategorie-ID erforderlich'
      })
    }

    if (method !== 'PUT') {
      throw createError({
        statusCode: 405,
        statusMessage: 'Method Not Allowed'
      })
    }

    return await handleReorderValues(event, categoryId)
  } catch (error: any) {
    console.error('Enum Values Reorder API Error:', error)
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || error.message || 'Internal Server Error'
    })
  }
})

async function handleReorderValues(event: any, categoryId: string) {
  const body = await readBody(event)
  const { valueIds } = reorderSchema.parse(body)

  // Check if category exists
  const category = await prisma.enumCategory.findUnique({
    where: { id: categoryId },
    include: {
      values: true
    }
  })

  if (!category) {
    throw createError({
      statusCode: 404,
      statusMessage: 'Enum-Kategorie nicht gefunden'
    })
  }

  // Validate that all provided IDs belong to this category
  const categoryValueIds = new Set(category.values.map(v => v.id))
  const invalidIds = valueIds.filter(id => !categoryValueIds.has(id))
  
  if (invalidIds.length > 0) {
    throw createError({
      statusCode: 400,
      statusMessage: `Ungültige Enum-Wert-IDs: ${invalidIds.join(', ')}`
    })
  }

  // Update sort order for each value
  const updates = valueIds.map((valueId, index) =>
    prisma.enumValue.update({
      where: { id: valueId },
      data: { sortOrder: index }
    })
  )

  await prisma.$transaction(updates)

  // Log activity
  // await logActivity({
  //   userId: event.context.user?.id,
  //   action: 'enum_values_reordered',
  //   description: `Enum-Werte in Kategorie '${category.label}' neu angeordnet`,
  //   details: { categoryId, newOrder: valueIds }
  // })

  return { success: true }
}
