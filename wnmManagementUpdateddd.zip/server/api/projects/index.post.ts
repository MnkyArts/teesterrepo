import { z } from 'zod'
import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

// Validation Schema
const createProjectSchema = z.object({
  name: z.string().min(1, 'Projektname ist erforderlich').max(255),
  key: z.string().min(1, 'Projektschlüssel ist erforderlich').max(50)
    .regex(/^[A-Z0-9-]+$/, 'Nur Großbuchstaben, Zahlen und Bindestriche erlaubt'),
  description: z.string().optional(),
  customerId: z.string().optional().nullable(),
  status: z.enum(['AKTIV', 'PAUSIERT', 'ABGESCHLOSSEN', 'ARCHIVIERT']).default('AKTIV'),
  startDate: z.string().optional().nullable(),
  endDate: z.string().optional().nullable(),
  budget: z.number().min(0).optional().nullable(),
  isInternal: z.boolean().default(false)
})

export default defineEventHandler(async (event) => {
  const method = getMethod(event)

  // Better Auth authentication - require project manager or admin
  const user = await requireAuth('PROJEKTLEITER')(event)

  try {
    if (method === 'GET') {
      // Projekte auflisten
      const projects = await prisma.project.findMany({
        include: {
          customer: {
            select: {
              id: true,
              companyName: true,
              contactName: true
            }
          },
          members: {
            include: {
              user: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  image: true
                }
              }
            }
          },
          _count: {
            select: {
              tasks: true,
              members: true,
              timeEntries: true
            }
          }
        },
        orderBy: {
          updatedAt: 'desc'
        }
      })

      // Calculate additional metrics for each project
      const projectsWithMetrics = await Promise.all(
        projects.map(async (project) => {
          // Calculate total hours
          const timeEntries = await prisma.timeEntry.aggregate({
            where: { projectId: project.id },
            _sum: { hours: true }
          })

          // Calculate progress based on completed tasks
          const taskStats = await prisma.task.groupBy({
            by: ['statusId'],
            where: { projectId: project.id },
            _count: { _all: true }
          })

          // Get total tasks count
          const totalTasks = taskStats.reduce((sum, stat) => sum + stat._count._all, 0)
          
          // Get completed tasks by checking enum values
          let completedTasks = 0
          if (taskStats.length > 0) {
            // Get the status enum values to find "completed" statuses
            const statusIds = taskStats.map(stat => stat.statusId).filter((id): id is string => id !== null)
            if (statusIds.length > 0) {
              const statusEnums = await prisma.enumValue.findMany({
                where: {
                  id: { in: statusIds },
                  category: { name: 'task_status' }
                }
              })
              
              // Look for completed status (can be "ERLEDIGT", "ABGESCHLOSSEN", "DONE", etc.)
              const completedStatusIds = statusEnums
                .filter(enumValue => 
                  enumValue.key.toLowerCase().includes('erledigt') || 
                  enumValue.key.toLowerCase().includes('abgeschlossen') ||
                  enumValue.key.toLowerCase().includes('done') ||
                  enumValue.key.toLowerCase().includes('completed')
                )
                .map(enumValue => enumValue.id)
              
              completedTasks = taskStats
                .filter(stat => stat.statusId && completedStatusIds.includes(stat.statusId))
                .reduce((sum, stat) => sum + stat._count._all, 0)
            }
          }
          
          const progress = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0

          return {
            ...project,
            totalHours: timeEntries._sum.hours || 0,
            progress
          }
        })
      )

      return {
        success: true,
        data: projectsWithMetrics
      }
    }

    if (method === 'POST') {
      // Berechtigung prüfen - user is already authenticated via requireAuth
      const currentUser = await prisma.user.findUnique({
        where: { id: user.id }
      })

      if (!currentUser || !['ADMINISTRATOR', 'PROJEKTLEITER'].includes(currentUser.role)) {
        throw createError({
          statusCode: 403,
          statusMessage: 'Keine Berechtigung zum Erstellen von Projekten'
        })
      }

      // Daten validieren
      const body = await readBody(event)
      const validatedData = createProjectSchema.parse(body)

      // Prüfen ob Projektschlüssel bereits existiert
      const existingProject = await prisma.project.findUnique({
        where: { key: validatedData.key }
      })

      if (existingProject) {
        throw createError({
          statusCode: 400,
          statusMessage: 'Projektschlüssel bereits vergeben'
        })
      }

      // Bei internem Projekt Kunde entfernen
      if (validatedData.isInternal) {
        validatedData.customerId = null
      }

      // Projekt erstellen
      const project = await prisma.project.create({
        data: {
          ...validatedData,
          startDate: validatedData.startDate ? new Date(validatedData.startDate) : null,
          endDate: validatedData.endDate ? new Date(validatedData.endDate) : null,
          members: {
            create: {
              userId: user.id,
              role: 'Projektleiter'
            }
          }
        },
        include: {
          customer: {
            select: {
              id: true,
              companyName: true,
              contactName: true
            }
          },
          members: {
            include: {
              user: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  image: true
                }
              }
            }
          },
          _count: {
            select: {
              tasks: true,
              members: true,
              timeEntries: true
            }
          }
        }
      })

      // Aktivitäts-Log erstellen
      await prisma.activityLog.create({
        data: {
          action: 'PROJECT_CREATED',
          description: `Projekt "${project.name}" wurde erstellt`,
          userId: user.id,
          projectId: project.id,
          newValue: JSON.stringify({
            projectKey: project.key,
            projectName: project.name
          })
        }
      })

      return {
        success: true,
        data: project,
        message: 'Projekt erfolgreich erstellt'
      }
    }

    throw createError({
      statusCode: 405,
      statusMessage: 'Methode nicht erlaubt'
    })

  } catch (error: any) {
    console.error('Fehler in Projects API:', error)

    if (error.statusCode) {
      throw error
    }

    if (error.name === 'ZodError') {
      throw createError({
        statusCode: 400,
        statusMessage: 'Validierungsfehler',
        data: {
          errors: error.errors.reduce((acc: any, err: any) => {
            acc[err.path[0]] = err.message
            return acc
          }, {})
        }
      })
    }

    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Serverfehler'
    })
  }
})
