import { z } from 'zod'
import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

// Validation Schema
const updateProjectSchema = z.object({
  name: z.string().min(1, 'Projektname ist erforderlich').max(255),
  description: z.string().optional(),
  customerId: z.string().optional().nullable(),
  status: z.enum(['AKTIV', 'PAUSIERT', 'ABGESCHLOSSEN', 'ARCHIVIERT']),
  startDate: z.string().optional().nullable(),
  endDate: z.string().optional().nullable(),
  budget: z.number().min(0).optional().nullable(),
  isInternal: z.boolean().default(false)
})

export default defineEventHandler(async (event) => {
  const method = getMethod(event)
  const projectId = getRouterParam(event, 'id')

  // Better Auth authentication
  const user = await requireAuth()(event)

  try {
    if (method === 'GET') {
      // Einzelnes Projekt laden
      const project = await prisma.project.findUnique({
        where: { id: projectId },
        include: {
          customer: {
            select: {
              id: true,
              companyName: true,
              contactName: true,
              email: true,
              phone: true
            }
          },
          members: {
            include: {
              user: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  image: true,
                  role: true
                }
              }
            }
          },
          tasks: {
            select: {
              id: true,
              key: true,
              title: true,
              status: {
                select: {
                  id: true,
                  key: true,
                  label: true,
                  color: true,
                  icon: true
                }
              },
              priority: {
                select: {
                  id: true,
                  key: true,
                  label: true,
                  color: true,
                  icon: true
                }
              },
              assignee: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  image: true
                }
              },
              createdAt: true,
              updatedAt: true
            },
            orderBy: {
              updatedAt: 'desc'
            },
            take: 10
          },
          _count: {
            select: {
              tasks: true,
              members: true,
              timeEntries: true
            }
          }
        }
      })

      if (!project) {
        throw createError({
          statusCode: 404,
          statusMessage: 'Projekt nicht gefunden'
        })
      }

      // Calculate additional metrics
      const timeEntries = await prisma.timeEntry.aggregate({
        where: { projectId: project.id },
        _sum: { hours: true }
      })

      const taskStats = await prisma.task.groupBy({
        by: ['statusId'],
        where: { projectId: project.id },
        _count: { _all: true }
      })

      // Get total tasks count
      const totalTasks = taskStats.reduce((sum, stat) => sum + stat._count._all, 0)
      
      // Get completed tasks by checking enum values
      let completedTasks = 0
      if (taskStats.length > 0 && totalTasks > 0) {
        // Get the status enum values to find "completed" statuses
        const statusIds = taskStats.map(stat => stat.statusId).filter((id): id is string => id !== null)
        if (statusIds.length > 0) {
          const statusEnums = await prisma.enumValue.findMany({
            where: {
              id: { in: statusIds },
              category: { name: 'task_status' }
            }
          })
          
          // Look for completed status - enhanced German keyword matching
          const completedStatusIds = statusEnums
            .filter(enumValue => {
              const key = enumValue.key.toLowerCase()
              const label = enumValue.label?.toLowerCase() || ''
              return (
                key.includes('erledigt') || 
                key.includes('geschlossen') ||
                key.includes('abgeschlossen') ||
                key.includes('done') ||
                key.includes('completed') ||
                key.includes('finished') ||
                label.includes('erledigt') ||
                label.includes('geschlossen') ||
                label.includes('abgeschlossen') ||
                label.includes('done') ||
                label.includes('completed')
              )
            })
            .map(enumValue => enumValue.id)
          
          completedTasks = taskStats
            .filter(stat => stat.statusId && completedStatusIds.includes(stat.statusId))
            .reduce((sum, stat) => sum + stat._count._all, 0)
        }
      }
      
      const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0

      return {
        success: true,
        data: {
          ...project,
          totalHours: timeEntries._sum.hours || 0,
          progress,
          taskStats
        }
      }
    }

    if (method === 'PUT') {
      // Berechtigung prüfen
      const currentUser = await prisma.user.findUnique({
        where: { id: user.id }
      })

      if (!currentUser || !['ADMINISTRATOR', 'PROJEKTLEITER'].includes(currentUser.role)) {
        throw createError({
          statusCode: 403,
          statusMessage: 'Keine Berechtigung zum Bearbeiten von Projekten'
        })
      }

      // Projekt existiert?
      const existingProject = await prisma.project.findUnique({
        where: { id: projectId }
      })

      if (!existingProject) {
        throw createError({
          statusCode: 404,
          statusMessage: 'Projekt nicht gefunden'
        })
      }

      // Daten validieren
      const body = await readBody(event)
      const validatedData = updateProjectSchema.parse(body)

      // Bei internem Projekt Kunde entfernen
      if (validatedData.isInternal) {
        validatedData.customerId = null
      }

      // Projekt aktualisieren
      const project = await prisma.project.update({
        where: { id: projectId },
        data: {
          ...validatedData,
          startDate: validatedData.startDate ? new Date(validatedData.startDate) : null,
          endDate: validatedData.endDate ? new Date(validatedData.endDate) : null
        },
        include: {
          customer: {
            select: {
              id: true,
              companyName: true,
              contactName: true
            }
          },
          members: {
            include: {
              user: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  image: true
                }
              }
            }
          },
          _count: {
            select: {
              tasks: true,
              members: true,
              timeEntries: true
            }
          }
        }
      })

      // Aktivitäts-Log erstellen
      await prisma.activityLog.create({
        data: {
          action: 'PROJECT_UPDATED',
          description: `Projekt "${project.name}" wurde aktualisiert`,
          userId: user.id,
          projectId: project.id,
          newValue: JSON.stringify(validatedData)
        }
      })

      return {
        success: true,
        data: project,
        message: 'Projekt erfolgreich aktualisiert'
      }
    }

    if (method === 'DELETE') {
      // Berechtigung prüfen (nur Administratoren)
      const currentUser = await prisma.user.findUnique({
        where: { id: user.id }
      })

      if (!currentUser || currentUser.role !== 'ADMINISTRATOR') {
        throw createError({
          statusCode: 403,
          statusMessage: 'Keine Berechtigung zum Löschen von Projekten'
        })
      }

      // Projekt existiert?
      const existingProject = await prisma.project.findUnique({
        where: { id: projectId }
      })

      if (!existingProject) {
        throw createError({
          statusCode: 404,
          statusMessage: 'Projekt nicht gefunden'
        })
      }

      // Prüfen ob Projekt Tasks hat
      const taskCount = await prisma.task.count({
        where: { projectId: projectId }
      })

      if (taskCount > 0) {
        throw createError({
          statusCode: 400,
          statusMessage: 'Projekt kann nicht gelöscht werden, da es noch Aufgaben enthält'
        })
      }

      // Projekt löschen
      await prisma.project.delete({
        where: { id: projectId }
      })

      // Aktivitäts-Log erstellen
      await prisma.activityLog.create({
        data: {
          action: 'PROJECT_DELETED',
          description: `Projekt "${existingProject.name}" wurde gelöscht`,
          userId: user.id,
          oldValue: JSON.stringify({
            projectKey: existingProject.key,
            projectName: existingProject.name
          })
        }
      })

      return {
        success: true,
        message: 'Projekt erfolgreich gelöscht'
      }
    }

    throw createError({
      statusCode: 405,
      statusMessage: 'Methode nicht erlaubt'
    })

  } catch (error: any) {
    console.error('Fehler in Project API:', error)

    if (error.statusCode) {
      throw error
    }

    if (error.name === 'ZodError') {
      throw createError({
        statusCode: 400,
        statusMessage: 'Validierungsfehler',
        data: {
          errors: error.errors.reduce((acc: any, err: any) => {
            acc[err.path[0]] = err.message
            return acc
          }, {})
        }
      })
    }

    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Serverfehler'
    })
  }
})
