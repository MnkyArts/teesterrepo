import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  try {
    // Authentifizierung prüfen
    const decoded = await requireAuth()(event)
    
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Authentifizierung erforderlich'
      })
    }

    const ticketId = getRouterParam(event, 'ticketId')
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ticket-ID ist erforderlich'
      })
    }

    // Benutzer laden
    const user = await prisma.user.findUnique({
      where: { id: decoded.id }
    })

    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Benutzer nicht gefunden'
      })
    }

    // Berechtigung prüfen (nur Administratoren und Projektleiter können Tickets löschen)
    if (!['ADMINISTRATOR', 'PROJEKTLEITER'].includes(user.role)) {
      throw createError({
        statusCode: 403,
        statusMessage: 'Keine Berechtigung zum Löschen von Tickets'
      })
    }

    // Ticket existiert prüfen
    const existingTicket = await prisma.ticket.findUnique({
      where: { id: ticketId },
      include: {
        comments: true,
        status: true
      }
    })

    if (!existingTicket) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Ticket nicht gefunden'
      })
    }

    // Prüfen ob Ticket bereits geschlossen ist (zusätzliche Sicherheit)
    if (existingTicket.statusId && existingTicket.status?.key === 'GESCHLOSSEN') {
      console.warn(`Attempt to delete closed ticket ${ticketId} by user ${user.id}`)
    }

    // Ticket und alle zugehörigen Daten löschen (Cascade wird durch Prisma Schema gehandhabt)
    await prisma.ticket.delete({
      where: { id: ticketId }
    })

    return {
      success: true,
      message: 'Ticket erfolgreich gelöscht'
    }

  } catch (error: any) {
    console.error('Fehler beim Löschen des Tickets:', error)
    
    if (error.statusCode) {
      throw error
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Serverfehler beim Löschen des Tickets'
    })
  }
})
