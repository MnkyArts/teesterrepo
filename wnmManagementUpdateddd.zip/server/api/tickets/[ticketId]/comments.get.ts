import { PrismaClient } from '@prisma/client'
import { requireAuth } from '~/server/utils/auth'

const prisma = new PrismaClient()

export default defineEventHandler(async (event) => {
  try {
    // Verify authentication
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Unauthorized'
      })
    }

    const ticketId = getRouterParam(event, 'ticketId')
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ticket ID is required'
      })
    }

    // Get user details
    const currentUser = await prisma.user.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        role: true
      }
    })

    if (!currentUser) {
      throw createError({
        statusCode: 401,
        statusMessage: 'User not found'
      })
    }

    // Check if user is internal staff
    if (user.role === 'KUNDE') {
      throw createError({
        statusCode: 403,
        statusMessage: 'Access denied'
      })
    }

    // Check if ticket exists
    const ticket = await prisma.ticket.findUnique({
      where: { id: ticketId },
      select: {
        id: true
      }
    })

    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Ticket not found'
      })
    }

    // Get all comments (internal staff can see all comments)
    const comments = await prisma.ticketComment.findMany({
      where: {
        ticketId: ticketId
      },
      include: {
        author: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            role: true
          }
        }
      },
      orderBy: {
        createdAt: 'asc'
      }
    })

    return comments

  } catch (error) {
    console.error('Error fetching ticket comments:', error)
    
    if ((error as any).statusCode) {
      throw error
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Internal server error'
    })
  }
})
