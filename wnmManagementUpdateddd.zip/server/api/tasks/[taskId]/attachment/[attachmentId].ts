import { requireAuth } from '~/server/utils/auth'
import { PrismaClient } from '@prisma/client'
import fs from 'fs/promises'
import { createReadStream } from 'fs'
import path from 'path'

const prisma = new PrismaClient()

export default defineEventHandler(async (event) => {
  const method = getMethod(event)
  const taskId = getRouterParam(event, 'taskId')
  const attachmentId = getRouterParam(event, 'attachmentId')

  if (!taskId || !attachmentId) {
    throw createError({
      statusCode: 400,
      statusMessage: 'Task-ID und Attachment-ID sind erforderlich'
    })
  }

  // Authentifizierung prüfen
  const user = await requireAuth()(event)
  if (!user) {
    throw createError({
      statusCode: 401,
      statusMessage: 'Authentifizierung erforderlich'
    })
  }

  try {
    // Anhang existiert prüfen
    const attachment = await prisma.taskAttachment.findFirst({
      where: {
        id: attachmentId,
        taskId
      }
    })

    if (!attachment) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Anhang nicht gefunden'
      })
    }

    switch (method) {
      case 'GET':
        return await downloadAttachment(event, attachment)
      
      case 'DELETE':
        return await deleteAttachment(attachment, user.id)
      
      default:
        throw createError({
          statusCode: 405,
          statusMessage: 'Method not allowed'
        })
    }
  } catch (error: any) {
    console.error('Fehler bei Anhang-Operation:', error)
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || 'Interner Serverfehler'
    })
  }
})

async function downloadAttachment(event: any, attachment: any) {
  try {
    // Prüfen ob Datei existiert
    await fs.access(attachment.path)
    
    // Content-Type und Disposition Header setzen
    setHeader(event, 'Content-Type', attachment.mimeType)
    setHeader(event, 'Content-Disposition', `attachment; filename="${encodeURIComponent(attachment.originalName)}"`)
    setHeader(event, 'Content-Length', attachment.size.toString())
    
    // Datei-Stream zurückgeben
    return sendStream(event, createReadStream(attachment.path))
  } catch (error) {
    throw createError({
      statusCode: 404,
      statusMessage: 'Datei nicht gefunden'
    })
  }
}

async function deleteAttachment(attachment: any, userId: string) {
  try {
    // Datei aus Dateisystem löschen
    try {
      await fs.unlink(attachment.path)
    } catch (error) {
      console.warn('Datei konnte nicht aus Dateisystem gelöscht werden:', error)
    }
    
    // Datenbank-Eintrag löschen
    await prisma.taskAttachment.delete({
      where: { id: attachment.id }
    })
    
    // Aktivitätslog erstellen
    await prisma.activityLog.create({
      data: {
        action: 'ATTACHMENT_DELETED',
        description: `Datei "${attachment.originalName}" wurde gelöscht`,
        userId,
        taskId: attachment.taskId
      }
    })
    
    return { success: true, message: 'Anhang erfolgreich gelöscht' }
  } catch (error: any) {
    console.error('Fehler beim Löschen des Anhangs:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Löschen des Anhangs'
    })
  }
}
