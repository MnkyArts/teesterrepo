import { z } from 'zod'
import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

// Validation Schema für Kommentar-Erstellung
const createCommentSchema = z.object({
  content: z.string().min(1, 'Kommentar darf nicht leer sein'),
  isInternal: z.boolean().default(false)
})

export default defineEventHandler(async (event) => {
  const method = getMethod(event)
  
  try {
    const user = await requireAuth()(event)

    const taskId = getRouterParam(event, 'taskId')
    
    if (!taskId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Task-ID ist erforderlich'
      })
    }

    // Prüfen ob Task existiert und User berechtigt ist
    const task = await prisma.task.findUnique({
      where: { id: taskId },
      include: { project: true }
    })

    if (!task) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Aufgabe nicht gefunden'
      })
    }

    // Berechtigung prüfen
    if (user.role !== 'ADMINISTRATOR') {
      const isMember = await prisma.projectMember.findFirst({
        where: {
          projectId: task.projectId,
          userId: user.id
        }
      })

      if (!isMember) {
        throw createError({
          statusCode: 403,
          statusMessage: 'Keine Berechtigung für diese Aufgabe'
        })
      }
    }

    if (method === 'GET') {
      // Kommentare abrufen
      const comments = await prisma.taskComment.findMany({
        where: { taskId },
        include: {
          author: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              image: true
            }
          }
        },
        orderBy: { createdAt: 'asc' }
      })

      return comments
    }

    if (method === 'POST') {
      // Kommentar erstellen
      const body = await readBody(event)
      const validatedData = createCommentSchema.parse(body)

      const newComment = await prisma.taskComment.create({
        data: {
          content: validatedData.content,
          isInternal: validatedData.isInternal,
          taskId,
          authorId: user.id
        },
        include: {
          author: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              image: true
            }
          }
        }
      })

      // Aktivitätslog erstellen
      await prisma.activityLog.create({
        data: {
          action: 'COMMENT_ADDED',
          description: `Kommentar zu Aufgabe "${task.title}" hinzugefügt`,
          userId: user.id,
          projectId: task.projectId,
          taskId: task.id
        }
      })

      return newComment
    }

    throw createError({
      statusCode: 405,
      statusMessage: 'Methode nicht erlaubt'
    })

  } catch (error: any) {
    if (error.statusCode) {
      throw error
    }

    console.error('Task Comments API Error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Server-Fehler'
    })
  }
})
