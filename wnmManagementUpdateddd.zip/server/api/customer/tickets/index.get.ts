import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  // Better Auth authentication - only customers
  const user = await requireAuth('KUNDE')(event)

  try {
    // Kunden-ID aus dem User ermitteln
    const userData = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        customer: true
      }
    })

    if (!userData || !userData.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Kunde nicht gefunden'
      })
    }

    const customerId = userData.customer.id

    // Query-Parameter auslesen
    const query = getQuery(event)
    const limit = query.limit && typeof query.limit === 'string' ? parseInt(query.limit) : undefined
    const page = query.page && typeof query.page === 'string' ? parseInt(query.page) : 1
    
    // Where-Klausel aufbauen
    const where: any = {
      customerId
    }

    if (query.status && typeof query.status === 'string') {
      // Filter by enum key
      where.status = {
        key: query.status
      }
    }

    if (query.department && typeof query.department === 'string') {
      where.department = query.department
    }

    // Tickets laden mit Pagination
    const [tickets, total] = await Promise.all([
      prisma.ticket.findMany({
        where,
        include: {
          status: {
            select: {
              key: true,
              label: true
            }
          },
          priority: {
            select: {
              key: true,
              label: true
            }
          },
          type: {
            select: {
              key: true,
              label: true
            }
          }
        },
        orderBy: {
          createdAt: 'desc'
        },
        ...(limit && { take: limit }),
        ...(limit && page > 1 && { skip: (page - 1) * limit })
      }),
      prisma.ticket.count({ where })
    ])

    // Transform tickets to flatten enum relationships
    const transformedTickets = tickets.map(ticket => ({
      ...ticket,
      status: ticket.status?.key || 'UNKNOWN',
      priority: ticket.priority?.key || 'MEDIUM',
      type: ticket.type?.key || 'GENERAL'
    }))

    return {
      tickets: transformedTickets,
      pagination: {
        total,
        page,
        limit: limit || total,
        pages: limit ? Math.ceil(total / limit) : 1
      }
    }

  } catch (error) {
    console.error('Customer tickets error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Laden der Tickets'
    })
  }
})
