import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  // Better Auth authentication - only customers
  const user = await requireAuth('KUNDE')(event)

  try {
    // Kunden-ID aus dem User ermitteln
    const userData = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        customer: true
      }
    })

    if (!userData || !userData.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Kunde nicht gefunden'
      })
    }

    const customerId = userData.customer.id
    const ticketId = getRouterParam(event, 'id')

    // Ticket laden (nur wenn es dem Kunden gehört)
    const ticket = await prisma.ticket.findFirst({
      where: {
        id: ticketId,
        customerId
      },
      include: {
        status: {
          select: {
            key: true,
            label: true
          }
        },
        priority: {
          select: {
            key: true,
            label: true
          }
        },
        type: {
          select: {
            key: true,
            label: true
          }
        }
      }
    })

    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Ticket nicht gefunden'
      })
    }

    // Transform ticket to flatten enum relationships
    const transformedTicket = {
      ...ticket,
      status: ticket.status?.key || 'UNKNOWN',
      priority: ticket.priority?.key || 'MEDIUM',
      type: ticket.type?.key || 'GENERAL'
    }

    return transformedTicket

  } catch (error: any) {
    console.error('Customer ticket details error:', error)
    
    if (error.statusCode) {
      throw error
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Laden des Tickets'
    })
  }
})
