import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  try {
    // Better Auth authentication - only customers
    const user = await requireAuth('KUNDE')(event)
    
    // Benutzer und Kundendaten laden
    const userData = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        customer: {
          include: {
            sepaMandate: true
          }
        }
      }
    })

    if (!userData || userData.role !== 'KUNDE') {
      throw createError({
        statusCode: 404,
        statusMessage: 'Kunde nicht gefunden'
      })
    }

    if (!userData.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Kundendaten nicht gefunden'
      })
    }

    return {
      mandate: userData.customer.sepaMandate || null,
      hasActiveMandate: userData.customer.sepaMandate?.isActive || false
    }

  } catch (error: any) {
    console.error('SEPA mandate get error:', error)
    
    if (error.statusCode) {
      throw error
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Laden des SEPA-Mandats'
    })
  }
})
