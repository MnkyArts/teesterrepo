import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  try {
    // Nur DELETE-Requests erlauben
    assertMethod(event, 'DELETE')
    
    // Authentifizierung prüfen
    const decoded = await requireAuth()(event)
    
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Authentifizierung erforderlich'
      })
    }
    
    // Benutzer und Kundendaten laden
    const user = await prisma.user.findUnique({
      where: { id: decoded.id },
      include: {
        customer: {
          include: {
            sepaMandate: true
          }
        }
      }
    })

    if (!user || user.role !== 'KUNDE') {
      throw createError({
        statusCode: 404,
        statusMessage: 'Kunde nicht gefunden'
      })
    }

    if (!user.customer || !user.customer.sepaMandate) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Kein SEPA-Mandat gefunden'
      })
    }

    const mandate = user.customer.sepaMandate
    const customerId = user.customer.id
    
    // Mandat als inaktiv markieren (nicht löschen für Audit-Zwecke)
    const revokedMandate = await prisma.sepaMandate.update({
      where: { customerId },
      data: {
        isActive: false,
        validUntil: new Date() // Sofort ungültig setzen
      }
    })

    // Activity Log erstellen
    await prisma.activityLog.create({
      data: {
        action: 'SEPA_MANDATE_REVOKED',
        description: `SEPA-Mandat wurde widerrufen`,
        userId: decoded.id,
        details: {
          mandateId: mandate.mandateId,
          iban: mandate.iban.substring(0, 8) + '****', // Anonymisiert für Log
          revokedAt: new Date()
        }
      }
    })

    return {
      message: 'SEPA-Mandat wurde erfolgreich widerrufen',
      mandate: revokedMandate
    }

  } catch (error: any) {
    console.error('SEPA mandate revoke error:', error)
    
    if (error.statusCode) {
      throw error
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Widerrufen des SEPA-Mandats'
    })
  }
})
