import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  try {
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Nicht authentifiziert'
      })
    }

    // Berechtigung prüfen
    if (user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER') {
      throw createError({
        statusCode: 403,
        statusMessage: 'Keine Berechtigung für Skill-Matrix-Ansicht'
      })
    }

    // Skill-Matrix-Daten laden
    const [
      skillCategories,
      teamSkills,
      skillStatistics,
      verificationStats
    ] = await Promise.all([
      // Skill-Kategorien
      prisma.userSkill.groupBy({
        by: ['category'],
        _count: {
          id: true
        },
        where: {
          user: {
            isActive: true,
            role: { not: 'KUNDE' }
          }
        }
      }),

      // Team-Skills mit Benutzerdaten
      prisma.userSkill.findMany({
        where: {
          user: {
            isActive: true,
            role: { not: 'KUNDE' }
          }
        },
        include: {
          user: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              role: true,
              image: true
            }
          }
        },
        orderBy: [
          { category: 'asc' },
          { name: 'asc' },
          { level: 'desc' }
        ]
      }),

      // Skill-Level-Statistiken
      prisma.userSkill.groupBy({
        by: ['name', 'level'],
        _count: {
          id: true
        },
        where: {
          user: {
            isActive: true,
            role: { not: 'KUNDE' }
          }
        }
      }),

      // Verifizierungs-Statistiken
      prisma.userSkill.groupBy({
        by: ['verified'],
        _count: {
          id: true
        },
        where: {
          user: {
            isActive: true,
            role: { not: 'KUNDE' }
          }
        }
      })
    ])

    // Skill-Matrix aufbauen
    const skillMatrix = skillCategories.map(category => {
      const categorySkills = teamSkills.filter(skill => skill.category === category.category)
      
      // Skills nach Namen gruppieren
      const skillsGrouped = categorySkills.reduce((acc, skill) => {
        if (!acc[skill.name]) {
          acc[skill.name] = []
        }
        acc[skill.name].push(skill)
        return acc
      }, {} as Record<string, typeof categorySkills>)

      return {
        category: category.category,
        totalSkills: category._count.id,
        skills: Object.entries(skillsGrouped).map(([skillName, skillInstances]) => ({
          name: skillName,
          totalUsers: skillInstances.length,
          averageLevel: skillInstances.reduce((sum, s) => sum + s.level, 0) / skillInstances.length,
          maxLevel: Math.max(...skillInstances.map(s => s.level)),
          verifiedCount: skillInstances.filter(s => s.verified).length,
          verificationRate: (skillInstances.filter(s => s.verified).length / skillInstances.length) * 100,
          users: skillInstances.map(skill => ({
            user: skill.user,
            level: skill.level,
            verified: skill.verified,
            verifiedBy: skill.verifiedBy,
            verifiedAt: skill.verifiedAt,
            experience: skill.experience
          }))
        }))
      }
    })

    // Top Skills finden
    const topSkills = skillStatistics
      .reduce((acc, stat) => {
        if (!acc[stat.name]) {
          acc[stat.name] = { totalUsers: 0, weightedScore: 0 }
        }
        acc[stat.name].totalUsers += stat._count.id
        acc[stat.name].weightedScore += stat._count.id * stat.level
        return acc
      }, {} as Record<string, { totalUsers: number, weightedScore: number }>)

    const topSkillsList = Object.entries(topSkills)
      .map(([name, data]) => ({
        name,
        totalUsers: data.totalUsers,
        averageLevel: data.weightedScore / data.totalUsers,
        weightedScore: data.weightedScore
      }))
      .sort((a, b) => b.weightedScore - a.weightedScore)
      .slice(0, 10)

    // Skill-Coverage berechnen
    const allUniqueSkills = [...new Set(teamSkills.map(s => s.name))]
    const allUsers = [...new Set(teamSkills.map(s => s.user.id))]
    
    const skillCoverage = allUsers.map(userId => {
      const userSkills = teamSkills.filter(s => s.user.id === userId)
      const user = userSkills[0]?.user
      
      return {
        user,
        totalSkills: userSkills.length,
        verifiedSkills: userSkills.filter(s => s.verified).length,
        averageLevel: userSkills.reduce((sum, s) => sum + s.level, 0) / userSkills.length || 0,
        categories: [...new Set(userSkills.map(s => s.category))],
        skillCoveragePercent: (userSkills.length / allUniqueSkills.length) * 100
      }
    }).sort((a, b) => b.totalSkills - a.totalSkills)

    // Zusammenfassung
    const totalVerified = verificationStats.find(v => v.verified)?._count.id || 0
    const totalSkillsCount = verificationStats.reduce((sum, v) => sum + v._count.id, 0)
    
    const summary = {
      totalSkills: allUniqueSkills.length,
      totalCategories: skillCategories.length,
      totalTeamMembers: allUsers.length,
      averageSkillsPerMember: teamSkills.length / allUsers.length,
      verificationRate: totalSkillsCount > 0 ? (totalVerified / totalSkillsCount) * 100 : 0
    }

    return {
      success: true,
      data: {
        skillMatrix,
        topSkills: topSkillsList,
        skillCoverage,
        summary,
        lastUpdated: new Date().toISOString()
      }
    }

  } catch (error: any) {
    console.error('Fehler beim Laden der Skill-Matrix:', error)
    
    if (error.statusCode) {
      throw error
    }

    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Server-Fehler'
    })
  }
})
