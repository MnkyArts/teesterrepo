import { z } from 'zod'
import { hash } from 'bcryptjs'
import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

// Schema für Benutzer-Erstellung
const createUserSchema = z.object({
  email: z.string().email('Ungültige E-Mail-Adresse'),
  firstName: z.string().min(1, 'Vorname ist erforderlich'),
  lastName: z.string().min(1, 'Nachname ist erforderlich'),
  role: z.enum(['ADMINISTRATOR', 'PROJEKTLEITER', 'ENTWICKLER', 'SUPPORTER', 'VIEWER', 'KUNDE']),
  image: z.string().url().optional(),
  isActive: z.boolean().default(true),
  skills: z.array(z.object({
    name: z.string().min(1),
    category: z.string().min(1),
    level: z.number().min(1).max(5),
    experience: z.string().optional(),
  })).optional()
})

// Schema für Benutzer-Update  
const updateUserSchema = z.object({
  firstName: z.string().min(1).optional(),
  lastName: z.string().min(1).optional(),
  email: z.string().email().optional(),
  role: z.enum(['ADMINISTRATOR', 'PROJEKTLEITER', 'ENTWICKLER', 'SUPPORTER', 'VIEWER', 'KUNDE']).optional(),
  image: z.string().url().optional(),
  isActive: z.boolean().optional()
})

export default defineEventHandler(async (event) => {
  const method = getMethod(event)

  try {
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Nicht authentifiziert'
      })
    }

    if (method === 'GET') {
      // Benutzer auflisten
      const query = getQuery(event)
      const {
        role,
        isActive,
        search,
        skills,
        availability,
        page = '1',
        limit = '50'
      } = query

      const where: any = {}
      
      if (role) {
        where.role = role as string
      }
      
      if (isActive !== undefined) {
        where.isActive = isActive === 'true'
      }
      
      if (search) {
        where.OR = [
          { firstName: { contains: search as string, mode: 'insensitive' } },
          { lastName: { contains: search as string, mode: 'insensitive' } },
          { email: { contains: search as string, mode: 'insensitive' } }
        ]
      }

      // Berechtigung prüfen - normale Benutzer sehen nur aktive Mitglieder
      if (user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER') {
        where.isActive = true
        where.role = { not: 'KUNDE' } // Kunden werden nicht angezeigt
      }

      const pageNum = parseInt(page as string)
      const limitNum = parseInt(limit as string)
      const skip = (pageNum - 1) * limitNum

      const [users, total] = await Promise.all([
        prisma.user.findMany({
          where,
          select: {
            id: true,
            email: true,
            firstName: true,
            lastName: true,
            image: true,
            role: true,
            isActive: true,
            lastLoginAt: true,
            createdAt: true,
            updatedAt: true,
            _count: {
              select: {
                assignedTasks: true,
                timeEntries: true,
                projectMembers: true
              }
            }
          },
          orderBy: [
            { lastName: 'asc' },
            { firstName: 'asc' }
          ],
          skip,
          take: limitNum
        }),
        prisma.user.count({ where })
      ])

      const totalPages = Math.ceil(total / limitNum)

      return {
        users,
        total,
        page: pageNum,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrev: pageNum > 1
      }
    }

    if (method === 'POST') {
      // Neuen Benutzer erstellen
      if (user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER') {
        throw createError({
          statusCode: 403,
          statusMessage: 'Keine Berechtigung zum Erstellen von Benutzern'
        })
      }

      const body = await readBody(event)
      const validatedData = createUserSchema.parse(body)

      // Prüfen ob E-Mail bereits existiert
      const existingUser = await prisma.user.findUnique({
        where: { email: validatedData.email }
      })

      if (existingUser) {
        throw createError({
          statusCode: 400,
          statusMessage: 'E-Mail-Adresse bereits vergeben'
        })
      }

      // Standard-Passwort wird über Better Auth verwaltet

      // Benutzer erstellen
      const newUser = await prisma.user.create({
        data: {
          email: validatedData.email,
          name: `${validatedData.firstName} ${validatedData.lastName}`, // Add required name field
          firstName: validatedData.firstName,
          lastName: validatedData.lastName,
          role: validatedData.role,
          image: validatedData.image,
          isActive: validatedData.isActive
        },
        include: {
          _count: {
            select: {
              assignedTasks: true,
              timeEntries: true,
              projectMembers: true
            }
          }
        }
      })

      // Aktivitätslog erstellen
      await prisma.activityLog.create({
        data: {
          action: 'USER_CREATED',
          description: `Benutzer ${newUser.firstName} ${newUser.lastName} wurde erstellt`,
          userId: user.id
        }
      })

      // Passwort aus Response entfernen
      return newUser
    }

    throw createError({
      statusCode: 405,
      statusMessage: 'Methode nicht erlaubt'
    })

  } catch (error: any) {
    if (error.statusCode) {
      throw error
    }

    console.error('Users API Error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Server-Fehler'
    })
  }
})
