import { z } from 'zod'
import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

// Schema für Skill-Erstellung
const createSkillSchema = z.object({
  skills: z.array(z.object({
    name: z.string().min(1, 'Skill-Name ist erforderlich'),
    category: z.string().min(1, 'Kategorie ist erforderlich'),
    level: z.number().min(1).max(5, 'Level muss zwischen 1 und 5 liegen'),
    experience: z.string().optional()
  }))
})

export default defineEventHandler(async (event) => {
  const method = getMethod(event)
  const userId = getRouterParam(event, 'userId')

  if (!userId) {
    throw createError({
      statusCode: 400,
      statusMessage: 'Benutzer-ID ist erforderlich'
    })
  }

  try {
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Nicht authentifiziert'
      })
    }

    // Prüfen ob Zielbenutzer existiert
    const targetUser = await prisma.user.findUnique({
      where: { id: userId }
    })

    if (!targetUser) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Benutzer nicht gefunden'
      })
    }

    if (method === 'GET') {
      // Skills des Benutzers laden
      const skills = await prisma.userSkill.findMany({
        where: { userId },
        orderBy: [
          { category: 'asc' },
          { name: 'asc' }
        ]
      })

      return { skills }
    }

    if (method === 'POST') {
      // Skills hinzufügen/aktualisieren
      const body = await readBody(event)
      const { skills } = createSkillSchema.parse(body)

      // Prüfen ob Berechtigung zum Bearbeiten
      if (user.id !== userId && !['ADMINISTRATOR', 'PROJEKTLEITER'].includes(user.role)) {
        throw createError({
          statusCode: 403,
          statusMessage: 'Keine Berechtigung zum Bearbeiten von Skills'
        })
      }

      // Erst alle bestehenden Skills löschen
      await prisma.userSkill.deleteMany({
        where: { userId }
      })

      // Neue Skills hinzufügen
      const createdSkills = await prisma.userSkill.createMany({
        data: skills.map(skill => ({
          userId,
          ...skill
        }))
      })

      // Skills neu laden
      const updatedSkills = await prisma.userSkill.findMany({
        where: { userId },
        orderBy: [
          { category: 'asc' },
          { name: 'asc' }
        ]
      })

      // Activity Log erstellen
      await prisma.activityLog.create({
        data: {
          action: 'USER_SKILL_UPDATE',
          description: `Skills für Benutzer ${targetUser.firstName} ${targetUser.lastName} aktualisiert`,
          userId: user.id,
          projectId: null,
          taskId: null,
          details: JSON.stringify({
            targetUserId: userId,
            skillsCount: skills.length,
            categories: [...new Set(skills.map(s => s.category))]
          })
        }
      })

      return { 
        skills: updatedSkills,
        message: `${skills.length} Skills erfolgreich aktualisiert`
      }
    }

    if (method === 'DELETE') {
      // Alle Skills löschen
      if (user.id !== userId && !['ADMINISTRATOR', 'PROJEKTLEITER'].includes(user.role)) {
        throw createError({
          statusCode: 403,
          statusMessage: 'Keine Berechtigung zum Löschen von Skills'
        })
      }

      await prisma.userSkill.deleteMany({
        where: { userId }
      })

      // Activity Log erstellen
      await prisma.activityLog.create({
        data: {
          action: 'USER_SKILL_DELETE',
          description: `Alle Skills für Benutzer ${targetUser.firstName} ${targetUser.lastName} gelöscht`,
          userId: user.id,
          projectId: null,
          taskId: null,
          details: JSON.stringify({
            targetUserId: userId
          })
        }
      })

      return { 
        message: 'Alle Skills erfolgreich gelöscht'
      }
    }

    throw createError({
      statusCode: 405,
      statusMessage: 'Methode nicht erlaubt'
    })

  } catch (error: any) {
    if (error.statusCode) {
      throw error
    }

    console.error('User Skills API Error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Server-Fehler'
    })
  }
})
