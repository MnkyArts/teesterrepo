import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'
import { z } from 'zod'

const verifySkillSchema = z.object({
  skillId: z.string().cuid(),
  verified: z.boolean(),
  notes: z.string().optional()
})

export default defineEventHandler(async (event) => {
  try {
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Nicht authentifiziert'
      })
    }

    // Berechtigung prüfen - nur Projektleiter und Administratoren können verifizieren
    if (user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER') {
      throw createError({
        statusCode: 403,
        statusMessage: 'Keine Berechtigung für Skill-Verifizierung'
      })
    }

    const body = await readBody(event)
    const { skillId, verified, notes } = verifySkillSchema.parse(body)

    // Skill existence prüfen
    const skill = await prisma.userSkill.findUnique({
      where: { id: skillId },
      include: { user: true }
    })

    if (!skill) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Skill nicht gefunden'
      })
    }

    // Skill aktualisieren
    const updatedSkill = await prisma.userSkill.update({
      where: { id: skillId },
      data: {
        verified,
        verifiedBy: verified ? user.id : null,
        verifiedAt: verified ? new Date() : null
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true
          }
        }
      }
    })

    // Aktivitätslog erstellen
    await prisma.activityLog.create({
      data: {
        action: verified ? 'skill_verified' : 'skill_unverified',
        description: `Skill "${skill.name}" für ${skill.user.firstName} ${skill.user.lastName} ${verified ? 'verifiziert' : 'Verifizierung entfernt'}`,
        details: {
          skillId: skill.id,
          skillName: skill.name,
          skillLevel: skill.level,
          targetUserId: skill.userId,
          notes
        },
        userId: user.id
      }
    })

    return {
      success: true,
      skill: updatedSkill,
      message: verified ? 'Skill erfolgreich verifiziert' : 'Verifizierung entfernt'
    }

  } catch (error: any) {
    console.error('Fehler bei Skill-Verifizierung:', error)
    
    if (error.statusCode) {
      throw error
    }

    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Server-Fehler'
    })
  }
})
