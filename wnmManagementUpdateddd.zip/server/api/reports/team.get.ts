import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'
import type { User, TimeEntry, Task } from '@prisma/client'

type UserWithRelations = User & {
  timeEntries: TimeEntry[]
  assignedTasks: Task[]
}

export default defineEventHandler(async (event) => {
  // Require staff authentication
  const user = await requireAuth()(event)
  
  // Check if user has required role
  if (!['ADMINISTRATOR', 'PROJEKTLEITER'].includes(user.role)) {
    throw createError({
      statusCode: 403,
      statusMessage: 'Keine Berechtigung für diese Aktion'
    })
  }
  
  const query = getQuery(event)
  const startDate = query.startDate as string
  const endDate = query.endDate as string
  
  if (!startDate || !endDate) {
    throw createError({
      statusCode: 400,
      statusMessage: 'Start- und Enddatum sind erforderlich'
    })
  }

  try {
    const start = new Date(startDate)
    const end = new Date(endDate)
    end.setHours(23, 59, 59, 999)

    // Get team members
    const teamMembers: UserWithRelations[] = await prisma.user.findMany({
      where: {
        role: {
          in: ['ADMINISTRATOR', 'PROJEKTLEITER', 'ENTWICKLER', 'SUPPORTER']
        },
        isActive: true
      },
      include: {
        timeEntries: {
          where: {
            date: {
              gte: start,
              lte: end
            }
          }
        },
        assignedTasks: {
          where: {
            updatedAt: {
              gte: start,
              lte: end
            },
            status: {
              key: 'ERLEDIGT'
            }
          }
        },
        skills: true
      }
    })

    // Calculate team statistics
    const totalMembers = teamMembers.length
    const totalHours = teamMembers.reduce((sum, member) => 
      sum + member.timeEntries.reduce((memberSum: number, entry: TimeEntry) => memberSum + entry.hours, 0), 0
    )
    
    // Assuming 8h per day as target
    const workingDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24))
    const targetHours = totalMembers * workingDays * 8
    const avgUtilization = targetHours > 0 ? Math.round((totalHours / targetHours) * 100) : 0

    const completedTasks = teamMembers.reduce((sum, member) => sum + member.assignedTasks.length, 0)

    // Team productivity based on completed tasks vs time spent
    const teamProductivity = totalHours > 0 ? Math.round((completedTasks / totalHours) * 10) : 0

    // Team workload data
    const teamWorkload = teamMembers.map(member => {
      const memberHours = member.timeEntries.reduce((sum: number, entry: TimeEntry) => sum + entry.hours, 0)
      const memberTargetHours = workingDays * 8
      const utilization = memberTargetHours > 0 ? Math.round((memberHours / memberTargetHours) * 100) : 0
      
      return {
        name: `${member.firstName} ${member.lastName}`,
        utilization,
        capacity: 100
      }
    }).sort((a, b) => b.utilization - a.utilization)

    // Individual performance data
    const individualPerformance = teamMembers.map(member => {
      const memberHours = member.timeEntries.reduce((sum: number, entry: TimeEntry) => sum + entry.hours, 0)
      const memberTasks = member.assignedTasks.length
      const efficiency = memberHours > 0 ? Math.round((memberTasks / memberHours) * 100) : 0
      
      let performance: 'excellent' | 'good' | 'average' | 'below-average'
      if (efficiency >= 90) performance = 'excellent'
      else if (efficiency >= 70) performance = 'good'
      else if (efficiency >= 50) performance = 'average'
      else performance = 'below-average'

      return {
        id: member.id,
        name: `${member.firstName} ${member.lastName}`,
        role: getRoleDisplayName(member.role),
        image: null,
        completedTasks: memberTasks,
        hoursWorked: memberHours,
        efficiency,
        performance
      }
    }).sort((a, b) => b.efficiency - a.efficiency)

    return {
      totalMembers,
      avgUtilization,
      completedTasks,
      teamProductivity,
      teamWorkload: teamWorkload.slice(0, 10), // Top 10
      individualPerformance
    }

  } catch (error) {
    console.error('Team report error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Laden des Team-Berichts'
    })
  }
})

function getRoleDisplayName(role: string): string {
  const roles: Record<string, string> = {
    'ADMINISTRATOR': 'Administrator',
    'PROJEKTLEITER': 'Projektleiter',
    'ENTWICKLER': 'Entwickler',
    'SUPPORTER': 'Supporter',
    'VIEWER': 'Betrachter'
  }
  return roles[role] || role
}
