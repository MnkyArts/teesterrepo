import { requireAuth, getCurrentUser } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  // Nur GET-Anfragen erlauben
  assertMethod(event, 'GET')

  try {
    // Authentifizierung erforderlich
    await requireAuth()(event)
    const user = getCurrentUser(event)

    const query = getQuery(event)
    const { limit = '10' } = query

    // Recent activities abrufen - optimized query with limited data
    const userProjects = await prisma.projectMember.findMany({
      where: { userId: user.id },
      select: { projectId: true }
    })

    const projectIds = userProjects.map(pm => pm.projectId)

    // Falls Admin, alle Aktivitäten anzeigen
    const whereCondition = user.role === 'ADMINISTRATOR' 
      ? {}
      : projectIds.length > 0 
        ? { projectId: { in: projectIds } }
        : { projectId: 'none' } // Keine Aktivitäten wenn keine Projekte

    const activities = await prisma.activityLog.findMany({
      where: whereCondition,
      select: {
        id: true,
        action: true,
        description: true,
        createdAt: true,
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            image: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      },
      take: parseInt(limit as string)
    })

    return {
      success: true,
      data: activities
    }

  } catch (error: any) {
    if (error.statusCode) {
      throw error
    }

    console.error('Recent activities error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Laden der Aktivitäten'
    })
  }
})
