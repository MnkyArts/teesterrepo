import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  if (event.node.req.method === 'GET') {
    return await getTimeEntry(event)
  } else if (event.node.req.method === 'PUT') {
    return await updateTimeEntry(event)
  } else if (event.node.req.method === 'DELETE') {
    return await deleteTimeEntry(event)
  }
})

async function getTimeEntry(event: any) {
  try {
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Nicht authentifiziert'
      })
    }

    const timeEntryId = getRouterParam(event, 'id')
    if (!timeEntryId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Zeiteintrag-ID erforderlich'
      })
    }

    const timeEntry = await prisma.timeEntry.findFirst({
      where: {
        id: timeEntryId,
        // Users can only access their own time entries unless admin/projektleiter
        ...(user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER' ? { userId: user.id } : {})
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      }
    })

    if (!timeEntry) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Zeiteintrag nicht gefunden'
      })
    }

    return {
      timeEntry
    }

  } catch (error: any) {
    console.error('Error fetching time entry:', error)
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || 'Fehler beim Laden des Zeiteintrags'
    })
  }
}

async function updateTimeEntry(event: any) {
  try {
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Nicht authentifiziert'
      })
    }

    const timeEntryId = getRouterParam(event, 'id')
    if (!timeEntryId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Zeiteintrag-ID erforderlich'
      })
    }

    // Check if time entry exists and user has permission
    const existingEntry = await prisma.timeEntry.findFirst({
      where: {
        id: timeEntryId,
        // Users can only update their own time entries unless admin/projektleiter
        ...(user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER' ? { userId: user.id } : {})
      }
    })

    if (!existingEntry) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Zeiteintrag nicht gefunden oder keine Berechtigung'
      })
    }

    const body = await readBody(event)
    const { description, hours, date, category, billable, projectId, taskId } = body

    // Validation
    if (hours !== undefined && hours <= 0) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Stunden müssen größer als 0 sein'
      })
    }

    // Verify project if changing (remove member check for time tracking flexibility)
    if (projectId && projectId !== existingEntry.projectId) {
      const project = await prisma.project.findFirst({
        where: {
          id: projectId
        }
      })

      if (!project) {
        throw createError({
          statusCode: 404,
          statusMessage: 'Projekt nicht gefunden'
        })
      }
    }

    // Verify task if provided
    if (taskId) {
      const task = await prisma.task.findFirst({
        where: {
          id: taskId,
          projectId: projectId || existingEntry.projectId
        }
      })

      if (!task) {
        throw createError({
          statusCode: 400,
          statusMessage: 'Aufgabe nicht gefunden oder gehört nicht zum Projekt'
        })
      }
    }

    // Build update data
    const updateData: any = {}
    if (description !== undefined) updateData.description = description
    if (hours !== undefined) updateData.hours = parseFloat(hours)
    if (date !== undefined) updateData.date = new Date(date)
    if (category !== undefined) updateData.category = category
    if (billable !== undefined) updateData.billable = billable
    if (projectId !== undefined) updateData.projectId = projectId
    if (taskId !== undefined) updateData.taskId = taskId

    // Update time entry
    const timeEntry = await prisma.timeEntry.update({
      where: { id: timeEntryId },
      data: updateData,
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      }
    })

    // Log activity
    await prisma.activityLog.create({
      data: {
        action: 'time_entry_updated',
        description: `Zeiteintrag aktualisiert: ${timeEntry.hours}h für ${timeEntry.project.name}`,
        userId: user.id,
        projectId: timeEntry.projectId,
        taskId: timeEntry.taskId
      }
    })

    return {
      timeEntry
    }

  } catch (error: any) {
    console.error('Error updating time entry:', error)
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || 'Fehler beim Aktualisieren des Zeiteintrags'
    })
  }
}

async function deleteTimeEntry(event: any) {
  try {
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Nicht authentifiziert'
      })
    }

    const timeEntryId = getRouterParam(event, 'id')
    if (!timeEntryId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Zeiteintrag-ID erforderlich'
      })
    }

    // Check if time entry exists and user has permission
    const existingEntry = await prisma.timeEntry.findFirst({
      where: {
        id: timeEntryId,
        // Users can only delete their own time entries unless admin/projektleiter
        ...(user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER' ? { userId: user.id } : {})
      },
      include: {
        project: {
          select: {
            name: true
          }
        }
      }
    })

    if (!existingEntry) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Zeiteintrag nicht gefunden oder keine Berechtigung'
      })
    }

    // Delete time entry
    await prisma.timeEntry.delete({
      where: { id: timeEntryId }
    })

    // Log activity
    await prisma.activityLog.create({
      data: {
        action: 'time_entry_deleted',
        description: `Zeiteintrag gelöscht: ${existingEntry.hours}h für ${existingEntry.project.name}`,
        userId: user.id,
        projectId: existingEntry.projectId,
        taskId: existingEntry.taskId
      }
    })

    return {
      success: true
    }

  } catch (error: any) {
    console.error('Error deleting time entry:', error)
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || 'Fehler beim Löschen des Zeiteintrags'
    })
  }
}
