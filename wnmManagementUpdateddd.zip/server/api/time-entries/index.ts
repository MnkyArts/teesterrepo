import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  if (event.node.req.method === 'GET') {
    return await getTimeEntries(event)
  } else if (event.node.req.method === 'POST') {
    return await createTimeEntry(event)
  }
})

async function getTimeEntries(event: any) {
  try {
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Nicht authentifiziert'
      })
    }

    const query = getQuery(event)
    const { startDate, endDate, projectId, userId } = query

    // Build where clause
    const whereConditions: any = {}
    
    // Users can only see their own time entries unless they're admin/projektleiter
    if (user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER') {
      whereConditions.userId = user.id
    } else if (userId) {
      whereConditions.userId = userId as string
    } else {
      // Default to current user if no specific user requested
      whereConditions.userId = user.id
    }

    if (projectId) {
      whereConditions.projectId = projectId as string
    }

    if (startDate || endDate) {
      whereConditions.date = {}
      if (startDate) {
        whereConditions.date.gte = new Date(startDate as string)
      }
      if (endDate) {
        whereConditions.date.lte = new Date(endDate as string)
      }
    }

    const timeEntries = await prisma.timeEntry.findMany({
      where: whereConditions,
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      },
      orderBy: {
        date: 'desc'
      }
    })

    return {
      timeEntries
    }

  } catch (error: any) {
    console.error('Error fetching time entries:', error)
    throw createError({
      statusCode: 500,
      statusMessage: error.message || 'Fehler beim Laden der Zeiteinträge'
    })
  }
}

async function createTimeEntry(event: any) {
  try {
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Nicht authentifiziert'
      })
    }

    const body = await readBody(event)
    const { description, hours, date, category, billable, projectId, taskId } = body

    // Validation
    if (!hours || hours <= 0) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Stunden müssen größer als 0 sein'
      })
    }

    if (!date) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Datum ist erforderlich'
      })
    }

    if (!projectId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Projekt ist erforderlich'
      })
    }

    // Recommend but don't require taskId
    if (!taskId) {
      console.warn('Time entry created without task assignment - consider assigning to a task')
    }

    // Verify project exists (remove member check for time tracking flexibility)
    const project = await prisma.project.findFirst({
      where: {
        id: projectId
      }
    })

    if (!project) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Projekt nicht gefunden'
      })
    }

    // Verify task if provided
    if (taskId) {
      const task = await prisma.task.findFirst({
        where: {
          id: taskId,
          projectId: projectId
        }
      })

      if (!task) {
        throw createError({
          statusCode: 400,
          statusMessage: 'Aufgabe nicht gefunden oder gehört nicht zum Projekt'
        })
      }
    }

    // Create time entry
    const timeEntry = await prisma.timeEntry.create({
      data: {
        description: description || '',
        hours: parseFloat(hours),
        date: new Date(date),
        category: category || 'Entwicklung',
        billable: billable !== false, // Default to true
        userId: user.id,
        projectId,
        taskId: taskId || null
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      }
    })

    // Log activity
    await prisma.activityLog.create({
      data: {
        action: 'time_entry_created',
        description: `Zeiteintrag erstellt: ${hours}h für ${project.name}${taskId ? ` (${timeEntry.task?.key})` : ''}`,
        userId: user.id,
        projectId: projectId,
        taskId: taskId || null
      }
    })

    return {
      timeEntry
    }

  } catch (error: any) {
    console.error('Error creating time entry:', error)
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || 'Fehler beim Erstellen des Zeiteintrags'
    })
  }
}
