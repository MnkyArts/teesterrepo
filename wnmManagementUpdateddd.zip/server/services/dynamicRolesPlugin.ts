import { createAuthEndpoint, sessionMiddleware } from "better-auth/api";
import { createAuthMiddleware } from "better-auth/plugins";
import type { BetterAuthPlugin } from "better-auth";
import { APIError } from "better-call";

export interface DynamicRolesOptions {
  defaultRole?: string;
  adminRole?: string;
  maxRoleDepth?: number;
  enableWildcardPermissions?: boolean;
  cacheTimeout?: number;
}

export const dynamicRolesPlugin = (options: DynamicRolesOptions = {}) => {
  const {
    defaultRole = "user",
    adminRole = "admin",
    maxRoleDepth = 5,
    enableWildcardPermissions = true,
    cacheTimeout = 300000 // 5 minutes
  } = options;

  return {
    id: "dynamic-roles",
    schema: {
      // Roles table
      roles: {
        fields: {
          name: {
            type: "string",
            required: true,
            unique: true
          },
          displayName: {
            type: "string",
            required: true
          },
          description: {
            type: "string",
            required: false
          },
          priority: {
            type: "number",
            required: true
          },
          isDefault: {
            type: "boolean",
            required: true
          },
          isSystem: {
            type: "boolean",
            required: true
          },
          metadata: {
            type: "string", // JSON string
            required: false
          },
          createdAt: {
            type: "date",
            required: true
          },
          updatedAt: {
            type: "date",
            required: true
          }
        }
      },
      // Permissions table
      permissions: {
        fields: {
          name: {
            type: "string",
            required: true,
            unique: true
          },
          displayName: {
            type: "string",
            required: true
          },
          description: {
            type: "string",
            required: false
          },
          category: {
            type: "string",
            required: false
          },
          isSystem: {
            type: "boolean",
            required: true
          },
          metadata: {
            type: "string", // JSON string
            required: false
          },
          createdAt: {
            type: "date",
            required: true
          }
        }
      },
      // Role-Permission relationships
      rolePermissions: {
        fields: {
          roleId: {
            type: "string",
            required: true,
            references: {
              model: "roles",
              field: "id",
              onDelete: "cascade"
            }
          },
          permissionId: {
            type: "string",
            required: true,
            references: {
              model: "permissions",
              field: "id",
              onDelete: "cascade"
            }
          },
          granted: {
            type: "boolean",
            required: true
          },
          context: {
            type: "string", // JSON string for contextual permissions
            required: false
          },
          expiresAt: {
            type: "date",
            required: false
          },
          createdAt: {
            type: "date",
            required: true
          }
        }
      },
      // Role inheritance
      roleInheritance: {
        fields: {
          parentRoleId: {
            type: "string",
            required: true,
            references: {
              model: "roles",
              field: "id",
              onDelete: "cascade"
            }
          },
          childRoleId: {
            type: "string",
            required: true,
            references: {
              model: "roles",
              field: "id",
              onDelete: "cascade"
            }
          },
          priority: {
            type: "number",
            required: true
          },
          createdAt: {
            type: "date",
            required: true
          }
        }
      },
      // User roles
      userRoles: {
        fields: {
          userId: {
            type: "string",
            required: true,
            references: {
              model: "user",
              field: "id",
              onDelete: "cascade"
            }
          },
          roleId: {
            type: "string",
            required: true,
            references: {
              model: "roles",
              field: "id",
              onDelete: "cascade"
            }
          },
          context: {
            type: "string", // JSON string for contextual roles
            required: false
          },
          expiresAt: {
            type: "date",
            required: false
          },
          assignedBy: {
            type: "string",
            required: false,
            references: {
              model: "user",
              field: "id",
              onDelete: "set null"
            }
          },
          createdAt: {
            type: "date",
            required: true
          }
        }
      },
      // Direct user permissions (overrides)
      userPermissions: {
        fields: {
          userId: {
            type: "string",
            required: true,
            references: {
              model: "user",
              field: "id",
              onDelete: "cascade"
            }
          },
          permissionId: {
            type: "string",
            required: true,
            references: {
              model: "permissions",
              field: "id",
              onDelete: "cascade"
            }
          },
          granted: {
            type: "boolean",
            required: true
          },
          context: {
            type: "string", // JSON string
            required: false
          },
          expiresAt: {
            type: "date",
            required: false
          },
          assignedBy: {
            type: "string",
            required: false,
            references: {
              model: "user",
              field: "id",
              onDelete: "set null"
            }
          },
          createdAt: {
            type: "date",
            required: true
          }
        }
      }
    },
    
    endpoints: {
      // Role management endpoints
      createRole: createAuthEndpoint("/dynamic-roles/roles", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Authentication required" });
        }

        const hasPermission = await checkUserPermission(ctx, session.session.session.userId, "roles.create");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { name, displayName, description, priority, metadata } = ctx.body;
        
        const role = await ctx.context.adapter.create({
          model: "roles",
          data: {
            name,
            displayName,
            description,
            priority: priority || 0,
            isDefault: false,
            isSystem: false,
            metadata: metadata ? JSON.stringify(metadata) : null,
            createdAt: new Date(),
            updatedAt: new Date()
          }
        });

        return ctx.json({ role });
      }),

      updateRole: createAuthEndpoint("/dynamic-roles/roles/:id", {
        method: "PUT",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Authentication required" });
        }

        const hasPermission = await checkUserPermission(ctx, session.session.session.userId, "roles.update");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { id } = ctx.params;
        const { displayName, description, priority, metadata } = ctx.body;
        
        const role = await ctx.context.adapter.update({
          model: "roles",
          where: [{ field: "id", value: id }],
          update: {
            displayName,
            description,
            priority,
            metadata: metadata ? JSON.stringify(metadata) : null,
            updatedAt: new Date()
          }
        });

        return ctx.json({ role });
      }),

      deleteRole: createAuthEndpoint("/dynamic-roles/roles/:id", {
        method: "DELETE",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Authentication required" });
        }

        const hasPermission = await checkUserPermission(ctx, session.session.session.userId, "roles.delete");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { id } = ctx.params;
        
        // Check if role is system role
        const roles = await ctx.context.adapter.findMany({
          model: "roles",
          where: [{ field: "id", value: id }]
        });
        const role = roles[0];

        if ((role as any)?.isSystem) {
          throw new APIError("FORBIDDEN", { message: "Cannot delete system role" });
        }
        
        await ctx.context.adapter.delete({
          model: "roles",
          where: [{ field: "id", value: id }]
        });

        return ctx.json({ success: true });
      }),

      listRoles: createAuthEndpoint("/dynamic-roles/roles", {
        method: "GET",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Authentication required" });
        }

        const hasPermission = await checkUserPermission(ctx, session.session.session.userId, "roles.read");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const roles = await ctx.context.adapter.findMany({
          model: "roles",
          sortBy: { field: "priority", direction: "desc" }
        });

        return ctx.json({ roles });
      }),

      // Permission management endpoints
      createPermission: createAuthEndpoint("/dynamic-roles/permissions", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Authentication required" });
        }

        const hasPermission = await checkUserPermission(ctx, session.session.userId, "permissions.create");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { name, displayName, description, category, metadata } = ctx.body;
        
        const permission = await ctx.context.adapter.create({
          model: "permissions",
          data: {
            name,
            displayName,
            description,
            category,
            isSystem: false,
            metadata: metadata ? JSON.stringify(metadata) : null,
            createdAt: new Date()
          }
        });

        return ctx.json({ permission });
      }),

      listPermissions: createAuthEndpoint("/dynamic-roles/permissions", {
        method: "GET",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Authentication required" });
        }

        const hasPermission = await checkUserPermission(ctx, session.session.userId, "permissions.read");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const permissions = await ctx.context.adapter.findMany({
          model: "permissions",
          sortBy: { field: "category", direction: "asc" }
        });

        return ctx.json({ permissions });
      }),

      // Role-Permission assignment
      assignPermissionToRole: createAuthEndpoint("/dynamic-roles/roles/:roleId/permissions", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Authentication required" });
        }

        const hasPermission = await checkUserPermission(ctx, session.session.userId, "roles.permissions.assign");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { roleId } = ctx.params;
        const { permissionId, granted, context, expiresAt } = ctx.body;
        
        const assignment = await ctx.context.adapter.create({
          model: "rolePermissions",
          data: {
            roleId,
            permissionId,
            granted: granted !== false,
            context: context ? JSON.stringify(context) : null,
            expiresAt: expiresAt ? new Date(expiresAt) : null,
            createdAt: new Date()
          }
        });

        return ctx.json({ assignment });
      }),

      // User role assignment
      assignRoleToUser: createAuthEndpoint("/dynamic-roles/users/:userId/roles", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Authentication required" });
        }

        const hasPermission = await checkUserPermission(ctx, session.session.userId, "users.roles.assign");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { userId } = ctx.params;
        const { roleId, context, expiresAt } = ctx.body;
        
        const assignment = await ctx.context.adapter.create({
          model: "userRoles",
          data: {
            userId,
            roleId,
            context: context ? JSON.stringify(context) : null,
            expiresAt: expiresAt ? new Date(expiresAt) : null,
            assignedBy: session.session.userId,
            createdAt: new Date()
          }
        });

        return ctx.json({ assignment });
      }),

      // Check user permissions
      checkUserPermission: createAuthEndpoint("/dynamic-roles/users/:userId/permissions/:permission", {
        method: "GET",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Authentication required" });
        }

        const { userId, permission } = ctx.params;
        const contextParam = ctx.query?.context;
        
        // Users can check their own permissions, or need admin permission
        if (userId !== session.session.userId) {
          const hasPermission = await checkUserPermission(ctx, session.session.userId, "users.permissions.check");
          if (!hasPermission) {
            throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
          }
        }

        const hasPermission = await checkUserPermission(
          ctx, 
          userId, 
          permission, 
          contextParam ? JSON.parse(contextParam) : undefined
        );

        return ctx.json({ hasPermission });
      }),

      // Get user effective permissions
      getUserPermissions: createAuthEndpoint("/dynamic-roles/users/:userId/permissions", {
        method: "GET",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Authentication required" });
        }

        const { userId } = ctx.params;
        
        // Users can check their own permissions, or need admin permission
        if (userId !== session.session.userId) {
          const hasPermission = await checkUserPermission(ctx, session.session.userId, "users.permissions.read");
          if (!hasPermission) {
            throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
          }
        }

        const permissions = await getUserEffectivePermissions(ctx, userId);
        return ctx.json({ permissions });
      }),

      // Role inheritance
      setRoleInheritance: createAuthEndpoint("/dynamic-roles/roles/:parentId/inherit/:childId", {
        method: "POST",
        use: [sessionMiddleware],
      }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) {
          throw new APIError("UNAUTHORIZED", { message: "Authentication required" });
        }

        const hasPermission = await checkUserPermission(ctx, session.session.userId, "roles.inheritance.manage");
        if (!hasPermission) {
          throw new APIError("FORBIDDEN", { message: "Insufficient permissions" });
        }

        const { parentId, childId } = ctx.params;
        const { priority } = ctx.body;
        
        // Check for circular inheritance
        const wouldCreateCircle = await checkCircularInheritance(ctx, parentId, childId);
        if (wouldCreateCircle) {
          throw new APIError("BAD_REQUEST", { message: "Circular inheritance detected" });
        }

        const inheritance = await ctx.context.adapter.create({
          model: "roleInheritance",
          data: {
            parentRoleId: parentId,
            childRoleId: childId,
            priority: priority || 0,
            createdAt: new Date()
          }
        });

        return ctx.json({ inheritance });
      })
    },

    hooks: {
      after: [{
        matcher: (context) => {
          return context.path === "/sign-up/email" || context.path === "/sign-up";
        },
        handler: async (ctx) => {
          // Assign default role to new users - this will be handled by Better Auth's proper hook system
          return;
        }
      }]
    }
  } satisfies BetterAuthPlugin;

  // Helper functions
  async function checkUserPermission(
    ctx: { context: { adapter: any } }, 
    userId: string, 
    permission: string, 
    context?: Record<string, any>
  ): Promise<boolean> {
    const permissions = await getUserEffectivePermissions(ctx, userId);
    
    // Check exact permission match
    const exactMatch = permissions.find(p => p.name === permission);
    if (exactMatch) {
      return exactMatch.granted;
    }

    // Check wildcard permissions if enabled
    if (enableWildcardPermissions) {
      const wildcardMatch = permissions.find(p => {
        if (p.name.includes('*')) {
          const pattern = p.name.replace(/\*/g, '.*');
          return new RegExp(`^${pattern}$`).test(permission);
        }
        return false;
      });
      
      if (wildcardMatch) {
        return wildcardMatch.granted;
      }
    }

    return false;
  }

  async function getUserEffectivePermissions(ctx: { context: { adapter: any } }, userId: string) {
    // Get user's direct roles
    const userRoles = await ctx.context.adapter.findMany({
      model: "userRoles",
      where: { 
        userId,
        OR: [
          { expiresAt: null },
          { expiresAt: { gt: new Date() } }
        ]
      }
    });

    // Get all inherited roles
    const allRoles = await getAllInheritedRoles(ctx, userRoles.map((ur: any) => ur.roleId));

    // Get role permissions
    const rolePermissions = await ctx.context.adapter.findMany({
      model: "rolePermissions",
      where: {
        roleId: { in: allRoles.map((r: any) => r.id) },
        OR: [
          { expiresAt: null },
          { expiresAt: { gt: new Date() } }
        ]
      }
    });

    // Get direct user permissions
    const userPermissions = await ctx.context.adapter.findMany({
      model: "userPermissions",
      where: {
        userId,
        OR: [
          { expiresAt: null },
          { expiresAt: { gt: new Date() } }
        ]
      }
    });

    // Combine and resolve conflicts (user permissions override role permissions)
    const permissionMap = new Map();
    
    // Get permission details for role permissions
    for (const rp of rolePermissions) {
      const permissions = await ctx.context.adapter.findMany({
        model: "permissions",
        where: [{ field: "id", value: rp.permissionId }]
      });
      const permission = permissions[0];
      if (permission) {
        permissionMap.set(permission.name, {
          name: permission.name,
          granted: rp.granted,
          source: 'role'
        });
      }
    }

    // Override with user permissions
    for (const up of userPermissions) {
      const permissions = await ctx.context.adapter.findMany({
        model: "permissions", 
        where: [{ field: "id", value: up.permissionId }]
      });
      const permission = permissions[0];
      if (permission) {
        permissionMap.set(permission.name, {
          name: permission.name,
          granted: up.granted,
          source: 'user'
        });
      }
    }

    return Array.from(permissionMap.values());
  }

  async function getAllInheritedRoles(ctx: { context: { adapter: any } }, roleIds: string[]): Promise<Array<{ id: string; name: string; [key: string]: any }>> {
    const visited = new Set<string>();
    const result: any[] = [];
    
    async function processRoles(currentRoleIds: string[], depth = 0): Promise<void> {
      if (depth > maxRoleDepth) return;
      
      for (const roleId of currentRoleIds) {
        if (visited.has(roleId)) continue;
        visited.add(roleId);
        
        const roles = await ctx.context.adapter.findMany({
          model: "roles",
          where: [{ field: "id", value: roleId }]
        });
        const role = roles[0];
        
        if (role) {
          result.push(role);
          
          // Get inherited roles
          const inheritances = await ctx.context.adapter.findMany({
            model: "roleInheritance",
            where: [{ field: "childRoleId", value: roleId }],
            sortBy: { field: "priority", direction: "desc" }
          });
          
          const parentRoleIds = inheritances.map((i: any) => i.parentRoleId);
          if (parentRoleIds.length > 0) {
            await processRoles(parentRoleIds, depth + 1);
          }
        }
      }
    }
    
    await processRoles(roleIds);
    return result;
  }

  async function checkCircularInheritance(ctx: { context: { adapter: any } }, parentId: string, childId: string): Promise<boolean> {
    const visited = new Set<string>();
    
    async function checkPath(currentId: string): Promise<boolean> {
      if (currentId === parentId) return true;
      if (visited.has(currentId)) return false;
      visited.add(currentId);
      
      const inheritances = await ctx.context.adapter.findMany({
        model: "roleInheritance",
        where: [{ field: "childRoleId", value: currentId }]
      });
      
      for (const inheritance of inheritances) {
        if (await checkPath(inheritance.parentRoleId)) {
          return true;
        }
      }
      
      return false;
    }
    
    return await checkPath(childId);
  }
};