/**
 * Hydration-safe Plugin für Client-Server-Synchronisation
 */
export default defineNuxtPlugin(() => {
  // Track hydration state
  const isHydrated = ref(false)
  
  if (process.client) {
    // Mark as hydrated after client-side mounting
    onMounted(() => {
      isHydrated.value = true
    })
  } else {
    // Server-side always considered hydrated
    isHydrated.value = true
  }
  
  return {
    provide: {
      isHydrated: readonly(isHydrated)
    }
  }
})
