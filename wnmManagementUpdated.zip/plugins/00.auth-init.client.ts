/**
 * Optimized Auth Initialization Plugin
 * Minimiert Race Conditions und beschleunigt Auth-Prüfung
 */
export default defineNuxtPlugin({
  name: 'auth-init',
  async setup() {
    // Nur auf Client-Seite und nur einmal ausführen
    if (process.server) return

    // Ensure Pinia is available before using stores
    await nextTick()
    
    try {
      const authStore = useAuthStore()
      const { initializeAuth } = authStore
      const { isInitialized } = storeToRefs(authStore)
      
      // Sofortige synchrone Initialisierung wo möglich
      if (!isInitialized.value) {
        // Non-blocking initialization
        await nextTick()
        initializeAuth()
      }
    } catch (error) {
      console.warn('Auth store not yet available, will retry on route change')
    }
  },
  // Plugin vor Router-Navigation aber nicht blockierend
  enforce: 'pre'
})
