export default defineNuxtPlugin(async () => {
  // Better Auth auf Client-Seite initialisieren
  if (process.client) {
    try {
      // Ensure Pinia is available before using stores
      await nextTick()
      
      const authStore = useAuthStore()
      const { initializeAuth } = authStore
      
      // Authentifizierung initialisieren bevor Navigation startet
      await initializeAuth()
    } catch (error) {
      console.error('Failed to initialize Better Auth:', error)
    }
  }
})
