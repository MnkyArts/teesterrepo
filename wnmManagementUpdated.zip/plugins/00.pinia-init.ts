/**
 * Pinia Initialization Plugin
 * Stellt sicher, dass Pinia korrekt verfügbar ist
 */
export default defineNuxtPlugin({
  name: 'pinia-init',
  setup() {
    // Plugin läuft automatisch durch @pinia/nuxt
    // Dieser Plugin stellt nur sicher, dass Pinia verfügbar ist
    if (process.client) {
      // Auf Client-Seite: Warte auf DOM-Bereitschaft
      onMounted(() => {
        // Pinia ist jetzt definitiv verfügbar
      })
    }
  }
})
