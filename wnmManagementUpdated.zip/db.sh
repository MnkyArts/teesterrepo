#!/bin/bash

# Database Management Script for wnmManagement

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Database configuration
DB_CONTAINER="wnm_postgres"
DB_NAME="wnm_management"
DB_USER="wnm_user"

print_help() {
    echo -e "${BLUE}wnmManagement Database Management${NC}"
    echo ""
    echo "Usage: $0 [command]"
    echo ""
    echo "Commands:"
    echo "  start         Start database services"
    echo "  stop          Stop database services"
    echo "  restart       Restart database services"
    echo "  status        Show service status"
    echo "  logs          Show database logs"
    echo "  setup         Initial setup (start + migrate + seed)"
    echo "  migrate       Run Prisma migrations"
    echo "  seed          Run database seeding"
    echo "  reset         Reset database (drop + migrate + seed)"
    echo "  backup        Create database backup"
    echo "  restore       Restore database from backup"
    echo "  pgadmin       Start with pgAdmin for database management"
    echo "  psql          Connect to database with psql"
    echo "  help          Show this help message"
}

start_services() {
    echo -e "${BLUE}Starting database services...${NC}"
    docker-compose up -d postgres redis
    echo -e "${GREEN}Database services started!${NC}"
    echo ""
    echo "PostgreSQL: localhost:5432"
    echo "Redis: localhost:6379"
}

start_with_pgadmin() {
    echo -e "${BLUE}Starting database services with pgAdmin...${NC}"
    docker-compose --profile dev up -d
    echo -e "${GREEN}All services started!${NC}"
    echo ""
    echo "PostgreSQL: localhost:5432"
    echo "Redis: localhost:6379"
    echo "pgAdmin: http://localhost:8080"
    echo "  Email: admin@wnm.de"
    echo "  Password: admin123!"
}

stop_services() {
    echo -e "${BLUE}Stopping database services...${NC}"
    docker-compose down
    echo -e "${GREEN}Services stopped!${NC}"
}

restart_services() {
    echo -e "${BLUE}Restarting database services...${NC}"
    docker-compose restart postgres redis
    echo -e "${GREEN}Services restarted!${NC}"
}

show_status() {
    echo -e "${BLUE}Service Status:${NC}"
    docker-compose ps
}

show_logs() {
    echo -e "${BLUE}Database logs:${NC}"
    docker-compose logs -f postgres
}

wait_for_db() {
    echo -e "${YELLOW}Waiting for database to be ready...${NC}"
    while ! docker-compose exec postgres pg_isready -U $DB_USER -d $DB_NAME >/dev/null 2>&1; do
        sleep 1
    done
    echo -e "${GREEN}Database is ready!${NC}"
}

run_migrations() {
    echo -e "${BLUE}Running Prisma migrations...${NC}"
    bun prisma migrate dev
    echo -e "${GREEN}Migrations completed!${NC}"
}

run_seed() {
    echo -e "${BLUE}Seeding database...${NC}"
    bun prisma/seed.ts
    echo -e "${GREEN}Database seeded!${NC}"
}

setup_database() {
    start_services
    wait_for_db
    run_migrations
    run_seed
    echo -e "${GREEN}Database setup completed!${NC}"
}

reset_database() {
    echo -e "${YELLOW}This will reset your database and you'll lose all data!${NC}"
    read -p "Are you sure? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo -e "${BLUE}Resetting database...${NC}"
        bun prisma migrate reset --force
        echo -e "${GREEN}Database reset completed!${NC}"
    else
        echo -e "${YELLOW}Reset cancelled.${NC}"
    fi
}

backup_database() {
    BACKUP_FILE="backup_$(date +%Y%m%d_%H%M%S).sql"
    echo -e "${BLUE}Creating database backup: $BACKUP_FILE${NC}"
    docker-compose exec postgres pg_dump -U $DB_USER $DB_NAME > $BACKUP_FILE
    echo -e "${GREEN}Backup created: $BACKUP_FILE${NC}"
}

restore_database() {
    if [ -z "$2" ]; then
        echo -e "${RED}Please specify backup file: $0 restore <backup_file.sql>${NC}"
        exit 1
    fi
    
    BACKUP_FILE="$2"
    if [ ! -f "$BACKUP_FILE" ]; then
        echo -e "${RED}Backup file not found: $BACKUP_FILE${NC}"
        exit 1
    fi
    
    echo -e "${YELLOW}This will overwrite your current database!${NC}"
    read -p "Are you sure? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo -e "${BLUE}Restoring database from $BACKUP_FILE...${NC}"
        docker-compose exec -T postgres psql -U $DB_USER $DB_NAME < $BACKUP_FILE
        echo -e "${GREEN}Database restored!${NC}"
    else
        echo -e "${YELLOW}Restore cancelled.${NC}"
    fi
}

connect_psql() {
    echo -e "${BLUE}Connecting to database...${NC}"
    docker-compose exec postgres psql -U $DB_USER $DB_NAME
}

# Main command handling
case "$1" in
    start)
        start_services
        ;;
    stop)
        stop_services
        ;;
    restart)
        restart_services
        ;;
    status)
        show_status
        ;;
    logs)
        show_logs
        ;;
    setup)
        setup_database
        ;;
    migrate)
        run_migrations
        ;;
    seed)
        run_seed
        ;;
    reset)
        reset_database
        ;;
    backup)
        backup_database
        ;;
    restore)
        restore_database "$@"
        ;;
    pgadmin)
        start_with_pgadmin
        ;;
    psql)
        connect_psql
        ;;
    help|--help|-h)
        print_help
        ;;
    "")
        print_help
        ;;
    *)
        echo -e "${RED}Unknown command: $1${NC}"
        echo ""
        print_help
        exit 1
        ;;
esac
