import { defineStore } from 'pinia'

// Types
interface SepaMandate {
  id: string
  isActive: boolean
  createdAt: string
  updatedAt: string
  validUntil: string | null
  mandateId: string
  iban: string
  bic: string | null
  accountHolder: string
  signedDate: string
  customerId: string
}

interface SepaMandateData {
  iban: string
  bic?: string
  accountHolder: string
  validUntil?: string
}

export const useSepaStore = defineStore('sepa', () => {
  // State
  const mandate = ref<SepaMandate | null>(null)
  const loading = ref(false)
  const error = ref<string | null>(null)

  // Computed
  const hasActiveMandate = computed(() => 
    mandate.value?.isActive === true
  )

  const isMandateActive = computed(() => {
    if (!mandate.value) return false
    if (!mandate.value.isActive) return false
    
    if (mandate.value.validUntil) {
      const validUntil = new Date(mandate.value.validUntil)
      const now = new Date()
      return validUntil > now
    }
    
    return true
  })

  const isExpiringSoon = computed(() => {
    if (!mandate.value || !mandate.value.validUntil) return false
    
    const validUntil = new Date(mandate.value.validUntil)
    const now = new Date()
    const threeMonthsFromNow = new Date()
    threeMonthsFromNow.setMonth(threeMonthsFromNow.getMonth() + 3)
    
    return validUntil <= threeMonthsFromNow && validUntil > now
  })

  // Actions
  const loadMandate = async () => {
    loading.value = true
    error.value = null
    
    try {
      const data = await $fetch<SepaMandate>('/api/customer/sepa-mandate')
      mandate.value = data
      return data
    } catch (err: any) {
      if (err.status === 404) {
        // No mandate found
        mandate.value = null
      } else {
        error.value = err.data?.message || 'Fehler beim Laden des SEPA-Mandats'
        throw err
      }
    } finally {
      loading.value = false
    }
  }

  const saveMandate = async (mandateData: SepaMandateData) => {
    loading.value = true
    error.value = null
    
    try {
      const data = await $fetch<SepaMandate>('/api/customer/sepa-mandate', {
        method: mandate.value ? 'PUT' : 'POST',
        body: mandateData
      })
      
      mandate.value = data
      return data
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Speichern des SEPA-Mandats'
      throw err
    } finally {
      loading.value = false
    }
  }

  const revokeMandate = async () => {
    if (!mandate.value) return
    
    loading.value = true
    error.value = null
    
    try {
      await $fetch(`/api/customer/sepa-mandate/${mandate.value.id}`, {
        method: 'DELETE'
      })
      
      mandate.value = null
      return true
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Widerrufen des SEPA-Mandats'
      throw err
    } finally {
      loading.value = false
    }
  }

  // Utility functions
  const formatIban = (iban: string) => {
    if (!iban) return ''
    const cleanIban = iban.toUpperCase().replace(/\s/g, '')
    return cleanIban.match(/.{1,4}/g)?.join(' ') || cleanIban
  }

  const validateIban = (iban: string) => {
    if (!iban) return false
    const cleanIban = iban.toUpperCase().replace(/\s/g, '')
    
    // Grundlegende Format-Prüfung
    if (!/^[A-Z]{2}[0-9]{2}[A-Z0-9]+$/.test(cleanIban)) {
      return false
    }
    
    // Deutsche IBAN sollte 22 Zeichen haben
    if (cleanIban.startsWith('DE') && cleanIban.length !== 22) {
      return false
    }
    
    return true
  }

  const validateBic = (bic: string) => {
    if (!bic) return true // BIC is optional for German IBANs
    
    const cleanBic = bic.toUpperCase().replace(/\s/g, '')
    
    // BIC Format: 4 letters (bank code) + 2 letters (country) + 2 letters/digits (location) + optional 3 letters/digits (branch)
    return /^[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}([A-Z0-9]{3})?$/.test(cleanBic)
  }

  const getAnonymizedIban = (iban: string) => {
    if (!iban) return ''
    const cleanIban = iban.replace(/\s/g, '')
    if (cleanIban.length < 8) return iban
    
    const start = cleanIban.substring(0, 4)
    const end = cleanIban.substring(cleanIban.length - 4)
    const middle = '*'.repeat(cleanIban.length - 8)
    
    return formatIban(start + middle + end)
  }

  const formatDate = (date: string | Date) => {
    if (!date) return ''
    const d = new Date(date)
    return d.toLocaleDateString('de-DE', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    })
  }

  const clearMandate = () => {
    mandate.value = null
    error.value = null
  }

  return {
    // State
    mandate: readonly(mandate),
    loading: readonly(loading),
    error: readonly(error),
    
    // Computed
    hasActiveMandate,
    isMandateActive,
    isExpiringSoon,
    
    // Actions
    loadMandate,
    saveMandate,
    revokeMandate,
    clearMandate,
    
    // Utilities
    formatIban,
    validateIban,
    validateBic,
    getAnonymizedIban,
    formatDate
  }
})
