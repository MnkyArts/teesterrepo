import { defineStore } from 'pinia'
import { authClient } from '~/lib/auth-client'
import type { UserRole } from '@prisma/client'

// Extended user type for Better Auth with additional fields
export interface ExtendedUser {
  id: string
  name: string
  email: string
  emailVerified: boolean
  image?: string | null
  createdAt: Date
  updatedAt: Date
  firstName: string
  lastName: string
  role: UserRole
  avatar?: string | null
  isActive: boolean
  lastLoginAt?: Date | null
}

export interface LoginCredentials {
  email: string
  password: string
}

export interface RegisterData {
  email: string
  password: string
  firstName: string
  lastName: string
  role?: UserRole
}

export const useAuthStore = defineStore('auth', () => {
  // Better Auth session hook
  const session = authClient.useSession()
  
  // State
  const isLoading = ref<boolean>(false)
  const isInitialized = ref<boolean>(false)
  const hasCheckedAuth = ref<boolean>(false)
  
  // Singleton pattern for Auth-Initialisierung
  let initPromise: Promise<void> | null = null

  // Computed values based on Better Auth session
  const isLoggedIn = computed(() => !!session.value.data?.user)
  const user = computed(() => session.value.data?.user as ExtendedUser | null)
  
  // Full name computed property
  const fullName = computed(() => {
    if (!user.value) return ''
    return `${user.value.firstName} ${user.value.lastName}`.trim()
  })

  // Initials computed property
  const initials = computed(() => {
    if (!user.value) return ''
    const firstName = user.value.firstName || ''
    const lastName = user.value.lastName || ''
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
  })

  /**
   * Initialize auth - Optimized for performance
   */
  const initializeAuth = async () => {
    if (isInitialized.value) return
    if (initPromise) return initPromise

    initPromise = (async () => {
      try {
        isLoading.value = true
        
        // Session is automatically handled by Better Auth
        // Just mark as initialized and checked
        hasCheckedAuth.value = true
        isInitialized.value = true
      } catch (error) {
        console.error('Auth initialization failed:', error)
      } finally {
        isLoading.value = false
      }
    })()

    return initPromise
  }

  /**
   * Benutzer anmelden
   */
  const login = async (credentials: LoginCredentials): Promise<boolean> => {
    try {
      isLoading.value = true
      
      const result = await authClient.signIn.email({
        email: credentials.email,
        password: credentials.password,
      })

      if (result.error) {
        throw new Error(result.error.message || 'Login fehlgeschlagen')
      }

      return true
    } catch (error: any) {
      console.error('Login error:', error)
      throw error
    } finally {
      isLoading.value = false
    }
  }

  /**
   * Benutzer registrieren
   */
  const register = async (userData: RegisterData): Promise<boolean> => {
    try {
      isLoading.value = true
      
      const result = await authClient.signUp.email({
        email: userData.email,
        password: userData.password,
        name: `${userData.firstName} ${userData.lastName}`,
      })

      if (result.error) {
        throw new Error(result.error.message || 'Registrierung fehlgeschlagen')
      }

      return true
    } catch (error: any) {
      console.error('Registration error:', error)
      throw error
    } finally {
      isLoading.value = false
    }
  }

  /**
   * Benutzer abmelden
   */
  const logout = async (): Promise<void> => {
    try {
      isLoading.value = true
      
      await authClient.signOut({
        fetchOptions: {
          onSuccess: () => {
            // Clear any client-side state if needed
            hasCheckedAuth.value = false
          }
        }
      })
    } catch (error: any) {
      console.error('Logout error:', error)
      throw error
    } finally {
      isLoading.value = false
    }
  }

  /**
   * Passwort ändern
   */
  const changePassword = async (currentPassword: string, newPassword: string): Promise<boolean> => {
    try {
      isLoading.value = true
      
      const result = await authClient.changePassword({
        currentPassword,
        newPassword,
        revokeOtherSessions: true,
      })

      if (result.error) {
        throw new Error(result.error.message || 'Passwort-Änderung fehlgeschlagen')
      }

      return true
    } catch (error: any) {
      console.error('Change password error:', error)
      throw error
    } finally {
      isLoading.value = false
    }
  }

  /**
   * Überprüft Berechtigung basierend auf Rolle
   */
  const hasPermission = (requiredRole: UserRole): boolean => {
    if (!user.value) return false

    const roleHierarchy: Record<UserRole, number> = {
      'KUNDE': 1,
      'VIEWER': 2,
      'SUPPORTER': 3,
      'ENTWICKLER': 4,
      'PROJEKTLEITER': 5,
      'ADMINISTRATOR': 6
    }

    const userLevel = roleHierarchy[user.value.role] || 0
    const requiredLevel = roleHierarchy[requiredRole] || 0

    return userLevel >= requiredLevel
  }

  /**
   * Überprüft ob Benutzer Administrator ist
   */
  const isAdmin = computed(() => hasPermission('ADMINISTRATOR'))

  /**
   * Überprüft ob Benutzer Projektleiter ist
   */
  const isProjectManager = computed(() => hasPermission('PROJEKTLEITER'))

  /**
   * Überprüft ob Benutzer Teammitglied ist
   */
  const isTeamMember = computed(() => hasPermission('ENTWICKLER'))

  return {
    // State
    isLoading: readonly(isLoading),
    isInitialized: readonly(isInitialized),
    hasCheckedAuth: readonly(hasCheckedAuth),
    
    // Computed
    isLoggedIn,
    user,
    fullName,
    initials,
    isAdmin,
    isProjectManager,
    isTeamMember,
    
    // Actions
    initializeAuth,
    login,
    register,
    logout,
    changePassword,
    hasPermission
  }
})
