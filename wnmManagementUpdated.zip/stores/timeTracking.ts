export interface TimeEntry {
  id: string
  description?: string
  hours: number
  date: string
  category: string
  billable: boolean
  createdAt: string
  updatedAt: string
  user: {
    id: string
    firstName: string
    lastName: string
  }
  project: {
    id: string
    name: string
    key: string
  }
  task?: {
    id: string
    title: string
    key: string
  }
}

export interface ActiveTimer {
  id?: string
  taskId: string // Made required
  projectId: string
  description: string
  category: string
  startTime: Date
  elapsedSeconds: number
}

export interface TimeTrackingStats {
  todayTotal: number
  weekTotal: number
  monthTotal: number
  billableToday: number
  nonBillableToday: number
  targetDailyHours: number
  projectBreakdown: Array<{
    projectId: string
    projectName: string
    hours: number
    percentage: number
  }>
}

export const useTimeTrackingStore = defineStore('timeTracking', () => {
  const notificationsStore = useNotificationsStore()
  const authStore = useAuthStore()

  // State
  const timeEntries = ref<TimeEntry[]>([])
  const activeTimer = ref<ActiveTimer | null>(null)
  const stats = ref<TimeTrackingStats | null>(null)
  const isLoading = ref(false)
  const error = ref<string | null>(null)

  // Timer state
  const timerInterval = ref<NodeJS.Timeout | null>(null)

  // Computed
  const isTimerRunning = computed(() => activeTimer.value !== null)
  
  const formattedElapsedTime = computed(() => {
    if (!activeTimer.value) return '00:00:00'
    return formatDuration(activeTimer.value.elapsedSeconds)
  })

  const todayEntries = computed(() => {
    const today = new Date().toISOString().split('T')[0]
    return timeEntries.value.filter(entry => entry.date === today)
  })

  const weekEntries = computed(() => {
    const now = new Date()
    const startOfWeek = getStartOfWeek(now)
    const endOfWeek = getEndOfWeek(now)
    
    return timeEntries.value.filter(entry => {
      const entryDate = new Date(entry.date)
      return entryDate >= startOfWeek && entryDate <= endOfWeek
    })
  })

  const todayTotal = computed(() => {
    return todayEntries.value.reduce((total, entry) => total + entry.hours, 0)
  })

  const weekTotal = computed(() => {
    return weekEntries.value.reduce((total, entry) => total + entry.hours, 0)
  })

  // Utility functions
  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const formatHours = (hours: number): string => {
    const h = Math.floor(hours)
    const m = Math.round((hours - h) * 60)
    if (m === 0) {
      return `${h}h`
    }
    return `${h}h ${m}m`
  }

  const getStartOfWeek = (date: Date): Date => {
    const d = new Date(date)
    const day = d.getDay()
    const diff = d.getDate() - day + (day === 0 ? -6 : 1) // Adjust when day is Sunday
    return new Date(d.setDate(diff))
  }

  const getEndOfWeek = (date: Date): Date => {
    const startOfWeek = getStartOfWeek(date)
    return new Date(startOfWeek.getTime() + 6 * 24 * 60 * 60 * 1000)
  }

  // Actions - Updated to match composable API endpoints
  const fetchTimeEntries = async (filters?: {
    startDate?: string
    endDate?: string
    projectId?: string
    userId?: string
  }) => {
    isLoading.value = true
    error.value = null

    try {
      const query = new URLSearchParams()
      if (filters?.startDate) query.append('startDate', filters.startDate)
      if (filters?.endDate) query.append('endDate', filters.endDate)
      if (filters?.projectId) query.append('projectId', filters.projectId)
      if (filters?.userId) query.append('userId', filters.userId)

      // Updated to match composable endpoint structure
      const response = await $fetch<{ timeEntries: TimeEntry[] }>(
        `/api/time-entries${query.toString() ? '?' + query.toString() : ''}`
      )
      timeEntries.value = response.timeEntries

      return response.timeEntries
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Laden der Zeiteinträge'
      notificationsStore.error('Fehler', error.value || 'Unbekannter Fehler')
      throw err
    } finally {
      isLoading.value = false
    }
  }

  const createTimeEntry = async (entry: {
    description?: string
    hours: number
    date: string
    category: string
    billable: boolean
    projectId: string
    taskId?: string
  }) => {
    try {
      // Updated to match composable endpoint structure
      const response = await $fetch<{ timeEntry: TimeEntry }>('/api/time-entries', {
        method: 'POST',
        body: entry
      })

      timeEntries.value.unshift(response.timeEntry)
      notificationsStore.success('Erfolg', 'Zeiteintrag erstellt')

      return response.timeEntry
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Erstellen des Zeiteintrags'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const updateTimeEntry = async (entryId: string, updates: Partial<TimeEntry>) => {
    try {
      // Updated to match composable endpoint structure
      const response = await $fetch<{ timeEntry: TimeEntry }>(`/api/time-entries/${entryId}`, {
        method: 'PUT',
        body: updates
      })

      const index = timeEntries.value.findIndex(e => e.id === entryId)
      if (index !== -1) {
        timeEntries.value[index] = response.timeEntry
      }

      notificationsStore.success('Erfolg', 'Zeiteintrag aktualisiert')

      return response.timeEntry
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Aktualisieren des Zeiteintrags'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const deleteTimeEntry = async (entryId: string) => {
    try {
      await $fetch(`/api/time-entries/${entryId}`, {
        method: 'DELETE'
      })

      timeEntries.value = timeEntries.value.filter(e => e.id !== entryId)
      notificationsStore.success('Erfolg', 'Zeiteintrag gelöscht')

      return true
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Löschen des Zeiteintrags'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  // Timer functions
  const startTimer = (taskId: string, projectId: string, description = '', category = 'development') => {
    if (activeTimer.value) {
      stopTimer()
    }

    activeTimer.value = {
      taskId,
      projectId,
      description,
      category,
      startTime: new Date(),
      elapsedSeconds: 0
    }

    // Start interval to update elapsed time
    timerInterval.value = setInterval(() => {
      if (activeTimer.value) {
        const now = new Date()
        activeTimer.value.elapsedSeconds = Math.floor(
          (now.getTime() - activeTimer.value.startTime.getTime()) / 1000
        )
      }
    }, 1000)

    notificationsStore.info('Timer gestartet', 'Zeiterfassung läuft')
  }

  const stopTimer = async (saveEntry = true) => {
    if (!activeTimer.value) return null

    const timer = activeTimer.value
    
    // Clear interval
    if (timerInterval.value) {
      clearInterval(timerInterval.value)
      timerInterval.value = null
    }

    // Reset active timer
    activeTimer.value = null

    if (saveEntry && timer.elapsedSeconds > 0) {
      const hours = timer.elapsedSeconds / 3600
      
      try {
        const entry = await createTimeEntry({
          description: timer.description,
          hours: Math.round(hours * 100) / 100, // Round to 2 decimal places
          date: new Date().toISOString().split('T')[0],
          category: timer.category,
          billable: true, // Default to billable
          projectId: timer.projectId,
          taskId: timer.taskId
        })

        notificationsStore.success('Timer gestoppt', `${formatHours(hours)} erfasst`)
        return entry
      } catch (error) {
        notificationsStore.error('Fehler', 'Zeiterfassung konnte nicht gespeichert werden')
        return null
      }
    } else {
      notificationsStore.info('Timer gestoppt', 'Keine Zeit erfasst')
      return null
    }
  }

  const pauseTimer = () => {
    if (timerInterval.value) {
      clearInterval(timerInterval.value)
      timerInterval.value = null
    }
  }

  const resumeTimer = () => {
    if (activeTimer.value && !timerInterval.value) {
      // Adjust start time to account for already elapsed time
      const now = new Date()
      activeTimer.value.startTime = new Date(now.getTime() - activeTimer.value.elapsedSeconds * 1000)
      
      timerInterval.value = setInterval(() => {
        if (activeTimer.value) {
          const now = new Date()
          activeTimer.value.elapsedSeconds = Math.floor(
            (now.getTime() - activeTimer.value.startTime.getTime()) / 1000
          )
        }
      }, 1000)
    }
  }

  const fetchStats = async () => {
    try {
      // Updated to match composable endpoint structure
      const response = await $fetch<{ stats: TimeTrackingStats }>('/api/time-entries/stats')
      stats.value = response.stats
      return response.stats
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Laden der Statistiken'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  // Cleanup timer on unmount
  const cleanup = () => {
    if (timerInterval.value) {
      clearInterval(timerInterval.value)
      timerInterval.value = null
    }
  }

  // Additional missing methods
  const exportTimeEntries = async (startDate: string, endDate: string, format = 'csv') => {
    try {
      const response = await $fetch(`/api/time-tracking/export`, {
        method: 'GET',
        query: {
          startDate,
          endDate,
          format
        }
      })
      return response
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Exportieren der Zeiteinträge'
      notificationsStore.error('Fehler', 'Export fehlgeschlagen')
      throw err
    }
  }

  // Helper functions for weekly reports (different from the ones above)
  const getWeekStart = (date = new Date()) => {
    const d = new Date(date)
    const day = d.getDay()
    const diff = d.getDate() - day + (day === 0 ? -6 : 1) // Adjust when day is Sunday
    return new Date(d.setDate(diff))
  }

  const getWeekEnd = (date = new Date()) => {
    const start = getWeekStart(date)
    return new Date(start.getTime() + 6 * 24 * 60 * 60 * 1000)
  }

  return {
    // State
    timeEntries: readonly(timeEntries),
    activeTimer: readonly(activeTimer),
    stats: readonly(stats),
    isLoading: readonly(isLoading),
    error: readonly(error),
    
    // Computed
    isTimerRunning,
    formattedElapsedTime,
    todayEntries,
    weekEntries,
    todayTotal,
    weekTotal,
    
    // Actions
    fetchTimeEntries,
    createTimeEntry,
    updateTimeEntry,
    deleteTimeEntry,
    startTimer,
    stopTimer,
    pauseTimer,
    resumeTimer,
    fetchStats,
    cleanup,
    exportTimeEntries,
    getWeekStart,
    getWeekEnd,
    
    // Utilities
    formatDuration,
    formatHours
  }
})