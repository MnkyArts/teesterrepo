import { defineStore } from 'pinia'
import type { User, UserRole } from '@prisma/client'

interface TeamMember extends User {
  isOnline?: boolean
  lastActivity?: Date
  skills?: UserSkill[]
  workload?: number
  availability?: 'available' | 'busy' | 'away' | 'offline'
}

interface UserSkill {
  id: string
  name: string
  category: string
  level: 1 | 2 | 3 | 4 | 5
  experience?: string
  verified?: boolean
  verifiedBy?: string
  verifiedAt?: Date
}

interface TeamStatistics {
  totalMembers: number
  activeMembers: number
  onlineMembers: number
  averageWorkload: number
  skillDistribution: Record<string, number>
  roleDistribution: Record<UserRole, number>
}

interface CreateUserRequest {
  email: string
  firstName: string
  lastName: string
  role: UserRole
  avatar?: string
  skills?: Omit<UserSkill, 'id'>[]
  isActive?: boolean
}

interface UpdateUserRequest {
  firstName?: string
  lastName?: string
  email?: string
  role?: UserRole
  avatar?: string
  isActive?: boolean
}

interface UserFilters {
  role?: UserRole
  isActive?: boolean
  skills?: string[]
  availability?: string
  search?: string
}

interface SkillMatrixData {
  skillMatrix: Array<{
    category: string
    totalSkills: number
    skills: Array<{
      name: string
      totalUsers: number
      averageLevel: number
      maxLevel: number
      verifiedCount: number
      verificationRate: number
      users: Array<{
        user: User
        level: number
        verified: boolean
        verifiedBy?: string
        verifiedAt?: Date
        experience?: string
      }>
    }>
  }>
  topSkills: Array<{
    name: string
    totalUsers: number
    averageLevel: number
  }>
  skillCoverage: Array<{
    user: User
    totalSkills: number
    verifiedSkills: number
    averageLevel: number
    categories: string[]
    skillCoveragePercent: number
  }>
  summary: {
    totalSkills: number
    totalCategories: number
    totalTeamMembers: number
    averageSkillsPerMember: number
    verificationRate: number
  }
  lastUpdated: string
}

interface BulkActionRequest {
  action: 'activate' | 'deactivate' | 'change_role' | 'delete'
  userIds: string[]
  newRole?: UserRole
}

export const useTeamManagementStore = defineStore('teamManagement', () => {
  const notificationsStore = useNotificationsStore()
  const authStore = useAuthStore()

  // State
  const teamMembers = ref<TeamMember[]>([])
  const currentUser = ref<TeamMember | null>(null)
  const statistics = ref<TeamStatistics | null>(null)
  const skillMatrix = ref<SkillMatrixData | null>(null)
  const isLoading = ref(false)
  const error = ref<string | null>(null)

  // User roles with German labels
  const userRoles = [
    { label: 'Administrator', value: 'ADMINISTRATOR' as UserRole, description: 'Vollzugriff auf alle Systemfunktionen' },
    { label: 'Projektleiter', value: 'PROJEKTLEITER' as UserRole, description: 'Verwaltung von Projekten und Teams' },
    { label: 'Entwickler', value: 'ENTWICKLER' as UserRole, description: 'Entwicklungsaufgaben und Code-Review' },
    { label: 'Supporter', value: 'SUPPORTER' as UserRole, description: 'Kundensupport und Ticketbearbeitung' },
    { label: 'Viewer', value: 'VIEWER' as UserRole, description: 'Nur-Lese-Zugriff auf Projektinformationen' },
    { label: 'Kunde', value: 'KUNDE' as UserRole, description: 'Kunde mit eingeschränktem Zugriff' },
  ]

  // Computed
  const activeMembers = computed(() => 
    teamMembers.value.filter(member => member.isActive)
  )

  const membersByRole = computed(() => {
    const grouped = new Map<UserRole, TeamMember[]>()
    teamMembers.value.forEach(member => {
      if (!grouped.has(member.role)) {
        grouped.set(member.role, [])
      }
      grouped.get(member.role)!.push(member)
    })
    return grouped
  })

  const onlineMembers = computed(() => 
    teamMembers.value.filter(member => member.isOnline)
  )

  // Actions
  const fetchTeamMembers = async (filters?: UserFilters) => {
    isLoading.value = true
    error.value = null

    try {
      const query = new URLSearchParams()
      if (filters?.role) query.append('role', filters.role)
      if (filters?.isActive !== undefined) query.append('isActive', filters.isActive.toString())
      if (filters?.search) query.append('search', filters.search)
      if (filters?.availability) query.append('availability', filters.availability)
      if (filters?.skills?.length) {
        filters.skills.forEach(skill => query.append('skills', skill))
      }

      const response = await $fetch<{ users: TeamMember[], total: number }>(`/api/users?${query.toString()}`)
      teamMembers.value = response.users.map(member => ({
        ...member,
        lastActivity: member.lastActivity ? new Date(member.lastActivity) : undefined
      }))

      return response
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Laden der Team-Mitglieder'
      notificationsStore.error('Fehler', error.value || 'Unbekannter Fehler')
      throw err
    } finally {
      isLoading.value = false
    }
  }

  const fetchUser = async (userId: string) => {
    try {
      const user = await $fetch<TeamMember>(`/api/users/${userId}`)
      currentUser.value = {
        ...user,
        lastActivity: user.lastActivity ? new Date(user.lastActivity) : undefined
      }

      // Update in team members list if exists
      const index = teamMembers.value.findIndex(m => m.id === userId)
      if (index !== -1) {
        teamMembers.value[index] = currentUser.value
      }

      return currentUser.value
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Laden des Benutzers'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const createUser = async (userData: CreateUserRequest) => {
    try {
      const newUser = await $fetch<TeamMember>('/api/users', {
        method: 'POST',
        body: userData
      })

      teamMembers.value.unshift(newUser)
      notificationsStore.success('Erfolg', 'Benutzer wurde erfolgreich erstellt')

      return newUser
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Erstellen des Benutzers'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const updateUser = async (userId: string, updates: UpdateUserRequest) => {
    try {
      const updatedUser = await $fetch<TeamMember>(`/api/users/${userId}`, {
        method: 'PUT',
        body: updates
      })

      // Update in team members list
      const index = teamMembers.value.findIndex(m => m.id === userId)
      if (index !== -1) {
        teamMembers.value[index] = updatedUser
      }

      // Update current user if it's the same
      if (currentUser.value?.id === userId) {
        currentUser.value = updatedUser
      }

      notificationsStore.success('Erfolg', 'Benutzer wurde erfolgreich aktualisiert')

      return updatedUser
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Aktualisieren des Benutzers'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const deleteUser = async (userId: string) => {
    try {
      await $fetch(`/api/users/${userId}`, {
        method: 'DELETE'
      })

      // Remove from team members list
      teamMembers.value = teamMembers.value.filter(m => m.id !== userId)

      // Clear current user if it's the deleted one
      if (currentUser.value?.id === userId) {
        currentUser.value = null
      }

      notificationsStore.success('Erfolg', 'Benutzer wurde erfolgreich gelöscht')

      return true
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Löschen des Benutzers'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const bulkAction = async (action: BulkActionRequest) => {
    try {
      const result = await $fetch('/api/users/bulk-actions', {
        method: 'POST',
        body: action
      })

      // Refresh team members after bulk action
      await fetchTeamMembers()

      const actionText = {
        activate: 'aktiviert',
        deactivate: 'deaktiviert',
        change_role: 'Rolle geändert',
        delete: 'gelöscht'
      }[action.action]

      notificationsStore.success('Erfolg', `${action.userIds.length} Benutzer ${actionText}`)

      return result
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler bei der Bulk-Aktion'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const fetchStatistics = async () => {
    try {
      const data = await $fetch<TeamStatistics>('/api/users/statistics')
      statistics.value = data
      return data
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Laden der Statistiken'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const fetchSkillMatrix = async () => {
    isLoading.value = true
    try {
      const data = await $fetch<SkillMatrixData>('/api/users/skill-matrix')
      skillMatrix.value = data
      return data
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Laden der Skill-Matrix'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    } finally {
      isLoading.value = false
    }
  }

  const updateUserSkill = async (userId: string, skillId: string, updates: Partial<UserSkill>) => {
    try {
      // Note: This endpoint may need to be implemented on the server
      // Currently using the generic skills endpoint pattern
      const updatedSkill = await $fetch<UserSkill>(`/api/users/${userId}/skills/${skillId}`, {
        method: 'PUT',
        body: updates
      })

      // Update skill in current user if applicable
      if (currentUser.value?.id === userId && currentUser.value.skills) {
        const skillIndex = currentUser.value.skills.findIndex(s => s.id === skillId)
        if (skillIndex !== -1) {
          currentUser.value.skills[skillIndex] = updatedSkill
        }
      }

      // Update skill in team member
      const memberIndex = teamMembers.value.findIndex(m => m.id === userId)
      if (memberIndex !== -1 && teamMembers.value[memberIndex].skills) {
        const skillIndex = teamMembers.value[memberIndex].skills!.findIndex(s => s.id === skillId)
        if (skillIndex !== -1) {
          teamMembers.value[memberIndex].skills![skillIndex] = updatedSkill
        }
      }

      notificationsStore.success('Erfolg', 'Skill wurde aktualisiert')

      return updatedSkill
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Aktualisieren des Skills'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const addUserSkill = async (userId: string, skillData: Omit<UserSkill, 'id'>) => {
    try {
      const response = await $fetch<{ skills: UserSkill[] }>(`/api/users/${userId}/skills`, {
        method: 'POST',
        body: { skills: [skillData] }
      })

      const newSkill = response.skills[0]

      // Add skill to current user if applicable
      if (currentUser.value?.id === userId) {
        if (!currentUser.value.skills) currentUser.value.skills = []
        currentUser.value.skills.push(newSkill)
      }

      // Add skill to team member
      const memberIndex = teamMembers.value.findIndex(m => m.id === userId)
      if (memberIndex !== -1) {
        if (!teamMembers.value[memberIndex].skills) teamMembers.value[memberIndex].skills = []
        teamMembers.value[memberIndex].skills!.push(newSkill)
      }

      notificationsStore.success('Erfolg', 'Skill wurde hinzugefügt')

      return newSkill
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Hinzufügen des Skills'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const addUserSkills = async (userId: string, skills: Omit<UserSkill, 'id'>[]) => {
    try {
      const response = await $fetch<{ skills: UserSkill[] }>(`/api/users/${userId}/skills`, {
        method: 'POST',
        body: { skills }
      })

      // Add skills to current user if applicable
      if (currentUser.value?.id === userId) {
        if (!currentUser.value.skills) currentUser.value.skills = []
        currentUser.value.skills.push(...response.skills)
      }

      // Add skills to team member
      const memberIndex = teamMembers.value.findIndex(m => m.id === userId)
      if (memberIndex !== -1) {
        if (!teamMembers.value[memberIndex].skills) teamMembers.value[memberIndex].skills = []
        teamMembers.value[memberIndex].skills!.push(...response.skills)
      }

      notificationsStore.success('Erfolg', 'Skills wurden erfolgreich hinzugefügt')

      return response.skills
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Hinzufügen des Skills'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const removeUserSkill = async (userId: string, skillId: string) => {
    try {
      // Note: This endpoint may need to be implemented on the server
      // Currently using the generic skills endpoint pattern  
      await $fetch(`/api/users/${userId}/skills/${skillId}`, {
        method: 'DELETE'
      })

      // Remove skill from current user if applicable
      if (currentUser.value?.id === userId && currentUser.value.skills) {
        currentUser.value.skills = currentUser.value.skills.filter(s => s.id !== skillId)
      }

      // Remove skill from team member
      const memberIndex = teamMembers.value.findIndex(m => m.id === userId)
      if (memberIndex !== -1 && teamMembers.value[memberIndex].skills) {
        teamMembers.value[memberIndex].skills = teamMembers.value[memberIndex].skills!.filter(s => s.id !== skillId)
      }

      notificationsStore.success('Erfolg', 'Skill wurde entfernt')

      return true
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Entfernen des Skills'
      notificationsStore.error('Fehler', errorMessage)
      throw err
    }
  }

  const setCurrentUser = (user: TeamMember | null) => {
    currentUser.value = user
  }

  const clearTeamData = () => {
    teamMembers.value = []
    currentUser.value = null
    statistics.value = null
    skillMatrix.value = null
    error.value = null
  }

  // Missing methods needed by components
  const verifySkill = async (userId: string, skillId: string) => {
    try {
      const response = await $fetch(`/api/users/skills/verify`, {
        method: 'POST',
        body: {
          skillId,
          verified: true
        }
      })
      
      // Update skill in team member
      const memberIndex = teamMembers.value.findIndex(m => m.id === userId)
      if (memberIndex !== -1 && teamMembers.value[memberIndex].skills) {
        const skillIndex = teamMembers.value[memberIndex].skills!.findIndex(s => s.id === skillId)
        if (skillIndex !== -1) {
          teamMembers.value[memberIndex].skills![skillIndex].verified = true
          teamMembers.value[memberIndex].skills![skillIndex].verifiedAt = new Date()
        }
      }

      notificationsStore.addNotification({
        type: 'success',
        title: 'Erfolg',
        message: 'Skill wurde verifiziert'
      })

      return response
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Verifizieren des Skills'
      notificationsStore.addNotification({
        type: 'error',
        title: 'Fehler',
        message: errorMessage
      })
      throw err
    }
  }

  const fetchTeamStatistics = async () => {
    try {
      isLoading.value = true
      const stats = await $fetch<TeamStatistics>('/api/users/statistics')
      statistics.value = stats
      return stats
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Laden der Team-Statistiken'
      notificationsStore.addNotification({
        type: 'error',
        title: 'Fehler',
        message: 'Team-Statistiken konnten nicht geladen werden'
      })
      throw err
    } finally {
      isLoading.value = false
    }
  }

  const selectedUsers = ref<string[]>([])

  const toggleUserSelection = (userId: string) => {
    const index = selectedUsers.value.indexOf(userId)
    if (index > -1) {
      selectedUsers.value.splice(index, 1)
    } else {
      selectedUsers.value.push(userId)
    }
  }

  const clearUserSelection = () => {
    selectedUsers.value = []
  }

  const executeBulkAction = async (action: string, userIds: string[], data?: any) => {
    try {
      isLoading.value = true
      const response = await $fetch('/api/users/bulk-actions', {
        method: 'POST',
        body: {
          action,
          userIds,
          data
        }
      })

      // Refresh team members after bulk action
      await fetchTeamMembers()

      notificationsStore.addNotification({
        type: 'success',
        title: 'Erfolg',
        message: `Aktion "${action}" wurde auf ${userIds.length} Benutzer angewendet`
      })

      return response
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler bei der Bulk-Aktion'
      notificationsStore.addNotification({
        type: 'error',
        title: 'Fehler',
        message: errorMessage
      })
      throw err
    } finally {
      isLoading.value = false
    }
  }

  const bulkActionLoading = computed(() => isLoading.value)

  // Computed properties for skill matrix data
  const skillMatrixData = computed(() => skillMatrix.value)
  const loading = computed(() => isLoading.value)

  return {
    // State
    teamMembers: readonly(teamMembers),
    currentUser: readonly(currentUser),
    statistics: readonly(statistics),
    skillMatrix: readonly(skillMatrix),
    isLoading: readonly(isLoading),
    error: readonly(error),
    userRoles,
    selectedUsers,
    
    // Computed
    activeMembers,
    membersByRole,
    onlineMembers,
    skillMatrixData,
    loading,
    bulkActionLoading,
    
    // Actions
    fetchTeamMembers,
    fetchUser,
    createUser,
    updateUser,
    deleteUser,
    bulkAction,
    fetchStatistics,
    fetchSkillMatrix,
    updateUserSkill,
    addUserSkill,
    addUserSkills,
    removeUserSkill,
    setCurrentUser,
    clearTeamData,
    verifySkill,
    fetchTeamStatistics,
    toggleUserSelection,
    clearUserSelection,
    executeBulkAction
  }
})
