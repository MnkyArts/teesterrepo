import { defineStore } from 'pinia'
import { ref, computed, readonly, onMounted, onUnmounted } from 'vue'

interface DashboardStats {
  totalProjects: number
  activeProjects: number
  totalTasks: number
  completedTasks: number
  totalTimeThisWeek: number
  totalTimeThisMonth: number
  teamMembers: number
  activeTeamMembers: number
  myTasks: number
  completionRate: number
  totalUsers: number
}

interface DashboardTask {
  id: string
  title: string
  status: 'GEPLANT' | 'TECHNISCHES_DESIGN' | 'IN_BEARBEITUNG' | 'REVIEW' | 'TESTING' | 'ERLEDIGT' | 'GESCHLOSSEN'
  priority: "NIEDRIG" | "NORMAL" | "HOCH" | "KRITISCH" | "BLOCKER"
  dueDate?: string
  project: {
    id: string
    name: string
    key: string
  }
}

interface DashboardActivity {
  id: string
  action: string
  description: string
  createdAt: string | Date
  user: {
    id: string
    firstName: string
    lastName: string
    avatar?: string | null
  }
  project?: {
    id: string
    name: string
    key: string
  } | null
  task?: {
    id: string
    title: string
    key: string
  } | null
}

interface DashboardData {
  stats: DashboardStats | null
  myTasks: DashboardTask[]
  recentActivities: DashboardActivity[]
  teamActivities: DashboardActivity[]
}

export const useDashboardStore = defineStore('dashboard', () => {
  const notificationsStore = useNotificationsStore()
  
  // State
  const data = ref<DashboardData>({
    stats: null,
    myTasks: [],
    recentActivities: [],
    teamActivities: []
  })
  
  const isLoading = ref(false)
  const refreshInProgress = ref(false)
  const lastRefreshTime = ref<Date | null>(null)
  const error = ref<string | null>(null)
  
  const REFRESH_COOLDOWN = 30000 // 30 seconds

  // Computed
  const hasData = computed(() => {
    return data.value.stats !== null || 
           data.value.myTasks.length > 0 || 
           data.value.recentActivities.length > 0
  })

  const isStale = computed(() => {
    if (!lastRefreshTime.value) return true
    const now = new Date()
    return (now.getTime() - lastRefreshTime.value.getTime()) > 300000 // 5 minutes
  })

  const canRefresh = computed(() => {
    if (!lastRefreshTime.value) return true
    const now = new Date()
    return (now.getTime() - lastRefreshTime.value.getTime()) > REFRESH_COOLDOWN
  })

  // Individual data computed properties
  const dashboardStats = computed(() => data.value.stats)
  const myTasksData = computed(() => data.value.myTasks)
  const recentActivitiesData = computed(() => data.value.recentActivities)
  const teamActivitiesData = computed(() => data.value.teamActivities)

  // Loading states
  const statsLoading = computed(() => isLoading.value)
  const tasksLoading = computed(() => isLoading.value)
  const activitiesLoading = computed(() => isLoading.value)
  const teamLoading = computed(() => isLoading.value)

  // Error state
  const hasErrors = computed(() => error.value !== null)

  // Actions
  const fetchDashboardStats = async () => {
    try {
      const response = await $fetch<{ success: boolean, data: DashboardStats }>('/api/dashboard/stats')
      
      if (response.success && response.data) {
        data.value.stats = response.data
      }
      
      return response.data
    } catch (err: any) {
      console.error('Error fetching dashboard stats:', err)
      throw err
    }
  }

  const fetchMyTasks = async (limit = 5) => {
    try {
      const response = await $fetch<{ success: boolean, data: DashboardTask[] }>('/api/dashboard/my-tasks', {
        query: { limit }
      })
      
      data.value.myTasks = response?.data || []
      
      return response?.data || []
    } catch (err: any) {
      console.error('Error fetching my tasks:', err)
      throw err
    }
  }

  const fetchRecentActivities = async (limit = 5) => {
    try {
      const response = await $fetch<{ success: boolean, data: any[] }>('/api/dashboard/activities', {
        query: { limit }
      })
      
      const activities = response?.data || []
      data.value.recentActivities = activities.map(activity => ({
        id: activity.id,
        action: activity.action,
        description: activity.description,
        createdAt: activity.createdAt,
        user: activity.user,
        project: activity.project,
        task: activity.task
      }))
      
      return activities
    } catch (err: any) {
      console.error('Error fetching recent activities:', err)
      throw err
    }
  }

  const fetchTeamActivities = async (limit = 5) => {
    try {
      const response = await $fetch<{ success: boolean, data: any[] }>('/api/dashboard/team-activities', {
        query: { limit }
      })
      
      const activities = response?.data || []
      data.value.teamActivities = activities.map(activity => ({
        id: activity.id,
        action: activity.action,
        description: activity.description,
        createdAt: activity.createdAt,
        user: activity.user,
        project: activity.project,
        task: activity.task
      }))
      
      return activities
    } catch (err: any) {
      console.error('Error fetching team activities:', err)
      throw err
    }
  }

  const fetchAllData = async (force = false) => {
    if (!force && !canRefresh.value) {
      console.log('Dashboard refresh on cooldown')
      return false
    }

    if (refreshInProgress.value) {
      console.log('Dashboard refresh already in progress')
      return false
    }

    refreshInProgress.value = true
    isLoading.value = true
    error.value = null

    try {
      // Fetch all dashboard data in parallel
      const promises = [
        fetchDashboardStats(),
        fetchMyTasks(),
        fetchRecentActivities(),
        fetchTeamActivities()
      ]

      await Promise.allSettled(promises)
      
      lastRefreshTime.value = new Date()
      
      return true
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Laden der Dashboard-Daten'
      notificationsStore.error('Fehler', error.value || 'Unbekannter Fehler')
      return false
    } finally {
      isLoading.value = false
      refreshInProgress.value = false
    }
  }

  const refreshDashboard = async (force = false) => {
    return await fetchAllData(force)
  }

  // Auto-refresh functionality
  let refreshInterval: NodeJS.Timeout | null = null

  const startAutoRefresh = (intervalMs = 300000) => { // 5 minutes default
    if (refreshInterval) {
      clearInterval(refreshInterval)
    }

    refreshInterval = setInterval(() => {
      // Only refresh if page is visible and user is active
      if (process.client && !document.hidden) {
        fetchAllData()
      }
    }, intervalMs)
  }

  const stopAutoRefresh = () => {
    if (refreshInterval) {
      clearInterval(refreshInterval)
      refreshInterval = null
    }
  }

  // Visibility API to pause/resume auto-refresh
  if (process.client) {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        stopAutoRefresh()
      } else if (isStale.value) {
        // Refresh data when page becomes visible and data is stale
        fetchAllData()
        startAutoRefresh()
      }
    }

    onMounted(() => {
      document.addEventListener('visibilitychange', handleVisibilityChange)
      startAutoRefresh()
    })

    onUnmounted(() => {
      document.removeEventListener('visibilitychange', handleVisibilityChange)
      stopAutoRefresh()
    })
  }

  // Individual update methods for real-time updates
  const updateTaskStatus = (taskId: string, newStatus: 'GEPLANT' | 'TECHNISCHES_DESIGN' | 'IN_BEARBEITUNG' | 'REVIEW' | 'TESTING' | 'ERLEDIGT' | 'GESCHLOSSEN') => {
    const task = data.value.myTasks.find(t => t.id === taskId)
    if (task) {
      task.status = newStatus
    }
  }

  const addActivity = (activity: Omit<DashboardActivity, 'id' | 'createdAt'>) => {
    const newActivity: DashboardActivity = {
      id: `activity-${Date.now()}-${Math.random()}`,
      createdAt: new Date(),
      ...activity
    }
    
    data.value.recentActivities.unshift(newActivity)
    
    // Keep only the latest 10 activities
    data.value.recentActivities = data.value.recentActivities.slice(0, 10)
  }

  const clearDashboard = () => {
    data.value = {
      stats: null,
      myTasks: [],
      recentActivities: [],
      teamActivities: []
    }
    lastRefreshTime.value = null
    error.value = null
  }

  // Additional methods needed by components
  const refreshAllData = async () => {
    return await refreshDashboard()
  }

  const initializeDashboard = async () => {
    await fetchAllData()
  }

  const cleanupDashboard = () => {
    clearDashboard()
  }

  return {
    // State
    data: readonly(data),
    isLoading: readonly(isLoading),
    refreshInProgress: readonly(refreshInProgress),
    lastRefreshTime: readonly(lastRefreshTime),
    error: readonly(error),
    
    // Computed
    hasData,
    isStale,
    canRefresh,
    dashboardStats,
    myTasksData,
    recentActivitiesData,
    teamActivitiesData,
    statsLoading,
    tasksLoading,
    activitiesLoading,
    teamLoading,
    hasErrors,
    
    // Actions
    fetchAllData,
    refreshDashboard,
    fetchDashboardStats,
    fetchMyTasks,
    fetchRecentActivities,
    fetchTeamActivities,
    startAutoRefresh,
    stopAutoRefresh,
    updateTaskStatus,
    addActivity,
    clearDashboard,
    refreshAllData,
    initializeDashboard,
    cleanupDashboard
  }
})
