# JWT Token Debugging Guide

## 🔍 Problem Diagnosis

Wenn JWT-Token-Probleme auftreten, folge diesen Schritten zur Diagnose:

### 1. Quick Status Check
```bash
npm run jwt:test-config
```

### 2. Häufige Probleme

#### Problem: "Invalid Signature" bei jwt.io
**Ursache:** Das JWT Secret stimmt nicht überein
**Lösung:**
1. Prüfe dein `.env` File: `JWT_SECRET` sollte gesetzt sein
2. Das Secret auf jwt.io muss exakt dem in `.env` entsprechen
3. Aktueller Secret aus `.env`: `a-string-secret-at-least-256-bits-long`

#### Problem: Token wird als ungültig abgelehnt
**Ursache:** Verschiedene mögliche Gründe
**Debugging:**
```bash
# Dekodiere Token ohne Verifizierung
npm run jwt:decode <dein-token>

# Verifiziere Token mit aktuellem Secret
npm run jwt:verify <dein-token>
```

#### Problem: "JWT_SECRET not configured" Warning
**Ursache:** Fehlende oder zu kurze JWT_SECRET
**Lösung:**
```bash
# Generiere neues sicheres Secret
npm run jwt:generate-secret

# Kopiere das generierte Secret in deine .env Datei
```

### 3. JWT Secret Management

#### Aktuelles Secret prüfen
```bash
grep JWT_SECRET .env
```

#### Neues sicheres Secret generieren
```bash
npm run jwt:generate-secret
```

#### Secret in Produktion
- **Niemals** das default Secret verwenden
- Mindestens 64 Zeichen lang
- Zufällig generiert mit hoher Entropie
- Sicher gespeichert (Umgebungsvariablen, Secrets Manager)

### 4. Token-Struktur verstehen

Ein wnmManagement JWT Token enthält:

```json
{
  "userId": "user-id-from-database",
  "email": "user@example.com", 
  "role": "ADMINISTRATOR|PROJECT_MANAGER|DEVELOPER|SUPPORTER|VIEWER|CUSTOMER",
  "iat": 1234567890,  // issued at
  "exp": 1234567890,  // expires at
  "aud": "wnmManagement-app",  // audience
  "iss": "wnmManagement"       // issuer
}
```

### 5. Testing und Validation

#### Vollständiger Konfigurationstest
```bash
npm run jwt:test-config
```

#### Token manuell testen
```javascript
// In Browser Console oder Node
const token = "dein-jwt-token-hier"
const parts = token.split('.')
const payload = JSON.parse(atob(parts[1]))
console.log('Token Payload:', payload)
console.log('Expires:', new Date(payload.exp * 1000))
```

### 6. Sicherheits-Best-Practices

#### JWT Secret
- ✅ Mindestens 256 Bit (32 Zeichen)
- ✅ Kryptographisch sicher generiert
- ✅ Eindeutig pro Umgebung (dev/staging/prod)
- ✅ Nie in Code committed
- ❌ Nie default Werte verwenden

#### Token Handling
- ✅ HTTPS für Token-Übertragung
- ✅ Sichere Storage (httpOnly Cookies bevorzugt)
- ✅ Angemessene Expiration Time (7 Tage default)
- ✅ Refresh Token Mechanismus
- ❌ Nie in localStorage bei sensiblen Daten

### 7. Debugging Commands

```bash
# Alle verfügbaren JWT-Kommandos anzeigen
npm run jwt:help

# Secret generieren
npm run jwt:generate-secret

# Token verifizieren
npm run jwt:verify eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Token dekodieren (ohne Verifikation)
npm run jwt:decode eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Konfiguration testen
npm run jwt:test-config
```

### 8. Troubleshooting Checklist

- [ ] `.env` Datei existiert
- [ ] `JWT_SECRET` ist gesetzt und mindestens 32 Zeichen
- [ ] Secret stimmt zwischen Generation und Verifikation überein
- [ ] Token ist nicht abgelaufen (check `exp` Feld)
- [ ] Issuer und Audience sind korrekt (`wnmManagement` / `wnmManagement-app`)
- [ ] Nuxt Server ist neugestartet nach `.env` Änderungen

### 9. Integration mit jwt.io

Für manuelle Token-Verifikation auf jwt.io:

1. **Token eingeben**: Füge deinen Token in das Token-Feld ein
2. **Secret eingeben**: Verwende exakt den Wert aus `JWT_SECRET` in deiner `.env`
3. **Algorithm**: Sollte automatisch auf `HS256` stehen
4. **Verify**: Sollte "signature verified" anzeigen

**Aktueller Secret für jwt.io:** `a-string-secret-at-least-256-bits-long`

### 10. Production Deployment

Für Production-Deployment:

```bash
# 1. Neues sicheres Secret generieren
npm run jwt:generate-secret

# 2. Secret in Production Environment setzen
export JWT_SECRET="dein-production-secret"

# 3. In Docker/Kubernetes Secrets speichern
kubectl create secret generic jwt-secret --from-literal=JWT_SECRET="dein-secret"

# 4. Testen dass alles funktioniert
npm run jwt:test-config
```
