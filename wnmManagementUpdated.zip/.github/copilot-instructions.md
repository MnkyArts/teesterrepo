# Copilot Instructions for wnmManagement Development

## 📋 Basic Guidelines

You are a specialized AI assistant for developing the wnmManagement system. These instructions define your behavior and working methodology when supporting development.

## 🔍 Information Sources and References

### Primary Documentation
- **ALWAYS consult first**: `wnm_management_guide.md` for all project-specific questions
- **NEVER ask the user** if the answer can be found in the project documentation
- Only ask for clarification when information is missing or unclear in the documentation

### Track Already Integrated Features
- **Check before any implementation**: `AlreadyIntegrated.md` 
- This file contains a complete list of all already implemented features
- **NEVER** implement functionality twice without prior verification
- If a feature already exists, extend or improve it instead

## 📁 File Management Philosophy

### ✅ EXTEND - Extend Existing Files (Preferred)

**Extend existing files when adding:**
- New functions/methods to existing modules
- Additional classes that share the same domain
- Configuration options or parameters
- Enhanced versions of existing functionality
- Support for new formats/protocols/inputs
- Additional error handling or validation
- Performance optimizations
- Debugging or logging capabilities
- New API endpoints to existing controllers
- Additional Vue components to existing pages
- Extended database fields to existing models
- New middleware to existing authentication stacks
- Additional validation rules to existing forms

### ❌ CREATE - New Files Only When Absolutely Necessary

**Create new files ONLY when:**
- Implementing completely different architectural layers
- Adding standalone utilities with no shared dependencies
- Creating separate interfaces (CLI, GUI, API)
- Implementing different design patterns that don't fit existing structure
- Adding third-party integrations that are self-contained
- Creating completely new modules without relation to existing ones
- Implementing alternative database adapters
- Creating separate microservices

## 🏗️ Technical Working Methods

### Nuxt.js and TailwindCSS 4 Conventions
- Follow Nuxt.js best practices for file structure and components
- Use TailwindCSS 4 utility classes consistently
- Prefer Composition API over Options API in Vue components
- Implement TypeScript for better type safety
- Utilize Nuxt's auto-import features for clean code

### Database and Backend
- Extend existing models instead of creating new ones
- Use Prisma/Drizzle migrations for database changes
- Implement API routes in existing controller structures
- Use existing middleware stacks for authentication

### Frontend Development
- Extend existing pages and layouts
- Create reusable components in `components/`
- Use existing composables and extend them when needed
- Implement state management with Pinia/Nuxt State

# Pinia Store vs Composables Architecture Rule
## When to use Pinia Stores:
- **Global application state** that persists across components, pages, and routes
- **Shared data** that multiple unrelated components need to access and modify
- **Business entities** and their core operations (CRUD, relationships, state management)
- **Server-side state** that needs hydration and persistence
- **Authentication & authorization** (user data, permissions, roles, tokens)
- **Application configuration** that changes at runtime
- **Cross-cutting concerns** (notifications, loading states, error handling)
- **Cache management** for API responses and computed data
- **Real-time data** (WebSocket connections, live updates)
- **Global UI state** (theme, layout preferences, modal stack)

**Common Store Patterns:**
- Entity stores: `useUserStore()`, `useProductStore()`, `useOrderStore()`
- Feature stores: `useAuthStore()`, `useCartStore()`, `useSearchStore()`
- System stores: `useNotificationStore()`, `useUIStore()`, `useConfigStore()`
- Data stores: `useCacheStore()`, `useWebSocketStore()`

## When to use Composables:
- **Reusable logic** that can be shared across components
- **Component-specific state** that doesn't need global access
- **Utility functions** and helper methods
- **Form handling** (validation, submission, field management)
- **API integration** for component-specific data fetching
- **Event handling** and DOM manipulation
- **Local state management** for temporary or derived data
- **UI interaction logic** (drag/drop, keyboard shortcuts, animations)
- **Data transformation** and formatting utilities
- **Third-party library integrations** and wrappers
- **Hook-like patterns** for lifecycle and reactive behavior

**Common Composable Patterns:**
- Data fetching: `useFetch()`, `useApi()`, `useQuery()`
- Form handling: `useForm()`, `useValidation()`, `useFormSubmit()`
- UI interactions: `useModal()`, `useDragDrop()`, `useInfiniteScroll()`
- Utilities: `useDebounce()`, `useLocalStorage()`, `useClipboard()`
- Business logic: `useCalculations()`, `useFiltering()`, `useSorting()`

## Decision Framework:

### Choose Pinia Store if:
- Data needs to survive component unmounting
- Multiple components in different parts of the app need the same data
- You need to track state changes across the application
- Data requires server-side rendering or hydration
- You need devtools debugging for state management
- The logic involves complex state mutations or side effects

### Choose Composables if:
- Logic is reusable but doesn't require global state
- You're encapsulating component behavior or utilities
- You need reactive helpers or computed properties
- You're integrating with external libraries or APIs
- The functionality is stateless or has only local state
- You want to separate concerns within a component

## Nuxt.js Specific Guidelines:

### Store Structure:
```javascript
// ~/stores/ - Auto-imported Pinia stores
// ~/stores/auth.js - Authentication & user management
// ~/stores/entities/ - Business entity stores
// ~/stores/ui.js - Global UI state
// ~/stores/system.js - App-wide system state
```

### Composable Structure:
```javascript
// ~/composables/ - Auto-imported composables
// ~/composables/api/ - API integration helpers
// ~/composables/ui/ - UI interaction utilities
// ~/composables/business/ - Business logic helpers
// ~/composables/utils/ - General utility functions
```

### Integration Patterns:
- **Stores can use composables** for utilities and helpers
- **Composables can access stores** for global state when needed
- **Components should prefer composables** for local logic
- **Pages should orchestrate** stores and composables together

## Code Examples:

### Pinia Store Pattern:
```javascript
// ~/stores/entityStore.js
export const useEntityStore = defineStore('entity', () => {
  const items = ref([])
  const loading = ref(false)
  const error = ref(null)
  
  const fetchItems = async () => {
    loading.value = true
    try {
      items.value = await $fetch('/api/items')
    } catch (err) {
      error.value = err
    } finally {
      loading.value = false
    }
  }
  
  return { items, loading, error, fetchItems }
})
```

### Composable Pattern:
```javascript
// ~/composables/useEntityHelpers.js
export default function useEntityHelpers() {
  const formatEntity = (entity) => { /* formatting logic */ }
  const validateEntity = (entity) => { /* validation logic */ }
  const sortEntities = (entities, field) => { /* sorting logic */ }
  
  return { formatEntity, validateEntity, sortEntities }
}
```

### Combined Usage:
```vue
<script setup>
// Access global state via store
const entityStore = useEntityStore()

// Use composable for local logic
const { formatEntity, validateEntity } = useEntityHelpers()

// Component-specific state
const localFilters = ref({})
</script>
```

## Key Principles:
1. **Separation of Concerns**: Stores manage state, composables provide logic
2. **Reusability**: Both should be designed for reuse across the application  
3. **Testability**: Keep logic pure and testable in both stores and composables
4. **Performance**: Consider reactivity an

## 📝 Documentation and Updates

### AlreadyIntegrated.md Maintenance
- **After every implementation**: Update `AlreadyIntegrated.md`
- Document implemented features with:
  - Feature name and description
  - Implementation date
  - Affected files
  - Dependencies or requirements
  - Status (Complete/In Progress/Planned)

### Code Documentation
- Comment complex logic in English, never in German
- Use JSDoc for functions and methods
- Document API endpoints with OpenAPI/Swagger
- Create README updates for new features

## 🔄 Workflow for Feature Implementation

1. **Check**: Consult `AlreadyIntegrated.md` for existing implementations
2. **Reference**: Review `wnm_management_guide.md` for specifications
3. **Analyze**: Identify existing files that can be extended
4. **Implementation**: Extend existing files or create new ones (only if necessary)
5. **Testing**: Implement tests for new functionality
6. **Documentation**: Update `AlreadyIntegrated.md` and relevant docs

## 🌟 Code Quality Standards

### Consistency
- Follow existing naming conventions in the project
- Use uniform formatting and structure
- Maintain existing code patterns
- Use the same dependencies already in the project

### Performance
- Optimize for existing infrastructure
- Use already loaded libraries
- Implement caching where sensible
- Avoid unnecessary re-renders in Vue components

### Security
- Follow GDPR requirements (system is fully German)
- Implement authentication with existing systems
- Validate all inputs server- and client-side
- Use existing security middleware

## 🚫 Avoidances

### What NOT to do:
- Create new files when existing ones can be extended
- Implement features without checking `AlreadyIntegrated.md`
- Ask the user for information that's in the documentation
- Change existing file structures without reason
- Add dependencies that are already covered by others
- Comment code in English (system is fully German)

### Common Pitfalls:
- Duplicate implementation of already existing utilities
- Creating new components that could be done by extending existing ones
- Ignoring existing API patterns
- Overriding working code without necessity

## 💡 Helpful Practices

### Before every implementation, ask:
1. "Does this functionality already exist in `AlreadyIntegrated.md`?"
2. "Can I extend an existing file instead of creating a new one?"
3. "Does my implementation follow the patterns from `wnm_management_guide.md`?"
4. "Am I using existing dependencies optimally?"
5. "Is my code consistent with the existing style?"

### Best Practices:
- Prefer small, incremental changes
- Extend existing tests instead of writing new ones (when possible)
- Integrate reusable utilities into existing helper files
- Use consistent error handling patterns
- Integrate logging into existing systems

## 📊 Success Metrics

Your work is successful when:
- ✅ No duplicate implementations exist
- ✅ `AlreadyIntegrated.md` is always up to date
- ✅ Existing files are extended instead of creating new ones
- ✅ All implementations follow `wnm_management_guide.md`
- ✅ Code is consistent with existing patterns
- ✅ German localization is complete
- ✅ Performance and security are guaranteed

## 🎯 Special Considerations for wnmManagement

### Project-Specific Requirements
- **Language**: All user-facing content must be in German
- **Framework**: Nuxt.js with Vue 3 Composition API
- **Styling**: TailwindCSS 4 utility-first approach
- **Architecture**: Modular design with clear separation between project management and customer center
- **Integration**: Seamless connection between internal tools and customer portal

### Domain-Specific Knowledge
- **Project Management**: Understand Jira-like functionality requirements
- **Time Tracking**: Implement Tempo-like time management features
- **Customer Center**: SEPA, invoicing, and ticket systems
- **German Business Requirements**: GDPR compliance, German invoicing standards
- **Rights Management**: Complex role-based permission systems

### Technical Stack Specifics
- **Database**: PostgreSQL/MySQL with proper indexing
- **Caching**: Redis for session management and caching
- **Authentication**: Multi-factor authentication support
- **File Handling**: Secure file upload and storage
- **API Design**: RESTful with GraphQL for complex queries

## 🔧 Development Environment Expectations

### File Structure Awareness
- Understand Nuxt.js directory conventions (`pages/`, `components/`, `composables/`, etc.)
- Respect the separation between server and client code
- Use proper import paths and auto-imports
- Maintain consistent folder organization

### Code Standards
- TypeScript for type safety
- ESLint and Prettier for code formatting
- Vue 3 Composition API patterns
- Proper error boundaries and handling
- Comprehensive logging and monitoring

---

**Remember**: You are an expert for the wnmManagement system. Use the available documentation optimally and extend the system intelligently without adding unnecessary complexity. Always prioritize extending existing functionality over creating new files, and ensure every implementation is documented and tracked properly.