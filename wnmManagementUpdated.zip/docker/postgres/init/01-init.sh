#!/bin/bash
set -e

# Create additional databases if needed
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
    -- Create extensions
    CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
    CREATE EXTENSION IF NOT EXISTS "pg_trgm";
    CREATE EXTENSION IF NOT EXISTS "btree_gin";
    
    -- Set timezone
    SET timezone = 'Europe/Berlin';
    
    -- Create schema if not exists
    CREATE SCHEMA IF NOT EXISTS public;
    
    -- Grant permissions
    GRANT ALL PRIVILEGES ON DATABASE wnm_management TO wnm_user;
    GRANT ALL ON SCHEMA public TO wnm_user;
    
    -- Create test database for development
    CREATE DATABASE wnm_management_test OWNER wnm_user;
    GRANT ALL PRIVILEGES ON DATABASE wnm_management_test TO wnm_user;
EOSQL

echo "Database initialization completed!"
