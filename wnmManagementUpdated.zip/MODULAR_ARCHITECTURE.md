# WNM Management - Modular Architecture

This project has been refactored to use a **modular layer-based architecture** using Nuxt.js Layers. This allows you to easily enable/disable features and create a customized version of the management system.

## 📁 Project Structure

```
wnmManagementUpdated/
├── modules.config.ts          # Main module configuration
├── nuxt.config.ts            # Main Nuxt config with dynamic layer loading
├── layers/                   # Modular layers
│   ├── core/                # Core functionality (always enabled)
│   ├── auth/                # Authentication & user management
│   ├── projects/            # Project management
│   ├── tasks/               # Task management
│   ├── timetracking/        # Time tracking
│   ├── customers/           # Customer portal
│   ├── team/                # Team management
│   ├── reports/             # Reports & analytics
│   ├── notifications/       # Notification system
│   ├── financial/           # SEPA/Financial management
│   ├── tickets/             # Support tickets
│   └── admin/               # Admin panel
├── components/              # Legacy components (being migrated)
├── pages/                   # Legacy pages (being migrated)
└── stores/                  # Legacy stores (being migrated)
```

## 🔧 Module Configuration

### Enabling/Disabling Modules

Edit `modules.config.ts` to control which modules are active:

```typescript
export const modulesConfig: ModulesConfig = {
  // Core module - always required
  core: {
    enabled: true,
    description: 'Core functionality, authentication, and shared components',
    layer: 'layers/core'
  },

  // Task Management (can work independently of projects)
  tasks: {
    enabled: true,
    dependencies: ['core', 'auth'],
    description: 'Task management system - works independently or with projects',
    layer: 'layers/tasks'
  },

  // Time Tracking
  timetracking: {
    enabled: false, // Disabled
    dependencies: ['core', 'auth', 'tasks'],
    description: 'Time tracking and timesheets',
    layer: 'layers/timetracking'
  }
}
```

### Module Dependencies

Each module can specify dependencies that must be enabled:

- **Core dependencies**: `core` and `auth` are required by most modules
- **Feature dependencies**: `timetracking` requires `tasks` to be enabled
- **Independent modules**: Some modules like `tasks` can work without `projects`

## 🚀 Usage

### 1. Development Mode

Start the development server:

```bash
npm run dev
```

The system will automatically:
- Load only enabled layers
- Validate module dependencies
- Show conditional UI based on enabled modules

### 2. Managing Modules

**For Administrators:**
- Go to `/admin/modules` to see the module management interface
- Enable/disable modules with real-time dependency validation
- View module statistics and status

**For Developers:**
- Edit `modules.config.ts` to change module configuration
- Restart the development server to apply changes

### 3. Conditional Features

The system automatically shows/hides features based on enabled modules:

```vue
<template>
  <!-- Only show if timetracking module is enabled -->
  <TimeTrackingWidget v-if="isModuleEnabled('timetracking')" />
  
  <!-- Only show navigation item if projects module is enabled -->
  <NuxtLink v-if="isModuleEnabled('projects')" to="/projects">
    Projects
  </NuxtLink>
</template>

<script setup>
const { isModuleEnabled } = useModules()
</script>
```

## 📦 Layer Structure

Each layer follows the standard Nuxt directory structure:

```
layers/example/
├── nuxt.config.ts           # Layer-specific configuration
├── components/              # Layer components
├── composables/             # Layer composables
├── stores/                  # Layer stores
├── pages/                   # Layer pages
├── assets/                  # Layer assets
└── plugins/                 # Layer plugins
```

## 🔍 Composables

### useModules()

Main composable for module system interaction:

```typescript
const { 
  isModuleEnabled,           // Check if a module is enabled
  getEnabledModules,         // Get list of enabled modules
  getAvailableNavigation,    // Get navigation items for enabled modules
  validateDependencies,      // Validate module dependencies
  modulesConfig             // Access to full module configuration
} = useModules()
```

### Conditional Store Loading

Stores are loaded conditionally based on enabled modules:

```typescript
// Only load if projects module is enabled
const projectsStore = isModuleEnabled('projects') ? useProjectsStore() : null

// Safe access with fallback
const projects = projectsStore?.projects || []
```

## 🛠️ Adding New Modules

### 1. Create Layer Structure

```bash
mkdir -p layers/newmodule/{components,composables,stores,pages}
```

### 2. Add Layer Configuration

Create `layers/newmodule/nuxt.config.ts`:

```typescript
export default defineNuxtConfig({
  // New module configuration
  components: [
    {
      path: '~/components',
      pathPrefix: false,
    }
  ],
  pages: true
})
```

### 3. Register in Module Config

Add to `modules.config.ts`:

```typescript
newmodule: {
  enabled: true,
  dependencies: ['core', 'auth'],
  description: 'Description of new module functionality',
  layer: 'layers/newmodule'
}
```

### 4. Create Module Components

Add your components, pages, and functionality to the layer directories.

## 🔄 Migration Status

The system is currently in migration from a monolithic to modular architecture:

### ✅ Completed
- [x] Module configuration system
- [x] Dynamic layer loading
- [x] Core layer with shared components
- [x] Authentication layer
- [x] Conditional UI rendering
- [x] Module management interface
- [x] Dependency validation

### 🚧 In Progress
- [ ] Complete component migration to layers
- [ ] Update all imports and references
- [ ] Layer-specific route handling
- [ ] Advanced module permissions

### 📋 Planned
- [ ] Module marketplace/plugin system
- [ ] Hot module swapping
- [ ] Module-specific configuration
- [ ] Module testing framework

## 🎯 Benefits

1. **Modularity**: Enable only the features you need
2. **Maintainability**: Isolated code in logical layers
3. **Scalability**: Easy to add new features as layers
4. **Customization**: Create different versions for different clients
5. **Performance**: Smaller bundle sizes by excluding unused modules
6. **Development**: Teams can work on different modules independently

## 🔧 Troubleshooting

### Module Not Loading
- Check that the module is enabled in `modules.config.ts`
- Verify all dependencies are enabled
- Restart the development server

### Dependency Errors
- Use the admin interface at `/admin/modules` to see validation errors
- Ensure required dependencies are enabled before enabling dependent modules

### Components Not Found
- Check that components are in the correct layer directory
- Verify the layer's `nuxt.config.ts` includes the components directory
- Ensure imports use the correct paths

## 📚 Resources

- [Nuxt Layers Documentation](https://nuxt.com/docs/getting-started/layers)
- [Nuxt Configuration](https://nuxt.com/docs/api/configuration/nuxt-config)
- [Vue 3 Composition API](https://vuejs.org/guide/extras/composition-api-faq.html)
