import { createAuthClient } from "better-auth/vue";
import { adminClient } from "better-auth/client/plugins"

export const authClient = createAuthClient({
    plugins: [
        adminClient()
    ]
})

export const {
	signIn,
	signOut,
	signUp,
	useSession,
	requestPasswordReset,
	resetPassword,
} = authClient;
