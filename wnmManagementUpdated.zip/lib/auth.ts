import { betterAuth } from "better-auth";
import { admin } from "better-auth/plugins"
import { prismaAdapter } from "better-auth/adapters/prisma";
import { createAuthMiddleware } from "better-auth/api";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export const auth = betterAuth({
  database: prismaAdapter(prisma, {
    provider: "postgresql",
  }),

  plugins: [
      admin() 
  ],
  
  baseURL: process.env.BETTER_AUTH_URL || process.env.APP_URL || "http://localhost:3000",
  
  emailAndPassword: {
    enabled: true,
    autoSignIn: true,
  },
  
  session: {
    cookieCache: {
      enabled: true,
      maxAge: 60 * 60 * 24 * 7, // 7 days
    },
  },
  
  // Map existing User fields to Better Auth requirements
  user: {
    modelName: "user",
    fields: {
      email: "email",
      name: "name",
      image: "image"
    },
    additionalFields: {
      firstName: {
        type: "string",
        required: true,
      },
      lastName: {
        type: "string", 
        required: true,
      },
      role: {
        type: "string",
        required: true,
        defaultValue: "ENTWICKLER",
      },
      avatar: {
        type: "string",
        required: false,
      },
      isActive: {
        type: "boolean",
        required: true,
        defaultValue: true,
      },
      lastLoginAt: {
        type: "date",
        required: false,
      },
    },
  },
  
  // Hooks für automatische lastLoginAt-Aktualisierung
  hooks: {
    after: createAuthMiddleware(async (ctx) => {
      if (ctx.path === "/sign-in/email" || ctx.path === "/sign-up/email") {
        const newSession = ctx.context.newSession;
        if (newSession?.user?.id) {
          // Update lastLoginAt when user signs in
          await prisma.user.update({
            where: { id: newSession.user.id },
            data: { lastLoginAt: new Date() }
          });
          
          console.log(`Updated lastLoginAt for user ${newSession.user.id}`);
        }
      }
    }),
  },
});

export type Session = typeof auth.$Infer.Session;
export type User = typeof auth.$Infer.Session.user;
