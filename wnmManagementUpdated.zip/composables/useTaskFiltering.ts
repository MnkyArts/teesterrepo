import type { EnumValue } from '@prisma/client'
import type { TaskWithDetails } from '~/stores/tasks'

export interface TaskFilters {
  status?: string
  priority?: string
  type?: string
  projectId?: string
  assigneeId?: string
  search?: string
}

export const useTaskFiltering = () => {
  const enumManagementStore = useEnumManagementStore()

  /**
   * Filter tasks based on enum values and other criteria
   */
  const filterTasks = (tasks: TaskWithDetails[], filters: TaskFilters): TaskWithDetails[] => {
    return tasks.filter(task => {
      // Status filter
      if (filters.status) {
        const taskStatus = task.status?.key || task.status
        if (taskStatus !== filters.status) return false
      }

      // Priority filter
      if (filters.priority) {
        const taskPriority = task.priority?.key || task.priority
        if (taskPriority !== filters.priority) return false
      }

      // Type filter
      if (filters.type) {
        const taskType = task.type?.key || task.type
        if (taskType !== filters.type) return false
      }

      // Project filter
      if (filters.projectId && task.projectId !== filters.projectId) {
        return false
      }

      // Assignee filter
      if (filters.assigneeId && task.assigneeId !== filters.assigneeId) {
        return false
      }

      // Search filter
      if (filters.search) {
        const searchLower = filters.search.toLowerCase()
        const title = task.title?.toLowerCase() || ''
        const description = task.description?.toLowerCase() || ''
        const projectName = task.project?.name?.toLowerCase() || ''
        const assigneeName = task.assignee ? 
          `${task.assignee.firstName} ${task.assignee.lastName}`.toLowerCase() : ''

        if (!title.includes(searchLower) && 
            !description.includes(searchLower) && 
            !projectName.includes(searchLower) && 
            !assigneeName.includes(searchLower)) {
          return false
        }
      }

      return true
    })
  }

  /**
   * Get enum value by key and category
   */
  const getEnumValue = (categoryName: string, key: string): EnumValue | undefined => {
    return enumManagementStore.getValueByKey(categoryName, key)
  }

  /**
   * Get enum values for a specific project
   */
  const getProjectEnumValues = (projectId: string, categoryName: string): EnumValue[] => {
    return enumManagementStore.getValuesForProject(projectId, categoryName)
  }

  /**
   * Sort tasks by enum property priority/order
   */
  const sortTasksByEnumOrder = (tasks: TaskWithDetails[], property: 'status' | 'priority' | 'type'): TaskWithDetails[] => {
    return [...tasks].sort((a, b) => {
      const aValue = a[property] as EnumValue | string | undefined
      const bValue = b[property] as EnumValue | string | undefined

      const aOrder = typeof aValue === 'object' ? aValue?.sortOrder || 0 : 0
      const bOrder = typeof bValue === 'object' ? bValue?.sortOrder || 0 : 0

      return aOrder - bOrder
    })
  }

  /**
   * Group tasks by enum property
   */
  const groupTasksByEnumProperty = (
    tasks: TaskWithDetails[], 
    property: 'status' | 'priority' | 'type'
  ): Map<string, TaskWithDetails[]> => {
    const grouped = new Map<string, TaskWithDetails[]>()

    tasks.forEach(task => {
      const value = task[property] as EnumValue | string | undefined
      const key = typeof value === 'object' ? value?.key || 'unknown' : value || 'unknown'

      if (!grouped.has(key)) {
        grouped.set(key, [])
      }
      grouped.get(key)!.push(task)
    })

    return grouped
  }

  /**
   * Get display name for enum value
   */
  const getEnumDisplayName = (value: EnumValue | string | undefined): string => {
    if (typeof value === 'object' && value) {
      return value.label
    }
    if (typeof value === 'string') {
      return value
    }
    return 'Unbekannt'
  }

  /**
   * Get enum color class for styling
   */
  const getEnumColorClass = (value: EnumValue | string | undefined): string => {
    if (typeof value === 'object' && value?.color) {
      const color = value.color
      const colorMap = {
        'gray': 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200',
        'red': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
        'orange': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
        'yellow': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
        'green': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
        'blue': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
        'purple': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
        'pink': 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200'
      }
      return colorMap[color as keyof typeof colorMap] || colorMap.gray
    }
    return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
  }

  return {
    filterTasks,
    getEnumValue,
    getProjectEnumValues,
    sortTasksByEnumOrder,
    groupTasksByEnumProperty,
    getEnumDisplayName,
    getEnumColorClass
  }
}
