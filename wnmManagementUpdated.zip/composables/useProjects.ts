import { ref, computed } from 'vue'

interface Project {
  id: string
  name: string
  description?: string
  status: 'active' | 'completed' | 'on-hold' | 'cancelled'
  progress: number
  startDate: Date
  endDate?: Date
  customerId: string
  customer?: {
    id: string
    name: string
    email: string
  }
  teamMembers: string[]
  budget?: number
  tags: string[]
  createdAt: Date
  updatedAt: Date
}

// Global state für Projekte
const projects = ref<Project[]>([])
const currentProject = ref<Project | null>(null)
const isLoading = ref(false)

export const useProjects = () => {
  // Computed properties
  const activeProjects = computed(() => 
    Array.isArray(projects.value) ? projects.value.filter(p => p.status === 'active') : []
  )

  const completedProjects = computed(() => 
    Array.isArray(projects.value) ? projects.value.filter(p => p.status === 'completed') : []
  )

  const userProjects = computed(() => {
    // TODO: Filter based on user permissions/assignments
    return Array.isArray(projects.value) ? projects.value : []
  })

  // Methods
  const fetchProjects = async () => {
    isLoading.value = true
    try {
      const data = await $fetch<Project[]>('/api/projects')
      projects.value = Array.isArray(data) ? data : []
    } catch (error) {
      console.error('Failed to fetch projects:', error)
      projects.value = []
    } finally {
      isLoading.value = false
    }
  }

  const fetchProject = async (id: string) => {
    try {
      const project = await $fetch<Project>(`/api/projects/${id}`)
      currentProject.value = project
      return project
    } catch (error) {
      console.error('Failed to fetch project:', error)
      return null
    }
  }

  const createProject = async (projectData: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const newProject = await $fetch<Project>('/api/projects', {
        method: 'POST',
        body: projectData
      })
      
      if (Array.isArray(projects.value)) {
        projects.value.push(newProject)
      } else {
        projects.value = [newProject]
      }
      return { success: true, project: newProject }
    } catch (error: any) {
      console.error('Failed to create project:', error)
      return { 
        success: false, 
        error: error.data?.message || 'Fehler beim Erstellen des Projekts' 
      }
    }
  }

  const updateProject = async (id: string, updates: Partial<Project>) => {
    try {
      const updatedProject = await $fetch<Project>(`/api/projects/${id}`, {
        method: 'PUT',
        body: updates
      })
      
      if (Array.isArray(projects.value)) {
        const index = projects.value.findIndex(p => p.id === id)
        if (index > -1) {
          projects.value[index] = updatedProject
        }
      }
      
      if (currentProject.value?.id === id) {
        currentProject.value = updatedProject
      }
      
      return { success: true, project: updatedProject }
    } catch (error: any) {
      console.error('Failed to update project:', error)
      return { 
        success: false, 
        error: error.data?.message || 'Fehler beim Aktualisieren des Projekts' 
      }
    }
  }

  const deleteProject = async (id: string) => {
    try {
      await $fetch(`/api/projects/${id}`, {
        method: 'DELETE'
      })
      
      if (Array.isArray(projects.value)) {
        projects.value = projects.value.filter(p => p.id !== id)
      }
      
      if (currentProject.value?.id === id) {
        currentProject.value = null
      }
      
      return { success: true }
    } catch (error: any) {
      console.error('Failed to delete project:', error)
      return { 
        success: false, 
        error: error.data?.message || 'Fehler beim Löschen des Projekts' 
      }
    }
  }

  const getProjectProgress = (project: Project) => {
    // TODO: Calculate progress based on tasks
    return project.progress || 0
  }

  const getProjectStats = (project: Project) => {
    // TODO: Get project statistics
    return {
      totalTasks: 0,
      completedTasks: 0,
      openTasks: 0,
      overdueTasks: 0,
      totalTimeSpent: 0,
      budgetUsed: 0
    }
  }

  return {
    projects: readonly(projects),
    currentProject: readonly(currentProject),
    isLoading: readonly(isLoading),
    activeProjects,
    completedProjects,
    userProjects,
    fetchProjects,
    fetchProject,
    createProject,
    updateProject,
    deleteProject,
    getProjectProgress,
    getProjectStats
  }
}
