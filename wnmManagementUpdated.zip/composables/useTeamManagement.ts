import { ref, computed, readonly } from 'vue'
import type { User, UserRole } from '@prisma/client'
import { useAuth } from './useAuth'
import { useNotifications } from './useNotifications'

interface TeamMember extends User {
  isOnline?: boolean
  lastActivity?: Date
  skills?: UserSkill[]
  workload?: number
  availability?: 'available' | 'busy' | 'away' | 'offline'
}

interface UserSkill {
  id: string
  name: string
  category: string
  level: 1 | 2 | 3 | 4 | 5
  experience?: string
  verified?: boolean
  verifiedBy?: string
  verifiedAt?: Date
}

interface TeamStatistics {
  totalMembers: number
  activeMembers: number
  onlineMembers: number
  averageWorkload: number
  skillDistribution: Record<string, number>
  roleDistribution: Record<UserRole, number>
}

interface CreateUserRequest {
  email: string
  firstName: string
  lastName: string
  role: UserRole
  avatar?: string
  skills?: Omit<UserSkill, 'id'>[]
  isActive?: boolean
}

interface UpdateUserRequest {
  firstName?: string
  lastName?: string
  email?: string
  role?: UserRole
  avatar?: string
  isActive?: boolean
}

interface UserFilters {
  role?: UserRole
  isActive?: boolean
  skills?: string[]
  availability?: string
  search?: string
}

interface SkillMatrixData {
  skillMatrix: Array<{
    category: string
    totalSkills: number
    skills: Array<{
      name: string
      totalUsers: number
      averageLevel: number
      maxLevel: number
      verifiedCount: number
      verificationRate: number
      users: Array<{
        user: User
        level: number
        verified: boolean
        verifiedBy?: string
        verifiedAt?: Date
        experience?: string
      }>
    }>
  }>
  topSkills: Array<{
    name: string
    totalUsers: number
    averageLevel: number
  }>
  skillCoverage: Array<{
    user: User
    totalSkills: number
    verifiedSkills: number
    averageLevel: number
    categories: string[]
    skillCoveragePercent: number
  }>
  summary: {
    totalSkills: number
    totalCategories: number
    totalTeamMembers: number
    averageSkillsPerMember: number
    verificationRate: number
  }
  lastUpdated: string
}

interface BulkActionRequest {
  action: 'activate' | 'deactivate' | 'change_role' | 'delete'
  userIds: string[]
  data?: {
    role?: UserRole
    isActive?: boolean
  }
}

/**
 * Team Management Composable
 * Verwaltet Team-Mitglieder, Benutzerprofile, Rollen und Skills
 */
export const useTeamManagement = () => {
  // State
  const teamMembers = ref<TeamMember[]>([])
  const currentUser = ref<TeamMember | null>(null)
  const loading = ref(false)
  const error = ref<string>('')
  
  // Get auth headers from useAuth composable
  
  
  // Notification helper
  const { addNotification } = useNotifications()

  // State for new features
  const skillMatrixData = ref<SkillMatrixData | null>(null)
  const selectedUsers = ref<string[]>([])
  const bulkActionLoading = ref(false)

  /**
   * Lädt alle Team-Mitglieder
   */
  const fetchTeamMembers = async (filters?: UserFilters) => {
    loading.value = true
    error.value = ''
    
    try {
      const queryParams = new URLSearchParams()
      if (filters?.role) queryParams.append('role', filters.role)
      if (filters?.isActive !== undefined) queryParams.append('isActive', filters.isActive.toString())
      if (filters?.search) queryParams.append('search', filters.search)
      if (filters?.skills?.length) queryParams.append('skills', filters.skills.join(','))
      if (filters?.availability) queryParams.append('availability', filters.availability)

      const url = `/api/users${queryParams.toString() ? `?${queryParams.toString()}` : ''}`
      
      const response = await $fetch<{ users: TeamMember[], total: number }>(url, {
        
      })
      
      teamMembers.value = response.users
      return response
    } catch (err: any) {
      const errorMessage = err?.data?.message || 'Fehler beim Laden der Team-Mitglieder'
      error.value = errorMessage
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: errorMessage
      })
      throw err
    } finally {
      loading.value = false
    }
  }

  /**
   * Lädt einen einzelnen Benutzer
   */
  const fetchUser = async (userId: string) => {
    loading.value = true
    error.value = ''
    
    try {
      const user = await $fetch<TeamMember>(`/api/users/${userId}`, {
        
      })
      
      currentUser.value = user
      return user
    } catch (err: any) {
      const errorMessage = err?.data?.message || 'Fehler beim Laden des Benutzers'
      error.value = errorMessage
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: errorMessage
      })
      throw err
    } finally {
      loading.value = false
    }
  }

  /**
   * Erstellt einen neuen Benutzer
   */
  const createUser = async (userData: CreateUserRequest) => {
    loading.value = true
    error.value = ''
    
    try {
      const newUser = await $fetch<TeamMember>('/api/users', {
        method: 'POST',
        
        body: userData
      })
      
      teamMembers.value.unshift(newUser)
      
      addNotification({
        type: 'success',
        title: 'Erfolg',
        message: `Benutzer ${newUser.firstName} ${newUser.lastName} wurde erfolgreich erstellt`
      })
      
      return newUser
    } catch (err: any) {
      const errorMessage = err?.data?.message || 'Fehler beim Erstellen des Benutzers'
      error.value = errorMessage
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: errorMessage
      })
      throw err
    } finally {
      loading.value = false
    }
  }

  /**
   * Aktualisiert einen Benutzer
   */
  const updateUser = async (userId: string, userData: UpdateUserRequest) => {
    loading.value = true
    error.value = ''
    
    try {
      const updatedUser = await $fetch<TeamMember>(`/api/users/${userId}`, {
        method: 'PUT',
        
        body: userData
      })
      
      const index = teamMembers.value.findIndex(u => u.id === userId)
      if (index !== -1) {
        teamMembers.value[index] = updatedUser
      }
      
      if (currentUser.value?.id === userId) {
        currentUser.value = updatedUser
      }
      
      addNotification({
        type: 'success',
        title: 'Erfolg',
        message: `Benutzer wurde erfolgreich aktualisiert`
      })
      
      return updatedUser
    } catch (err: any) {
      const errorMessage = err?.data?.message || 'Fehler beim Aktualisieren des Benutzers'
      error.value = errorMessage
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: errorMessage
      })
      throw err
    } finally {
      loading.value = false
    }
  }

  /**
   * Deaktiviert einen Benutzer (Soft Delete)
   */
  const deactivateUser = async (userId: string) => {
    return updateUser(userId, { isActive: false })
  }

  /**
   * Reaktiviert einen Benutzer
   */
  const activateUser = async (userId: string) => {
    return updateUser(userId, { isActive: true })
  }

  /**
   * Fügt Skills zu einem Benutzer hinzu
   */
  const addUserSkills = async (userId: string, skills: Omit<UserSkill, 'id'>[]) => {
    loading.value = true
    error.value = ''
    
    try {
      const response = await $fetch<{ skills: UserSkill[] }>(`/api/users/${userId}/skills`, {
        method: 'POST',
        
        body: { skills }
      })
      
      // Update local user data
      const userIndex = teamMembers.value.findIndex(u => u.id === userId)
      if (userIndex !== -1 && teamMembers.value[userIndex].skills) {
        teamMembers.value[userIndex].skills!.push(...response.skills)
      }
      
      addNotification({
        type: 'success',
        title: 'Erfolg',
        message: 'Skills wurden erfolgreich hinzugefügt'
      })
      
      return response.skills
    } catch (err: any) {
      const errorMessage = err?.data?.message || 'Fehler beim Hinzufügen der Skills'
      error.value = errorMessage
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: errorMessage
      })
      throw err
    } finally {
      loading.value = false
    }
  }

  /**
   * Aktualisiert einen Skill
   */
  const updateUserSkill = async (userId: string, skillId: string, skillData: Partial<UserSkill>) => {
    loading.value = true
    error.value = ''
    
    try {
      const updatedSkill = await $fetch<UserSkill>(`/api/users/${userId}/skills/${skillId}`, {
        method: 'PUT',
        
        body: skillData
      })
      
      // Update local user data
      const userIndex = teamMembers.value.findIndex(u => u.id === userId)
      if (userIndex !== -1 && teamMembers.value[userIndex].skills) {
        const skillIndex = teamMembers.value[userIndex].skills!.findIndex(s => s.id === skillId)
        if (skillIndex !== -1) {
          teamMembers.value[userIndex].skills![skillIndex] = updatedSkill
        }
      }
      
      addNotification({
        type: 'success',
        title: 'Erfolg',
        message: 'Skill wurde erfolgreich aktualisiert'
      })
      
      return updatedSkill
    } catch (err: any) {
      const errorMessage = err?.data?.message || 'Fehler beim Aktualisieren des Skills'
      error.value = errorMessage
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: errorMessage
      })
      throw err
    } finally {
      loading.value = false
    }
  }

  /**
   * Entfernt einen Skill
   */
  const removeUserSkill = async (userId: string, skillId: string) => {
    loading.value = true
    error.value = ''
    
    try {
      await $fetch(`/api/users/${userId}/skills/${skillId}`, {
        method: 'DELETE',
        
      })
      
      // Update local user data
      const userIndex = teamMembers.value.findIndex(u => u.id === userId)
      if (userIndex !== -1 && teamMembers.value[userIndex].skills) {
        teamMembers.value[userIndex].skills = teamMembers.value[userIndex].skills!.filter(s => s.id !== skillId)
      }
      
      addNotification({
        type: 'success',
        title: 'Erfolg',
        message: 'Skill wurde erfolgreich entfernt'
      })
    } catch (err: any) {
      const errorMessage = err?.data?.message || 'Fehler beim Entfernen des Skills'
      error.value = errorMessage
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: errorMessage
      })
      throw err
    } finally {
      loading.value = false
    }
  }

  /**
   * Lädt Team-Statistiken
   */
  const fetchTeamStatistics = async (): Promise<TeamStatistics> => {
    try {
      const stats = await $fetch<TeamStatistics>('/api/users/statistics', {
        
      })
      
      return stats
    } catch (err: any) {
      const errorMessage = err?.data?.message || 'Fehler beim Laden der Team-Statistiken'
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: errorMessage
      })
      throw err
    }
  }

  /**
   * Lädt die Skill-Matrix-Daten
   */
  const fetchSkillMatrix = async () => {
    loading.value = true
    error.value = ''
    
    try {
      const response = await $fetch<{ success: boolean, data: SkillMatrixData }>('/api/users/skill-matrix', {
        
      })
      
      skillMatrixData.value = response.data
      return response.data
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Laden der Skill-Matrix'
      throw err
    } finally {
      loading.value = false
    }
  }

  /**
   * Verifiziert oder entfernt die Verifizierung eines Skills
   */
  const verifySkill = async (skillId: string, verified: boolean, notes?: string) => {
    try {
      const response = await $fetch<{ success: boolean, skill: UserSkill, message: string }>('/api/users/skills/verify', {
        method: 'POST',
        
        body: { skillId, verified, notes }
      })
      
      addNotification({
        title: 'Skill-Verifizierung',
        message: response.message,
        type: 'success'
      })
      
      return response.skill
    } catch (err: any) {
      const message = err.data?.message || 'Fehler bei der Skill-Verifizierung'
      addNotification({
        title: 'Fehler',
        message,
        type: 'error'
      })
      throw err
    }
  }

  /**
   * Führt Bulk-Aktionen auf ausgewählte Benutzer aus
   */
  const executeBulkAction = async (request: BulkActionRequest) => {
    bulkActionLoading.value = true
    
    try {
      const response = await $fetch<{ 
        success: boolean
        affectedUsers: number
        action: string
        message: string 
      }>('/api/users/bulk-actions', {
        method: 'POST',
        
        body: request
      })
      
      addNotification({
        title: 'Bulk-Aktion erfolgreich',
        message: response.message,
        type: 'success'
      })
      
      // Teamliste aktualisieren
      await fetchTeamMembers()
      selectedUsers.value = []
      
      return response
    } catch (err: any) {
      const message = err.data?.message || 'Fehler bei der Bulk-Aktion'
      addNotification({
        title: 'Fehler',
        message,
        type: 'error'
      })
      throw err
    } finally {
      bulkActionLoading.value = false
    }
  }

  /**
   * Benutzer-Auswahl für Bulk-Aktionen verwalten
   */
  const toggleUserSelection = (userId: string) => {
    const index = selectedUsers.value.indexOf(userId)
    if (index > -1) {
      selectedUsers.value.splice(index, 1)
    } else {
      selectedUsers.value.push(userId)
    }
  }

  const selectAllUsers = (userIds: string[]) => {
    selectedUsers.value = [...userIds]
  }

  const clearUserSelection = () => {
    selectedUsers.value = []
  }

  const isUserSelected = (userId: string) => {
    return selectedUsers.value.includes(userId)
  }

  // Computed properties
  const activeMembers = computed(() => 
    teamMembers.value.filter(member => member.isActive)
  )

  const onlineMembers = computed(() => 
    teamMembers.value.filter(member => member.availability === 'available')
  )

  const membersByRole = computed(() => {
    const roles: Record<UserRole, TeamMember[]> = {
      ADMINISTRATOR: [],
      PROJEKTLEITER: [],
      ENTWICKLER: [],
      SUPPORTER: [],
      VIEWER: [],
      KUNDE: []
    }
    
    teamMembers.value.forEach(member => {
      roles[member.role].push(member)
    })
    
    return roles
  })

  const availableSkills = computed(() => {
    const skillsSet = new Set<string>()
    teamMembers.value.forEach(member => {
      member.skills?.forEach(skill => {
        skillsSet.add(skill.name)
      })
    })
    return Array.from(skillsSet).sort()
  })

  const skillCategories = computed(() => {
    const categoriesSet = new Set<string>()
    teamMembers.value.forEach(member => {
      member.skills?.forEach(skill => {
        categoriesSet.add(skill.category)
      })
    })
    return Array.from(categoriesSet).sort()
  })

  // Helper functions
  const getUsersBySkill = (skillName: string) => {
    return teamMembers.value.filter(member => 
      member.skills?.some(skill => skill.name === skillName)
    )
  }

  const getUsersByRole = (role: UserRole) => {
    return teamMembers.value.filter(member => member.role === role)
  }

  const getFullName = (user: TeamMember) => {
    return `${user.firstName} ${user.lastName}`
  }

  const getInitials = (user: TeamMember) => {
    return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase()
  }

  const getWorkloadColor = (workload: number) => {
    if (workload <= 50) return 'green'
    if (workload <= 80) return 'yellow'
    return 'red'
  }

  // User roles configuration
  const userRoles: Array<{value: UserRole, label: string, description: string}> = [
    { 
      value: 'ADMINISTRATOR', 
      label: 'Administrator', 
      description: 'Vollzugriff auf alle Systembereiche' 
    },
    { 
      value: 'PROJEKTLEITER', 
      label: 'Projektleiter', 
      description: 'Projektmanagement und Team-Koordination' 
    },
    { 
      value: 'ENTWICKLER', 
      label: 'Entwickler', 
      description: 'Aufgabenbearbeitung und Zeiterfassung' 
    },
    { 
      value: 'SUPPORTER', 
      label: 'Supporter', 
      description: 'Kundencenter und Ticket-Bearbeitung' 
    },
    { 
      value: 'VIEWER', 
      label: 'Betrachter', 
      description: 'Nur-Lese-Zugriff für Stakeholder' 
    },
    { 
      value: 'KUNDE', 
      label: 'Kunde', 
      description: 'Zugriff nur auf Kundencenter-Bereiche' 
    }
  ]

  const skillLevels = [
    { value: 1, label: 'Anfänger', description: 'Grundkenntnisse vorhanden' },
    { value: 2, label: 'Fortgeschritten', description: 'Kann eigenständig arbeiten' },
    { value: 3, label: 'Kompetent', description: 'Erfahren und selbstständig' },
    { value: 4, label: 'Experte', description: 'Kann andere anleiten' },
    { value: 5, label: 'Meister', description: 'Branchenführende Expertise' }
  ] as const

  return {
    // State
    teamMembers: readonly(teamMembers),
    currentUser: readonly(currentUser),
    loading: readonly(loading),
    error: readonly(error),
    skillMatrixData: readonly(skillMatrixData),
    selectedUsers: readonly(selectedUsers),
    bulkActionLoading: readonly(bulkActionLoading),

    // Actions
    fetchTeamMembers,
    fetchUser,
    createUser,
    updateUser,
    deactivateUser,
    activateUser,
    addUserSkills,
    updateUserSkill,
    removeUserSkill,
    fetchTeamStatistics,
    fetchSkillMatrix,
    verifySkill,
    executeBulkAction,
    toggleUserSelection,
    selectAllUsers,
    clearUserSelection,
    isUserSelected,

    // Computed
    activeMembers,
    onlineMembers,
    membersByRole,
    availableSkills,
    skillCategories,

    // Helpers
    getUsersBySkill,
    getUsersByRole,
    getFullName,
    getInitials,
    getWorkloadColor,

    // Constants
    userRoles,
    skillLevels
  }
}
