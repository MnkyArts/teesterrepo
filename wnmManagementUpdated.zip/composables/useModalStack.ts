export const useModalStack = () => {
  const modalStack = ref<string[]>([])

  const openModal = (modalId: string) => {
    if (!modalStack.value.includes(modalId)) {
      modalStack.value.push(modalId)
    }
    updateBodyOverflow()
  }

  const closeModal = (modalId: string) => {
    const index = modalStack.value.indexOf(modalId)
    if (index > -1) {
      modalStack.value.splice(index, 1)
    }
    updateBodyOverflow()
  }

  const closeTopModal = () => {
    if (modalStack.value.length > 0) {
      const topModal = modalStack.value.pop()
      updateBodyOverflow()
      return topModal
    }
    return null
  }

  const closeAllModals = () => {
    modalStack.value = []
    updateBodyOverflow()
  }

  const getModalZIndex = (modalId: string) => {
    const index = modalStack.value.indexOf(modalId)
    return index >= 0 ? 50 + index * 10 : 50
  }

  const isTopModal = (modalId: string) => {
    return modalStack.value[modalStack.value.length - 1] === modalId
  }

  const updateBodyOverflow = () => {
    if (process.client) {
      document.body.style.overflow = modalStack.value.length > 0 ? 'hidden' : ''
    }
  }

  // Handle ESC key
  if (process.client) {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && modalStack.value.length > 0) {
        closeTopModal()
      }
    }

    onMounted(() => {
      document.addEventListener('keydown', handleEscape)
    })

    onUnmounted(() => {
      document.removeEventListener('keydown', handleEscape)
      closeAllModals()
    })
  }

  return {
    modalStack: readonly(modalStack),
    openModal,
    closeModal,
    closeTopModal,
    closeAllModals,
    getModalZIndex,
    isTopModal
  }
}
