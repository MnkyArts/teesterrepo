import { ref, computed, onMounted, onUnmounted, readonly } from 'vue'

export interface TimeEntry {
  id: string
  description?: string
  hours: number
  date: string
  category: string
  billable: boolean
  createdAt: string
  updatedAt: string
  user: {
    id: string
    firstName: string
    lastName: string
  }
  project: {
    id: string
    name: string
    key: string
  }
  task?: {
    id: string
    title: string
    key: string
  }
}

export interface ActiveTimer {
  id?: string
  taskId: string // Made required
  projectId: string
  description: string
  category: string
  startTime: Date
  elapsedSeconds: number
}

export interface TimeTrackingStats {
  todayTotal: number
  weekTotal: number
  monthTotal: number
  billableToday: number
  nonBillableToday: number
  targetDailyHours: number
  projectBreakdown: Array<{
    projectId: string
    projectName: string
    hours: number
    percentage: number
  }>
}

export const useTimeTracking = () => {
  // State
  const timeEntries = ref<TimeEntry[]>([])
  const activeTimer = ref<ActiveTimer | null>(null)
  const stats = ref<TimeTrackingStats | null>(null)
  const isLoading = ref(false)
  const error = ref<string | null>(null)

  // Timer state
  const timerInterval = ref<NodeJS.Timeout | null>(null)

  // Get auth from useAuth (for user info, not headers)
  const { user } = useAuth()

  // Computed
  const isTimerRunning = computed(() => activeTimer.value !== null)
  
  const formattedElapsedTime = computed(() => {
    if (!activeTimer.value) return '00:00'
    return formatDuration(activeTimer.value.elapsedSeconds)
  })

  const todayEntries = computed(() => {
    const today = new Date().toISOString().split('T')[0]
    return timeEntries.value.filter(entry => entry.date.startsWith(today))
  })

  const weekEntries = computed(() => {
    const startOfWeek = getStartOfWeek(new Date())
    const endOfWeek = getEndOfWeek(new Date())
    
    return timeEntries.value.filter(entry => {
      const entryDate = new Date(entry.date)
      return entryDate >= startOfWeek && entryDate <= endOfWeek
    })
  })

  // Utility functions
  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`
  }

  const formatHours = (hours: number): string => {
    const h = Math.floor(hours)
    const m = Math.round((hours - h) * 60)
    return `${h}:${m.toString().padStart(2, '0')}`
  }

  const getStartOfWeek = (date: Date): Date => {
    const d = new Date(date)
    const day = d.getDay()
    const diff = d.getDate() - day + (day === 0 ? -6 : 1) // Monday as first day
    return new Date(d.setDate(diff))
  }

  const getEndOfWeek = (date: Date): Date => {
    const startOfWeek = getStartOfWeek(date)
    const endOfWeek = new Date(startOfWeek)
    endOfWeek.setDate(startOfWeek.getDate() + 6)
    return endOfWeek
  }

  // API Functions
  const fetchTimeEntries = async (filters?: {
    startDate?: string
    endDate?: string
    projectId?: string
    userId?: string
  }) => {
    try {
      isLoading.value = true
      error.value = null

      const queryParams = new URLSearchParams()
      if (filters?.startDate) queryParams.append('startDate', filters.startDate)
      if (filters?.endDate) queryParams.append('endDate', filters.endDate)
      if (filters?.projectId) queryParams.append('projectId', filters.projectId)
      if (filters?.userId) queryParams.append('userId', filters.userId)

      const url = `/api/time-entries${queryParams.toString() ? '?' + queryParams.toString() : ''}`
      
      const response = await $fetch<{ timeEntries: TimeEntry[] }>(url)

      timeEntries.value = response.timeEntries
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Laden der Zeiteinträge'
      console.error('Error fetching time entries:', err)
    } finally {
      isLoading.value = false
    }
  }

  const createTimeEntry = async (entry: {
    description?: string
    hours: number
    date: string
    category: string
    billable: boolean
    projectId: string
    taskId?: string
  }) => {
    try {
      isLoading.value = true
      error.value = null

      const response = await $fetch<{ timeEntry: TimeEntry }>('/api/time-entries', {
        method: 'POST',
        body: entry
      })

      timeEntries.value.unshift(response.timeEntry)
      await fetchStats() // Refresh stats
      
      return response.timeEntry
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Erstellen des Zeiteintrags'
      console.error('Error creating time entry:', err)
      throw err
    } finally {
      isLoading.value = false
    }
  }

  const updateTimeEntry = async (id: string, updates: Partial<TimeEntry>) => {
    try {
      isLoading.value = true
      error.value = null

      const response = await $fetch<{ timeEntry: TimeEntry }>(`/api/time-entries/${id}`, {
        method: 'PUT',
        body: updates
      })

      const index = timeEntries.value.findIndex(entry => entry.id === id)
      if (index !== -1) {
        timeEntries.value[index] = response.timeEntry
      }

      await fetchStats() // Refresh stats
      
      return response.timeEntry
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Aktualisieren des Zeiteintrags'
      console.error('Error updating time entry:', err)
      throw err
    } finally {
      isLoading.value = false
    }
  }

  const deleteTimeEntry = async (id: string) => {
    try {
      isLoading.value = true
      error.value = null

      await $fetch(`/api/time-entries/${id}`, {
        method: 'DELETE'
      })

      timeEntries.value = timeEntries.value.filter(entry => entry.id !== id)
      await fetchStats() // Refresh stats
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Löschen des Zeiteintrags'
      console.error('Error deleting time entry:', err)
      throw err
    } finally {
      isLoading.value = false
    }
  }

  const fetchStats = async () => {
    try {
      const response = await $fetch<{ stats: TimeTrackingStats }>('/api/time-entries/stats')

      stats.value = response.stats
    } catch (err: any) {
      console.error('Error fetching time tracking stats:', err)
    }
  }

  // Timer functions
  const startTimer = async (config: {
    taskId: string // Now required
    projectId: string
    description?: string
    category?: string
  }) => {
    if (activeTimer.value) {
      await stopTimer() // Stop any existing timer
    }

    activeTimer.value = {
      taskId: config.taskId,
      projectId: config.projectId,
      description: config.description || '',
      category: config.category || 'Entwicklung',
      startTime: new Date(),
      elapsedSeconds: 0
    }

    // Start the timer interval
    timerInterval.value = setInterval(() => {
      if (activeTimer.value) {
        activeTimer.value.elapsedSeconds = Math.floor(
          (new Date().getTime() - activeTimer.value.startTime.getTime()) / 1000
        )
      }
    }, 1000)

    // Save timer state to localStorage for persistence
    localStorage.setItem('wnm_active_timer', JSON.stringify(activeTimer.value))
  }

  const stopTimer = async () => {
    if (!activeTimer.value) return

    const timer = activeTimer.value
    const hours = timer.elapsedSeconds / 3600

    // Clear timer
    if (timerInterval.value) {
      clearInterval(timerInterval.value)
      timerInterval.value = null
    }

    activeTimer.value = null
    localStorage.removeItem('wnm_active_timer')

    // Create time entry if there's meaningful time
    if (hours >= 0.01) { // At least 36 seconds
      try {
        await createTimeEntry({
          description: timer.description,
          hours: Math.round(hours * 100) / 100, // Round to 2 decimal places
          date: new Date().toISOString().split('T')[0],
          category: timer.category,
          billable: true,
          projectId: timer.projectId,
          taskId: timer.taskId
        })
      } catch (err) {
        console.error('Error saving time entry:', err)
      }
    }
  }

  const pauseTimer = () => {
    if (timerInterval.value) {
      clearInterval(timerInterval.value)
      timerInterval.value = null
    }
  }

  const resumeTimer = () => {
    if (activeTimer.value && !timerInterval.value) {
      timerInterval.value = setInterval(() => {
        if (activeTimer.value) {
          activeTimer.value.elapsedSeconds = Math.floor(
            (new Date().getTime() - activeTimer.value.startTime.getTime()) / 1000
          )
        }
      }, 1000)
    }
  }

  // Restore timer from localStorage on mount
  const restoreTimer = () => {
    const saved = localStorage.getItem('wnm_active_timer')
    if (saved) {
      try {
        const timer = JSON.parse(saved)
        timer.startTime = new Date(timer.startTime)
        
        // Calculate elapsed time from when it was started
        timer.elapsedSeconds = Math.floor(
          (new Date().getTime() - timer.startTime.getTime()) / 1000
        )
        
        activeTimer.value = timer
        resumeTimer()
      } catch (err) {
        console.error('Error restoring timer:', err)
        localStorage.removeItem('wnm_active_timer')
      }
    }
  }

  // Export functions
  const exportTimeEntries = async (format: 'csv' | 'pdf', filters?: {
    startDate?: string
    endDate?: string
    projectId?: string
  }) => {
    try {
      // For now, we'll create a basic CSV export from current data
      if (format === 'csv') {
        const headers = ['Datum', 'Projekt', 'Aufgabe', 'Kategorie', 'Stunden', 'Beschreibung', 'Abrechenbar']
        const csvData = timeEntries.value.map(entry => [
          entry.date,
          entry.project.name,
          entry.task?.key || '',
          entry.category,
          entry.hours.toString(),
          entry.description || '',
          entry.billable ? 'Ja' : 'Nein'
        ])
        
        const csvContent = [
          headers.join(','),
          ...csvData.map(row => row.map(cell => `"${cell}"`).join(','))
        ].join('\n')
        
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `zeiterfassung_${new Date().toISOString().split('T')[0]}.csv`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      } else {
        console.log('PDF Export wird in einer zukünftigen Version implementiert')
      }
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Export'
      console.error('Error exporting time entries:', err)
    }
  }

  // Lifecycle
  onMounted(() => {
    restoreTimer()
    fetchStats()
  })

  // Cleanup on unmount
  onUnmounted(() => {
    if (timerInterval.value) {
      clearInterval(timerInterval.value)
    }
  })

  return {
    // State
    timeEntries: readonly(timeEntries),
    activeTimer: readonly(activeTimer),
    stats: readonly(stats),
    isLoading: readonly(isLoading),
    error: readonly(error),

    // Computed
    isTimerRunning,
    formattedElapsedTime,
    todayEntries,
    weekEntries,

    // Methods
    fetchTimeEntries,
    createTimeEntry,
    updateTimeEntry,
    deleteTimeEntry,
    fetchStats,
    startTimer,
    stopTimer,
    pauseTimer,
    resumeTimer,
    exportTimeEntries,

    // Utils
    formatDuration,
    formatHours,
    getStartOfWeek,
    getEndOfWeek
  }
}
