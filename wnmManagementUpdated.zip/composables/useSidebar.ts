import { ref, computed, watch, readonly } from 'vue'
import { useWindowSize } from '@vueuse/core'

// Global state für Sidebar
const isOpen = ref(true)

export const useSidebar = () => {
  // Detect mobile breakpoint
  const { width } = useWindowSize()
  const isMobile = computed(() => width.value < 1024) // lg breakpoint

  // Auto-close sidebar on mobile
  watch(isMobile, (newIsMobile) => {
    if (newIsMobile) {
      isOpen.value = false
    } else {
      isOpen.value = true
    }
  }, { immediate: true })

  // Methods
  const toggle = () => {
    isOpen.value = !isOpen.value
  }

  const open = () => {
    isOpen.value = true
  }

  const close = () => {
    isOpen.value = false
  }

  return {
    isOpen: readonly(isOpen),
    isMobile,
    toggle,
    toggleSidebar: toggle, // Alias for compatibility
    open,
    close
  }
}
