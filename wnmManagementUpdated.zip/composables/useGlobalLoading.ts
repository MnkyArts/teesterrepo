import { ref } from 'vue'

// Global state für Loading
const isLoading = ref(false)
const loadingMessage = ref('')

export const useGlobalLoading = () => {
  const setLoading = (loading: boolean, message = '') => {
    isLoading.value = loading
    loadingMessage.value = message
  }

  const startLoading = (message = 'Lädt...') => {
    setLoading(true, message)
  }

  const stopLoading = () => {
    setLoading(false, '')
  }

  return {
    isLoading: readonly(isLoading),
    loadingMessage: readonly(loadingMessage),
    setLoading,
    startLoading,
    stopLoading
  }
}
