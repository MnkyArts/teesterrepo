import { ref, computed, readonly } from 'vue'
import { authClient } from '~/lib/auth-client'
import type { UserRole } from '@prisma/client'

// Extended user type for Better Auth with additional fields
export interface ExtendedUser {
  id: string
  name: string
  email: string
  emailVerified: boolean
  image?: string | null
  createdAt: Date
  updatedAt: Date
  firstName: string
  lastName: string
  role: UserRole
  avatar?: string | null
  isActive: boolean
  lastLoginAt?: Date | null
}

// Global state für Authentifizierung - sicher initialisiert  
const isLoading = ref<boolean>(false)
const isInitialized = ref<boolean>(false)
// Sofortige Auth-State-Erkennung für bessere UX
const hasCheckedAuth = ref<boolean>(false)

// Singleton pattern für Auth-Initialisierung
let initPromise: Promise<void> | null = null

export interface LoginCredentials {
  email: string
  password: string
}

export interface RegisterData {
  email: string
  password: string
  firstName: string
  lastName: string
  role?: UserRole
}

export const useAuth = () => {
  // Better Auth session hook
  const session = authClient.useSession()
  const { addNotification } = useNotifications()
  
  // Computed values based on Better Auth session
  const isLoggedIn = computed(() => !!session.value.data?.user)
  const user = computed(() => session.value.data?.user as ExtendedUser | null)
  
  // Full name computed property
  const fullName = computed(() => {
    if (!user.value) return ''
    return `${user.value.firstName} ${user.value.lastName}`
  })

  // Initials computed property
  const initials = computed(() => {
    if (!user.value) return ''
    const firstName = user.value.firstName?.charAt(0) || ''
    const lastName = user.value.lastName?.charAt(0) || ''
    return `${firstName}${lastName}`.toUpperCase()
  })

  /**
   * Initialize auth - Optimized for performance
   */
  const initializeAuth = async () => {
    if (isInitialized.value) return
    
    if (initPromise) {
      await initPromise
      return
    }

    initPromise = new Promise(async (resolve) => {
      try {
        // Sofortiger State-Check für bessere UX
        hasCheckedAuth.value = true
        
        // Better Auth session is automatically managed
        // Minimal initialization for better performance
        isInitialized.value = true
        resolve()
      } catch (error) {
        console.error('Auth initialization error:', error)
        isInitialized.value = true
        hasCheckedAuth.value = true
        resolve()
      }
    })
  }

  /**
   * Benutzer anmelden
   */
  const login = async (credentials: LoginCredentials): Promise<boolean> => {
    isLoading.value = true
    
    try {
      const result = await authClient.signIn.email({
        email: credentials.email,
        password: credentials.password,
        callbackURL: '/'
      })

      if (result.data) {
        addNotification({
          type: 'success',
          title: 'Anmeldung erfolgreich',
          message: 'Sie wurden erfolgreich angemeldet'
        })
        
        // Automatic redirect based on user role
        await redirectToRoleBasedDashboard()
        return true
      }
      
      return false
    } catch (error: any) {
      console.error('Login error:', error)
      addNotification({
        type: 'error',
        title: 'Anmeldung fehlgeschlagen',
        message: error.message || 'Ein unbekannter Fehler ist aufgetreten'
      })
      return false
    } finally {
      isLoading.value = false
    }
  }

  /**
   * Benutzer registrieren
   */
  const register = async (userData: RegisterData): Promise<boolean> => {
    isLoading.value = true
    
    try {
      const result = await authClient.signUp.email({
        email: userData.email,
        password: userData.password,
        name: `${userData.firstName} ${userData.lastName}`,
        callbackURL: '/'
      })

      if (result.data) {
        addNotification({
          type: 'success',
          title: 'Registrierung erfolgreich',
          message: 'Ihr Konto wurde erfolgreich erstellt'
        })
        
        await navigateTo('/')
        return true
      }
      
      return false
    } catch (error: any) {
      console.error('Registration error:', error)
      addNotification({
        type: 'error',
        title: 'Registrierung fehlgeschlagen',
        message: error.message || 'Ein unbekannter Fehler ist aufgetreten'
      })
      return false
    } finally {
      isLoading.value = false
    }
  }

  /**
   * Benutzer abmelden
   */
  const logout = async (): Promise<void> => {
    isLoading.value = true
    
    try {
      await authClient.signOut({
        fetchOptions: {
          onSuccess: () => {
            addNotification({
              type: 'success',
              title: 'Abmeldung erfolgreich',
              message: 'Sie wurden erfolgreich abgemeldet'
            })
          }
        }
      })
      
      await navigateTo('/auth/login')
    } catch (error: any) {
      console.error('Logout error:', error)
      addNotification({
        type: 'error',
        title: 'Abmeldung fehlgeschlagen',
        message: error.message || 'Ein unbekannter Fehler ist aufgetreten'
      })
    } finally {
      isLoading.value = false
    }
  }

  /**
   * Passwort ändern
   */
  const changePassword = async (currentPassword: string, newPassword: string): Promise<boolean> => {
    isLoading.value = true
    
    try {
      // Better Auth will handle password changes through its API
      const result = await $fetch('/api/auth/change-password', {
        method: 'POST',
        body: {
          currentPassword,
          newPassword
        }
      })

      if (result) {
        addNotification({
          type: 'success',
          title: 'Passwort geändert',
          message: 'Ihr Passwort wurde erfolgreich geändert'
        })
        return true
      }
      
      return false
    } catch (error: any) {
      console.error('Password change error:', error)
      addNotification({
        type: 'error',
        title: 'Passwort-Änderung fehlgeschlagen',
        message: error.message || 'Ein unbekannter Fehler ist aufgetreten'
      })
      return false
    } finally {
      isLoading.value = false
    }
  }

  /**
   * Überprüft Berechtigung basierend auf Rolle
   */
  const hasPermission = (requiredRole: UserRole): boolean => {
    if (!user.value) return false
    
    const roleHierarchy: Record<UserRole, number> = {
      VIEWER: 1,
      KUNDE: 2,
      SUPPORTER: 3,
      ENTWICKLER: 4,
      PROJEKTLEITER: 5,
      ADMINISTRATOR: 6
    }
    
    const userRoleLevel = roleHierarchy[user.value.role as UserRole] || 0
    const requiredRoleLevel = roleHierarchy[requiredRole] || 0
    
    return userRoleLevel >= requiredRoleLevel
  }

  /**
   * Überprüft ob Benutzer Administrator ist
   */
  const isAdmin = computed(() => hasPermission('ADMINISTRATOR'))

  /**
   * Überprüft ob Benutzer Projektleiter oder höher ist
   */
  const isProjectManager = computed(() => hasPermission('PROJEKTLEITER'))

  /**
   * Überprüft ob Benutzer Entwickler oder höher ist
   */
  const isDeveloper = computed(() => hasPermission('ENTWICKLER'))

  /**
   * Überprüft ob Benutzer Kunde ist
   */
  const isCustomer = computed(() => user.value?.role === 'KUNDE')

  /**
   * Redirects user to appropriate dashboard based on their role
   */
  const redirectToRoleBasedDashboard = async () => {
    if (!user.value) return
    
    if (user.value.role === 'KUNDE') {
      await navigateTo('/customer')
    } else {
      await navigateTo('/')
    }
  }

  /**
   * Gets the default route for the current user role
   */
  const getDefaultRoute = computed(() => {
    if (!user.value) return '/auth/login'
    
    if (user.value.role === 'KUNDE') {
      return '/customer'
    } else {
      return '/'
    }
  })

  // Return all auth functions and state
  return {
    // State
    user: readonly(user),
    isLoggedIn: readonly(isLoggedIn),
    isLoading: readonly(isLoading),
    isInitialized: readonly(isInitialized),
    hasCheckedAuth: readonly(hasCheckedAuth),
    fullName: readonly(fullName),
    initials: readonly(initials),
    
    // Actions
    initializeAuth,
    login,
    register,
    logout,
    changePassword,
    
    // Permissions
    hasPermission,
    isAdmin: readonly(isAdmin),
    isProjectManager: readonly(isProjectManager),
    isDeveloper: readonly(isDeveloper),
    isCustomer: readonly(isCustomer),
    
    // Redirects
    redirectToRoleBasedDashboard,
    getDefaultRoute: readonly(getDefaultRoute)
  }
}
