# wnmManagement - Datenbank Setup

## 🚀 Schnellstart

### 1. Erstmalige Einrichtung

```bash
# 1. Datenbank-Services starten
./db.sh setup

# Oder alternativ mit separaten Befehlen:
./db.sh start
./db.sh migrate
./db.sh seed
```

### 2. Development starten

```bash
# Datenbank ist bereits gestartet, nur Nuxt starten
bun dev
```

## 📊 Datenbankzugriff

### Verfügbare Services

- **PostgreSQL**: `localhost:5432`
  - Database: `wnm_management`
  - User: `wnm_user`
  - Password: `wnm_password`

- **Redis**: `localhost:6379`

- **pgAdmin** (optional): `http://localhost:8080`
  - Email: `admin@wnm.de`
  - Password: `admin123!`

### Verbindung zur Datenbank

```bash
# Mit integriertem psql
./db.sh psql

# Oder direkt mit Docker
docker-compose exec postgres psql -U wnm_user wnm_management
```

## 🛠️ Datenbank-Management

### Grundlegende Befehle

```bash
# Services starten
./db.sh start
bun run db:start

# Services stoppen
./db.sh stop
bun run db:stop

# Status anzeigen
./db.sh status

# Logs anzeigen
./db.sh logs
```

### Migrations und Seeding

```bash
# Prisma Migrationen ausführen
./db.sh migrate
bun run db:migrate

# Datenbank mit Testdaten füllen
./db.sh seed
bun run db:seed

# Datenbank komplett zurücksetzen
./db.sh reset
bun run db:reset
```

### Backup und Restore

```bash
# Backup erstellen
./db.sh backup

# Backup wiederherstellen
./db.sh restore backup_20250619_143000.sql
```

## 🔧 Entwicklung

### Mit pgAdmin arbeiten

```bash
# pgAdmin mitstarting
./db.sh pgadmin
```

Dann öffne `http://localhost:8080` und verbinde dich zur Datenbank:
- Host: `postgres` (Docker-interner Name)
- Port: `5432`
- Database: `wnm_management`
- Username: `wnm_user`
- Password: `wnm_password`

### Prisma Studio

```bash
# Prisma Studio für grafische Datenbankansicht
bun run db:studio
```

Öffnet `http://localhost:5555` mit einer grafischen Oberfläche für die Datenbank.

## 📁 Dateistruktur

```
/
├── docker-compose.yml          # Docker Services Konfiguration
├── .env                        # Umgebungsvariablen
├── db.sh                       # Datenbank-Management-Script
├── docker/
│   └── postgres/
│       └── init/
│           └── 01-init.sh      # Datenbank-Initialisierung
├── prisma/
│   ├── schema.prisma           # Datenbankschema
│   └── seed.ts                 # Seed-Daten
└── README-DATABASE.md          # Diese Datei
```

## 🔐 Test-Benutzer

Nach dem Seeding sind folgende Benutzer verfügbar:

- **Administrator**: `admin@wnm.de` / `admin123!`
- **Projektleiter**: `manager@wnm.de` / `manager123!`
- **Entwickler**: `dev@wnm.de` / `dev123!`

## 🐳 Docker-Services

### PostgreSQL
- **Image**: `postgres:15-alpine`
- **Port**: `5432:5432`
- **Volumes**: Persistente Datenspeicherung
- **Extensions**: uuid-ossp, pg_trgm, btree_gin
- **Timezone**: Europe/Berlin

### Redis
- **Image**: `redis:7-alpine`
- **Port**: `6379:6379`
- **Konfiguration**: 256MB Memory Limit, LRU Eviction

### pgAdmin (Optional)
- **Image**: `dpage/pgadmin4:latest`
- **Port**: `8080:80`
- **Profile**: `dev` (nur mit `--profile dev` gestartet)

## 🚨 Troubleshooting

### Häufige Probleme

1. **Port bereits belegt**
   ```bash
   # Prüfe welcher Prozess Port 5432 verwendet
   lsof -i :5432
   
   # Stoppe lokale PostgreSQL-Installation falls vorhanden
   sudo systemctl stop postgresql
   ```

2. **Verbindung fehlgeschlagen**
   ```bash
   # Prüfe ob Container läuft
   docker-compose ps
   
   # Zeige Container-Logs
   ./db.sh logs
   ```

3. **Migration-Fehler**
   ```bash
   # Prisma-Client neu generieren
   bun run db:generate
   
   # Datenbank komplett zurücksetzen
   ./db.sh reset
   ```

4. **Berechtigungsfehler**
   ```bash
   # Script ausführbar machen
   chmod +x ./db.sh
   ```

### Datenbank komplett neu aufsetzen

```bash
# Alle Container und Volumes löschen
docker-compose down -v
docker volume prune -f

# Neu starten
./db.sh setup
```

## 🔗 Nützliche Links

- [Prisma Documentation](https://www.prisma.io/docs/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [Docker Compose Documentation](https://docs.docker.com/compose/)

## 📝 Entwickler-Notizen

- Die Datenbank läuft in einem Docker-Container für konsistente Entwicklungsumgebung
- Alle Daten werden in benannten Volumes persistiert
- Die `.env`-Datei enthält alle notwendigen Verbindungsparameter
- Das `db.sh`-Script vereinfacht alle gängigen Datenbankoperationen
- pgAdmin ist optional und nur für detaillierte Datenbankanalyse gedacht
