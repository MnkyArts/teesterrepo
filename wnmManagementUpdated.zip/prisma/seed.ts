import { PrismaClient } from '@prisma/client'
import { auth } from '../lib/auth'

const prisma = new PrismaClient()

async function createUserWithAuth(email: string, password: string, userData: any) {
  try {
    console.log(`👤 Creating user: ${email}`)
    
    // Check if user already exists
    const existingUser = await prisma.user.findUnique({ where: { email } })
    if (existingUser) {
      console.log(`   User ${email} already exists, skipping...`)
      return existingUser
    }

    // Create user with Better Auth
    const result = await auth.api.signUpEmail({
      body: {
        email,
        password,
        ...userData
      }
    })

    if (!result.user) {
      throw new Error(`Failed to create user ${email}`)
    }

    console.log(`   ✅ Created user: ${email}`)
    return await prisma.user.findUnique({ where: { email } })

  } catch (error: any) {
    console.error(`   ❌ Failed to create ${email}:`, error?.message || error)
    throw error
  }
}

async function main() {
  console.log('🌱 Seeding database with Better Auth...')

  try {
    // Create users using Better Auth's native signup
    const admin = await createUserWithAuth('admin@wnm.de', 'AdminPassword123!', {
      name: 'System Administrator',
      firstName: 'System',
      lastName: 'Administrator',
      role: 'ADMINISTRATOR'
    })

    const manager = await createUserWithAuth('manager@wnm.de', 'ManagerPassword123!', {
      name: 'Max Mustermann',
      firstName: 'Max',
      lastName: 'Mustermann',
      role: 'PROJEKTLEITER'
    })

    const developer = await createUserWithAuth('dev@wnm.de', 'DevPassword123!', {
      name: 'Anna Schmidt',
      firstName: 'Anna',
      lastName: 'Schmidt',
      role: 'ENTWICKLER'
    })

    // Create demo customer user for testing customer portal
    const customerUser = await createUserWithAuth('kunde@demo.de', 'KundePassword123!', {
      name: 'Maria Beispiel',
      firstName: 'Maria',
      lastName: 'Beispiel',
      role: 'KUNDE'
    })

    if (!admin || !manager || !developer || !customerUser) {
      throw new Error('Failed to create all required users')
    }

    // Update users to set email as verified and additional fields
    console.log('🔧 Updating user verification status...')
    await prisma.user.updateMany({
      where: {
        email: {
          in: ['admin@wnm.de', 'manager@wnm.de', 'dev@wnm.de', 'kunde@demo.de']
        }
      },
      data: {
        emailVerified: true,
        emailVerifiedAt: new Date(),
        isActive: true
      }
    })

  // Create enum categories and values first
  console.log('🏷️ Creating enum categories and values...')
  
  // Task Type Category
  const taskTypeCategory = await prisma.enumCategory.upsert({
    where: { name: 'task_type' },
    update: {},
    create: {
      name: 'task_type',
      label: 'Aufgabentyp',
      description: 'Verschiedene Aufgabentypen',
      isSystem: true,
      sortOrder: 1
    }
  })

  // Priority Category
  const priorityCategory = await prisma.enumCategory.upsert({
    where: { name: 'priority' },
    update: {},
    create: {
      name: 'priority',
      label: 'Priorität',
      description: 'Aufgaben- und Ticket-Prioritäten',
      isSystem: true,
      sortOrder: 2
    }
  })

  // Task Status Category
  const taskStatusCategory = await prisma.enumCategory.upsert({
    where: { name: 'task_status' },
    update: {},
    create: {
      name: 'task_status',
      label: 'Task Status',
      description: 'Verschiedene Aufgabenstatus',
      isSystem: true,
      sortOrder: 3
    }
  })

  // Ticket Status Category
  const ticketStatusCategory = await prisma.enumCategory.upsert({
    where: { name: 'ticket_status' },
    update: {},
    create: {
      name: 'ticket_status',
      label: 'Ticket Status',
      description: 'Verschiedene Ticketstatus',
      isSystem: true,
      sortOrder: 4
    }
  })

  // Ticket Type Category
  const ticketTypeCategory = await prisma.enumCategory.upsert({
    where: { name: 'ticket_type' },
    update: {},
    create: {
      name: 'ticket_type',
      label: 'Ticket-Typ',
      description: 'Verschiedene Ticket-Typen',
      isSystem: true,
      sortOrder: 5
    }
  })

  // Create enum values
  // Task Types - For global enums, we'll use findFirst and create pattern instead of upsert
  let taskTypeAufgabe = await prisma.enumValue.findFirst({
    where: { 
      categoryId: taskTypeCategory.id, 
      key: 'AUFGABE',
      projectId: null
    }
  })
  
  if (!taskTypeAufgabe) {
    taskTypeAufgabe = await prisma.enumValue.create({
      data: {
        categoryId: taskTypeCategory.id,
        key: 'AUFGABE',
        label: 'Aufgabe',
        description: 'Allgemeine Aufgabe',
        color: '#3b82f6',
        icon: 'task',
        isDefault: true,
        sortOrder: 1,
        projectId: null
      }
    })
  }

  let taskTypeFeature = await prisma.enumValue.findFirst({
    where: { 
      categoryId: taskTypeCategory.id, 
      key: 'FEATURE',
      projectId: null
    }
  })
  
  if (!taskTypeFeature) {
    taskTypeFeature = await prisma.enumValue.create({
      data: {
        categoryId: taskTypeCategory.id,
        key: 'FEATURE',
        label: 'Feature',
        description: 'Neue Funktionalität',
        color: '#10b981',
        icon: 'star',
        sortOrder: 2,
        projectId: null
      }
    })
  }

  let taskTypeBug = await prisma.enumValue.findFirst({
    where: { 
      categoryId: taskTypeCategory.id, 
      key: 'BUG',
      projectId: null
    }
  })
  
  if (!taskTypeBug) {
    taskTypeBug = await prisma.enumValue.create({
      data: {
        categoryId: taskTypeCategory.id,
        key: 'BUG',
        label: 'Bug',
        description: 'Fehlerbehebung',
        color: '#ef4444',
        icon: 'bug',
        sortOrder: 3,
        projectId: null
      }
    })
  }

  // Priorities
  let priorityNormal = await prisma.enumValue.findFirst({
    where: { 
      categoryId: priorityCategory.id, 
      key: 'NORMAL',
      projectId: null
    }
  })
  
  if (!priorityNormal) {
    priorityNormal = await prisma.enumValue.create({
      data: {
        categoryId: priorityCategory.id,
        key: 'NORMAL',
        label: 'Normal',
        description: 'Normale Priorität',
        color: '#6b7280',
        icon: 'minus',
        isDefault: true,
        sortOrder: 2,
        projectId: null
      }
    })
  }

  let priorityHoch = await prisma.enumValue.findFirst({
    where: { 
      categoryId: priorityCategory.id, 
      key: 'HOCH',
      projectId: null
    }
  })
  
  if (!priorityHoch) {
    priorityHoch = await prisma.enumValue.create({
      data: {
        categoryId: priorityCategory.id,
        key: 'HOCH',
        label: 'Hoch',
        description: 'Hohe Priorität',
        color: '#f59e0b',
        icon: 'chevron-up',
        sortOrder: 3,
        projectId: null
      }
    })
  }

  // Task Status
  let statusErledigt = await prisma.enumValue.findFirst({
    where: { 
      categoryId: taskStatusCategory.id, 
      key: 'ERLEDIGT',
      projectId: null
    }
  })
  
  if (!statusErledigt) {
    statusErledigt = await prisma.enumValue.create({
      data: {
        categoryId: taskStatusCategory.id,
        key: 'ERLEDIGT',
        label: 'Erledigt',
        description: 'Aufgabe abgeschlossen',
        color: '#10b981',
        icon: 'check',
        sortOrder: 6,
        projectId: null
      }
    })
  }

  let statusInBearbeitung = await prisma.enumValue.findFirst({
    where: { 
      categoryId: taskStatusCategory.id, 
      key: 'IN_BEARBEITUNG',
      projectId: null
    }
  })
  
  if (!statusInBearbeitung) {
    statusInBearbeitung = await prisma.enumValue.create({
      data: {
        categoryId: taskStatusCategory.id,
        key: 'IN_BEARBEITUNG',
        label: 'In Bearbeitung',
        description: 'Aufgabe wird bearbeitet',
        color: '#3b82f6',
        icon: 'play',
        sortOrder: 3,
        projectId: null
      }
    })
  }

  let statusGeplant = await prisma.enumValue.findFirst({
    where: { 
      categoryId: taskStatusCategory.id, 
      key: 'GEPLANT',
      projectId: null
    }
  })
  
  if (!statusGeplant) {
    statusGeplant = await prisma.enumValue.create({
      data: {
        categoryId: taskStatusCategory.id,
        key: 'GEPLANT',
        label: 'Geplant',
        description: 'Aufgabe geplant',
        color: '#6b7280',
        icon: 'calendar',
        isDefault: true,
        sortOrder: 1,
        projectId: null
      }
    })
  }

  // Ticket Status
  let ticketStatusOffen = await prisma.enumValue.findFirst({
    where: { 
      categoryId: ticketStatusCategory.id, 
      key: 'OFFEN',
      projectId: null
    }
  })
  
  if (!ticketStatusOffen) {
    ticketStatusOffen = await prisma.enumValue.create({
      data: {
        categoryId: ticketStatusCategory.id,
        key: 'OFFEN',
        label: 'Offen',
        description: 'Ticket offen',
        color: '#ef4444',
        icon: 'circle',
        isDefault: true,
        sortOrder: 1,
        projectId: null
      }
    })
  }

  let ticketStatusInBearbeitung = await prisma.enumValue.findFirst({
    where: { 
      categoryId: ticketStatusCategory.id, 
      key: 'IN_BEARBEITUNG',
      projectId: null
    }
  })
  
  if (!ticketStatusInBearbeitung) {
    ticketStatusInBearbeitung = await prisma.enumValue.create({
      data: {
        categoryId: ticketStatusCategory.id,
        key: 'IN_BEARBEITUNG',
        label: 'In Bearbeitung',
        description: 'Ticket wird bearbeitet',
        color: '#3b82f6',
        icon: 'play',
        sortOrder: 2,
        projectId: null
      }
    })
  }

  let ticketStatusGeloest = await prisma.enumValue.findFirst({
    where: { 
      categoryId: ticketStatusCategory.id, 
      key: 'GELOEST',
      projectId: null
    }
  })
  
  if (!ticketStatusGeloest) {
    ticketStatusGeloest = await prisma.enumValue.create({
      data: {
        categoryId: ticketStatusCategory.id,
        key: 'GELOEST',
        label: 'Gelöst',
        description: 'Ticket gelöst',
        color: '#10b981',
        icon: 'check',
        sortOrder: 4,
        projectId: null
      }
    })
  }

  let ticketStatusGeschlossen = await prisma.enumValue.findFirst({
    where: { 
      categoryId: ticketStatusCategory.id, 
      key: 'GESCHLOSSEN',
      projectId: null
    }
  })
  
  if (!ticketStatusGeschlossen) {
    ticketStatusGeschlossen = await prisma.enumValue.create({
      data: {
        categoryId: ticketStatusCategory.id,
        key: 'GESCHLOSSEN',
        label: 'Geschlossen',
        description: 'Ticket geschlossen',
        color: '#6b7280',
        icon: 'x',
        sortOrder: 5,
        projectId: null
      }
    })
  }

  // Ticket Types
  let ticketTypeSupport = await prisma.enumValue.findFirst({
    where: { 
      categoryId: ticketTypeCategory.id, 
      key: 'SUPPORT',
      projectId: null
    }
  })
  
  if (!ticketTypeSupport) {
    ticketTypeSupport = await prisma.enumValue.create({
      data: {
        categoryId: ticketTypeCategory.id,
        key: 'SUPPORT',
        label: 'Support',
        description: 'Allgemeine Support-Anfrage',
        color: '#3b82f6',
        icon: 'question-mark-circle',
        isDefault: true,
        sortOrder: 1,
        projectId: null
      }
    })
  }

  let ticketTypeBuchhaltung = await prisma.enumValue.findFirst({
    where: { 
      categoryId: ticketTypeCategory.id, 
      key: 'BUCHHALTUNG',
      projectId: null
    }
  })
  
  if (!ticketTypeBuchhaltung) {
    ticketTypeBuchhaltung = await prisma.enumValue.create({
      data: {
        categoryId: ticketTypeCategory.id,
        key: 'BUCHHALTUNG',
        label: 'Buchhaltung',
        description: 'Rechnungs- und Zahlungsanfragen',
        color: '#10b981',
        icon: 'calculator',
        sortOrder: 2,
        projectId: null
      }
    })
  }

  let ticketTypeTechnik = await prisma.enumValue.findFirst({
    where: { 
      categoryId: ticketTypeCategory.id, 
      key: 'TECHNIK',
      projectId: null
    }
  })
  
  if (!ticketTypeTechnik) {
    ticketTypeTechnik = await prisma.enumValue.create({
      data: {
        categoryId: ticketTypeCategory.id,
        key: 'TECHNIK',
        label: 'Technische Probleme',
        description: 'Technische Probleme und Fehlerberichte',
        color: '#ef4444',
        icon: 'wrench-screwdriver',
        sortOrder: 3,
        projectId: null
      }
    })
  }

  let ticketTypeFeatureRequest = await prisma.enumValue.findFirst({
    where: { 
      categoryId: ticketTypeCategory.id, 
      key: 'FEATURE_REQUEST',
      projectId: null
    }
  })
  
  if (!ticketTypeFeatureRequest) {
    ticketTypeFeatureRequest = await prisma.enumValue.create({
      data: {
        categoryId: ticketTypeCategory.id,
        key: 'FEATURE_REQUEST',
        label: 'Feature-Anfrage',
        description: 'Neue Funktionen oder Verbesserungsvorschläge',
        color: '#8b5cf6',
        icon: 'light-bulb',
        sortOrder: 4,
        projectId: null
      }
    })
  }

  // Demo-Kunde mit Benutzeraccount erstellen
  const demoCustomer = await prisma.customer.upsert({
    where: { email: 'kunde@demo.de' },
    update: {},
    create: {
      companyName: 'Demo AG',
      contactName: 'Maria Beispiel',
      email: 'kunde@demo.de',
      phone: '+49 89 123456789',
      address: 'Beispielstraße 42',
      city: 'Berlin',
      postalCode: '10115',
      country: 'Deutschland',
      vatNumber: 'DE123456789',
      userId: customerUser.id
    }
  })

  // Test-Kunde erstellen
  const customer = await prisma.customer.upsert({
    where: { email: 'test@kunde.de' },
    update: {},
    create: {
      companyName: 'Test GmbH',
      contactName: 'Hans Müller',
      email: 'test@kunde.de',
      phone: '+49 123 456789',
      address: 'Musterstraße 123',
      city: 'München',
      postalCode: '80331',
      country: 'Deutschland'
    }
  })

  // Test-Projekt erstellen
  const project = await prisma.project.upsert({
    where: { key: 'TEST-001' },
    update: {},
    create: {
      key: 'TEST-001',
      name: 'Test-Projekt',
      description: 'Ein Beispielprojekt für die Entwicklung',
      status: 'AKTIV',
      customerId: customer.id,
      startDate: new Date(),
      budget: 50000.00
    }
  })

  // Projektmitglieder hinzufügen
  await prisma.projectMember.upsert({
    where: { 
      userId_projectId: {
        userId: manager.id,
        projectId: project.id
      }
    },
    update: {},
    create: {
      userId: manager.id,
      projectId: project.id,
      role: 'Projektleiter'
    }
  })

  await prisma.projectMember.upsert({
    where: { 
      userId_projectId: {
        userId: developer.id,
        projectId: project.id
      }
    },
    update: {},
    create: {
      userId: developer.id,
      projectId: project.id,
      role: 'Entwickler'
    }
  })

  // Test-Aufgaben erstellen
  const task1 = await prisma.task.upsert({
    where: { key: 'TEST-001-001' },
    update: {},
    create: {
      key: 'TEST-001-001',
      title: 'Projektinitialisierung',
      description: 'Grundlegende Projektstruktur und Setup',
      typeId: taskTypeAufgabe.id,
      priorityId: priorityHoch.id,
      statusId: statusErledigt.id,
      projectId: project.id,
      assigneeId: developer.id,
      creatorId: manager.id,
      estimatedHours: 8,
      remainingHours: 0
    }
  })

  const task2 = await prisma.task.upsert({
    where: { key: 'TEST-001-002' },
    update: {},
    create: {
      key: 'TEST-001-002',
      title: 'User Interface Design',
      description: 'Erstellung der Benutzeroberfläche',
      typeId: taskTypeFeature.id,
      priorityId: priorityNormal.id,
      statusId: statusInBearbeitung.id,
      projectId: project.id,
      assigneeId: developer.id,
      creatorId: manager.id,
      estimatedHours: 16,
      remainingHours: 8,
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // In einer Woche
    }
  })

  // Zeiterfassungen erstellen
  await prisma.timeEntry.create({
    data: {
      description: 'Projektsetup und Konfiguration',
      hours: 8,
      date: new Date(),
      category: 'Entwicklung',
      billable: true,
      userId: developer.id,
      projectId: project.id,
      taskId: task1.id
    }
  })

  await prisma.timeEntry.create({
    data: {
      description: 'UI-Konzept und erste Implementierung',
      hours: 4,
      date: new Date(),
      category: 'Entwicklung',
      billable: true,
      userId: developer.id,
      projectId: project.id,
      taskId: task2.id
    }
  })

  // Aktivitätslogs erstellen
  await prisma.activityLog.create({
    data: {
      action: 'task_created',
      description: 'Aufgabe "Projektinitialisierung" wurde erstellt',
      userId: manager.id,
      projectId: project.id,
      taskId: task1.id
    }
  })

  await prisma.activityLog.create({
    data: {
      action: 'task_status_changed',
      description: 'Status von "Projektinitialisierung" geändert',
      oldValue: 'GEPLANT',
      newValue: 'ERLEDIGT',
      userId: developer.id,
      projectId: project.id,
      taskId: task1.id
    }
  })

  // Benachrichtigungen erstellen
  await prisma.notification.create({
    data: {
      title: 'Willkommen bei wenoma!',
      message: 'Ihr Konto wurde erfolgreich erstellt.',
      type: 'INFO',
      userId: developer.id
    }
  })

  // Test-Ticket erstellen
  await prisma.ticket.create({
    data: {
      title: 'Frage zur Rechnungsstellung',
      description: 'Ich hätte eine Frage bezüglich der aktuellen Rechnung...',
      typeId: ticketTypeBuchhaltung.id,
      priorityId: priorityNormal.id,
      statusId: ticketStatusOffen.id,
      department: 'Buchhaltung',
      customerId: customer.id
    }
  })

  // Test-Rechnung erstellen
  await prisma.invoice.upsert({
    where: { number: 'R-2025-001' },
    update: {},
    create: {
      number: 'R-2025-001',
      amount: 4000.00,
      vatAmount: 760.00,
      totalAmount: 4760.00,
      status: 'VERSENDET',
      issueDate: new Date(),
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 Tage
      description: 'Entwicklungsarbeiten Januar 2025',
      customerId: customer.id
    }
  })

  // Demo-Kundendaten erstellen
  // SEPA-Mandat für Demo-Kunden
  await prisma.sepaMandate.upsert({
    where: { mandateId: 'DEMO-MANDATE-001' },
    update: {},
    create: {
      mandateId: 'DEMO-MANDATE-001',
      iban: 'DE89370400440532013000',
      bic: 'COBADEFFXXX',
      accountHolder: 'Demo AG',
      signedDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // vor 30 Tagen
      customerId: demoCustomer.id
    }
  })

  // Demo-Projekt für Kunden
  const demoCustomerProject = await prisma.project.upsert({
    where: { key: 'DEMO-001' },
    update: {},
    create: {
      key: 'DEMO-001',
      name: 'Kundenprojekt Demo',
      description: 'Ein Demoprojekt für den Kundenbereich',
      status: 'AKTIV',
      customerId: demoCustomer.id,
      startDate: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000), // vor 60 Tagen
      budget: 25000.00
    }
  })

  // Demo-Ticket für Kunden
  await prisma.ticket.create({
    data: {
      title: 'Frage zur Projektfortschritt',
      description: 'Könnten Sie mir bitte ein Update zum aktuellen Projektstand geben?',
      typeId: ticketTypeSupport.id,
      priorityId: priorityNormal.id,
      statusId: ticketStatusOffen.id,
      department: 'Projektmanagement',
      customerId: demoCustomer.id
    }
  })

  // Demo-Rechnung für Kunden
  await prisma.invoice.upsert({
    where: { number: 'R-2025-002' },
    update: {},
    create: {
      number: 'R-2025-002',
      amount: 5000.00,
      vatAmount: 950.00,
      totalAmount: 5950.00,
      status: 'BEZAHLT',
      issueDate: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000), // vor 45 Tagen
      dueDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), // vor 15 Tagen
      paidDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // vor 10 Tagen
      description: 'Webentwicklung Phase 1',
      customerId: demoCustomer.id
    }
  })

  await prisma.invoice.upsert({
    where: { number: 'R-2025-003' },
    update: {},
    create: {
      number: 'R-2025-003',
      amount: 3200.00,
      vatAmount: 608.00,
      totalAmount: 3808.00,
      status: 'VERSENDET',
      issueDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), // vor 15 Tagen
      dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000), // in 15 Tagen
      description: 'Webentwicklung Phase 2',
      customerId: demoCustomer.id
    }
  })

    console.log('✅ Database seeded successfully!')
    console.log('\n👤 Test-Benutzer:')
    console.log('📧 admin@wnm.de (Passwort: AdminPassword123!)')
    console.log('📧 manager@wnm.de (Passwort: ManagerPassword123!)')
    console.log('📧 dev@wnm.de (Passwort: DevPassword123!)')
    console.log('\n🏢 Demo-Kunde (für Kundenportal-Tests):')
    console.log('📧 kunde@demo.de (Passwort: KundePassword123!)')
    console.log('   Unternehmen: Demo AG')
    console.log('   SEPA-Mandat: DEMO-MANDATE-001')
    console.log('   Projekt: DEMO-001 (Kundenprojekt Demo)')
    console.log('   Rechnungen: 2 (eine bezahlt, eine offen)')

  } catch (error) {
    console.error('❌ Seeding failed:', error instanceof Error ? error.message : String(error))
    throw error
  }
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error('❌ Seeding failed:', e instanceof Error ? e.message : String(e))
    await prisma.$disconnect()
    process.exit(1)
  })
