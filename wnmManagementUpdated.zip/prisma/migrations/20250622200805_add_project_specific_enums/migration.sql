/*
  Warnings:

  - A unique constraint covering the columns `[categoryId,key,projectId]` on the table `enum_values` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "enum_values_categoryId_key_key";

-- AlterTable
ALTER TABLE "enum_values" ADD COLUMN     "projectId" TEXT;

-- CreateIndex
CREATE INDEX "enum_values_projectId_idx" ON "enum_values"("projectId");

-- CreateIndex
CREATE UNIQUE INDEX "enum_values_categoryId_key_projectId_key" ON "enum_values"("categoryId", "key", "projectId");

-- AddForeignKey
ALTER TABLE "enum_values" ADD CONSTRAINT "enum_values_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "projects"("id") ON DELETE CASCADE ON UPDATE CASCADE;
