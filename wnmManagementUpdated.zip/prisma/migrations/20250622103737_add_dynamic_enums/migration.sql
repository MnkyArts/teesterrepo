/*
  Warnings:

  - You are about to drop the column `priority` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `status` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `type` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `priority` on the `tickets` table. All the data in the column will be lost.
  - You are about to drop the column `status` on the `tickets` table. All the data in the column will be lost.

*/
-- DropIndex
DROP INDEX "tasks_assigneeId_status_idx";

-- DropIndex
DROP INDEX "tasks_priority_dueDate_idx";

-- DropIndex
DROP INDEX "tasks_projectId_status_idx";

-- DropIndex
DROP INDEX "tasks_status_idx";

-- AlterTable
ALTER TABLE "tasks" DROP COLUMN "priority",
DROP COLUMN "status",
DROP COLUMN "type",
ADD COLUMN     "priorityId" TEXT,
ADD COLUMN     "statusId" TEXT,
ADD COLUMN     "typeId" TEXT;

-- AlterTable
ALTER TABLE "tickets" DROP COLUMN "priority",
DROP COLUMN "status",
ADD COLUMN     "priorityId" TEXT,
ADD COLUMN     "statusId" TEXT,
ADD COLUMN     "typeId" TEXT;

-- DropEnum
DROP TYPE "Priority";

-- DropEnum
DROP TYPE "TaskStatus";

-- DropEnum
DROP TYPE "TaskType";

-- DropEnum
DROP TYPE "TicketStatus";

-- CreateTable
CREATE TABLE "enum_categories" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "description" TEXT,
    "isSystem" BOOLEAN NOT NULL DEFAULT false,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "enum_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "enum_values" (
    "id" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "description" TEXT,
    "color" TEXT,
    "icon" TEXT,
    "isDefault" BOOLEAN NOT NULL DEFAULT false,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "categoryId" TEXT NOT NULL,

    CONSTRAINT "enum_values_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "project_enum_overrides" (
    "id" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "sortOrder" INTEGER,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "projectId" TEXT NOT NULL,
    "categoryId" TEXT NOT NULL,
    "enumValueId" TEXT NOT NULL,

    CONSTRAINT "project_enum_overrides_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "enum_categories_name_key" ON "enum_categories"("name");

-- CreateIndex
CREATE INDEX "enum_values_categoryId_isActive_idx" ON "enum_values"("categoryId", "isActive");

-- CreateIndex
CREATE INDEX "enum_values_categoryId_sortOrder_idx" ON "enum_values"("categoryId", "sortOrder");

-- CreateIndex
CREATE UNIQUE INDEX "enum_values_categoryId_key_key" ON "enum_values"("categoryId", "key");

-- CreateIndex
CREATE INDEX "project_enum_overrides_projectId_idx" ON "project_enum_overrides"("projectId");

-- CreateIndex
CREATE INDEX "project_enum_overrides_categoryId_idx" ON "project_enum_overrides"("categoryId");

-- CreateIndex
CREATE UNIQUE INDEX "project_enum_overrides_projectId_categoryId_enumValueId_key" ON "project_enum_overrides"("projectId", "categoryId", "enumValueId");

-- CreateIndex
CREATE INDEX "tasks_assigneeId_statusId_idx" ON "tasks"("assigneeId", "statusId");

-- CreateIndex
CREATE INDEX "tasks_projectId_statusId_idx" ON "tasks"("projectId", "statusId");

-- CreateIndex
CREATE INDEX "tasks_statusId_idx" ON "tasks"("statusId");

-- CreateIndex
CREATE INDEX "tasks_priorityId_dueDate_idx" ON "tasks"("priorityId", "dueDate");

-- CreateIndex
CREATE INDEX "tasks_typeId_idx" ON "tasks"("typeId");

-- CreateIndex
CREATE INDEX "tickets_statusId_idx" ON "tickets"("statusId");

-- CreateIndex
CREATE INDEX "tickets_priorityId_idx" ON "tickets"("priorityId");

-- CreateIndex
CREATE INDEX "tickets_typeId_idx" ON "tickets"("typeId");

-- CreateIndex
CREATE INDEX "tickets_customerId_idx" ON "tickets"("customerId");

-- AddForeignKey
ALTER TABLE "tasks" ADD CONSTRAINT "tasks_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES "enum_values"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tasks" ADD CONSTRAINT "tasks_priorityId_fkey" FOREIGN KEY ("priorityId") REFERENCES "enum_values"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tasks" ADD CONSTRAINT "tasks_statusId_fkey" FOREIGN KEY ("statusId") REFERENCES "enum_values"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "enum_values" ADD CONSTRAINT "enum_values_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "enum_categories"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "project_enum_overrides" ADD CONSTRAINT "project_enum_overrides_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "projects"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "project_enum_overrides" ADD CONSTRAINT "project_enum_overrides_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "enum_categories"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "project_enum_overrides" ADD CONSTRAINT "project_enum_overrides_enumValueId_fkey" FOREIGN KEY ("enumValueId") REFERENCES "enum_values"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tickets" ADD CONSTRAINT "tickets_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES "enum_values"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tickets" ADD CONSTRAINT "tickets_priorityId_fkey" FOREIGN KEY ("priorityId") REFERENCES "enum_values"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tickets" ADD CONSTRAINT "tickets_statusId_fkey" FOREIGN KEY ("statusId") REFERENCES "enum_values"("id") ON DELETE SET NULL ON UPDATE CASCADE;
