-- Migration to add project-specific enum support
-- Add projectId to enum_values table

BEGIN;

-- Add projectId column to enum_values table
ALTER TABLE "enum_values" 
ADD COLUMN "projectId" TEXT REFERENCES "projects"("id") ON DELETE CASCADE;

-- Update the unique constraint to include projectId
ALTER TABLE "enum_values" 
DROP CONSTRAINT "enum_values_categoryId_key_key";

ALTER TABLE "enum_values" 
ADD CONSTRAINT "enum_values_categoryId_key_projectId_key" 
UNIQUE ("categoryId", "key", "projectId");

-- Add index for project-specific queries
CREATE INDEX "enum_values_projectId_idx" ON "enum_values"("projectId");

-- Update existing enum values to have null projectId (they are global)
-- No action needed as column will be null by default

COMMIT;
