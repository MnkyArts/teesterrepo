<template>
  <div class="space-y-4">
    <!-- Chart Container -->
    <div class="h-64 w-full">
      <canvas ref="chartCanvas" class="w-full h-full"></canvas>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick, watch } from 'vue'

interface RevenueData {
  date: string
  revenue: number
  target: number
}

interface Props {
  data: RevenueData[]
}

const props = defineProps<Props>()

const chartCanvas = ref<HTMLCanvasElement>()

const renderChart = async () => {
  await nextTick()
  
  if (!chartCanvas.value || !props.data.length) return
  
  const ctx = chartCanvas.value.getContext('2d')
  if (!ctx) return
  
  const { width, height } = chartCanvas.value
  
  ctx.clearRect(0, 0, width, height)
  
  // Chart dimensions
  const padding = 50
  const chartWidth = width - 2 * padding
  const chartHeight = height - 2 * padding
  
  // Find max value for scaling
  const maxRevenue = Math.max(...props.data.map(d => Math.max(d.revenue, d.target)))
  const scale = chartHeight / (maxRevenue * 1.1)
  
  // Draw grid lines
  ctx.strokeStyle = '#E5E7EB'
  ctx.lineWidth = 1
  
  for (let i = 0; i <= 5; i++) {
    const y = padding + (chartHeight / 5) * i
    ctx.beginPath()
    ctx.moveTo(padding, y)
    ctx.lineTo(width - padding, y)
    ctx.stroke()
  }
  
  // Draw axes
  ctx.strokeStyle = '#374151'
  ctx.lineWidth = 2
  ctx.beginPath()
  ctx.moveTo(padding, padding)
  ctx.lineTo(padding, height - padding)
  ctx.lineTo(width - padding, height - padding)
  ctx.stroke()
  
  // Draw data lines
  const stepX = chartWidth / (props.data.length - 1)
  
  // Revenue line (area chart)
  ctx.fillStyle = 'rgba(59, 130, 246, 0.1)'
  ctx.strokeStyle = '#3B82F6'
  ctx.lineWidth = 3
  ctx.beginPath()
  
  // Start area
  ctx.moveTo(padding, height - padding)
  
  props.data.forEach((point, index) => {
    const x = padding + index * stepX
    const y = height - padding - (point.revenue * scale)
    ctx.lineTo(x, y)
  })
  
  // Close area
  ctx.lineTo(padding + (props.data.length - 1) * stepX, height - padding)
  ctx.closePath()
  ctx.fill()
  
  // Draw revenue line
  ctx.beginPath()
  props.data.forEach((point, index) => {
    const x = padding + index * stepX
    const y = height - padding - (point.revenue * scale)
    
    if (index === 0) {
      ctx.moveTo(x, y)
    } else {
      ctx.lineTo(x, y)
    }
  })
  ctx.stroke()
  
  // Target line (dashed)
  ctx.strokeStyle = '#EF4444'
  ctx.setLineDash([5, 5])
  ctx.beginPath()
  props.data.forEach((point, index) => {
    const x = padding + index * stepX
    const y = height - padding - (point.target * scale)
    
    if (index === 0) {
      ctx.moveTo(x, y)
    } else {
      ctx.lineTo(x, y)
    }
  })
  ctx.stroke()
  ctx.setLineDash([]) // Reset line dash
  
  // Draw data points
  props.data.forEach((point, index) => {
    const x = padding + index * stepX
    
    // Revenue point
    const revenueY = height - padding - (point.revenue * scale)
    ctx.fillStyle = '#3B82F6'
    ctx.beginPath()
    ctx.arc(x, revenueY, 4, 0, 2 * Math.PI)
    ctx.fill()
    
    // Target point
    const targetY = height - padding - (point.target * scale)
    ctx.fillStyle = '#EF4444'
    ctx.beginPath()
    ctx.arc(x, targetY, 4, 0, 2 * Math.PI)
    ctx.fill()
  })
  
  // Labels
  ctx.fillStyle = '#374151'
  ctx.font = '12px system-ui'
  ctx.textAlign = 'center'
  
  props.data.forEach((point, index) => {
    const x = padding + index * stepX
    const label = new Date(point.date).toLocaleDateString('de-DE', { 
      month: 'short', 
      day: 'numeric' 
    })
    ctx.fillText(label, x, height - padding + 20)
  })
  
  // Y-axis labels
  ctx.textAlign = 'right'
  for (let i = 0; i <= 5; i++) {
    const value = (maxRevenue * 1.1 / 5) * (5 - i)
    const y = padding + (chartHeight / 5) * i
    ctx.fillText('€' + Math.round(value).toLocaleString('de-DE'), padding - 10, y + 4)
  }
}

const resizeCanvas = () => {
  if (!chartCanvas.value) return
  
  const container = chartCanvas.value.parentElement
  if (!container) return
  
  chartCanvas.value.width = container.clientWidth
  chartCanvas.value.height = container.clientHeight
  
  renderChart()
}

watch(() => props.data, () => {
  renderChart()
}, { deep: true })

onMounted(() => {
  resizeCanvas()
  window.addEventListener('resize', resizeCanvas)
})
</script>
