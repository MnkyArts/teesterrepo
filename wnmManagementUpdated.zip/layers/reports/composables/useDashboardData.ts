/**
 * Dashboard Data Management Composable
 * Optimized for performance with intelligent caching and refresh strategies
 */

interface DashboardData {
  stats: any
  myTasks: any[]
  recentActivities: any[]
  teamActivities: any[]
}

const refreshInProgress = ref(false)
const lastRefreshTime = ref<Date | null>(null)
const REFRESH_COOLDOWN = 30000 // 30 seconds

export const useDashboardData = () => {
  // Optimized fetch functions with better error handling
  const { data: dashboardStats, pending: statsLoading, refresh: refreshStats, error: statsError } = useFetch('/api/dashboard/stats', {
    key: 'dashboard-stats',
    default: () => ({ success: false, data: null }),
    server: false,
    lazy: true,
    transform: (data: any) => data?.data || null,
    onResponseError({ response }) {
      console.error('Stats API error:', response.status, response.statusText)
    }
  })

  const { data: myTasksData, pending: tasksLoading, refresh: refreshMyTasks, error: tasksError } = useFetch('/api/dashboard/my-tasks', {
    key: 'dashboard-my-tasks',
    default: () => [],
    server: false,
    lazy: true,
    query: { limit: 5 },
    transform: (data: any) => data?.data || [],
    onResponseError({ response }) {
      console.error('Tasks API error:', response.status, response.statusText)
    }
  })

  const { data: recentActivitiesData, pending: activitiesLoading, refresh: refreshActivities, error: activitiesError } = useFetch('/api/dashboard/activities', {
    key: 'dashboard-activities',
    default: () => [],
    server: false,
    lazy: true,
    query: { limit: 5 },
    transform: (data: any) => data?.data || [],
    onResponseError({ response }) {
      console.error('Activities API error:', response.status, response.statusText)
    }
  })

  const { data: teamActivitiesData, pending: teamLoading, refresh: refreshTeamActivities, error: teamError } = useFetch('/api/dashboard/team-activities', {
    key: 'dashboard-team-activities',
    default: () => [],
    server: false,
    lazy: true,
    query: { limit: 5 },
    transform: (data: any) => data?.data || [],
    onResponseError({ response }) {
      console.error('Team activities API error:', response.status, response.statusText)
    }
  })

  // Computed loading states
  const isLoading = computed(() => {
    return statsLoading.value || tasksLoading.value || activitiesLoading.value || teamLoading.value
  })

  const hasErrors = computed(() => {
    return !!(statsError.value || tasksError.value || activitiesError.value || teamError.value)
  })

  // Intelligent refresh with cooldown and error handling
  const refreshAllData = async (force = false): Promise<boolean> => {
    // Prevent too frequent refreshes
    if (!force && refreshInProgress.value) {
      console.log('Refresh already in progress, skipping...')
      return false
    }

    if (!force && lastRefreshTime.value && Date.now() - lastRefreshTime.value.getTime() < REFRESH_COOLDOWN) {
      console.log('Refresh cooldown active, skipping...')
      return false
    }

    refreshInProgress.value = true
    lastRefreshTime.value = new Date()

    try {
      // Parallel execution with individual error handling
      const results = await Promise.allSettled([
        refreshStats(),
        refreshMyTasks(),
        refreshActivities(),
        refreshTeamActivities()
      ])

      // Log any failed refreshes
      results.forEach((result, index) => {
        if (result.status === 'rejected') {
          const endpoints = ['stats', 'tasks', 'activities', 'team-activities']
          console.warn(`Failed to refresh ${endpoints[index]}:`, result.reason)
        }
      })

      // Return true if at least one succeeded
      return results.some(result => result.status === 'fulfilled')
    } catch (error) {
      console.error('Dashboard refresh error:', error)
      return false
    } finally {
      refreshInProgress.value = false
    }
  }

  // Auto-refresh with visibility API
  let refreshInterval: NodeJS.Timeout | null = null

  const startAutoRefresh = (intervalMs = 300000) => { // 5 minutes default
    if (refreshInterval) return

    refreshInterval = setInterval(() => {
      if (!document.hidden && !refreshInProgress.value) {
        refreshAllData()
      }
    }, intervalMs)
  }

  const stopAutoRefresh = () => {
    if (refreshInterval) {
      clearInterval(refreshInterval)
      refreshInterval = null
    }
  }

  // Handle page visibility changes
  const handleVisibilityChange = () => {
    if (document.hidden) {
      stopAutoRefresh()
    } else {
      startAutoRefresh()
      // Refresh if data is stale (older than 2 minutes)
      if (lastRefreshTime.value && Date.now() - lastRefreshTime.value.getTime() > 120000) {
        refreshAllData()
      }
    }
  }

  // Lifecycle management
  const initializeDashboard = () => {
    startAutoRefresh()
    if (process.client) {
      document.addEventListener('visibilitychange', handleVisibilityChange)
    }
  }

  const cleanupDashboard = () => {
    stopAutoRefresh()
    if (process.client) {
      document.removeEventListener('visibilitychange', handleVisibilityChange)
    }
  }

  return {
    // Data
    dashboardStats,
    myTasksData,
    recentActivitiesData,
    teamActivitiesData,
    
    // Loading states
    statsLoading,
    tasksLoading,
    activitiesLoading,
    teamLoading,
    isLoading,
    refreshInProgress,
    
    // Error states
    statsError,
    tasksError,
    activitiesError,
    teamError,
    hasErrors,
    
    // Actions
    refreshAllData,
    refreshStats,
    refreshMyTasks,
    refreshActivities,
    refreshTeamActivities,
    
    // Lifecycle
    initializeDashboard,
    cleanupDashboard,
    startAutoRefresh,
    stopAutoRefresh,
    
    // Meta
    lastRefreshTime
  }
}
