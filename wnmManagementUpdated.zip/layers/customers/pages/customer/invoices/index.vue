<template>
    <div class="space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between">
        <div>
          <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
            {{ $t('invoices.title') }}
          </h1>
          <p class="text-gray-600 dark:text-gray-400">
            Übersicht über alle Ihre Rechnungen und Zahlungen
          </p>
        </div>
      </div>

      <!-- Statistics -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div class="flex items-center">
            <div class="flex-shrink-0">
              <div class="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-md flex items-center justify-center">
                <Icon name="heroicons:document-text" class="w-5 h-5 text-blue-600" />
              </div>
            </div>
            <div class="ml-4">
              <div class="text-sm font-medium text-gray-600 dark:text-gray-400">
                {{ $t('invoices.totalInvoices') }}
              </div>
              <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                {{ pagination.total || 0 }}
              </div>
            </div>
          </div>
        </div>

        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div class="flex items-center">
            <div class="flex-shrink-0">
              <div class="w-8 h-8 bg-green-100 dark:bg-green-900 rounded-md flex items-center justify-center">
                <Icon name="heroicons:check-circle" class="w-5 h-5 text-green-600" />
              </div>
            </div>
            <div class="ml-4">
              <div class="text-sm font-medium text-gray-600 dark:text-gray-400">
                Bezahlt
              </div>
              <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                {{ getPaidCount() }}
              </div>
            </div>
          </div>
        </div>

        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div class="flex items-center">
            <div class="flex-shrink-0">
              <div class="w-8 h-8 bg-orange-100 dark:bg-orange-900 rounded-md flex items-center justify-center">
                <Icon name="heroicons:clock" class="w-5 h-5 text-orange-600" />
              </div>
            </div>
            <div class="ml-4">
              <div class="text-sm font-medium text-gray-600 dark:text-gray-400">
                Offen
              </div>
              <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                {{ getOpenCount() }}
              </div>
            </div>
          </div>
        </div>

        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div class="flex items-center">
            <div class="flex-shrink-0">
              <div class="w-8 h-8 bg-purple-100 dark:bg-purple-900 rounded-md flex items-center justify-center">
                <Icon name="heroicons:currency-euro" class="w-5 h-5 text-purple-600" />
              </div>
            </div>
            <div class="ml-4">
              <div class="text-sm font-medium text-gray-600 dark:text-gray-400">
                {{ $t('invoices.totalAmountStat') }}
              </div>
              <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                {{ formatCurrency(getTotalAmount()) }}
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Filters -->
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
        <div class="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0 md:space-x-4">
          <!-- Status Filter -->
          <div class="flex-1">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('invoices.filterByStatus') }}
            </label>
            <select
              v-model="filters.status"
              @change="loadInvoices"
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            >
              <option value="">{{ $t('invoices.allStatuses') }}</option>
              <option value="ENTWURF">{{ $t('invoices.status.entwurf') }}</option>
              <option value="VERSENDET">{{ $t('invoices.status.versendet') }}</option>
              <option value="BEZAHLT">{{ $t('invoices.status.bezahlt') }}</option>
              <option value="UEBERFAELLIG">{{ $t('invoices.status.ueberfaellig') }}</option>
              <option value="STORNIERT">{{ $t('invoices.status.storniert') }}</option>
            </select>
          </div>

          <!-- Year Filter -->
          <div class="flex-1">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('invoices.filterByYear') }}
            </label>
            <select
              v-model="filters.year"
              @change="loadInvoices"
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            >
              <option value="">{{ $t('invoices.allYears') }}</option>
              <option v-for="year in availableYears" :key="year" :value="year">
                {{ year }}
              </option>
            </select>
          </div>

          <!-- Search -->
          <div class="flex-1">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Suche
            </label>
            <div class="relative">
              <input
                v-model="searchQuery"
                @input="debouncedSearch"
                type="text"
                placeholder="Rechnungsnummer suchen..."
                class="w-full px-3 py-2 pl-10 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
              >
              <Icon name="heroicons:magnifying-glass" class="w-5 h-5 text-gray-400 absolute left-3 top-2.5" />
            </div>
          </div>
        </div>
      </div>

      <!-- Invoices List -->
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <!-- Loading State -->
        <div v-if="loading" class="p-6">
          <div class="space-y-4">
            <div v-for="i in 3" :key="i" class="animate-pulse">
              <div class="flex items-center space-x-4">
                <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
                <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/6"></div>
                <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Empty State -->
        <div v-else-if="invoices.length === 0" class="p-12 text-center">
          <Icon name="heroicons:document-text" class="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-600" />
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
            {{ $t('invoices.noInvoices') }}
          </h3>
          <p class="text-gray-600 dark:text-gray-400">
            Es wurden noch keine Rechnungen für Ihr Konto erstellt.
          </p>
        </div>

        <!-- Invoices Table -->
        <div v-else class="overflow-hidden">
          <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead class="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  {{ $t('invoices.invoiceNumber') }}
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  {{ $t('invoices.issueDate') }}
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  {{ $t('invoices.dueDate') }}
                </th>
                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  {{ $t('invoices.totalAmount') }}
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Status
                </th>
                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Aktionen
                </th>
              </tr>
            </thead>
            <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              <tr 
                v-for="invoice in invoices" 
                :key="invoice.id"
                class="hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <td class="px-6 py-4 whitespace-nowrap">
                  <div class="text-sm font-medium text-gray-900 dark:text-white">
                    {{ invoice.number }}
                  </div>
                  <div v-if="invoice.description" class="text-sm text-gray-500 dark:text-gray-400">
                    {{ invoice.description }}
                  </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                  {{ formatDate(invoice.issueDate) }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                  {{ formatDate(invoice.dueDate) }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-gray-900 dark:text-white">
                  {{ formatCurrency(invoice.totalAmount) }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <span 
                    class="inline-flex px-2 py-1 text-xs font-medium rounded-full"
                    :class="getStatusBadgeClass(invoice.status)"
                  >
                    {{ $t(`invoices.status.${invoice.status.toLowerCase()}`) }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <div class="flex justify-end space-x-2">
                    <button
                      v-if="invoice.pdfPath"
                      @click="downloadInvoice(invoice.id)"
                      class="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300"
                      title="PDF herunterladen"
                    >
                      <Icon name="heroicons:arrow-down-tray" class="w-4 h-4" />
                    </button>
                    <button
                      @click="viewInvoiceDetails(invoice)"
                      class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-300"
                      title="Details anzeigen"
                    >
                      <Icon name="heroicons:eye" class="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <div v-if="pagination.pages > 1" class="px-6 py-4 border-t border-gray-200 dark:border-gray-700">
          <div class="flex items-center justify-between">
            <div class="text-sm text-gray-700 dark:text-gray-300">
              Zeige {{ (pagination.page - 1) * pagination.limit + 1 }} bis 
              {{ Math.min(pagination.page * pagination.limit, pagination.total) }} von 
              {{ pagination.total }} Rechnungen
            </div>
            <div class="flex items-center space-x-2">
              <button
                @click="changePage(pagination.page - 1)"
                :disabled="pagination.page <= 1"
                class="px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Zurück
              </button>
              <span class="px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Seite {{ pagination.page }} von {{ pagination.pages }}
              </span>
              <button
                @click="changePage(pagination.page + 1)"
                :disabled="pagination.page >= pagination.pages"
                class="px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Weiter
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Invoice Details Modal (placeholder) -->
    <div v-if="selectedInvoice" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6">
          <div class="flex items-center justify-between mb-6">
            <h2 class="text-xl font-bold text-gray-900 dark:text-white">
              Rechnung {{ selectedInvoice.number }}
            </h2>
            <button
              @click="selectedInvoice = null"
              class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <Icon name="heroicons:x-mark" class="w-6 h-6" />
            </button>
          </div>
          
          <div class="space-y-4">
            <div class="grid grid-cols-2 gap-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  {{ $t('invoices.issueDate') }}
                </label>
                <p class="text-gray-900 dark:text-white">{{ formatDate(selectedInvoice.issueDate) }}</p>
              </div>
              <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  {{ $t('invoices.dueDate') }}
                </label>
                <p class="text-gray-900 dark:text-white">{{ formatDate(selectedInvoice.dueDate) }}</p>
              </div>
            </div>
            
            <div v-if="selectedInvoice.description">
              <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                {{ $t('invoices.description') }}
              </label>
              <p class="text-gray-900 dark:text-white">{{ selectedInvoice.description }}</p>
            </div>
            
            <div class="grid grid-cols-3 gap-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  {{ $t('invoices.amount') }}
                </label>
                <p class="text-gray-900 dark:text-white">{{ formatCurrency(selectedInvoice.amount) }}</p>
              </div>
              <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  {{ $t('invoices.vatAmount') }}
                </label>
                <p class="text-gray-900 dark:text-white">{{ formatCurrency(selectedInvoice.vatAmount) }}</p>
              </div>
              <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  {{ $t('invoices.totalAmount') }}
                </label>
                <p class="text-lg font-semibold text-gray-900 dark:text-white">{{ formatCurrency(selectedInvoice.totalAmount) }}</p>
              </div>
            </div>
            
            <div class="flex items-center justify-between pt-4">
              <span 
                class="inline-flex px-3 py-1 text-sm font-medium rounded-full"
                :class="getStatusBadgeClass(selectedInvoice.status)"
              >
                {{ $t(`invoices.status.${selectedInvoice.status.toLowerCase()}`) }}
              </span>
              
              <div class="flex space-x-3">
                <button
                  v-if="selectedInvoice.pdfPath"
                  @click="downloadInvoice(selectedInvoice.id)"
                  class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
                >
                  <Icon name="heroicons:arrow-down-tray" class="w-4 h-4 mr-2" />
                  {{ $t('invoices.downloadPdf') }}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script setup>
definePageMeta({
  layout: 'customer',
})

const notificationsStore = useNotificationsStore()
const { addNotification } = notificationsStore

// State
const loading = ref(false)
const invoices = ref([])
const statistics = ref([])
const selectedInvoice = ref(null)
const searchQuery = ref('')
const filters = ref({
  status: '',
  year: ''
})

const pagination = ref({
  page: 1,
  limit: 10,
  total: 0,
  pages: 0
})

// Computed
const availableYears = computed(() => {
  const years = []
  const currentYear = new Date().getFullYear()
  for (let i = currentYear; i >= currentYear - 5; i--) {
    years.push(i)
  }
  return years
})

// Load invoices
const loadInvoices = async (page = 1) => {
  loading.value = true
  try {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: pagination.value.limit.toString(),
      ...(filters.value.status && { status: filters.value.status }),
      ...(filters.value.year && { year: filters.value.year }),
      ...(searchQuery.value && { search: searchQuery.value })
    })

    const response = await $fetch(`/api/customer/invoices?${params}`)
    
    invoices.value = response.invoices
    statistics.value = response.stats
    pagination.value = response.pagination

  } catch (error) {
    console.error('Failed to load invoices:', error)
    addNotification({
      type: 'error',
      title: 'Fehler',
      message: 'Rechnungen konnten nicht geladen werden.'
    })
  } finally {
    loading.value = false
  }
}

// Pagination
const changePage = (page) => {
  if (page >= 1 && page <= pagination.value.pages) {
    loadInvoices(page)
  }
}

// Search debouncing
let searchTimeout
const debouncedSearch = () => {
  clearTimeout(searchTimeout)
  searchTimeout = setTimeout(() => {
    loadInvoices(1)
  }, 500)
}

// Actions
const downloadInvoice = async (invoiceId) => {
  try {
    addNotification({
      type: 'info',
      title: 'Feature in Entwicklung',
      message: 'PDF-Download wird in einer zukünftigen Version verfügbar sein.'
    })
  } catch (error) {
    addNotification({
      type: 'error',
      title: 'Fehler',
      message: 'PDF konnte nicht heruntergeladen werden.'
    })
  }
}

const viewInvoiceDetails = (invoice) => {
  selectedInvoice.value = invoice
}

// Statistics helpers
const getPaidCount = () => {
  if (!Array.isArray(statistics.value)) return 0
  return statistics.value.find(s => s.status === 'BEZAHLT')?._count?.status || 0
}

const getOpenCount = () => {
  if (!Array.isArray(statistics.value)) return 0
  const openStatuses = ['VERSENDET', 'UEBERFAELLIG']
  return statistics.value
    .filter(s => openStatuses.includes(s.status))
    .reduce((sum, s) => sum + (s._count?.status || 0), 0)
}

const getTotalAmount = () => {
  if (!Array.isArray(statistics.value)) return 0
  return statistics.value.reduce((sum, s) => sum + (s._sum?.totalAmount || 0), 0)
}

// Utility functions
const formatDate = (date) => {
  return new Date(date).toLocaleDateString('de-DE', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  })
}

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('de-DE', {
    style: 'currency',
    currency: 'EUR'
  }).format(amount)
}

const getStatusBadgeClass = (status) => {
  const classes = {
    'ENTWURF': 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300',
    'VERSENDET': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
    'BEZAHLT': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    'UEBERFAELLIG': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
    'STORNIERT': 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
  }
  return classes[status] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
}

// Load initial data
onMounted(() => {
  loadInvoices()
})
</script>
