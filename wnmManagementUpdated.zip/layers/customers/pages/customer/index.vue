<template>
  <div class="space-y-8">
    <!-- Welcome Section -->
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
        <div class="flex items-center space-x-4">
          <div class="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
            <Icon name="heroicons:building-office" class="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
              {{ $t('customerCenter.welcome', { name: customerName }) }}
            </h1>
            <p class="text-gray-600 dark:text-gray-400">
              {{ $t('customerCenter.welcomeDescription') }}
            </p>
          </div>
        </div>
      </div>

      <!-- Quick Stats -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Open Tickets -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div class="flex items-center">
            <div class="flex-shrink-0">
              <div class="w-8 h-8 bg-orange-100 dark:bg-orange-900 rounded-md flex items-center justify-center">
                <Icon name="heroicons:ticket" class="w-5 h-5 text-orange-600" />
              </div>
            </div>
            <div class="ml-4">
              <div class="text-sm font-medium text-gray-600 dark:text-gray-400">
                {{ $t('customerCenter.stats.openTickets') }}
              </div>
              <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                {{ stats.openTickets }}
              </div>
            </div>
          </div>
          <div class="mt-4">
            <NuxtLink 
              to="/customer/tickets"
              class="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium"
            >
              {{ $t('customerCenter.stats.viewTickets') }} →
            </NuxtLink>
          </div>
        </div>

        <!-- Pending Invoices -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div class="flex items-center">
            <div class="flex-shrink-0">
              <div class="w-8 h-8 bg-red-100 dark:bg-red-900 rounded-md flex items-center justify-center">
                <Icon name="heroicons:document-text" class="w-5 h-5 text-red-600" />
              </div>
            </div>
            <div class="ml-4">
              <div class="text-sm font-medium text-gray-600 dark:text-gray-400">
                {{ $t('customerCenter.stats.pendingInvoices') }}
              </div>
              <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                {{ stats.pendingInvoices }}
              </div>
            </div>
          </div>
          <div class="mt-4">
            <NuxtLink 
              to="/customer/invoices"
              class="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium"
            >
              {{ $t('customerCenter.stats.viewInvoices') }} →
            </NuxtLink>
          </div>
        </div>

        <!-- Account Status / SEPA Mandate -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div class="flex items-center">
            <div class="flex-shrink-0">
              <div class="w-8 h-8 rounded-md flex items-center justify-center"
                :class="sepaMandate?.isActive ? 
                  'bg-green-100 dark:bg-green-900' : 
                  'bg-yellow-100 dark:bg-yellow-900'"
              >
                <Icon 
                  :name="sepaMandate?.isActive ? 'heroicons:credit-card' : 'heroicons:exclamation-triangle'" 
                  class="w-5 h-5"
                  :class="sepaMandate?.isActive ? 'text-green-600' : 'text-yellow-600'"
                />
              </div>
            </div>
            <div class="ml-4">
              <div class="text-sm font-medium text-gray-600 dark:text-gray-400">
                {{ $t('customerCenter.stats.paymentMethod') }}
              </div>
              <div class="text-2xl font-semibold"
                :class="sepaMandate?.isActive ? 'text-green-600' : 'text-yellow-600'"
              >
                {{ sepaMandate?.isActive ? $t('sepa.mandateActive') : $t('sepa.mandateInactive') }}
              </div>
            </div>
          </div>
          <div class="mt-4">
            <NuxtLink 
              to="/customer/payments"
              class="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium"
            >
              {{ sepaMandate?.isActive ? $t('customerCenter.stats.managePayment') : $t('customerCenter.stats.setupPayment') }} →
            </NuxtLink>
          </div>
        </div>
      </div>

      <!-- Recent Activity -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- Recent Tickets -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
          <div class="p-6">
            <div class="flex items-center justify-between">
              <h2 class="text-lg font-semibold text-gray-900 dark:text-white">
                {{ $t('customerCenter.recentTickets.title') }}
              </h2>
              <NuxtLink 
                to="/customer/tickets"
                class="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium"
              >
                {{ $t('common.viewAll') }}
              </NuxtLink>
            </div>
            
            <div class="mt-6 space-y-4">
              <div 
                v-if="recentTickets.length === 0"
                class="text-center py-8 text-gray-500 dark:text-gray-400"
              >
                <Icon name="heroicons:ticket" class="w-12 h-12 mx-auto mb-3 text-gray-300 dark:text-gray-600" />
                <p>{{ $t('customerCenter.recentTickets.empty') }}</p>
                <NuxtLink 
                  to="/customer/tickets/new"
                  class="inline-block mt-3 text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium"
                >
                  {{ $t('customerCenter.recentTickets.createFirst') }}
                </NuxtLink>
              </div>
              
              <div 
                v-for="ticket in recentTickets" 
                :key="ticket.id"
                class="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg"
              >
                <div>
                  <h3 class="font-medium text-gray-900 dark:text-white">
                    {{ ticket.title }}
                  </h3>
                  <p class="text-sm text-gray-600 dark:text-gray-400">
                    {{ ticket.department }} • {{ formatDate(ticket.createdAt) }}
                  </p>
                </div>
                <div class="flex items-center space-x-2">
                  <span 
                    class="inline-flex px-2 py-1 text-xs font-medium rounded-full"
                    :class="getTicketStatusBadgeClass(ticket.status)"
                  >
                    {{ $t(`tickets.status.${ticket.status.toLowerCase()}`) }}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Recent Invoices -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
          <div class="p-6">
            <div class="flex items-center justify-between">
              <h2 class="text-lg font-semibold text-gray-900 dark:text-white">
                {{ $t('customerCenter.recentInvoices.title') }}
              </h2>
              <NuxtLink 
                to="/customer/invoices"
                class="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium"
              >
                {{ $t('common.viewAll') }}
              </NuxtLink>
            </div>
            
            <div class="mt-6 space-y-4">
              <div 
                v-if="recentInvoices.length === 0"
                class="text-center py-8 text-gray-500 dark:text-gray-400"
              >
                <Icon name="heroicons:document-text" class="w-12 h-12 mx-auto mb-3 text-gray-300 dark:text-gray-600" />
                <p>{{ $t('customerCenter.recentInvoices.empty') }}</p>
              </div>
              
              <div 
                v-for="invoice in recentInvoices" 
                :key="invoice.id"
                class="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg"
              >
                <div>
                  <h3 class="font-medium text-gray-900 dark:text-white">
                    {{ invoice.number }}
                  </h3>
                  <p class="text-sm text-gray-600 dark:text-gray-400">
                    {{ formatDate(invoice.issueDate) }}
                  </p>
                </div>
                <div class="flex items-center space-x-2">
                  <span class="font-medium text-gray-900 dark:text-white">
                    {{ formatCurrency(invoice.totalAmount) }}
                  </span>
                  <span 
                    class="inline-flex px-2 py-1 text-xs font-medium rounded-full"
                    :class="getInvoiceStatusBadgeClass(invoice.status)"
                  >
                    {{ $t(`invoices.status.${invoice.status.toLowerCase()}`) }}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
        <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-6">
          {{ $t('customerCenter.quickActions.title') }}
        </h2>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <NuxtLink
            to="/customer/tickets/new"
            class="flex items-center p-4 bg-blue-50 dark:bg-blue-900/50 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/70 transition-colors"
          >
            <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <Icon name="heroicons:plus" class="w-5 h-5 text-white" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-gray-900 dark:text-white">
                {{ $t('customerCenter.quickActions.newTicket') }}
              </div>
              <div class="text-sm text-gray-600 dark:text-gray-400">
                {{ $t('customerCenter.quickActions.newTicketDesc') }}
              </div>
            </div>
          </NuxtLink>

          <NuxtLink
            to="/customer/invoices"
            class="flex items-center p-4 bg-green-50 dark:bg-green-900/50 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/70 transition-colors"
          >
            <div class="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
              <Icon name="heroicons:document-text" class="w-5 h-5 text-white" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-gray-900 dark:text-white">
                {{ $t('customerCenter.quickActions.viewInvoices') }}
              </div>
              <div class="text-sm text-gray-600 dark:text-gray-400">
                {{ $t('customerCenter.quickActions.viewInvoicesDesc') }}
              </div>
            </div>
          </NuxtLink>

          <NuxtLink
            to="/customer/profile"
            class="flex items-center p-4 bg-purple-50 dark:bg-purple-900/50 rounded-lg hover:bg-purple-100 dark:hover:bg-purple-900/70 transition-colors"
          >
            <div class="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
              <Icon name="heroicons:user-circle" class="w-5 h-5 text-white" />
            </div>
            <div class="ml-4">
              <div class="font-medium text-gray-900 dark:text-white">
                {{ $t('customerCenter.quickActions.updateProfile') }}
              </div>
              <div class="text-sm text-gray-600 dark:text-gray-400">
                {{ $t('customerCenter.quickActions.updateProfileDesc') }}
              </div>
            </div>
          </NuxtLink>
        </div>
      </div>
    </div>
</template>

<script setup>
definePageMeta({
  layout: 'customer'
})

const authStore = useAuthStore()
const { user } = storeToRefs(authStore)
const { addNotification } = useNotifications()
const { mandate: sepaMandate, loadMandate } = useSepaManagement()

// Customer dashboard data
const stats = ref({
  openTickets: 0,
  pendingInvoices: 0,
  totalInvoices: 0
})

const recentTickets = ref([])
const recentInvoices = ref([])

const customerName = computed(() => {
  if (!user.value) return ''
  return `${user.value.firstName} ${user.value.lastName}`
})

// Load dashboard data
const loadDashboardData = async () => {
  try {
    // Load all data in parallel
    await Promise.all([
      // Load stats
      (async () => {
        const statsResponse = await $fetch('/api/customer/dashboard/stats')
        stats.value = statsResponse
      })(),
      
      // Load SEPA mandate
      loadMandate(),
      
      // Load recent tickets
      (async () => {
        const ticketsResponse = await $fetch('/api/customer/tickets?limit=3')
        recentTickets.value = ticketsResponse.tickets || []
      })(),
      
      // Load recent invoices
      (async () => {
        const invoicesResponse = await $fetch('/api/customer/invoices?limit=3')
        recentInvoices.value = invoicesResponse.invoices || []
      })()
    ])

  } catch (error) {
    console.error('Failed to load dashboard data:', error)
    addNotification({
      type: 'error',
      title: 'Fehler',
      message: 'Dashboard-Daten konnten nicht geladen werden.'
    })
  }
}

// Utility functions
const formatDate = (date) => {
  return new Date(date).toLocaleDateString('de-DE', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  })
}

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('de-DE', {
    style: 'currency',
    currency: 'EUR'
  }).format(amount)
}

const getTicketStatusBadgeClass = (status) => {
  const classes = {
    'OFFEN': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
    'IN_BEARBEITUNG': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
    'WARTEN_AUF_KUNDE': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
    'GELOEST': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    'GESCHLOSSEN': 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
  }
  return classes[status] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
}

const getInvoiceStatusBadgeClass = (status) => {
  const classes = {
    'ENTWURF': 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300',
    'VERSENDET': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
    'BEZAHLT': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    'UEBERFAELLIG': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
    'STORNIERT': 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
  }
  return classes[status] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
}

// Load data on mount
onMounted(() => {
  loadDashboardData()
})

// Auto-refresh every 5 minutes
onMounted(() => {
  const interval = setInterval(loadDashboardData, 5 * 60 * 1000)
  onUnmounted(() => clearInterval(interval))
})
</script>
