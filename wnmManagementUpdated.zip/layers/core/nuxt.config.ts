// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  // Core layer configuration
  modules: [
    '@pinia/nuxt',
    '@vueuse/nuxt',
    '@nuxtjs/tailwindcss',
    '@nuxtjs/color-mode',
    '@nuxt/icon',
    '@nuxt/image'
  ],

  // Component auto-imports
  components: [
    {
      path: './components',
      pathPrefix: false,
    }
  ],
  
  // Auto-imports for stores and composables
  imports: {
    dirs: [
      './stores/**',
      './composables/**'
    ]
  },

  // Core CSS
  css: ['~/assets/css/main.css']
})
