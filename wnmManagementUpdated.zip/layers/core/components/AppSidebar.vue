<template>
  <aside class="fixed left-0 top-16 h-[calc(100vh-4rem)] w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 overflow-y-auto transition-transform duration-300 ease-in-out z-40"
         :class="{ '-translate-x-full': !uiStore.sidebarOpen, 'translate-x-0': uiStore.sidebarOpen }"
  >
    <nav class="p-4">
      <!-- Hauptnavigation -->
      <div class="space-y-2">
        <SidebarItem
          v-for="item in filteredMainNavigation"
          :key="item.name"
          :item="item"
        />
      </div>

      <!-- Trennlinie -->
      <div class="my-6 border-t border-gray-200 dark:border-gray-700"></div>

      <!-- Projektnavigation -->
      <div v-if="projectsStore.userProjects.length > 0 && isModuleEnabled('projects')">
        <h3 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">
          {{ $t('navigation.projects') }}
        </h3>
        <div class="space-y-1">
          <SidebarProjectItem
            v-for="project in projectsStore.userProjects"
            :key="project.id"
            :project="project"
          />
        </div>
      </div>

      <!-- Administration (nur für Admins und wenn Admin-Modul aktiviert ist) -->
      <div v-if="userRole === 'ADMINISTRATOR' && isModuleEnabled('admin')" class="mt-6">
        <div class="pt-6">
          <h3 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">
            {{ $t('navigation.administration') }}
          </h3>
          <div class="space-y-2">
            <SidebarItem
              v-for="item in adminNavigation"
              :key="item.name"
              :item="item"
            />
          </div>
        </div>
      </div>
    </nav>
  </aside>

  <!-- Mobile Overlay -->
  <div
    v-if="uiStore.sidebarOpen && uiStore.isMobile"
    class="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
    @click="uiStore.closeSidebar"
  ></div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import {
  HomeIcon,
  FolderIcon,
  ClipboardDocumentListIcon,
  ClockIcon,
  UsersIcon,
  TicketIcon,
  ChartBarIcon,
  CogIcon,
  UserGroupIcon,
  DocumentTextIcon,
  ShieldCheckIcon,
  Squares2X2Icon
} from '@heroicons/vue/24/outline'
// Stores
const uiStore = useUIStore()
const authStore = useAuthStore()
const projectsStore = useProjectsStore()

// Modules
const { isModuleEnabled } = useModules()

// Computed user role
const userRole = computed(() => authStore.user?.role || null)

// Navigation Items
const mainNavigation = computed(() => [
  {
    name: 'dashboard',
    label: 'Dashboard',
    icon: HomeIcon,
    href: '/',
    active: true,
    module: 'core'
  },
  {
    name: 'projects',
    label: 'Projekte',
    icon: FolderIcon,
    href: '/projects',
    badge: projectsStore.userProjects.length || undefined,
    module: 'projects'
  },
  {
    name: 'tasks',
    label: 'Aufgaben',
    icon: ClipboardDocumentListIcon,
    href: '/tasks',
    badge: 5, // TODO: Get from API
    module: 'tasks'
  },
  {
    name: 'timeTracking',
    label: 'Zeiterfassung',
    icon: ClockIcon,
    href: '/time-tracking',
    module: 'timetracking'
  },
  {
    name: 'team',
    label: 'Team',
    icon: UsersIcon,
    href: '/team',
    permissions: ['ADMINISTRATOR', 'PROJEKTLEITER'],
    module: 'team'
  },
  {
    name: 'customers',
    label: 'Kunden',
    icon: UserGroupIcon,
    href: '/customers',
    permissions: ['ADMINISTRATOR', 'PROJEKTLEITER', 'SUPPORTER'],
    module: 'customers'
  },
  {
    name: 'tickets',
    label: 'Tickets',
    icon: TicketIcon,
    href: '/tickets',
    permissions: ['ADMINISTRATOR', 'PROJEKTLEITER', 'SUPPORTER'],
    module: 'tickets'
  },
  {
    name: 'reports',
    label: 'Berichte',
    icon: ChartBarIcon,
    href: '/reports',
    permissions: ['ADMINISTRATOR', 'PROJEKTLEITER'],
    module: 'reports'
  }
])

const adminNavigation = computed(() => [
  {
    name: 'users',
    label: 'Benutzerverwaltung',
    icon: UserGroupIcon,
    href: '/admin/users',
    module: 'admin'
  },
  {
    name: 'system',
    label: 'Systemeinstellungen',
    icon: CogIcon,
    href: '/admin/system',
    module: 'admin'
  },
  {
    name: 'audit',
    label: 'Audit-Protokolle',
    icon: DocumentTextIcon,
    href: '/admin/audit',
    module: 'admin'
  },
  {
    name: 'security',
    label: 'Sicherheit',
    icon: ShieldCheckIcon,
    href: '/admin/security',
    module: 'admin'
  }
])

// Filter navigation items based on user permissions and module status
const filteredMainNavigation = computed(() => {
  return mainNavigation.value.filter(item => {
    // Check if module is enabled
    if (item.module && !isModuleEnabled(item.module)) {
      return false
    }
    
    // Check user permissions
    if (!item.permissions) return true
    if (!userRole.value) return false
    return item.permissions.includes(userRole.value)
  })
})
</script>
