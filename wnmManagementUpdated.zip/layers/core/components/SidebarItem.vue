<template>
  <NuxtLink
    :to="item.href"
    class="flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 group"
    :class="linkClasses"
    @click="handleClick"
  >
    <component
      :is="item.icon"
      class="mr-3 h-5 w-5 flex-shrink-0"
      :class="iconClasses"
    />
    
    <span class="flex-1">{{ $t(`navigation.${item.name}`) }}</span>
    
    <!-- Badge -->
    <span
      v-if="item.badge"
      class="ml-auto inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
      :class="badgeClasses"
    >
      {{ item.badge }}
    </span>
    
    <!-- Chevron für Submenüs -->
    <ChevronRightIcon
      v-if="item.children && item.children.length > 0"
      class="ml-auto h-4 w-4 transition-transform duration-200"
      :class="{ 'rotate-90': isExpanded }"
    />
  </NuxtLink>

  <!-- Submenü -->
  <div
    v-if="item.children && isExpanded"
    class="ml-6 mt-1 space-y-1"
  >
    <SidebarItem
      v-for="child in item.children"
      :key="child.name"
      :item="child"
      class="text-sm"
    />
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue'
import { ChevronRightIcon } from '@heroicons/vue/24/outline'

interface NavigationItem {
  name: string
  label: string
  icon: any
  href: string
  active?: boolean
  badge?: number | string
  children?: NavigationItem[]
  permissions?: string[]
}

interface Props {
  item: NavigationItem
}

const props = defineProps<Props>()

// State
const isExpanded = ref(false)

// Composables
const route = useRoute()
const uiStore = useUIStore()
const { isMobile } = storeToRefs(uiStore)
const { closeSidebar } = uiStore

// Computed
const isActive = computed(() => {
  return route.path === props.item.href || route.path.startsWith(props.item.href + '/')
})

const linkClasses = computed(() => {
  return {
    'bg-blue-50 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 border-r-2 border-blue-600': isActive.value,
    'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700': !isActive.value
  }
})

const iconClasses = computed(() => {
  return {
    'text-blue-600 dark:text-blue-400': isActive.value,
    'text-gray-500 dark:text-gray-400 group-hover:text-gray-700 dark:group-hover:text-gray-300': !isActive.value
  }
})

const badgeClasses = computed(() => {
  return {
    'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-200': isActive.value,
    'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200': !isActive.value
  }
})

// Methods
const handleClick = () => {
  if (props.item.children && props.item.children.length > 0) {
    isExpanded.value = !isExpanded.value
  }
  
  // Close sidebar on mobile after navigation
  if (isMobile.value) {
    uiStore.closeSidebar()
  }
}
</script>
