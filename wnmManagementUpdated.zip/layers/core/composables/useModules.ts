import { modulesConfig, type ModulesConfig, type ModuleConfig } from '../../../modules.config'

export const useModules = () => {
  // Get module configuration
  const getModuleConfig = (moduleName: string): ModuleConfig | undefined => {
    return modulesConfig[moduleName]
  }

  // Check if a module is enabled
  const isModuleEnabled = (moduleName: string): boolean => {
    return modulesConfig[moduleName]?.enabled || false
  }

  // Get all enabled modules
  const getEnabledModules = (): string[] => {
    return Object.entries(modulesConfig)
      .filter(([_, config]) => config.enabled)
      .map(([name]) => name)
  }

  // Get enabled layers for Nuxt extends
  const getEnabledLayers = (): string[] => {
    return Object.entries(modulesConfig)
      .filter(([_, config]) => config.enabled)
      .map(([_, config]) => config.layer)
  }

  // Validate module dependencies
  const validateDependencies = (): string[] => {
    const errors: string[] = []
    const enabledModules = getEnabledModules()

    for (const [moduleName, config] of Object.entries(modulesConfig)) {
      if (!config.enabled) continue

      if (config.dependencies) {
        for (const dependency of config.dependencies) {
          if (!enabledModules.includes(dependency)) {
            errors.push(`Module "${moduleName}" requires "${dependency}" but it's not enabled`)
          }
        }
      }
    }

    return errors
  }

  // Get modules grouped by their dependencies
  const getModuleHierarchy = () => {
    const hierarchy: { [level: number]: string[] } = {}
    const processed = new Set<string>()
    const enabledModules = getEnabledModules()

    const processModule = (moduleName: string, level: number = 0): void => {
      if (processed.has(moduleName)) return
      
      const config = modulesConfig[moduleName]
      if (!config || !config.enabled) return

      if (!hierarchy[level]) hierarchy[level] = []
      hierarchy[level].push(moduleName)
      processed.add(moduleName)

      // Process dependencies first
      if (config.dependencies) {
        for (const dep of config.dependencies) {
          if (enabledModules.includes(dep)) {
            processModule(dep, level - 1)
          }
        }
      }
    }

    // Start with modules that have no dependencies
    enabledModules.forEach(moduleName => {
      const config = modulesConfig[moduleName]
      if (!config.dependencies || config.dependencies.length === 0) {
        processModule(moduleName, 0)
      }
    })

    // Process remaining modules
    enabledModules.forEach(moduleName => {
      processModule(moduleName, 1)
    })

    return hierarchy
  }

  // Check if a specific feature is available
  const isFeatureAvailable = (feature: string): boolean => {
    // Map features to modules
    const featureModuleMap: { [key: string]: string } = {
      'projects': 'projects',
      'tasks': 'tasks',
      'timetracking': 'timetracking',
      'time-tracking': 'timetracking',
      'customers': 'customers',
      'customer': 'customers',
      'team': 'team',
      'reports': 'reports',
      'analytics': 'reports',
      'notifications': 'notifications',
      'financial': 'financial',
      'sepa': 'financial',
      'tickets': 'tickets',
      'support': 'tickets',
      'admin': 'admin'
    }

    const moduleName = featureModuleMap[feature.toLowerCase()]
    return moduleName ? isModuleEnabled(moduleName) : false
  }

  // Get navigation items based on enabled modules
  const getAvailableNavigation = () => {
    const navigation: Array<{
      name: string
      path: string
      icon: string
      module: string
      enabled: boolean
    }> = [
      {
        name: 'Dashboard',
        path: '/',
        icon: 'heroicons:home',
        module: 'core',
        enabled: true
      },
      {
        name: 'Projekte',
        path: '/projects',
        icon: 'heroicons:folder',
        module: 'projects',
        enabled: isModuleEnabled('projects')
      },
      {
        name: 'Aufgaben',
        path: '/tasks',
        icon: 'heroicons:clipboard-document-list',
        module: 'tasks',
        enabled: isModuleEnabled('tasks')
      },
      {
        name: 'Zeiterfassung',
        path: '/time-tracking',
        icon: 'heroicons:clock',
        module: 'timetracking',
        enabled: isModuleEnabled('timetracking')
      },
      {
        name: 'Team',
        path: '/team',
        icon: 'heroicons:users',
        module: 'team',
        enabled: isModuleEnabled('team')
      },
      {
        name: 'Kunden',
        path: '/customer',
        icon: 'heroicons:user-group',
        module: 'customers',
        enabled: isModuleEnabled('customers')
      },
      {
        name: 'Tickets',
        path: '/tickets',
        icon: 'heroicons:ticket',
        module: 'tickets',
        enabled: isModuleEnabled('tickets')
      },
      {
        name: 'Berichte',
        path: '/reports',
        icon: 'heroicons:chart-bar',
        module: 'reports',
        enabled: isModuleEnabled('reports')
      },
      {
        name: 'Administration',
        path: '/admin',
        icon: 'heroicons:cog-6-tooth',
        module: 'admin',
        enabled: isModuleEnabled('admin')
      }
    ]

    return navigation.filter(item => item.enabled)
  }

  return {
    modulesConfig,
    getModuleConfig,
    isModuleEnabled,
    getEnabledModules,
    getEnabledLayers,
    validateDependencies,
    validateModuleDependencies: validateDependencies, // Alias for backward compatibility
    getModuleHierarchy,
    isFeatureAvailable,
    getAvailableNavigation
  }
}
