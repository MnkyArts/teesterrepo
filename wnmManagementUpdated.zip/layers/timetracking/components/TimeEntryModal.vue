<template>
  <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" @click="handleBackdropClick">
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md mx-4" @click.stop>
      <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
          {{ entry ? $t('timeTracking.editTimeEntry') : $t('timeTracking.addTimeEntry') }}
        </h3>
      </div>

      <div class="px-6 py-4 space-y-4">
        <!-- Description -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {{ $t('timeTracking.description') }} ({{ $t('common.optional') }})
          </label>
          <textarea
            v-model="formData.description"
            rows="3"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white resize-none"
            :placeholder="$t('timeTracking.descriptionPlaceholder')"
          />
        </div>

        <!-- Date -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {{ $t('timeTracking.date') }} *
          </label>
          <input
            v-model="formData.date"
            type="date"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            required
          />
        </div>

        <!-- Hours Input Mode Toggle -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {{ $t('timeTracking.timeInputMode') }}
          </label>
          <div class="flex rounded-lg bg-gray-100 dark:bg-gray-700 p-1">
            <button
              type="button"
              @click="timeInputMode = 'manual'"
              :class="[
                'px-3 py-1.5 text-sm font-medium rounded-md transition-colors flex-1',
                timeInputMode === 'manual'
                  ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
              ]"
            >
              {{ $t('timeTracking.manualHours') }}
            </button>
            <button
              type="button"
              @click="timeInputMode = 'range'"
              :class="[
                'px-3 py-1.5 text-sm font-medium rounded-md transition-colors flex-1',
                timeInputMode === 'range'
                  ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
              ]"
            >
              {{ $t('timeTracking.timeRange') }}
            </button>
          </div>
        </div>

        <!-- Manual Hours Input -->
        <div v-if="timeInputMode === 'manual'">
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {{ $t('timeTracking.hours') }} *
          </label>
          <input
            v-model.number="formData.hours"
            type="number"
            step="0.25"
            min="0.25"
            max="24"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            :placeholder="$t('timeTracking.hoursPlaceholder')"
            required
          />
        </div>

        <!-- Time Range Input -->
        <div v-else class="space-y-4">
          <div class="grid grid-cols-2 gap-4">
            <!-- Start Time -->
            <div>
              <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {{ $t('timeTracking.startTime') }} *
              </label>
              <input
                v-model="formData.startTime"
                type="time"
                class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                required
                @change="calculateHours"
              />
            </div>

            <!-- End Time -->
            <div>
              <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {{ $t('timeTracking.endTime') }} *
              </label>
              <input
                v-model="formData.endTime"
                type="time"
                class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                required
                @change="calculateHours"
              />
            </div>
          </div>

          <!-- Calculated Hours Display -->
          <div v-if="calculatedHours > 0" class="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3">
            <div class="text-sm font-medium text-blue-800 dark:text-blue-200">
              {{ $t('timeTracking.calculatedHours') }}: {{ calculatedHours.toFixed(2) }}h
            </div>
          </div>
        </div>

        <!-- Task Selection (Now Primary) -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {{ $t('tasks.task') }} *
          </label>
          <select
            v-model="formData.taskId"
            @change="onTaskChange"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            required
          >
            <option value="">{{ $t('tasks.selectTask') }}</option>
            <option
              v-for="task in availableTasks"
              :key="task.id"
              :value="task.id"
            >
              {{ task.key }} - {{ task.title }} ({{ task.project.name }})
            </option>
          </select>
          <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
            {{ $t('timeTracking.taskSelectionHelp') }}
          </p>
        </div>

        <!-- Project Display (Read-only, derived from task) -->
        <div v-if="selectedProject">
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {{ $t('projects.project') }}
          </label>
          <div class="w-full px-3 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300">
            {{ selectedProject.key }} - {{ selectedProject.name }}
          </div>
        </div>

        <!-- Category -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {{ $t('timeTracking.category') }}
          </label>
          <select
            v-model="formData.category"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="Entwicklung">{{ $t('timeTracking.categories.development') }}</option>
            <option value="Testing">{{ $t('timeTracking.categories.testing') }}</option>
            <option value="Meeting">{{ $t('timeTracking.categories.meeting') }}</option>
            <option value="Dokumentation">{{ $t('timeTracking.categories.documentation') }}</option>
            <option value="Support">{{ $t('timeTracking.categories.support') }}</option>
            <option value="Schulung">{{ $t('timeTracking.categories.training') }}</option>
            <option value="Planung">{{ $t('timeTracking.categories.planning') }}</option>
            <option value="Review">{{ $t('timeTracking.categories.review') }}</option>
          </select>
        </div>

        <!-- Billable -->
        <div class="flex items-center">
          <input
            v-model="formData.billable"
            type="checkbox"
            class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          />
          <label class="ml-2 block text-sm text-gray-700 dark:text-gray-300">
            {{ $t('timeTracking.billable') }}
          </label>
        </div>
      </div>

      <div class="px-6 py-4 bg-gray-50 dark:bg-gray-700 rounded-b-lg flex justify-end space-x-3">
        <button
          @click="$emit('close')"
          class="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-600 border border-gray-300 dark:border-gray-500 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-500 transition-colors"
        >
          {{ $t('common.cancel') }}
        </button>
        <button
          @click="handleSave"
          :disabled="!isFormValid || isLoading"
          class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <span v-if="isLoading" class="flex items-center">
            <div class="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
            {{ entry ? $t('common.updating') : $t('common.saving') }}
          </span>
          <span v-else>
            {{ entry ? $t('common.update') : $t('common.save') }}
          </span>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'

interface TimeEntry {
  id?: string
  description?: string
  hours: number
  date: string
  category: string
  billable: boolean
  projectId: string
  taskId?: string // Keep optional for backward compatibility
  startTime?: string
  endTime?: string
}

interface Task {
  id: string
  title: string
  key: string
  project: {
    id: string
    name: string
    key: string
  }
}

// Props
const props = defineProps<{
  entry?: TimeEntry
  taskId?: string
  projectId?: string
}>()

// Simple interface for time entry form data emission
interface TimeEntryFormData {
  date: string
  hours: number
  taskId?: string
  projectId?: string
  category: string
  billable: boolean
  description?: string
  id?: string
}

// Emits
const emit = defineEmits<{
  close: []
  save: [entry: TimeEntryFormData]
}>()

// Composables
const tasksStore = useTasksStore()
const { tasks, fetchTasks } = tasksStore

// State
const availableTasks = ref<Task[]>([])
const isLoading = ref(false)

const formData = ref({
  date: new Date().toISOString().split('T')[0],
  hours: 1,
  taskId: '', // Task is now primary
  projectId: '', // Derived from task
  category: 'Entwicklung',
  billable: true,
  description: '',
  startTime: '',
  endTime: ''
})

// New state for time input mode
const timeInputMode = ref<'manual' | 'range'>('manual')

// Computed for calculated hours
const calculatedHours = computed(() => {
  if (timeInputMode.value === 'range' && formData.value.startTime && formData.value.endTime) {
    const start = new Date(`2000-01-01T${formData.value.startTime}:00`)
    const end = new Date(`2000-01-01T${formData.value.endTime}:00`)
    
    if (end <= start) {
      return 0
    }
    
    const diffMs = end.getTime() - start.getTime()
    const diffHours = diffMs / (1000 * 60 * 60)
    
    return Math.round(diffHours * 4) / 4 // Round to nearest 0.25
  }
  return 0
})

// Computed
const isFormValid = computed(() => {
  return (formData.value.taskId?.length || 0) > 0 && // Now requires taskId
         formData.value.hours > 0 && 
         (formData.value.date?.length || 0) > 0
})

const selectedProject = computed(() => {
  if (!formData.value.taskId) return null
  const selectedTask = availableTasks.value.find(task => task.id === formData.value.taskId)
  return selectedTask?.project || null
})

// Methods
const handleBackdropClick = () => {
  emit('close')
}

const onTaskChange = () => {
  // Automatically set the project from the selected task
  const selectedTask = availableTasks.value.find(task => task.id === formData.value.taskId)
  if (selectedTask) {
    formData.value.projectId = selectedTask.project.id
  } else {
    formData.value.projectId = ''
  }
}

const calculateHours = () => {
  if (timeInputMode.value === 'range') {
    const hours = calculatedHours.value
    if (hours > 0) {
      formData.value.hours = hours
    }
  }
}

const handleSave = () => {
  if (!isFormValid.value) return

  const entryData: TimeEntryFormData = {
    date: formData.value.date,
    hours: formData.value.hours,
    taskId: formData.value.taskId,
    projectId: formData.value.projectId, // Still needed for API compatibility
    category: formData.value.category,
    billable: formData.value.billable,
    ...(formData.value.description && { description: formData.value.description }),
    ...(props.entry && { id: props.entry.id })
  }

  emit('save', entryData)
}

// Watch for entry prop changes
watch(() => props.entry, (newEntry) => {
  if (newEntry) {
    formData.value = {
      date: newEntry.date,
      hours: newEntry.hours,
      taskId: newEntry.taskId || '',
      projectId: newEntry.projectId,
      category: newEntry.category,
      billable: newEntry.billable,
      description: newEntry.description || '',
      startTime: newEntry.startTime || '',
      endTime: newEntry.endTime || ''
    }
    
    // Set input mode based on whether we have time range data
    if (newEntry.startTime && newEntry.endTime) {
      timeInputMode.value = 'range'
    } else {
      timeInputMode.value = 'manual'
    }
  }
}, { immediate: true })

// Watch for taskId and projectId props to pre-fill form
watch(() => [props.taskId, props.projectId], ([newTaskId, newProjectId]) => {
  if (newTaskId && !props.entry) {
    formData.value.taskId = newTaskId
  }
  if (newProjectId && !props.entry) {
    formData.value.projectId = newProjectId
  }
}, { immediate: true })

// Lifecycle
onMounted(async () => {
  try {
    // Load enums first
    const { ensureLoaded, getTaskStatuses } = useDynamicEnums()
    await ensureLoaded()
    
    // Get active task status IDs (exclude ERLEDIGT/GESCHLOSSEN)
    const taskStatuses = getTaskStatuses()
    const activeStatusIds = taskStatuses
      .filter(status => status.isActive && !['ERLEDIGT', 'GESCHLOSSEN'].includes(status.key))
      .map(status => status.id)
    
    // Load all active tasks
    await fetchTasks({
      statusId: activeStatusIds
    })
    
    if (Array.isArray(tasks)) {
      availableTasks.value = tasks as Task[]
    } else {
      availableTasks.value = []
    }
  } catch (error) {
    console.error('Error loading tasks:', error)
    availableTasks.value = []
  }
})
</script>
