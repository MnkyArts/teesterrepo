import { defineStore } from 'pinia'
import { authClient } from '~/lib/auth-client'
import type { UserRole } from '@prisma/client'

// Extended user type for Better Auth with additional fields
export interface ExtendedUser {
  id: string
  name: string
  email: string
  emailVerified: boolean
  image?: string | null
  createdAt: Date
  updatedAt: Date
  firstName: string
  lastName: string
  role: UserRole
  avatar?: string | null
  isActive: boolean
  lastLoginAt?: Date | null
}

export interface LoginCredentials {
  email: string
  password: string
}

export interface RegisterData {
  firstName: string
  lastName: string
  email: string
  password: string
  role?: UserRole
}

export const useAuthStore = defineStore('auth', () => {
  // Better Auth session hook - this handles everything automatically
  const session = authClient.useSession()
  
  // Simple loading state for auth actions
  const isLoading = ref<boolean>(false)

  // Computed values based on Better Auth session
  const isLoggedIn = computed(() => !!session.value?.data?.user)
  const user = computed(() => session.value?.data?.user as ExtendedUser | null)
  
  // Full name computed property
  const fullName = computed(() => {
    if (!user.value) return ''
    return `${user.value.firstName} ${user.value.lastName}`.trim()
  })

  // Initials computed property
  const initials = computed(() => {
    if (!user.value) return ''
    const firstName = user.value.firstName || ''
    const lastName = user.value.lastName || ''
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
  })

  /**
   * Benutzer anmelden - Using Better Auth's proper format
   */
  const login = async (credentials: LoginCredentials): Promise<boolean> => {
    try {
      const { data, error } = await authClient.signIn.email({
        email: credentials.email,
        password: credentials.password,
        callbackURL: "/" // Better Auth will handle redirect
      }, {
        onRequest: (ctx) => {
          isLoading.value = true
        },
        onSuccess: (ctx) => {
          isLoading.value = false
          console.log('Login successful, Better Auth handling redirect')
        },
        onError: (ctx) => {
          isLoading.value = false
          console.error('Login error:', ctx.error)
        }
      })

      if (error) {
        throw new Error(error.message || 'Login fehlgeschlagen')
      }

      return !!data
    } catch (error: any) {
      isLoading.value = false
      console.error('Login error:', error)
      throw error
    }
  }

  /**
   * Benutzer registrieren - Using Better Auth's proper format
   */
  const register = async (userData: RegisterData): Promise<boolean> => {
    try {
      const { data, error } = await authClient.signUp.email({
        email: userData.email,
        password: userData.password,
        name: `${userData.firstName} ${userData.lastName}`,
        callbackURL: "/" // Better Auth will handle redirect
      }, {
        onRequest: (ctx) => {
          isLoading.value = true
        },
        onSuccess: (ctx) => {
          isLoading.value = false
          console.log('Registration successful, Better Auth handling redirect')
        },
        onError: (ctx) => {
          isLoading.value = false
          console.error('Registration error:', ctx.error)
        }
      })

      if (error) {
        throw new Error(error.message || 'Registrierung fehlgeschlagen')
      }

      return !!data
    } catch (error: any) {
      isLoading.value = false
      console.error('Registration error:', error)
      throw error
    }
  }

  /**
   * Benutzer abmelden - Using Better Auth's proper format
   */
  const logout = async (): Promise<void> => {
    try {
      await authClient.signOut({
        fetchOptions: {
          onSuccess: () => {
            console.log('Logout successful, Better Auth handling redirect')
          }
        }
      })
    } catch (error: any) {
      console.error('Logout error:', error)
      throw error
    }
  }

  /**
   * Passwort ändern
   */
  const changePassword = async (currentPassword: string, newPassword: string): Promise<boolean> => {
    try {
      isLoading.value = true
      
      const result = await authClient.changePassword({
        currentPassword,
        newPassword,
        revokeOtherSessions: true,
      })

      if (result.error) {
        throw new Error(result.error.message || 'Passwort-Änderung fehlgeschlagen')
      }

      return true
    } catch (error: any) {
      console.error('Change password error:', error)
      throw error
    } finally {
      isLoading.value = false
    }
  }

  /**
   * Überprüft Berechtigung basierend auf Rolle
   */
  const hasPermission = (requiredRole: UserRole): boolean => {
    if (!user.value) return false

    const roleHierarchy: Record<UserRole, number> = {
      'KUNDE': 1,
      'VIEWER': 2,
      'SUPPORTER': 3,
      'ENTWICKLER': 4,
      'PROJEKTLEITER': 5,
      'ADMINISTRATOR': 6
    }

    const userLevel = roleHierarchy[user.value.role] || 0
    const requiredLevel = roleHierarchy[requiredRole] || 0

    return userLevel >= requiredLevel
  }

  /**
   * Überprüft ob Benutzer Administrator ist
   */
  const isAdmin = computed(() => hasPermission('ADMINISTRATOR'))

  /**
   * Überprüft ob Benutzer Projektleiter ist
   */
  const isProjectManager = computed(() => hasPermission('PROJEKTLEITER'))

  /**
   * Überprüft ob Benutzer Teammitglied ist
   */
  const isTeamMember = computed(() => hasPermission('ENTWICKLER'))

  return {
    // State
    isLoading,
    
    // Computed
    isLoggedIn,
    user,
    fullName,
    initials,
    isAdmin,
    isProjectManager,
    isTeamMember,
    
    // Actions
    login,
    register,
    logout,
    changePassword,
    hasPermission
  }
})
