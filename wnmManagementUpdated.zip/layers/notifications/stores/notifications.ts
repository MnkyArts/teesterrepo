import { defineStore } from 'pinia'

interface Notification {
  id: string
  type: 'info' | 'success' | 'warning' | 'error'
  title: string
  message: string
  timestamp: Date
  read: boolean
  actions?: {
    label: string
    action: () => void
  }[]
}

export const useNotificationsStore = defineStore('notifications', () => {
  // State
  const notifications = ref<Notification[]>([])

  // Computed properties
  const unreadCount = computed(() => 
    notifications.value.filter(n => !n.read).length
  )

  const recentNotifications = computed(() => 
    notifications.value
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, 10)
  )

  // Actions
  const addNotification = (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
    const newNotification: Notification = {
      id: `notification-${Date.now()}-${Math.random()}`,
      timestamp: new Date(),
      read: false,
      ...notification
    }
    
    notifications.value.unshift(newNotification)
    
    // Auto-remove after 5 seconds for non-error notifications
    if (notification.type !== 'error') {
      setTimeout(() => {
        removeNotification(newNotification.id)
      }, 5000)
    }
    
    return newNotification.id
  }

  const removeNotification = (id: string) => {
    const index = notifications.value.findIndex(n => n.id === id)
    if (index > -1) {
      notifications.value.splice(index, 1)
    }
  }

  const markAsRead = (id: string) => {
    const notification = notifications.value.find(n => n.id === id)
    if (notification) {
      notification.read = true
    }
  }

  const markAllAsRead = () => {
    notifications.value.forEach(n => n.read = true)
  }

  const clearAll = () => {
    notifications.value = []
  }

  // Convenience methods for different notification types
  const success = (title: string, message: string) => {
    return addNotification({ type: 'success', title, message })
  }

  const error = (title: string, message: string) => {
    return addNotification({ type: 'error', title, message })
  }

  const warning = (title: string, message: string) => {
    return addNotification({ type: 'warning', title, message })
  }

  const info = (title: string, message: string) => {
    return addNotification({ type: 'info', title, message })
  }

  return {
    // State
    notifications: readonly(notifications),
    
    // Computed
    unreadCount,
    recentNotifications,
    
    // Actions
    addNotification,
    removeNotification,
    markAsRead,
    markAllAsRead,
    clearAll,
    success,
    error,
    warning,
    info
  }
})
