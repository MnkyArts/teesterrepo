<template>
  <div class="absolute right-0 mt-2 w-80 bg-white dark:bg-gray-800 rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 z-50">
    <div class="p-4 border-b border-gray-200 dark:border-gray-700">
      <div class="flex items-center justify-between">
        <h3 class="text-lg font-medium text-gray-900 dark:text-white">
          {{ $t('dashboard.notifications') }}
        </h3>
        <button
          v-if="notificationsStore.unreadCount > 0"
          @click="notificationsStore.markAllAsRead"
          class="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400"
        >
          Alle als gelesen markieren
        </button>
      </div>
    </div>

    <div class="max-h-96 overflow-y-auto">
      <div v-if="notificationsStore.recentNotifications.length === 0" class="p-4 text-center">
        <BellSlashIcon class="mx-auto h-12 w-12 text-gray-400" />
        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
          Keine Benachrichtigungen verfügbar
        </p>
      </div>

      <div v-else class="divide-y divide-gray-200 dark:divide-gray-700">
        <div
          v-for="notification in notificationsStore.recentNotifications"
          :key="notification.id"
          class="p-4 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer"
          :class="{ 'bg-blue-50 dark:bg-blue-900/20': !notification.read }"
          @click="notificationsStore.markAsRead(notification.id)"
        >
          <div class="flex items-start">
            <component
              :is="getNotificationIcon(notification.type)"
              class="h-5 w-5 mt-0.5 flex-shrink-0"
              :class="getNotificationIconColor(notification.type)"
            />
            
            <div class="ml-3 flex-1 min-w-0">
              <p class="text-sm font-medium text-gray-900 dark:text-white">
                {{ notification.title }}
              </p>
              <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                {{ notification.message }}
              </p>
              <p class="text-xs text-gray-400 dark:text-gray-500 mt-1">
                {{ formatRelativeTime(notification.timestamp) }}
              </p>
            </div>

            <div v-if="!notification.read" class="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0"></div>
          </div>
        </div>
      </div>
    </div>

    <div class="p-4 border-t border-gray-200 dark:border-gray-700">
      <NuxtLink
        to="/notifications"
        class="block text-center text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400"
        @click="$emit('close')"
      >
        Alle Benachrichtigungen anzeigen
      </NuxtLink>
    </div>
  </div>
</template>

<script setup lang="ts">
import {
  BellSlashIcon,
  CheckCircleIcon,
  ExclamationTriangleIcon,
  XCircleIcon,
  InformationCircleIcon
} from '@heroicons/vue/24/outline'

// Emits
const emit = defineEmits<{
  close: []
}>()

// Stores
const notificationsStore = useNotificationsStore()

// Methods
const getNotificationIcon = (type: string) => {
  const icons = {
    success: CheckCircleIcon,
    warning: ExclamationTriangleIcon,
    error: XCircleIcon,
    info: InformationCircleIcon
  }
  return icons[type as keyof typeof icons] || InformationCircleIcon
}

const getNotificationIconColor = (type: string) => {
  const colors = {
    success: 'text-green-500',
    warning: 'text-yellow-500',
    error: 'text-red-500',
    info: 'text-blue-500'
  }
  return colors[type as keyof typeof colors] || 'text-gray-500'
}

const formatRelativeTime = (date: Date) => {
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  const minutes = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)
  const days = Math.floor(diff / 86400000)

  if (minutes < 1) return 'Jetzt'
  if (minutes < 60) return `vor ${minutes} Min`
  if (hours < 24) return `vor ${hours} Std`
  if (days < 7) return `vor ${days} Tag${days > 1 ? 'en' : ''}`
  
  return date.toLocaleDateString('de-DE', {
    day: 'numeric',
    month: 'short'
  })
}
</script>
