<template>
  <div v-if="showModal && ticket" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
      <div class="p-6">
        <!-- Header -->
        <div class="flex items-center justify-between mb-6">
          <div>
            <h2 class="text-xl font-bold text-gray-900 dark:text-white">
              {{ $t('tickets.conversion.title') }}
            </h2>
            <p class="text-gray-600 dark:text-gray-400 mt-1">
              {{ $t('tickets.conversion.description') }}
            </p>
          </div>
          <button
            @click="closeModal"
            class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
          >
            <Icon name="heroicons:x-mark" class="w-6 h-6" />
          </button>
        </div>

        <!-- Ticket Information -->
        <div class="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 mb-6">
          <div class="flex items-start space-x-4">
            <div class="w-10 h-10 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center">
              <Icon name="heroicons:ticket" class="w-5 h-5 text-orange-600" />
            </div>
            <div class="flex-1">
              <h3 class="font-medium text-gray-900 dark:text-white">
                {{ ticket?.title }}
              </h3>
              <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">
                {{ ticket?.description?.substring(0, 200) }}{{ ticket?.description?.length > 200 ? '...' : '' }}
              </p>
              <div class="flex items-center space-x-4 mt-2 text-xs text-gray-500 dark:text-gray-400">
                <span>{{ $t('tickets.department') }}: {{ $t(`tickets.departments.${ticket?.department}`) }}</span>
                <span>{{ $t('common.priority.label') }}: {{ getEnumValueById(ticket?.priorityId)?.label || ticket?.priority || 'Unbekannt' }}</span>
                <span>{{ $t('tickets.createdAt') }}: {{ formatDate(ticket?.createdAt) }}</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Conversion Form -->
        <form @submit.prevent="submitConversion" class="space-y-6">
          <!-- Project Selection -->
          <div>
            <label for="project" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('projects.project') }} *
            </label>
            <select
              id="project"
              v-model="form.projectId"
              required
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">{{ $t('projects.selectProject') }}</option>
              <option 
                v-for="project in availableProjects" 
                :key="project.id" 
                :value="project.id"
              >
                {{ project.name }} ({{ project.key || project.id.substring(0, 8) }})
              </option>
            </select>
            <p v-if="errors.projectId" class="mt-1 text-sm text-red-600 dark:text-red-400">
              {{ errors.projectId }}
            </p>
          </div>

          <!-- Assignee Selection -->
          <div>
            <label for="assignee" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('tasks.assignee') }}
            </label>
            <select
              id="assignee"
              v-model="form.assigneeId"
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">{{ $t('tasks.noAssignee') }}</option>
              <option 
                v-for="member in projectMembers" 
                :key="member.user.id" 
                :value="member.user.id"
              >
                {{ member.user.firstName }} {{ member.user.lastName }} ({{ member.user.email }})
              </option>
            </select>
          </div>

          <!-- Priority Override -->
          <div>
            <label for="priority" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('common.priority.label') }}
            </label>
            <select
              id="priority"
              v-model="form.priority"
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">
                {{ 
                  form.projectId 
                    ? $t('tickets.conversion.selectPriority') 
                    : $t('tickets.conversion.keepOriginalPriority', { 
                        priority: getEnumValueById(ticket?.priorityId)?.label || ticket?.priority || 'Unbekannt'
                      }) 
                }}
              </option>
              <option 
                v-for="priority in availablePriorities" 
                :key="priority.value" 
                :value="priority.value"
              >
                {{ priority.label }}
              </option>
            </select>
            <p v-if="form.projectId" class="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {{ $t('tickets.conversion.projectSpecificPriorities') }}
            </p>
          </div>

          <!-- Estimated Hours -->
          <div>
            <label for="estimatedHours" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('tasks.estimatedHours') }}
            </label>
            <input
              id="estimatedHours"
              v-model.number="form.estimatedHours"
              type="number"
              min="0"
              step="0.5"
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              :placeholder="$t('tasks.estimatedHoursPlaceholder')"
            />
            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {{ $t('tasks.estimatedHoursHelp') }}
            </p>
          </div>

          <!-- Internal Notes -->
          <div>
            <label for="internalNotes" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('tickets.conversion.internalNotes') }}
            </label>
            <textarea
              id="internalNotes"
              v-model="form.internalNotes"
              rows="4"
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              :placeholder="$t('tickets.conversion.internalNotesPlaceholder')"
            ></textarea>
            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {{ $t('tickets.conversion.internalNotesHelp') }}
            </p>
          </div>

          <!-- Warning Notice -->
          <div class="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
            <div class="flex">
              <Icon name="heroicons:exclamation-triangle" class="w-5 h-5 text-yellow-400 mt-0.5" />
              <div class="ml-3">
                <h3 class="text-sm font-medium text-yellow-800 dark:text-yellow-200">
                  {{ $t('tickets.conversion.warningTitle') }}
                </h3>
                <div class="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
                  <ul class="list-disc list-inside space-y-1">
                    <li>{{ $t('tickets.conversion.warning1') }}</li>
                    <li>{{ $t('tickets.conversion.warning2') }}</li>
                    <li>{{ $t('tickets.conversion.warning3') }}</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <!-- Submit Buttons -->
          <div class="flex justify-end space-x-3 pt-6 border-t border-gray-200 dark:border-gray-700">
            <button
              type="button"
              @click="closeModal"
              class="px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-lg text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              {{ $t('common.cancel') }}
            </button>
            <button
              type="submit"
              :disabled="loading || !isFormValid"
              class="inline-flex items-center px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-medium rounded-lg transition-colors"
            >
              <Icon v-if="loading" name="heroicons:arrow-path" class="w-4 h-4 mr-2 animate-spin" />
              <Icon v-else name="heroicons:arrow-right" class="w-4 h-4 mr-2" />
              {{ $t('tickets.conversion.convertToTask') }}
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
const props = defineProps({
  ticket: {
    type: Object,
    required: false,
    default: null
  },
  showModal: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['close', 'converted'])

// Composables
const { t } = useI18n()
const notificationsStore = useNotificationsStore()
const { addNotification } = notificationsStore
const { 
  getPriorities, 
  getEnumValueById,
  priorityOptions,
  getProjectPriorities 
} = useDynamicEnums()

// Local state
const loading = ref(false)
const errors = ref({})
const availableProjects = ref([])
const projectMembers = ref([])

// Form data
const form = ref({
  projectId: '',
  assigneeId: '',
  priority: '',
  estimatedHours: null,
  internalNotes: ''
})

// Computed
const isFormValid = computed(() => {
  return form.value.projectId.length > 0
})

// Get project-specific priority options when a project is selected
const availablePriorities = computed(() => {
  if (form.value.projectId) {
    return getProjectPriorities(form.value.projectId).value
  }
  return priorityOptions.value
})

// Methods
const loadProjects = async () => {
  try {
    const response = await $fetch('/api/projects')
    // Handle the new API response format
    if (response.success && response.data) {
      availableProjects.value = response.data
    } else if (Array.isArray(response)) {
      // Fallback for old format
      availableProjects.value = response
    } else {
      availableProjects.value = []
    }
  } catch (error) {
    console.error('Failed to load projects:', error)
    addNotification({
      type: 'error',
      title: 'Fehler',
      message: 'Projekte konnten nicht geladen werden.'
    })
    availableProjects.value = []
  }
}

const loadProjectMembers = async (projectId) => {
  if (!projectId) {
    projectMembers.value = []
    return
  }
  
  try {
    const response = await $fetch(`/api/projects/${projectId}`)
    // Handle both old and new API response format
    if (response.success && response.data) {
      projectMembers.value = response.data.members || []
    } else if (response.members) {
      projectMembers.value = response.members
    } else {
      projectMembers.value = []
    }
  } catch (error) {
    console.error('Failed to load project members:', error)
    projectMembers.value = []
  }
}

const submitConversion = async () => {
  errors.value = {}
  
  if (!form.value.projectId) {
    errors.value.projectId = t('tickets.conversion.projectRequired')
    return
  }
  
  try {
    loading.value = true
    
    const conversionData = {
      ticketId: props.ticket.id,
      projectId: form.value.projectId,
      assigneeId: form.value.assigneeId || undefined,
      priorityId: form.value.priority || undefined, // Use priorityId instead of priority
      estimatedHours: form.value.estimatedHours || undefined,
      internalNotes: form.value.internalNotes || undefined
    }
    
    const response = await $fetch('/api/tickets/convert-to-task', {
      method: 'POST',
      body: conversionData
    })
    
    addNotification({
      type: 'success',
      title: 'Erfolg',
      message: response.message || 'Ticket wurde erfolgreich zu einer Aufgabe konvertiert.'
    })
    
    emit('converted', response.task)
    closeModal()
    
  } catch (error) {
    console.error('Failed to convert ticket:', error)
    addNotification({
      type: 'error',
      title: 'Fehler',
      message: error.data?.message || 'Ticket konnte nicht konvertiert werden.'
    })
  } finally {
    loading.value = false
  }
}

const closeModal = () => {
  emit('close')
  // Reset form
  form.value = {
    projectId: '',
    assigneeId: '',
    priority: '',
    estimatedHours: null,
    internalNotes: ''
  }
  errors.value = {}
}

const formatDate = (date) => {
  if (!date) return ''
  return new Date(date).toLocaleDateString('de-DE', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// Watch for project changes to load members and update enum options
watch(() => form.value.projectId, (newProjectId) => {
  loadProjectMembers(newProjectId)
  form.value.assigneeId = '' // Reset assignee when project changes
  form.value.priority = '' // Reset priority to see project-specific options
})

// Lifecycle
onMounted(async () => {
  await loadProjects()
  
  // Load enum data if not already loaded
  const enumStore = useEnumManagementStore()
  if (enumStore.categories.length === 0) {
    await enumStore.fetchCategories(true)
  }
})
</script>
