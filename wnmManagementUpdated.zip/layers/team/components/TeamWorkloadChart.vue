<template>
  <div class="space-y-4">
    <!-- Chart Container -->
    <div class="h-64 w-full">
      <canvas ref="chartCanvas" class="w-full h-full"></canvas>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick, watch } from 'vue'

interface TeamWorkloadData {
  name: string
  utilization: number
  capacity: number
}

interface Props {
  data: TeamWorkloadData[]
}

const props = defineProps<Props>()

const chartCanvas = ref<HTMLCanvasElement>()

const renderChart = async () => {
  await nextTick()
  
  if (!chartCanvas.value || !props.data.length) return
  
  const ctx = chartCanvas.value.getContext('2d')
  if (!ctx) return
  
  const { width, height } = chartCanvas.value
  
  ctx.clearRect(0, 0, width, height)
  
  // Chart dimensions
  const padding = 60
  const chartWidth = width - 2 * padding
  const chartHeight = height - 2 * padding
  
  // Bar dimensions
  const barHeight = chartHeight / props.data.length - 10
  const maxValue = 100 // Percentage
  
  // Draw grid lines
  ctx.strokeStyle = '#E5E7EB'
  ctx.lineWidth = 1
  
  for (let i = 0; i <= 5; i++) {
    const x = padding + (chartWidth / 5) * i
    ctx.beginPath()
    ctx.moveTo(x, padding)
    ctx.lineTo(x, height - padding)
    ctx.stroke()
  }
  
  // Draw bars
  props.data.forEach((member, index) => {
    const y = padding + index * (barHeight + 10)
    const barWidth = (member.utilization / maxValue) * chartWidth
    
    // Background bar (capacity)
    ctx.fillStyle = '#F3F4F6'
    ctx.fillRect(padding, y, chartWidth, barHeight)
    
    // Utilization bar
    const color = member.utilization > 90 ? '#EF4444' : 
                  member.utilization > 70 ? '#F59E0B' : '#10B981'
    ctx.fillStyle = color
    ctx.fillRect(padding, y, barWidth, barHeight)
    
    // Member name
    ctx.fillStyle = '#374151'
    ctx.font = '12px system-ui'
    ctx.textAlign = 'right'
    ctx.fillText(member.name, padding - 10, y + barHeight / 2 + 4)
    
    // Percentage label
    ctx.fillStyle = '#ffffff'
    ctx.textAlign = 'center'
    if (barWidth > 40) {
      ctx.fillText(`${member.utilization}%`, padding + barWidth / 2, y + barHeight / 2 + 4)
    }
  })
  
  // X-axis labels
  ctx.fillStyle = '#374151'
  ctx.font = '12px system-ui'
  ctx.textAlign = 'center'
  
  for (let i = 0; i <= 5; i++) {
    const value = (maxValue / 5) * i
    const x = padding + (chartWidth / 5) * i
    ctx.fillText(`${value}%`, x, height - padding + 20)
  }
}

const resizeCanvas = () => {
  if (!chartCanvas.value) return
  
  const container = chartCanvas.value.parentElement
  if (!container) return
  
  chartCanvas.value.width = container.clientWidth
  chartCanvas.value.height = container.clientHeight
  
  renderChart()
}

watch(() => props.data, () => {
  renderChart()
}, { deep: true })

onMounted(() => {
  resizeCanvas()
  window.addEventListener('resize', resizeCanvas)
})
</script>
