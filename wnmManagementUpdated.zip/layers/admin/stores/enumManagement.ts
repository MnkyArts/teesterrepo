import type { EnumCategory, EnumValue, ProjectEnumOverride } from '@prisma/client'

export interface EnumCategoryWithValues extends EnumCategory {
  values: (EnumValue & { projectId?: string | null })[]
}

export interface EnumValueWithCategory extends EnumValue {
  category: EnumCategory
  projectId: string | null
}

export interface ProjectEnumConfig {
  categoryId: string
  values: EnumValue[]
}

export interface CreateEnumCategoryData {
  name: string
  label: string
  description?: string
  isSystem?: boolean
  sortOrder?: number
}

export interface CreateEnumValueData {
  categoryId: string
  key: string
  label: string
  description?: string
  color?: string
  icon?: string
  isDefault?: boolean
  sortOrder?: number
}

export interface UpdateEnumValueData {
  label?: string
  description?: string
  color?: string
  icon?: string
  isDefault?: boolean
  sortOrder?: number
  isActive?: boolean
}

export interface EnumFilters {
  categoryId?: string
  isActive?: boolean
  search?: string
}

export interface CreateProjectEnumValueData extends CreateEnumValueData {
  projectId: string
}

export interface ProjectEnumSettings {
  categoryId: string
  globalValues: EnumValue[]
  projectValues: EnumValue[]
  overrides: ProjectEnumOverride[]
}

export const useEnumManagementStore = defineStore('enumManagement', () => {
  // State
  const categories = ref<EnumCategoryWithValues[]>([])
  const values = ref<EnumValueWithCategory[]>([])
  const projectOverrides = ref<ProjectEnumOverride[]>([])
  const loading = ref(false)
  const error = ref<string | null>(null)

  // Getters
  const categoriesMap = computed(() => {
    return new Map(categories.value.map(cat => [cat.id, cat]))
  })

  const valuesByCategory = computed(() => {
    const result = new Map<string, EnumValue[]>()
    categories.value.forEach(category => {
      result.set(category.id, category.values.filter(v => v.isActive).sort((a, b) => a.sortOrder - b.sortOrder))
    })
    return result
  })

  const taskTypeValues = computed(() => {
    const category = categories.value.find(c => c.name === 'task_type')
    return category?.values.filter(v => v.isActive).sort((a, b) => a.sortOrder - b.sortOrder) || []
  })

  const priorityValues = computed(() => {
    const category = categories.value.find(c => c.name === 'priority')
    return category?.values.filter(v => v.isActive).sort((a, b) => a.sortOrder - b.sortOrder) || []
  })

  const taskStatusValues = computed(() => {
    const category = categories.value.find(c => c.name === 'task_status')
    return category?.values.filter(v => v.isActive).sort((a, b) => a.sortOrder - b.sortOrder) || []
  })

  const ticketTypeValues = computed(() => {
    const category = categories.value.find(c => c.name === 'ticket_type')
    return category?.values.filter(v => v.isActive).sort((a, b) => a.sortOrder - b.sortOrder) || []
  })

  const ticketStatusValues = computed(() => {
    const category = categories.value.find(c => c.name === 'ticket_status')
    return category?.values.filter(v => v.isActive).sort((a, b) => a.sortOrder - b.sortOrder) || []
  })

  // Project-specific getters
  const getTaskTypesForProject = (projectId: string) => {
    return getValuesForProject(projectId, 'task_type')
  }

  const getPrioritiesForProject = (projectId: string) => {
    return getValuesForProject(projectId, 'priority')
  }

  const getTaskStatusesForProject = (projectId: string) => {
    return getValuesForProject(projectId, 'task_status')
  }

  const getTicketTypesForProject = (projectId: string) => {
    return getValuesForProject(projectId, 'ticket_type')
  }

  const getTicketStatusesForProject = (projectId: string) => {
    return getValuesForProject(projectId, 'ticket_status')
  }

  const getProjectEnumSettings = (projectId: string) => {
    return computed(() => {
      const settings: Record<string, ProjectEnumSettings> = {}
      
      categories.value.forEach(category => {
        const globalValues = category.values.filter(v => !v.projectId)
        const projectValues = category.values.filter(v => v.projectId === projectId)
        const overrides = projectOverrides.value.filter(
          o => o.projectId === projectId && o.categoryId === category.id
        )
        
        settings[category.name] = {
          categoryId: category.id,
          globalValues,
          projectValues,
          overrides
        }
      })
      
      return settings
    })
  }

  const getEffectiveEnumValues = (projectId: string, categoryName: string): EnumValue[] => {
    const category = categories.value.find(c => c.name === categoryName)
    if (!category) return []

    // Get global values
    const globalValues = category.values.filter(v => !v.projectId && v.isActive)
    
    // Get project-specific values
    const projectValues = category.values.filter(v => v.projectId === projectId && v.isActive)
    
    // Apply overrides to global values
    const overrides = projectOverrides.value.filter(
      o => o.projectId === projectId && o.categoryId === category.id
    )
    
    const effectiveGlobalValues = globalValues.map(value => {
      const override = overrides.find(o => o.enumValueId === value.id)
      if (override && !override.isActive) {
        return null // Exclude inactive values for this project
      }
      return {
        ...value,
        sortOrder: override?.sortOrder ?? value.sortOrder
      }
    }).filter(Boolean) as EnumValue[]
    
    // Combine and sort all values
    const allValues = [...effectiveGlobalValues, ...projectValues]
    return allValues.sort((a, b) => a.sortOrder - b.sortOrder)
  }

  // Actions
  const fetchCategories = async (includeValues = true): Promise<void> => {
    loading.value = true
    error.value = null

    try {
      const response = await $fetch<EnumCategoryWithValues[]>('/api/enums/categories', {
        query: { includeValues }
      })
      categories.value = response
      lastFetchTime.value = new Date()
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Laden der Enum-Kategorien'
      throw err
    } finally {
      loading.value = false
    }
  }

  const fetchValues = async (filters?: EnumFilters): Promise<void> => {
    loading.value = true
    error.value = null

    try {
      const response = await $fetch<EnumValueWithCategory[]>('/api/enums/values', {
        query: filters
      })
      values.value = response
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Laden der Enum-Werte'
      throw err
    } finally {
      loading.value = false
    }
  }

  const fetchProjectOverrides = async (projectId: string): Promise<void> => {
    loading.value = true
    error.value = null

    try {
      const response = await $fetch<ProjectEnumOverride[]>(`/api/projects/${projectId}/enum-overrides`)
      projectOverrides.value = response
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Laden der Projekt-Enum-Konfiguration'
      throw err
    } finally {
      loading.value = false
    }
  }

  const createCategory = async (data: CreateEnumCategoryData): Promise<EnumCategory> => {
    loading.value = true
    error.value = null

    try {
      const response = await $fetch<EnumCategory>('/api/enums/categories', {
        method: 'POST',
        body: data
      })

      // Update local state
      await fetchCategories()
      
      return response
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Erstellen der Enum-Kategorie'
      throw err
    } finally {
      loading.value = false
    }
  }

  const updateCategory = async (id: string, data: Partial<CreateEnumCategoryData>): Promise<EnumCategory> => {
    loading.value = true
    error.value = null

    try {
      const response = await $fetch<EnumCategory>(`/api/enums/categories/${id}`, {
        method: 'PUT',
        body: data
      })

      // Update local state
      const index = categories.value.findIndex(c => c.id === id)
      if (index !== -1) {
        categories.value[index] = { ...categories.value[index], ...response }
      }

      return response
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Aktualisieren der Enum-Kategorie'
      throw err
    } finally {
      loading.value = false
    }
  }

  const deleteCategory = async (id: string): Promise<void> => {
    loading.value = true
    error.value = null

    try {
      await $fetch(`/api/enums/categories/${id}`, {
        method: 'DELETE'
      })

      // Update local state
      categories.value = categories.value.filter(c => c.id !== id)
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Löschen der Enum-Kategorie'
      throw err
    } finally {
      loading.value = false
    }
  }

  const createValue = async (data: CreateEnumValueData): Promise<EnumValue> => {
    loading.value = true
    error.value = null

    try {
      const response = await $fetch<EnumValue>('/api/enums/values', {
        method: 'POST',
        body: data
      })

      // Update local state
      await fetchCategories()
      
      return response
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Erstellen des Enum-Werts'
      throw err
    } finally {
      loading.value = false
    }
  }

  const updateValue = async (id: string, data: UpdateEnumValueData): Promise<EnumValue> => {
    loading.value = true
    error.value = null

    try {
      const response = await $fetch<EnumValue>(`/api/enums/values/${id}`, {
        method: 'PUT',
        body: data
      })

      // Update local state
      const categoryIndex = categories.value.findIndex(c => 
        c.values.some(v => v.id === id)
      )
      if (categoryIndex !== -1) {
        const valueIndex = categories.value[categoryIndex].values.findIndex(v => v.id === id)
        if (valueIndex !== -1) {
          categories.value[categoryIndex].values[valueIndex] = response
        }
      }

      return response
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Aktualisieren des Enum-Werts'
      throw err
    } finally {
      loading.value = false
    }
  }

  const deleteValue = async (id: string): Promise<void> => {
    loading.value = true
    error.value = null

    try {
      await $fetch(`/api/enums/values/${id}`, {
        method: 'DELETE'
      })

      // Update local state
      categories.value.forEach(category => {
        category.values = category.values.filter(v => v.id !== id)
      })
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Löschen des Enum-Werts'
      throw err
    } finally {
      loading.value = false
    }
  }

  const updateProjectOverride = async (
    projectId: string, 
    categoryId: string, 
    enumValueId: string, 
    override: { isActive: boolean; sortOrder?: number }
  ): Promise<ProjectEnumOverride> => {
    loading.value = true
    error.value = null

    try {
      const response = await $fetch<ProjectEnumOverride>(`/api/projects/${projectId}/enum-overrides`, {
        method: 'PUT',
        body: {
          categoryId,
          enumValueId,
          ...override
        }
      })

      // Update local state
      const index = projectOverrides.value.findIndex(
        o => o.projectId === projectId && o.categoryId === categoryId && o.enumValueId === enumValueId
      )
      if (index !== -1) {
        projectOverrides.value[index] = response
      } else {
        projectOverrides.value.push(response)
      }

      return response
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Aktualisieren der Projekt-Enum-Konfiguration'
      throw err
    } finally {
      loading.value = false
    }
  }

  const createProjectValue = async (data: CreateProjectEnumValueData): Promise<EnumValue> => {
    loading.value = true
    error.value = null

    try {
      const response = await $fetch<EnumValue>('/api/enums/values', {
        method: 'POST',
        body: data
      })

      // Update local state
      await fetchCategories()
      
      return response
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Erstellen des projekt-spezifischen Enum-Werts'
      throw err
    } finally {
      loading.value = false
    }
  }

  const deleteProjectValue = async (id: string, projectId: string): Promise<void> => {
    loading.value = true
    error.value = null

    try {
      await $fetch(`/api/enums/values/${id}`, {
        method: 'DELETE',
        query: { projectId }
      })

      // Update local state
      categories.value.forEach(category => {
        category.values = category.values.filter(v => v.id !== id)
      })
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Löschen des projekt-spezifischen Enum-Werts'
      throw err
    } finally {
      loading.value = false
    }
  }

  const fetchProjectEnumSettings = async (projectId: string): Promise<void> => {
    loading.value = true
    error.value = null

    try {
      // Fetch categories with global values only
      await fetchCategories(true)
      
      // Fetch project overrides
      await fetchProjectOverrides(projectId)
      
      // Fetch project-specific enum values and add them to categories
      const projectEnumValues = await $fetch<EnumValue[]>('/api/enums/values', {
        query: { projectId }
      })
      
      // Filter to get only project-specific values (not global ones)
      const projectSpecificValues = projectEnumValues.filter(v => v.projectId === projectId)
      
      // Add project-specific values to their respective categories
      if (projectSpecificValues.length > 0) {
        projectSpecificValues.forEach(projectValue => {
          const categoryIndex = categories.value.findIndex(c => c.id === projectValue.categoryId)
          if (categoryIndex !== -1) {
            // Add project-specific value if not already present
            const existingIndex = categories.value[categoryIndex].values.findIndex(v => v.id === projectValue.id)
            if (existingIndex === -1) {
              categories.value[categoryIndex].values.push(projectValue as any)
            }
          }
        })
      }
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Laden der Projekt-Enum-Einstellungen'
      throw err
    } finally {
      loading.value = false
    }
  }

  const getValuesForProject = (projectId: string, categoryName: string): EnumValue[] => {
    const category = categories.value.find(c => c.name === categoryName)
    if (!category) return []

    const baseValues = category.values.filter(v => v.isActive)
    const overrides = projectOverrides.value.filter(
      o => o.projectId === projectId && o.categoryId === category.id
    )

    if (overrides.length === 0) {
      return baseValues.sort((a, b) => a.sortOrder - b.sortOrder)
    }

    // Apply project-specific overrides
    const result = baseValues.map(value => {
      const override = overrides.find(o => o.enumValueId === value.id)
      if (override && !override.isActive) {
        return null // Exclude inactive values for this project
      }
      return {
        ...value,
        sortOrder: override?.sortOrder ?? value.sortOrder
      }
    }).filter(Boolean) as EnumValue[]

    return result.sort((a, b) => a.sortOrder - b.sortOrder)
  }

  const getValueByKey = (categoryName: string, key: string): EnumValue | undefined => {
    const category = categories.value.find(c => c.name === categoryName)
    return category?.values.find(v => v.key === key && v.isActive)
  }

  const getValueById = (id: string): EnumValue | undefined => {
    for (const category of categories.value) {
      const value = category.values.find(v => v.id === id)
      if (value) return value
    }
    return undefined
  }

  const reorderValues = async (categoryId: string, valueIds: string[]): Promise<void> => {
    loading.value = true
    error.value = null

    try {
      await $fetch(`/api/enums/categories/${categoryId}/reorder`, {
        method: 'PUT',
        body: { valueIds }
      })

      // Update local state
      await fetchCategories()
    } catch (err: any) {
      error.value = err.message || 'Fehler beim Neuordnen der Enum-Werte'
      throw err
    } finally {
      loading.value = false
    }
  }

  const clearError = () => {
    error.value = null
  }

  // Performance optimizations
  const lastFetchTime = ref<Date | null>(null)
  const CACHE_DURATION = 5 * 60 * 1000 // 5 minutes in milliseconds

  const shouldRefreshCache = (): boolean => {
    if (!lastFetchTime.value) return true
    return Date.now() - lastFetchTime.value.getTime() > CACHE_DURATION
  }

  const fetchCategoriesIfNeeded = async (includeValues = true): Promise<void> => {
    if (categories.value.length === 0 || shouldRefreshCache()) {
      await fetchCategories(includeValues)
    }
  }

  // Efficient value lookup with caching
  const getValueByKeyOptimized = (categoryName: string, key: string): EnumValue | undefined => {
    const categoryId = categoriesMap.value.get(categoryName)?.id
    if (!categoryId) return undefined

    // Use Map for O(1) lookup
    const categoryValues = valuesByCategory.value.get(categoryId)
    return categoryValues?.find(v => v.key === key)
  }

  const resetState = () => {
    categories.value = []
    values.value = []
    projectOverrides.value = []
    error.value = null
    loading.value = false
  }

  const initialize = async (): Promise<void> => {
    if (categories.value.length === 0) {
      await fetchCategories(true)
    }
  }

  return {
    // State
    categories: readonly(categories),
    values: readonly(values),
    projectOverrides: readonly(projectOverrides),
    loading: readonly(loading),
    error: readonly(error),

    // Getters
    categoriesMap,
    valuesByCategory,
    taskTypeValues,
    priorityValues,
    taskStatusValues,
    ticketTypeValues,
    ticketStatusValues,

    // Project-specific getters
    getTaskTypesForProject,
    getPrioritiesForProject,
    getTaskStatusesForProject,
    getTicketTypesForProject,
    getTicketStatusesForProject,
    getProjectEnumSettings,
    getEffectiveEnumValues,

    // Actions
    fetchCategories,
    fetchCategoriesIfNeeded,
    fetchValues,
    fetchProjectOverrides,
    createCategory,
    updateCategory,
    deleteCategory,
    createValue,
    createProjectValue,
    updateValue,
    deleteValue,
    deleteProjectValue,
    updateProjectOverride,
    fetchProjectEnumSettings,
    getValuesForProject,
    getValueByKey,
    getValueByKeyOptimized,
    getValueById,
    reorderValues,
    clearError,
    resetState,
    initialize
  }
})
