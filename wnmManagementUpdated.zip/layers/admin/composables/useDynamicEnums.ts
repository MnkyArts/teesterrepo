import type { EnumValue, EnumCategory } from '@prisma/client'

/**
 * Composable für die einfache Verwendung dynamischer Enums in Komponenten
 * Bietet Hilfsfunktionen für die Anzeige und Formatierung von Enum-Werten
 */
export const useDynamicEnums = () => {
  const enumStore = useEnumManagementStore()

  // Enum-Werte für verschiedene Kategorien abrufen
  const getTaskTypes = (projectId?: string) => {
    if (projectId) {
      return enumStore.getValuesForProject(projectId, 'task_type')
    }
    return enumStore.taskTypeValues
  }

  const getPriorities = (projectId?: string) => {
    if (projectId) {
      return enumStore.getValuesForProject(projectId, 'priority')
    }
    return enumStore.priorityValues
  }

  const getTaskStatuses = (projectId?: string) => {
    if (projectId) {
      return enumStore.getValuesForProject(projectId, 'task_status')
    }
    return enumStore.taskStatusValues
  }

  const getTicketTypes = (projectId?: string) => {
    if (projectId) {
      return enumStore.getValuesForProject(projectId, 'ticket_type')
    }
    return enumStore.ticketTypeValues
  }

  const getTicketStatuses = (projectId?: string) => {
    if (projectId) {
      return enumStore.getValuesForProject(projectId, 'ticket_status')
    }
    return enumStore.ticketStatusValues
  }

  // Hilfsfunktionen für Enum-Werte
  const getEnumValueById = (id: string): EnumValue | undefined => {
    return enumStore.getValueById(id)
  }

  const getEnumValueByKey = (categoryName: string, key: string): EnumValue | undefined => {
    return enumStore.getValueByKey(categoryName, key)
  }

  const getDefaultValue = (categoryName: string): EnumValue | undefined => {
    const category = enumStore.categories.find(c => c.name === categoryName)
    return category?.values.find(v => v.isDefault && v.isActive)
  }

  // UI-Hilfsfunktionen
  const formatEnumValue = (value: EnumValue | undefined): string => {
    return value?.label || 'Unbekannt'
  }

  const getEnumValueColor = (value: EnumValue | undefined): string => {
    return value?.color || '#6b7280' // Default gray
  }

  const getEnumValueIcon = (value: EnumValue | undefined): string => {
    return value?.icon || 'tag'
  }

  // Computed für reaktive Werte
  const taskTypeOptions = computed(() => getTaskTypes().map(value => ({
    value: value.id,
    label: value.label,
    color: value.color,
    icon: value.icon
  })))

  const priorityOptions = computed(() => getPriorities().map(value => ({
    value: value.id,
    label: value.label,
    color: value.color,
    icon: value.icon
  })))

  const taskStatusOptions = computed(() => getTaskStatuses().map(value => ({
    value: value.id,
    label: value.label,
    color: value.color,
    icon: value.icon
  })))

  const ticketTypeOptions = computed(() => getTicketTypes().map(value => ({
    value: value.id,
    label: value.label,
    color: value.color,
    icon: value.icon
  })))

  const ticketStatusOptions = computed(() => getTicketStatuses().map(value => ({
    value: value.id,
    label: value.label,
    color: value.color,
    icon: value.icon
  })))

  // Projektspezifische Optionen
  const getProjectTaskTypes = (projectId: string) => computed(() => 
    getTaskTypes(projectId).map(value => ({
      value: value.id,
      label: value.label,
      color: value.color,
      icon: value.icon
    }))
  )

  const getProjectPriorities = (projectId: string) => computed(() => 
    getPriorities(projectId).map(value => ({
      value: value.id,
      label: value.label,
      color: value.color,
      icon: value.icon
    }))
  )

  const getProjectTaskStatuses = (projectId: string) => computed(() => 
    getTaskStatuses(projectId).map(value => ({
      value: value.id,
      label: value.label,
      color: value.color,
      icon: value.icon
    }))
  )

  // Enum-Badge-Komponente Hilfsfunktion
  const getEnumBadgeProps = (value: EnumValue | undefined) => {
    if (!value) {
      return {
        label: 'Unbekannt',
        color: 'gray',
        variant: 'secondary'
      }
    }

    return {
      label: value.label,
      color: value.color,
      icon: value.icon,
      variant: 'colored'
    }
  }

  // Validierungsfunktionen
  const isValidEnumValue = (categoryName: string, valueId: string): boolean => {
    const value = getEnumValueById(valueId)
    return value != null && value.isActive
  }

  const isValidForProject = (projectId: string, categoryName: string, valueId: string): boolean => {
    const projectValues = enumStore.getValuesForProject(projectId, categoryName)
    return projectValues.some(v => v.id === valueId)
  }

  // Migrations-Hilfsfunktionen (für Legacy-Unterstützung)
  const migrateTaskTypeToId = (oldType: string): string | undefined => {
    const mapping: Record<string, string> = {
      'BUG': 'task_type_bug',
      'FEATURE': 'task_type_feature',
      'VERBESSERUNG': 'task_type_improvement',
      'AUFGABE': 'task_type_task',
      'STORY': 'task_type_story',
      'EPIC': 'task_type_epic'
    }
    return mapping[oldType]
  }

  const migratePriorityToId = (oldPriority: string): string | undefined => {
    const mapping: Record<string, string> = {
      'NIEDRIG': 'priority_low',
      'NORMAL': 'priority_normal',
      'HOCH': 'priority_high',
      'KRITISCH': 'priority_critical',
      'BLOCKER': 'priority_blocker'
    }
    return mapping[oldPriority]
  }

  const migrateTaskStatusToId = (oldStatus: string): string | undefined => {
    const mapping: Record<string, string> = {
      'GEPLANT': 'task_status_planned',
      'TECHNISCHES_DESIGN': 'task_status_design',
      'IN_BEARBEITUNG': 'task_status_progress',
      'REVIEW': 'task_status_review',
      'TESTING': 'task_status_testing',
      'ERLEDIGT': 'task_status_done',
      'GESCHLOSSEN': 'task_status_closed'
    }
    return mapping[oldStatus]
  }

  // Lifecycle helper
  const ensureLoaded = async () => {
    await enumStore.fetchCategoriesIfNeeded(true)
  }

  onMounted(async () => {
    await ensureLoaded()
  })

  return {
    // Store-Zugriff
    enumStore,
    ensureLoaded,

    // Getter-Funktionen
    getTaskTypes,
    getPriorities,
    getTaskStatuses,
    getTicketTypes,
    getTicketStatuses,
    getEnumValueById,
    getEnumValueByKey,
    getDefaultValue,

    // UI-Hilfsfunktionen
    formatEnumValue,
    getEnumValueColor,
    getEnumValueIcon,
    getEnumBadgeProps,

    // Computed Options
    taskTypeOptions,
    priorityOptions,
    taskStatusOptions,
    ticketTypeOptions,
    ticketStatusOptions,

    // Projektspezifische Funktionen
    getProjectTaskTypes,
    getProjectPriorities,
    getProjectTaskStatuses,

    // Validierung
    isValidEnumValue,
    isValidForProject,

    // Legacy-Unterstützung
    migrateTaskTypeToId,
    migratePriorityToId,
    migrateTaskStatusToId
  }
}
