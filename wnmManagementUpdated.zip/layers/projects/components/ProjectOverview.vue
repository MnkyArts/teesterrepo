<template>
  <div class="space-y-3">
    <div
      v-for="project in displayProjects"
      :key="project.id"
      class="p-3 border border-gray-200 dark:border-gray-700 rounded-lg"
    >
      <div class="flex items-center justify-between mb-2">
        <h4 class="text-sm font-medium text-gray-900 dark:text-white truncate">
          {{ project.name }}
        </h4>
        <span
          class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium"
          :class="statusColor(project.status)"
        >
          {{ $t(`projects.${project.status}`) }}
        </span>
      </div>
      
      <div class="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 mb-2">
        <span>{{ project.customer?.name }}</span>
        <span>{{ project.progress }}%</span>
      </div>
      
      <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
        <div
          class="bg-blue-600 h-1.5 rounded-full transition-all duration-300"
          :style="{ width: `${project.progress}%` }"
        ></div>
      </div>
    </div>

    <div v-if="projects.length === 0" class="text-center py-8">
      <FolderIcon class="mx-auto h-12 w-12 text-gray-400" />
      <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
        Keine aktiven Projekte
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { FolderIcon } from '@heroicons/vue/24/outline'

interface Project {
  id: string
  name: string
  status: string
  progress: number
  customer?: {
    name: string
  }
}

interface Props {
  projects: Project[]
  maxItems?: number
}

const props = withDefaults(defineProps<Props>(), {
  maxItems: 5
})

const displayProjects = computed(() => 
  props.projects.slice(0, props.maxItems)
)

const statusColor = (status: string) => {
  const colors = {
    active: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
    completed: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    'on-hold': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
    cancelled: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
  }
  return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800'
}
</script>
