<template>
  <div
    v-if="visible"
    class="fixed inset-0 z-50 overflow-y-auto"
    @click.self="$emit('close')"
  >
    <div class="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
      <!-- Background overlay -->
      <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>

      <!-- Modal panel -->
      <div class="relative inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
        <!-- Header -->
        <div class="mb-6">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white">
            {{ isEditing ? 'Wert bearbeiten' : 'Neuen Wert hinzufügen' }}
          </h3>
          <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
            {{ isEditing ? 'Bearbeiten Sie den projektspezifischen Wert.' : 'Erstellen Sie einen neuen projektspezifischen Wert.' }}
          </p>
        </div>

        <!-- Form -->
        <form @submit.prevent="handleSubmit" class="space-y-4">
          <!-- Key -->
          <div>
            <label for="key" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Schlüssel *
            </label>
            <input
              id="key"
              v-model="form.key"
              type="text"
              required
              :disabled="isEditing"
              class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white sm:text-sm"
              placeholder="z.B. CUSTOM_TYPE"
            />
            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
              Eindeutiger Bezeichner für diesen Wert (nur beim Erstellen änderbar)
            </p>
          </div>

          <!-- Label -->
          <div>
            <label for="label" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Bezeichnung *
            </label>
            <input
              id="label"
              v-model="form.label"
              type="text"
              required
              class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white sm:text-sm"
              placeholder="z.B. Benutzerdefinierter Typ"
            />
          </div>

          <!-- Description -->
          <div>
            <label for="description" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Beschreibung
            </label>
            <textarea
              id="description"
              v-model="form.description"
              rows="3"
              class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white sm:text-sm"
              placeholder="Optionale Beschreibung für diesen Wert"
            ></textarea>
          </div>

          <!-- Color -->
          <div>
            <label for="color" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Farbe
            </label>
            <div class="mt-1 flex items-center space-x-3">
              <input
                id="color"
                v-model="form.color"
                type="color"
                class="h-10 w-16 border border-gray-300 dark:border-gray-600 rounded cursor-pointer"
              />
              <input
                v-model="form.color"
                type="text"
                class="flex-1 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white sm:text-sm"
                placeholder="#6366f1"
              />
            </div>
          </div>

          <!-- Icon -->
          <div>
            <label for="icon" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Icon
            </label>
            <select
              id="icon"
              v-model="form.icon"
              class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white sm:text-sm"
            >
              <option value="">Kein Icon</option>
              <option value="TagIcon">Tag</option>
              <option value="BugAntIcon">Bug</option>
              <option value="LightBulbIcon">Feature</option>
              <option value="ExclamationTriangleIcon">Warnung</option>
              <option value="CheckCircleIcon">Erledigt</option>
              <option value="ClockIcon">In Bearbeitung</option>
              <option value="PauseIcon">Pausiert</option>
              <option value="XCircleIcon">Abgebrochen</option>
              <option value="QuestionMarkCircleIcon">Frage</option>
              <option value="InformationCircleIcon">Information</option>
            </select>
          </div>

          <!-- Sort Order -->
          <div>
            <label for="sortOrder" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Sortierreihenfolge
            </label>
            <input
              id="sortOrder"
              v-model.number="form.sortOrder"
              type="number"
              min="0"
              class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white sm:text-sm"
              placeholder="0"
            />
            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
              Niedrigere Zahlen werden zuerst angezeigt
            </p>
          </div>

          <!-- Is Default -->
          <div class="flex items-center">
            <input
              id="isDefault"
              v-model="form.isDefault"
              type="checkbox"
              class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
            />
            <label for="isDefault" class="ml-2 block text-sm text-gray-700 dark:text-gray-300">
              Als Standard-Wert festlegen
            </label>
          </div>

          <!-- Actions -->
          <div class="flex justify-end space-x-3 pt-6">
            <button
              type="button"
              @click="$emit('close')"
              class="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
            >
              Abbrechen
            </button>
            <button
              type="submit"
              :disabled="loading"
              class="px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800 disabled:opacity-50"
            >
              {{ loading ? 'Speichern...' : (isEditing ? 'Aktualisieren' : 'Erstellen') }}
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { EnumValue } from '@prisma/client'
import type { CreateProjectEnumValueData, UpdateEnumValueData } from '../../admin/stores/enumManagement'

// Props
interface Props {
  visible: boolean
  categoryName: string
  projectId: string
  editValue?: EnumValue | null
}

const props = defineProps<Props>()

// Emits
const emit = defineEmits<{
  close: []
  saved: []
}>()

// Store
const enumStore = useEnumManagementStore()

// Reactive data
const loading = ref(false)

// Computed
const isEditing = computed(() => !!props.editValue)
const category = computed(() => 
  enumStore.categories.find(c => c.name === props.categoryName)
)

// Form data
const form = reactive({
  key: '',
  label: '',
  description: '',
  color: '#6366f1',
  icon: '',
  sortOrder: 0,
  isDefault: false
})

// Methods
const resetForm = () => {
  if (props.editValue) {
    // Populate form with existing values
    form.key = props.editValue.key
    form.label = props.editValue.label
    form.description = props.editValue.description || ''
    form.color = props.editValue.color || '#6366f1'
    form.icon = props.editValue.icon || ''
    form.sortOrder = props.editValue.sortOrder
    form.isDefault = props.editValue.isDefault
  } else {
    // Reset to defaults for new value
    form.key = ''
    form.label = ''
    form.description = ''
    form.color = '#6366f1'
    form.icon = ''
    form.sortOrder = 0
    form.isDefault = false
  }
}

const handleSubmit = async () => {
  if (!category.value) return
  
  loading.value = true
  
  try {
    if (isEditing.value && props.editValue) {
      // Update existing value
      const updateData: UpdateEnumValueData = {
        label: form.label,
        description: form.description || undefined,
        color: form.color,
        icon: form.icon || undefined,
        sortOrder: form.sortOrder,
        isDefault: form.isDefault
      }
      
      await enumStore.updateValue(props.editValue.id, updateData)
    } else {
      // Create new project-specific value
      const createData: CreateProjectEnumValueData = {
        categoryId: category.value.id,
        projectId: props.projectId,
        key: form.key,
        label: form.label,
        description: form.description || undefined,
        color: form.color,
        icon: form.icon || undefined,
        sortOrder: form.sortOrder,
        isDefault: form.isDefault
      }
      
      await enumStore.createProjectValue(createData)
    }
    
    emit('saved')
  } catch (error: any) {
    console.error('Error saving enum value:', error)
    // Handle error display
  } finally {
    loading.value = false
  }
}

// Watch for prop changes
watch(() => props.visible, (visible) => {
  if (visible) {
    resetForm()
  }
})

watch(() => props.editValue, () => {
  if (props.visible) {
    resetForm()
  }
})

// Initialize form when component mounts
onMounted(() => {
  if (props.visible) {
    resetForm()
  }
})
</script>
