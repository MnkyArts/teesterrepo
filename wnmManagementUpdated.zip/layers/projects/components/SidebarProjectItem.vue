<template>
  <NuxtLink
    :to="`/projects/${project.id}`"
    class="flex items-center px-3 py-2 text-sm rounded-lg transition-colors duration-200 group"
    :class="linkClasses"
  >
    <!-- Projekt Status Indikator -->
    <div
      class="w-2 h-2 rounded-full mr-3 flex-shrink-0"
      :class="statusClasses"
    ></div>
    
    <!-- Projekt Info -->
    <div class="flex-1 min-w-0">
      <div class="font-medium truncate">{{ project.name }}</div>
      <div class="text-xs text-gray-500 dark:text-gray-400 truncate">
        {{ project.customer?.name }}
      </div>
    </div>
    
    <!-- Progress Bar -->
    <div class="ml-2 w-8">
      <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1">
        <div
          class="bg-blue-600 h-1 rounded-full transition-all duration-300"
          :style="{ width: `${project.progress || 0}%` }"
        ></div>
      </div>
    </div>
  </NuxtLink>
</template>

<script setup lang="ts">
import { computed } from 'vue'

interface Project {
  id: string
  name: string
  status: 'active' | 'completed' | 'on-hold' | 'cancelled'
  progress?: number
  customer?: {
    name: string
  }
}

interface Props {
  project: Project
}

const props = defineProps<Props>()

// Composables
const route = useRoute()

// Computed
const isActive = computed(() => {
  return route.path.includes(`/projects/${props.project.id}`)
})

const linkClasses = computed(() => {
  return {
    'bg-blue-50 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300': isActive.value,
    'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700': !isActive.value
  }
})

const statusClasses = computed(() => {
  const statusMap = {
    'active': 'bg-green-500',
    'completed': 'bg-blue-500',
    'on-hold': 'bg-yellow-500',
    'cancelled': 'bg-red-500'
  }
  
  return statusMap[props.project.status] || 'bg-gray-400'
})
</script>
