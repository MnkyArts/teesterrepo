<template>
  <TransitionRoot appear :show="true" as="template">
    <Dialog as="div" class="relative z-50">
      <TransitionChild
        as="template"
        enter="duration-300 ease-out"
        enter-from="opacity-0"
        enter-to="opacity-100"
        leave="duration-200 ease-in"
        leave-from="opacity-100"
        leave-to="opacity-0"
      >
        <div class="fixed inset-0 bg-black/25 backdrop-blur-sm" />
      </TransitionChild>

      <div class="fixed inset-0 overflow-y-auto">
        <div class="flex min-h-full items-center justify-center p-4 text-center">
          <TransitionChild
            as="template"
            enter="duration-300 ease-out"
            enter-from="opacity-0 scale-95"
            enter-to="opacity-100 scale-100"
            leave="duration-200 ease-in"
            leave-from="opacity-100 scale-100"
            leave-to="opacity-0 scale-95"
          >
            <DialogPanel class="w-full max-w-2xl transform overflow-hidden rounded-2xl bg-white dark:bg-gray-800 p-6 text-left align-middle shadow-xl transition-all">
              <DialogTitle as="h3" class="text-lg font-medium leading-6 text-gray-900 dark:text-white mb-4">
                {{ isEditing ? $t('projects.editProject') : $t('projects.createProject') }}
              </DialogTitle>

              <form @submit.prevent="handleSubmit" class="space-y-6">
                <!-- Projektname -->
                <div>
                  <label for="name" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {{ $t('projects.form.name') }} *
                  </label>
                  <input
                    id="name"
                    v-model="form.name"
                    type="text"
                    required
                    class="input-field"
                    :class="{ 'border-red-300 dark:border-red-600': errors.name }"
                    :placeholder="$t('projects.form.namePlaceholder')"
                  />
                  <p v-if="errors.name" class="mt-1 text-sm text-red-600 dark:text-red-400">
                    {{ errors.name }}
                  </p>
                </div>

                <!-- Projektschlüssel -->
                <div>
                  <label for="key" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {{ $t('projects.form.key') }} *
                  </label>
                  <input
                    id="key"
                    v-model="form.key"
                    type="text"
                    required
                    :disabled="isEditing"
                    class="input-field"
                    :class="{ 
                      'border-red-300 dark:border-red-600': errors.key,
                      'bg-gray-50 dark:bg-gray-700 cursor-not-allowed': isEditing
                    }"
                    :placeholder="$t('projects.form.keyPlaceholder')"
                    pattern="[A-Z0-9-]+"
                    title="Nur Großbuchstaben, Zahlen und Bindestriche erlaubt"
                  />
                  <p v-if="errors.key" class="mt-1 text-sm text-red-600 dark:text-red-400">
                    {{ errors.key }}
                  </p>
                </div>

                <!-- Beschreibung -->
                <div>
                  <label for="description" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {{ $t('projects.form.description') }}
                  </label>
                  <textarea
                    id="description"
                    v-model="form.description"
                    rows="3"
                    class="input-field"
                    :placeholder="$t('projects.form.descriptionPlaceholder')"
                  ></textarea>
                </div>

                <!-- Kunde -->
                <div>
                  <label for="customer" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {{ $t('projects.form.customer') }}
                  </label>
                  <select
                    id="customer"
                    v-model="form.customerId"
                    class="input-field"
                  >
                    <option value="">{{ $t('projects.form.selectCustomer') }}</option>
                    <option v-for="customer in customers" :key="customer.id" :value="customer.id">
                      {{ customer.companyName }}
                    </option>
                  </select>
                  <div class="mt-2">
                    <label class="flex items-center">
                      <input
                        v-model="form.isInternal"
                        type="checkbox"
                        class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <span class="ml-2 text-sm text-gray-700 dark:text-gray-300">
                        {{ $t('projects.form.internalProject') }}
                      </span>
                    </label>
                  </div>
                </div>

                <!-- Status -->
                <div>
                  <label for="status" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {{ $t('projects.form.status') }}
                  </label>
                  <select
                    id="status"
                    v-model="form.status"
                    class="input-field"
                  >
                    <option value="AKTIV">{{ $t('projects.status.active') }}</option>
                    <option value="PAUSIERT">{{ $t('projects.status.paused') }}</option>
                    <option value="ABGESCHLOSSEN">{{ $t('projects.status.completed') }}</option>
                    <option value="ARCHIVIERT">{{ $t('projects.status.archived') }}</option>
                  </select>
                </div>

                <!-- Termine -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label for="startDate" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      {{ $t('projects.form.startDate') }}
                    </label>
                    <input
                      id="startDate"
                      v-model="form.startDate"
                      type="date"
                      class="input-field"
                    />
                  </div>
                  
                  <div>
                    <label for="endDate" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      {{ $t('projects.form.endDate') }}
                    </label>
                    <input
                      id="endDate"
                      v-model="form.endDate"
                      type="date"
                      class="input-field"
                    />
                  </div>
                </div>

                <!-- Budget -->
                <div>
                  <label for="budget" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {{ $t('projects.form.budget') }}
                  </label>
                  <div class="relative">
                    <input
                      id="budget"
                      v-model.number="form.budget"
                      type="number"
                      step="0.01"
                      min="0"
                      class="input-field pr-8"
                      :placeholder="$t('projects.form.budgetPlaceholder')"
                    />
                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                      <span class="text-gray-500 dark:text-gray-400 text-sm">€</span>
                    </div>
                  </div>
                </div>

                <!-- Aktionen -->
                <div class="flex justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
                  <button
                    type="button"
                    @click="$emit('close')"
                    class="btn-secondary"
                  >
                    {{ $t('common.cancel') }}
                  </button>
                  
                  <button
                    type="submit"
                    :disabled="loading"
                    class="btn-primary"
                  >
                    <span v-if="loading" class="flex items-center gap-2">
                      <div class="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      {{ $t('common.saving') }}
                    </span>
                    <span v-else>
                      {{ isEditing ? $t('common.save') : $t('common.create') }}
                    </span>
                  </button>
                </div>
              </form>
            </DialogPanel>
          </TransitionChild>
        </div>
      </div>
    </Dialog>
  </TransitionRoot>
</template>

<script setup lang="ts">
import { 
  Dialog, 
  DialogPanel, 
  DialogTitle, 
  TransitionChild, 
  TransitionRoot 
} from '@headlessui/vue'

// Props
const props = defineProps<{
  project?: any
}>()

// Emits
const emit = defineEmits(['close', 'saved'])

// Stores
const notificationsStore = useNotificationsStore()
const { addNotification } = notificationsStore

// Types
interface Customer {
  id: string
  email: string
  companyName: string
  contactName: string
  phone: string | null
  city: string | null
  country: string
}

interface ProjectErrors {
  name?: string
  key?: string
  [key: string]: string | undefined
}

// Reactive Data
const loading = ref(false)
const customers = ref<Customer[]>([])
const errors = ref<ProjectErrors>({})

const form = reactive({
  name: '',
  key: '',
  description: '',
  customerId: '',
  status: 'AKTIV',
  startDate: '',
  endDate: '',
  budget: null,
  isInternal: false
})

// Computed
const isEditing = computed(() => !!props.project)

// Methods
async function loadCustomers() {
  try {
    const response = await $fetch('/api/customers')
    customers.value = response.data || []
  } catch (error) {
    console.error('Fehler beim Laden der Kunden:', error)
  }
}

function initializeForm() {
  if (props.project) {
    Object.assign(form, {
      name: props.project.name || '',
      key: props.project.key || '',
      description: props.project.description || '',
      customerId: props.project.customerId || '',
      status: props.project.status || 'AKTIV',
      startDate: props.project.startDate ? new Date(props.project.startDate).toISOString().split('T')[0] : '',
      endDate: props.project.endDate ? new Date(props.project.endDate).toISOString().split('T')[0] : '',
      budget: props.project.budget || null,
      isInternal: props.project.isInternal || false
    })
  } else {
    // Reset form for new project
    Object.assign(form, {
      name: '',
      key: '',
      description: '',
      customerId: '',
      status: 'AKTIV',
      startDate: '',
      endDate: '',
      budget: null,
      isInternal: false
    })
  }
}

async function handleSubmit() {
  try {
    loading.value = true
    errors.value = {}

    // Basic validation
    if (!form.name.trim()) {
      errors.value.name = 'Projektname ist erforderlich'
      return
    }

    if (!form.key.trim()) {
      errors.value.key = 'Projektschlüssel ist erforderlich'
      return
    }

    // Prepare data
    const data = {
      ...form,
      startDate: form.startDate ? new Date(form.startDate).toISOString() : null,
      endDate: form.endDate ? new Date(form.endDate).toISOString() : null,
      customerId: form.customerId || null
    }

    let response
    if (isEditing.value) {
      response = await $fetch(`/api/projects/${props.project.id}`, {
        method: 'PUT',
        body: data
      })
    } else {
      response = await $fetch('/api/projects', {
        method: 'POST',
        body: data
      })
    }

    addNotification({
      type: 'success',
      title: isEditing.value ? 'Projekt aktualisiert' : 'Projekt erstellt',
      message: isEditing.value 
        ? 'Das Projekt wurde erfolgreich aktualisiert'
        : 'Das neue Projekt wurde erfolgreich erstellt'
    })

    // Handle different response formats
    const projectData = 'data' in response ? response.data : response
    emit('saved', projectData)
  } catch (err: any) {
    console.error('Fehler beim Speichern:', err)
    
    if (err?.data?.errors) {
      errors.value = err.data.errors
    } else {
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: err?.data?.message || 'Das Projekt konnte nicht gespeichert werden'
      })
    }
  } finally {
    loading.value = false
  }
}

// Watchers
watch(() => form.name, (newName) => {
  if (!isEditing.value && newName) {
    // Auto-generate key from name
    form.key = newName
      .toUpperCase()
      .replace(/[^A-Z0-9\s]/g, '')
      .replace(/\s+/g, '-')
      .substring(0, 10)
  }
})

watch(() => form.isInternal, (isInternal) => {
  if (isInternal) {
    form.customerId = ''
  }
})

// Lifecycle
onMounted(() => {
  loadCustomers()
  initializeForm()
})

watch(() => props.project, () => {
  initializeForm()
})
</script>
