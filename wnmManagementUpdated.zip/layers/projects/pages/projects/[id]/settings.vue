<template>
  <div class="min-h-screen bg-gray-50 dark:bg-gray-900 w-full">
    <!-- Header -->
    <div class="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
      <div class="px-6 py-4">
        <div class="flex items-center justify-between">
          <div>
            <nav class="flex" aria-label="Breadcrumb">
              <ol class="flex items-center space-x-4">
                <li>
                  <NuxtLink to="/projects" class="text-gray-400 hover:text-gray-500 dark:text-gray-300 dark:hover:text-gray-200">
                    Projekte
                  </NuxtLink>
                </li>
                <li>
                  <div class="flex items-center">
                    <ChevronRightIcon class="h-5 w-5 text-gray-400" />
                    <NuxtLink :to="`/projects/${project?.id}`" class="ml-4 text-gray-400 hover:text-gray-500 dark:text-gray-300 dark:hover:text-gray-200">
                      {{ project?.name || 'Projekt' }}
                    </NuxtLink>
                  </div>
                </li>
                <li>
                  <div class="flex items-center">
                    <ChevronRightIcon class="h-5 w-5 text-gray-400" />
                    <span class="ml-4 text-sm font-medium text-gray-900 dark:text-white">Einstellungen</span>
                  </div>
                </li>
              </ol>
            </nav>
            <h1 class="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
              Projekt-Einstellungen
            </h1>
            <p class="mt-1 text-gray-600 dark:text-gray-400">
              Konfigurieren Sie projektspezifische Enum-Werte und Einstellungen
            </p>
          </div>
        </div>
      </div>
    </div>

    <!-- Content -->
    <div class="py-8">
      <div class="w-full">
        <!-- Loading State -->
        <div v-if="loading" class="flex items-center justify-center py-12">
          <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
          <span class="ml-3 text-gray-600 dark:text-gray-400">Lade Einstellungen...</span>
        </div>

        <!-- Error State -->
        <div v-else-if="error" class="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 mb-6">
          <div class="flex items-center">
            <ExclamationTriangleIcon class="h-5 w-5 text-red-400" />
            <span class="ml-3 text-red-800 dark:text-red-200">{{ error }}</span>
          </div>
        </div>

        <!-- Enum Settings Sections -->
        <div v-else class="space-y-8">
          <!-- Task Types -->
          <ProjectEnumSection
            title="Aufgabentypen"
            description="Verwalten Sie die verfügbaren Aufgabentypen für dieses Projekt"
            icon="BugAntIcon"
            category-name="task_type"
            :project-id="projectId"
            :settings="enumSettings?.task_type"
            @refresh="refreshSettings"
          />

          <!-- Task Status -->
          <ProjectEnumSection
            title="Aufgabenstatus"
            description="Verwalten Sie die verfügbaren Status für Aufgaben in diesem Projekt"
            icon="QueueListIcon"
            category-name="task_status"
            :project-id="projectId"
            :settings="enumSettings?.task_status"
            @refresh="refreshSettings"
          />

          <!-- Priority -->
          <ProjectEnumSection
            title="Prioritäten"
            description="Verwalten Sie die verfügbaren Prioritätsstufen für dieses Projekt"
            icon="ExclamationTriangleIcon"
            category-name="priority"
            :project-id="projectId"
            :settings="enumSettings?.priority"
            @refresh="refreshSettings"
          />

          <!-- Ticket Types -->
          <ProjectEnumSection
            title="Ticket-Typen"
            description="Verwalten Sie die verfügbaren Ticket-Typen für dieses Projekt"
            icon="TicketIcon"
            category-name="ticket_type"
            :project-id="projectId"
            :settings="enumSettings?.ticket_type"
            @refresh="refreshSettings"
          />

          <!-- Ticket Status -->
          <ProjectEnumSection
            title="Ticket-Status"
            description="Verwalten Sie die verfügbaren Status für Tickets in diesem Projekt"
            icon="ChatBubbleLeftRightIcon"
            category-name="ticket_status"
            :project-id="projectId"
            :settings="enumSettings?.ticket_status"
            @refresh="refreshSettings"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ChevronRightIcon, ExclamationTriangleIcon } from '@heroicons/vue/24/outline'

// Route parameters
const route = useRoute()
const projectId = computed(() => route.params.id as string)

// Stores
const projectsStore = useProjectsStore()
const enumStore = useEnumManagementStore()

// Reactive data
const loading = ref(true)
const error = ref<string | null>(null)

// Computed
const project = computed(() => projectsStore.projects.find(p => p.id === projectId.value))
const enumSettings = computed(() => enumStore.getProjectEnumSettings(projectId.value).value)

// Methods
const refreshSettings = async () => {
  loading.value = true
  error.value = null
  
  try {
    await enumStore.fetchProjectEnumSettings(projectId.value)
  } catch (err: any) {
    error.value = err.message || 'Fehler beim Laden der Einstellungen'
  } finally {
    loading.value = false
  }
}

// Lifecycle
onMounted(async () => {
  try {
    // Load project if not already loaded
    if (!project.value) {
      await projectsStore.fetchProject(projectId.value)
    }
    
    // Load enum settings
    await refreshSettings()
  } catch (err: any) {
    error.value = err.message || 'Fehler beim Laden der Projekt-Daten'
    loading.value = false
  }
})

// Page meta
definePageMeta({
  layout: 'default'
})

// Page title
useHead({
  title: computed(() => `${project.value?.name || 'Projekt'} - Einstellungen`)
})
</script>
