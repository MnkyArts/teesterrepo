<template>
  <div class="space-y-6">
    <!-- Header mit Aktionen -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
      <div>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
          {{ $t('projects.title') }}
        </h1>
        <p class="text-gray-600 dark:text-gray-400">
          {{ $t('projects.subtitle') }}
        </p>
      </div>
      
      <div class="flex items-center gap-3">
        <button
          @click="refreshProjects"
          :disabled="loading"
          class="btn-secondary"
        >
          <ArrowPathIcon class="h-5 w-5" :class="{ 'animate-spin': loading }" />
          {{ $t('common.refresh') }}
        </button>
        
        <button
          @click="openCreateModal"
          class="btn-primary"
          v-if="canCreateProjects"
        >
          <PlusIcon class="h-5 w-5" />
          {{ $t('projects.create') }}
        </button>
      </div>
    </div>

    <!-- Filter und Suche -->
    <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
      <div class="flex flex-col sm:flex-row gap-4">
        <div class="flex-1">
          <input
            v-model="searchQuery"
            type="text"
            :placeholder="$t('projects.searchPlaceholder')"
            class="input-field"
          />
        </div>
        
        <div class="flex gap-2">
          <select v-model="statusFilter" class="input-field min-w-32">
            <option value="">{{ $t('projects.allStatuses') }}</option>
            <option value="AKTIV">{{ $t('projects.status.active') }}</option>
            <option value="PAUSIERT">{{ $t('projects.status.paused') }}</option>
            <option value="ABGESCHLOSSEN">{{ $t('projects.status.completed') }}</option>
          </select>
          
          <select v-model="typeFilter" class="input-field min-w-32">
            <option value="">{{ $t('projects.allTypes') }}</option>
            <option value="customer">{{ $t('projects.customerProjects') }}</option>
            <option value="internal">{{ $t('projects.internalProjects') }}</option>
          </select>
        </div>
      </div>
    </div>

    <!-- Projektliste -->
    <div class="grid gap-6">
      <template v-if="loading && projects.length === 0">
        <ProjectCardSkeleton v-for="i in 3" :key="i" />
      </template>
      
      <template v-else-if="filteredProjects.length > 0">
        <ProjectCard
          v-for="project in filteredProjects"
          :key="project.id"
          :project="project"
          @view="viewProject"
          @edit="editProject"
          @delete="deleteProject"
        />
      </template>
      
      <div v-else class="text-center py-12">
        <FolderIcon class="mx-auto h-12 w-12 text-gray-400" />
        <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">
          {{ searchQuery || statusFilter || typeFilter ? $t('projects.noResults') : $t('projects.empty') }}
        </h3>
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
          {{ searchQuery || statusFilter || typeFilter ? $t('projects.tryDifferentFilters') : $t('projects.createFirst') }}
        </p>
        <div class="mt-6" v-if="canCreateProjects && !searchQuery && !statusFilter && !typeFilter">
          <button @click="openCreateModal" class="btn-primary">
            <PlusIcon class="h-5 w-5" />
            {{ $t('projects.createFirst') }}
          </button>
        </div>
      </div>
    </div>

    <!-- Pagination -->
    <div v-if="totalPages > 1" class="flex justify-center">
      <nav class="flex items-center gap-2">
        <button
          @click="currentPage = Math.max(1, currentPage - 1)"
          :disabled="currentPage === 1"
          class="btn-secondary disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {{ $t('common.previous') }}
        </button>
        
        <span class="px-3 py-2 text-sm text-gray-700 dark:text-gray-300">
          {{ $t('common.pageOf', { current: currentPage, total: totalPages }) }}
        </span>
        
        <button
          @click="currentPage = Math.min(totalPages, currentPage + 1)"
          :disabled="currentPage === totalPages"
          class="btn-secondary disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {{ $t('common.next') }}
        </button>
      </nav>
    </div>

    <!-- Create/Edit Modal -->
    <ProjectModal
      v-if="showModal"
      :project="editingProject"
      @close="closeModal"
      @saved="onProjectSaved"
    />
  </div>
</template>

<script setup lang="ts">
import { PlusIcon, ArrowPathIcon, FolderIcon } from '@heroicons/vue/24/outline'

// Meta & Layout
definePageMeta({
  layout: 'default'
})

useSeoMeta({
  title: 'Projekte - wenoma',
  description: 'Verwalten Sie alle Ihre Projekte an einem Ort'
})

// Stores
const authStore = useAuthStore()
const { user } = storeToRefs(authStore)

const notificationsStore = useNotificationsStore()
const { addNotification } = notificationsStore

// Project interface
interface Project {
  id: string
  name: string
  key: string
  status: string
  isInternal: boolean
  customer?: {
    id: string
    companyName: string
    contactName: string
  } | null
  [key: string]: any
}

// Reactive Data
const loading = ref(false)
const projects = ref<Project[]>([])
const searchQuery = ref('')
const statusFilter = ref('')
const typeFilter = ref('')
const currentPage = ref(1)
const totalPages = ref(1)
const showModal = ref(false)
const editingProject = ref<Project | null>(null)
const itemsPerPage = 12

// Computed
const canCreateProjects = computed(() => {
  return ['ADMINISTRATOR', 'PROJEKTLEITER'].includes(user.value?.role as string)
})

const filteredProjects = computed(() => {
  let filtered = projects.value

  // Textsuche
  if (searchQuery.value) {
    const query = searchQuery.value.toLowerCase()
    filtered = filtered.filter(project => 
      project.name.toLowerCase().includes(query) ||
      project.key.toLowerCase().includes(query) ||
      project.customer?.companyName?.toLowerCase().includes(query)
    )
  }

  // Status-Filter
  if (statusFilter.value) {
    filtered = filtered.filter(project => project.status === statusFilter.value)
  }

  // Typ-Filter
  if (typeFilter.value) {
    if (typeFilter.value === 'internal') {
      filtered = filtered.filter(project => project.isInternal)
    } else if (typeFilter.value === 'customer') {
      filtered = filtered.filter(project => !project.isInternal)
    }
  }

  // Pagination
  const start = (currentPage.value - 1) * itemsPerPage
  const end = start + itemsPerPage
  
  totalPages.value = Math.ceil(filtered.length / itemsPerPage)
  
  return filtered.slice(start, end)
})

// Methods
async function loadProjects() {
  try {
    loading.value = true
    const response = await $fetch('/api/projects') as any
    projects.value = (response.data || response || []) as Project[]
  } catch (error) {
    console.error('Fehler beim Laden der Projekte:', error)
    addNotification({
      type: 'error',
      title: 'Fehler',
      message: 'Projekte konnten nicht geladen werden'
    })
  } finally {
    loading.value = false
  }
}

async function refreshProjects() {
  await loadProjects()
  addNotification({
    type: 'success',
    title: 'Aktualisiert',
    message: 'Projektliste wurde aktualisiert'
  })
}

function openCreateModal() {
  editingProject.value = null
  showModal.value = true
}

function closeModal() {
  showModal.value = false
  editingProject.value = null
}

function viewProject(project: Project) {
  navigateTo(`/projects/${project.id}`)
}

function editProject(project: Project) {
  editingProject.value = project
  showModal.value = true
}

async function deleteProject(project: Project) {
  if (!confirm(`Projekt "${project.name}" wirklich löschen?`)) {
    return
  }

  try {
    await $fetch(`/api/projects/${project.id}`, { 
      method: 'DELETE'
    })
    await loadProjects()
    addNotification({
      type: 'success',
      title: 'Gelöscht',
      message: 'Projekt wurde erfolgreich gelöscht'
    })
  } catch (error) {
    console.error('Fehler beim Löschen:', error)
    addNotification({
      type: 'error',
      title: 'Fehler',
      message: 'Projekt konnte nicht gelöscht werden'
    })
  }
}

function onProjectSaved() {
  closeModal()
  loadProjects()
}

// Watchers
watch([searchQuery, statusFilter, typeFilter], () => {
  currentPage.value = 1
})

// Lifecycle
onMounted(() => {
  loadProjects()
})
</script>
