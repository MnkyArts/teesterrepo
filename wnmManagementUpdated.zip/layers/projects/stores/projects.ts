import { defineStore } from 'pinia'

interface Project {
  id: string
  name: string
  description?: string
  status: 'active' | 'completed' | 'on-hold' | 'cancelled'
  progress: number
  startDate: Date
  endDate?: Date
  customerId: string
  customer?: {
    id: string
    name: string
    email: string
  }
  teamMembers: string[]
  budget?: number
  tags: string[]
  createdAt: Date
  updatedAt: Date
}

export const useProjectsStore = defineStore('projects', () => {
  const notificationsStore = useNotificationsStore()
  
  // State
  const projects = ref<Project[]>([])
  const currentProject = ref<Project | null>(null)
  const isLoading = ref(false)

  // Computed properties
  const activeProjects = computed(() => 
    Array.isArray(projects.value) ? projects.value.filter(p => p.status === 'active') : []
  )

  const completedProjects = computed(() => 
    Array.isArray(projects.value) ? projects.value.filter(p => p.status === 'completed') : []
  )

  const userProjects = computed(() => {
    // TODO: Filter based on user permissions/assignments
    return Array.isArray(projects.value) ? projects.value : []
  })

  // Actions
  const fetchProjects = async () => {
    isLoading.value = true
    try {
      const { data } = await $fetch<{ success: boolean, data: Project[] }>('/api/projects')
      
      if (data) {
        projects.value = data.map(project => ({
          ...project,
          startDate: new Date(project.startDate),
          endDate: project.endDate ? new Date(project.endDate) : undefined,
          createdAt: new Date(project.createdAt),
          updatedAt: new Date(project.updatedAt)
        }))
      }
    } catch (error) {
      console.error('Error fetching projects:', error)
      notificationsStore.error('Fehler', 'Projekte konnten nicht geladen werden')
    } finally {
      isLoading.value = false
    }
  }

  const fetchProject = async (id: string) => {
    try {
      const { data } = await $fetch<{ success: boolean, data: Project }>(`/api/projects/${id}`)
      
      if (data) {
        const project = {
          ...data,
          startDate: new Date(data.startDate),
          endDate: data.endDate ? new Date(data.endDate) : undefined,
          createdAt: new Date(data.createdAt),
          updatedAt: new Date(data.updatedAt)
        }
        
        currentProject.value = project
        
        // Update project in list if it exists
        const index = projects.value.findIndex(p => p.id === id)
        if (index > -1) {
          projects.value[index] = project
        }
      }
    } catch (error) {
      console.error('Error fetching project:', error)
      notificationsStore.error('Fehler', 'Projekt konnte nicht geladen werden')
    }
  }

  const createProject = async (projectData: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const { data } = await $fetch<{ success: boolean, data: Project }>('/api/projects', {
        method: 'POST',
        body: {
          ...projectData,
          startDate: projectData.startDate.toISOString(),
          endDate: projectData.endDate?.toISOString()
        }
      })
      
      if (data) {
        const newProject = {
          ...data,
          startDate: new Date(data.startDate),
          endDate: data.endDate ? new Date(data.endDate) : undefined,
          createdAt: new Date(data.createdAt),
          updatedAt: new Date(data.updatedAt)
        }
        
        projects.value.unshift(newProject)
        notificationsStore.success('Erfolg', 'Projekt wurde erfolgreich erstellt')
        return newProject
      }
    } catch (error: any) {
      console.error('Error creating project:', error)
      notificationsStore.error('Fehler', error.message || 'Projekt konnte nicht erstellt werden')
      throw error
    }
  }

  const updateProject = async (id: string, updates: Partial<Project>) => {
    try {
      const updateData = {
        ...updates,
        startDate: updates.startDate?.toISOString(),
        endDate: updates.endDate?.toISOString()
      }
      
      const { data } = await $fetch<{ success: boolean, data: Project }>(`/api/projects/${id}`, {
        method: 'PATCH',
        body: updateData
      })
      
      if (data) {
        const updatedProject = {
          ...data,
          startDate: new Date(data.startDate),
          endDate: data.endDate ? new Date(data.endDate) : undefined,
          createdAt: new Date(data.createdAt),
          updatedAt: new Date(data.updatedAt)
        }
        
        // Update in projects list
        const index = projects.value.findIndex(p => p.id === id)
        if (index > -1) {
          projects.value[index] = updatedProject
        }
        
        // Update current project if it's the same
        if (currentProject.value?.id === id) {
          currentProject.value = updatedProject
        }
        
        notificationsStore.success('Erfolg', 'Projekt wurde erfolgreich aktualisiert')
        return updatedProject
      }
    } catch (error: any) {
      console.error('Error updating project:', error)
      notificationsStore.error('Fehler', error.message || 'Projekt konnte nicht aktualisiert werden')
      throw error
    }
  }

  const deleteProject = async (id: string) => {
    try {
      await $fetch(`/api/projects/${id}`, {
        method: 'DELETE'
      })
      
      // Remove from projects list
      const index = projects.value.findIndex(p => p.id === id)
      if (index > -1) {
        projects.value.splice(index, 1)
      }
      
      // Clear current project if it's the deleted one
      if (currentProject.value?.id === id) {
        currentProject.value = null
      }
      
      notificationsStore.success('Erfolg', 'Projekt wurde erfolgreich gelöscht')
    } catch (error: any) {
      console.error('Error deleting project:', error)
      notificationsStore.error('Fehler', error.message || 'Projekt konnte nicht gelöscht werden')
      throw error
    }
  }

  const getProjectProgress = (project: Project) => {
    // TODO: Calculate progress based on tasks
    return project.progress || 0
  }

  const getProjectStats = (project: Project) => {
    // TODO: Get project statistics
    return {
      totalTasks: 0,
      completedTasks: 0,
      totalHours: 0,
      remainingHours: 0
    }
  }

  const setCurrentProject = (project: Project | null) => {
    currentProject.value = project
  }

  return {
    // State
    projects: readonly(projects),
    currentProject: readonly(currentProject),
    isLoading: readonly(isLoading),
    
    // Computed
    activeProjects,
    completedProjects,
    userProjects,
    
    // Actions
    fetchProjects,
    fetchProject,
    createProject,
    updateProject,
    deleteProject,
    getProjectProgress,
    getProjectStats,
    setCurrentProject
  }
})
