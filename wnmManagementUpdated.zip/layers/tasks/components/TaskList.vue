<template>
  <div class="space-y-3">
    <div
      v-for="task in displayTasks"
      :key="task.id"
      class="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
    >
      <div class="flex items-center space-x-3">
        <div class="flex-shrink-0">
          <TaskPropertyBadge 
            :enum-value="task.priority" 
            size="sm" 
            :show-dot="true" 
            :show-icon="false" 
            class="w-3 h-3" />
        </div>
        
        <div class="flex-1 min-w-0">
          <p class="text-sm font-medium text-gray-900 dark:text-white truncate">
            {{ task.title }}
          </p>
          <p v-if="showProject && task.project" class="text-xs text-gray-500 dark:text-gray-400">
            {{ task.project.name }}
          </p>
        </div>
      </div>

      <div class="flex items-center space-x-2">
        <TaskPropertyBadge 
          :enum-value="task.status" 
          size="sm" 
          class="text-xs" />
        
        <span class="text-xs text-gray-500 dark:text-gray-400">
          {{ formatDueDate(task.dueDate) }}
        </span>
      </div>
    </div>

    <div v-if="!Array.isArray(tasks) || tasks.length === 0" class="text-center py-8">
      <ClipboardDocumentListIcon class="mx-auto h-12 w-12 text-gray-400" />
      <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
        Keine Aufgaben verfügbar
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { ClipboardDocumentListIcon } from '@heroicons/vue/24/outline'

interface Task {
  id: string
  title: string
  project?: {
    id: string
    name: string
    key: string
  } | null
  priority: 'NIEDRIG' | 'NORMAL' | 'HOCH' | 'KRITISCH' | 'BLOCKER'
  dueDate?: string | Date | null
  status: 'GEPLANT' | 'TECHNISCHES_DESIGN' | 'IN_BEARBEITUNG' | 'REVIEW' | 'TESTING' | 'ERLEDIGT' | 'GESCHLOSSEN'
}

interface Props {
  tasks: Task[]
  showProject?: boolean
  maxItems?: number
}

const props = withDefaults(defineProps<Props>(), {
  tasks: () => [],
  showProject: false,
  maxItems: 5
})

const displayTasks = computed(() => {
  // Ensure tasks is always an array
  const tasksArray = Array.isArray(props.tasks) ? props.tasks : []
  return tasksArray.slice(0, props.maxItems)
})

const priorityColor = (priority: string) => {
  const colors = {
    'NIEDRIG': 'bg-gray-400',
    'NORMAL': 'bg-blue-400', 
    'HOCH': 'bg-orange-400',
    'KRITISCH': 'bg-red-500',
    'BLOCKER': 'bg-red-600'
  }
  return colors[priority as keyof typeof colors] || 'bg-gray-400'
}

const statusColor = (status: string) => {
  const colors = {
    'GEPLANT': 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200',
    'TECHNISCHES_DESIGN': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    'IN_BEARBEITUNG': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
    'REVIEW': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
    'TESTING': 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200',
    'ERLEDIGT': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
    'GESCHLOSSEN': 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
  }
  return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800'
}

const formatDueDate = (date?: string | Date | null) => {
  if (!date) return ''
  
  const dueDate = new Date(date)
  const now = new Date()
  const diff = dueDate.getTime() - now.getTime()
  const days = Math.ceil(diff / (1000 * 60 * 60 * 24))
  
  if (days < 0) return 'Überfällig'
  if (days === 0) return 'Heute'
  if (days === 1) return 'Morgen'
  if (days < 7) return `in ${days} Tagen`
  
  return dueDate.toLocaleDateString('de-DE', {
    day: 'numeric',
    month: 'short'
  })
}
</script>
