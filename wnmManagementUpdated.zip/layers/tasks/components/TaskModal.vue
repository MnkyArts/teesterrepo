<template>
  <TransitionRoot :show="isOpen" as="template">
    <Dialog as="div" class="relative z-50" @close="closeModal">
      <TransitionChild
        as="template"
        enter="ease-out duration-300"
        enter-from="opacity-0"
        enter-to="opacity-100"
        leave="ease-in duration-200"
        leave-from="opacity-100"
        leave-to="opacity-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
      </TransitionChild>

      <div class="fixed inset-0 z-10 overflow-y-auto">
        <div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
          <TransitionChild
            as="template"
            enter="ease-out duration-300"
            enter-from="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            enter-to="opacity-100 translate-y-0 sm:scale-100"
            leave="ease-in duration-200"
            leave-from="opacity-100 translate-y-0 sm:scale-100"
            leave-to="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95">
            <DialogPanel class="relative transform overflow-hidden rounded-lg bg-white dark:bg-gray-800 px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-2xl sm:p-6">
              
              <!-- Header -->
              <div class="mb-6">
                <div class="flex items-center justify-between">
                  <DialogTitle as="h3" class="text-lg font-semibold leading-6 text-gray-900 dark:text-white">
                    {{ isEdit ? 'Aufgabe bearbeiten' : 'Neue Aufgabe erstellen' }}
                  </DialogTitle>
                  <button
                    type="button"
                    class="rounded-md text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    @click="closeModal">
                    <XMarkIcon class="h-6 w-6" />
                  </button>
                </div>
              </div>

              <!-- Form -->
              <form @submit.prevent="handleSubmit" class="space-y-6">
                
                <!-- Projekt-Auswahl (nur bei Erstellung) -->
                <div v-if="!isEdit">
                  <label for="projectId" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Projekt *
                  </label>
                  <select
                    id="projectId"
                    v-model="form.projectId"
                    required
                    class="w-full rounded-md border-0 ring-1 ring-inset ring-gray-300 dark:ring-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:ring-2 focus:ring-inset focus:ring-blue-600 dark:focus:ring-blue-500">
                    <option value="">Projekt auswählen</option>
                    <option v-for="project in availableProjects" :key="project.id" :value="project.id">
                      {{ project.name }}
                    </option>
                  </select>
                </div>

                <!-- Titel -->
                <div>
                  <label for="title" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Titel *
                  </label>
                  <input
                    id="title"
                    v-model="form.title"
                    type="text"
                    required
                    class="w-full rounded-md border-0 ring-1 ring-inset ring-gray-300 dark:ring-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:ring-2 focus:ring-inset focus:ring-blue-600 dark:focus:ring-blue-500"
                    placeholder="Aufgaben-Titel eingeben...">
                </div>

                <!-- Beschreibung -->
                <div>
                  <label for="description" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Beschreibung
                  </label>
                  <textarea
                    id="description"
                    v-model="form.description"
                    rows="4"
                    class="w-full rounded-md border-0 ring-1 ring-inset ring-gray-300 dark:ring-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:ring-2 focus:ring-inset focus:ring-blue-600 dark:focus:ring-blue-500"
                    placeholder="Detaillierte Beschreibung der Aufgabe..."></textarea>
                </div>

                <!-- Typ, Priorität, Status -->
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <!-- Typ -->
                  <div>
                    <label for="type" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Typ
                    </label>
                    <select
                      id="type"
                      v-model="form.type"
                      class="w-full rounded-md border-0 ring-1 ring-inset ring-gray-300 dark:ring-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:ring-2 focus:ring-inset focus:ring-blue-600 dark:focus:ring-blue-500">
                      <option value="">Typ auswählen</option>
                      <option v-for="type in taskTypes" :key="type.enumValue.id" :value="type.enumValue.id">
                        {{ type.label }}
                      </option>
                    </select>
                  </div>

                  <!-- Priorität -->
                  <div>
                    <label for="priority" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Priorität
                    </label>
                    <select
                      id="priority"
                      v-model="form.priority"
                      class="w-full rounded-md border-0 ring-1 ring-inset ring-gray-300 dark:ring-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:ring-2 focus:ring-inset focus:ring-blue-600 dark:focus:ring-blue-500">
                      <option value="">Priorität auswählen</option>
                      <option v-for="priority in taskPriorities" :key="priority.enumValue.id" :value="priority.enumValue.id">
                        {{ priority.label }}
                      </option>
                    </select>
                  </div>

                  <!-- Status -->
                  <div>
                    <label for="status" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Status
                    </label>
                    <select
                      id="status"
                      v-model="form.status"
                      class="w-full rounded-md border-0 ring-1 ring-inset ring-gray-300 dark:ring-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:ring-2 focus:ring-inset focus:ring-blue-600 dark:focus:ring-blue-500">
                      <option value="">Status auswählen</option>
                      <option v-for="status in taskStatuses" :key="status.enumValue.id" :value="status.enumValue.id">
                        {{ status.label }}
                      </option>
                    </select>
                  </div>
                </div>

                <!-- Zuweisung und Fälligkeitsdatum -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <!-- Zuweisen an -->
                  <div>
                    <label for="assigneeId" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Zuweisen an
                    </label>
                    <select
                      id="assigneeId"
                      v-model="form.assigneeId"
                      class="w-full rounded-md border-0 ring-1 ring-inset ring-gray-300 dark:ring-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:ring-2 focus:ring-inset focus:ring-blue-600 dark:focus:ring-blue-500">
                      <option value="">Nicht zugewiesen</option>
                      <option v-for="user in availableUsers" :key="user.id" :value="user.id">
                        {{ user.firstName }} {{ user.lastName }}
                      </option>
                    </select>
                  </div>

                  <!-- Fälligkeitsdatum -->
                  <div>
                    <label for="dueDate" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Fälligkeitsdatum
                    </label>
                    <input
                      id="dueDate"
                      v-model="form.dueDate"
                      type="date"
                      class="w-full rounded-md border-0 ring-1 ring-inset ring-gray-300 dark:ring-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:ring-2 focus:ring-inset focus:ring-blue-600 dark:focus:ring-blue-500">
                  </div>
                </div>

                <!-- Zeitschätzung -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <!-- Geschätzte Stunden -->
                  <div>
                    <label for="estimatedHours" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Geschätzte Stunden
                    </label>
                    <input
                      id="estimatedHours"
                      v-model.number="form.estimatedHours"
                      type="number"
                      min="0"
                      step="0.5"
                      class="w-full rounded-md border-0 ring-1 ring-inset ring-gray-300 dark:ring-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:ring-2 focus:ring-inset focus:ring-blue-600 dark:focus:ring-blue-500"
                      placeholder="z.B. 8">
                  </div>

                  <!-- Verbleibende Stunden -->
                  <div v-if="isEdit">
                    <label for="remainingHours" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Verbleibende Stunden
                    </label>
                    <input
                      id="remainingHours"
                      v-model.number="form.remainingHours"
                      type="number"
                      min="0"
                      step="0.5"
                      class="w-full rounded-md border-0 ring-1 ring-inset ring-gray-300 dark:ring-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm focus:ring-2 focus:ring-inset focus:ring-blue-600 dark:focus:ring-blue-500"
                      placeholder="z.B. 4">
                  </div>
                </div>

                <!-- Error Message -->
                <div v-if="error" class="text-sm text-red-600 dark:text-red-400">
                  {{ error }}
                </div>

                <!-- Actions -->
                <div class="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200 dark:border-gray-700">
                  <button
                    type="button"
                    @click="closeModal"
                    class="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border-0 ring-1 ring-inset ring-gray-300 dark:ring-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    Abbrechen
                  </button>
                  <button
                    type="submit"
                    :disabled="loading"
                    class="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed">
                    <span v-if="loading" class="flex items-center">
                      <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Speichern...
                    </span>
                    <span v-else>
                      {{ isEdit ? 'Aktualisieren' : 'Erstellen' }}
                    </span>
                  </button>
                </div>
              </form>

            </DialogPanel>
          </TransitionChild>
        </div>
      </div>
    </Dialog>
  </TransitionRoot>
</template>

<script setup lang="ts">
import { ref, reactive, watch, computed, onMounted, nextTick } from 'vue'
import { Dialog, DialogPanel, DialogTitle, TransitionChild, TransitionRoot } from '@headlessui/vue'
import { XMarkIcon } from '@heroicons/vue/24/outline'
import type { TaskWithDetails, CreateTaskData, UpdateTaskData } from '../stores/tasks'
import type { User, Project } from '@prisma/client'

interface Props {
  isOpen: boolean
  task?: TaskWithDetails | null
  projectId?: string
  availableProjects?: Array<{ id: string; name: string }>
  availableUsers?: Array<{ id: string; firstName: string; lastName: string }>
}

const props = withDefaults(defineProps<Props>(), {
  task: null,
  projectId: '',
  availableProjects: () => [],
  availableUsers: () => []
})

const emit = defineEmits<{
  close: []
  create: [data: CreateTaskData]
  update: [taskId: string, data: UpdateTaskData]
}>()

// Stores
const tasksStore = useTasksStore()
const enumManagementStore = useEnumManagementStore()

// Project-specific enum values
const taskTypes = computed(() => {
  const projectId = form.projectId || props.projectId
  if (!projectId) return []
  
  const values = enumManagementStore.getEffectiveEnumValues(projectId, 'task_type')
  
  return values.map(value => ({
    label: value.label,
    value: value.key,
    color: value.color,
    icon: value.icon,
    enumValue: value
  }))
})

const taskPriorities = computed(() => {
  const projectId = form.projectId || props.projectId
  if (!projectId) return []
  
  const values = enumManagementStore.getEffectiveEnumValues(projectId, 'priority')
  
  return values.map(value => ({
    label: value.label,
    value: value.key,
    color: value.color,
    icon: value.icon,
    enumValue: value
  }))
})

const taskStatuses = computed(() => {
  const projectId = form.projectId || props.projectId
  if (!projectId) return []
  
  const values = enumManagementStore.getEffectiveEnumValues(projectId, 'task_status')
  
  return values.map(value => ({
    label: value.label,
    value: value.key,
    color: value.color,
    icon: value.icon,
    enumValue: value
  }))
})

// Ensure enums and project overrides are loaded
onMounted(async () => {
  if (enumManagementStore.categories.length === 0) {
    await enumManagementStore.fetchCategories()
  }
  
  // Load project overrides and project-specific enum values if we have a project
  const projectId = props.projectId || props.task?.projectId
  if (projectId) {
    await enumManagementStore.fetchProjectOverrides(projectId)
    await enumManagementStore.fetchProjectEnumSettings(projectId)
  }
})

// State
const loading = ref(false)
const error = ref('')

// Form Data
const defaultForm = {
  title: '',
  description: '',
  type: '', // Will be set from dynamic enums
  priority: '', // Will be set from dynamic enums  
  status: '', // Will be set from dynamic enums
  projectId: '',
  assigneeId: '',
  dueDate: '',
  estimatedHours: undefined as number | undefined,
  remainingHours: undefined as number | undefined
}

const form = reactive({ ...defaultForm })

// Computed
const isEdit = computed(() => !!props.task)

// Watchers
watch(() => props.isOpen, async (isOpen) => {
  if (isOpen) {
    resetForm()
    
    // Ensure enums are loaded
    if (enumManagementStore.categories.length === 0) {
      await enumManagementStore.fetchCategories()
    }
    
    if (props.task) {
      // Task zum Bearbeiten laden
      form.title = props.task.title
      form.description = props.task.description || ''
      form.type = props.task.type?.id || ''
      form.priority = props.task.priority?.id || ''
      form.status = props.task.status?.id || ''
      form.assigneeId = props.task.assigneeId || ''
      form.dueDate = props.task.dueDate ? new Date(props.task.dueDate).toISOString().split('T')[0] : ''
      form.estimatedHours = props.task.estimatedHours || undefined
      form.remainingHours = props.task.remainingHours || undefined
      
      // Load project overrides and enum settings for the task's project
      await enumManagementStore.fetchProjectOverrides(props.task.projectId)
      await enumManagementStore.fetchProjectEnumSettings(props.task.projectId)
    } else {
      // Neue Task - Standardwerte setzen
      if (props.projectId) {
        form.projectId = props.projectId
        // Load project overrides and enum settings for the selected project
        await enumManagementStore.fetchProjectOverrides(props.projectId)
        await enumManagementStore.fetchProjectEnumSettings(props.projectId)
      }
      
      // Setze Standard-Enums falls verfügbar (after project overrides are loaded)
      await nextTick()
      const defaultType = taskTypes.value.find(t => t.enumValue.isDefault)
      const defaultPriority = taskPriorities.value.find(p => p.enumValue.isDefault)
      const defaultStatus = taskStatuses.value.find(s => s.enumValue.isDefault)
      
      if (defaultType) form.type = defaultType.enumValue.id
      if (defaultPriority) form.priority = defaultPriority.enumValue.id
      if (defaultStatus) form.status = defaultStatus.enumValue.id
    }
  }
})

// Watch for project changes to reload overrides
watch(() => form.projectId, async (newProjectId, oldProjectId) => {
  if (newProjectId && newProjectId !== oldProjectId) {
    await enumManagementStore.fetchProjectOverrides(newProjectId)
    await enumManagementStore.fetchProjectEnumSettings(newProjectId)
    
    // Reset enum selections when project changes
    form.type = ''
    form.priority = ''
    form.status = ''
    
    // Set defaults for the new project
    await nextTick()
    const defaultType = taskTypes.value.find(t => t.enumValue.isDefault)
    const defaultPriority = taskPriorities.value.find(p => p.enumValue.isDefault)
    const defaultStatus = taskStatuses.value.find(s => s.enumValue.isDefault)
    
    if (defaultType) form.type = defaultType.enumValue.id
    if (defaultPriority) form.priority = defaultPriority.enumValue.id
    if (defaultStatus) form.status = defaultStatus.enumValue.id
  }
})

// Methods
const resetForm = () => {
  Object.assign(form, defaultForm)
  error.value = ''
}

const closeModal = () => {
  emit('close')
}

const handleSubmit = async () => {
  loading.value = true
  error.value = ''

  try {
    if (isEdit.value && props.task) {
      // Task aktualisieren
      const updateData: UpdateTaskData = {
        title: form.title,
        description: form.description || undefined,
        typeId: form.type || undefined,
        priorityId: form.priority || undefined,
        statusId: form.status || undefined,
        assigneeId: form.assigneeId || undefined,
        dueDate: form.dueDate || undefined,
        estimatedHours: form.estimatedHours,
        remainingHours: form.remainingHours
      }
      
      emit('update', props.task.id, updateData)
    } else {
      // Neue Task erstellen
      const createData: CreateTaskData = {
        title: form.title,
        description: form.description || undefined,
        typeId: form.type || undefined,
        priorityId: form.priority || undefined,
        statusId: form.status || undefined,
        projectId: form.projectId,
        assigneeId: form.assigneeId || undefined,
        dueDate: form.dueDate || undefined,
        estimatedHours: form.estimatedHours,
        remainingHours: form.remainingHours
      }
      
      emit('create', createData)
    }
  } catch (err: any) {
    error.value = err.message || 'Ein Fehler ist aufgetreten'
  } finally {
    loading.value = false
  }
}
</script>
