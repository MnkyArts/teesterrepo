import type { Task } from '@prisma/client'
import type { TaskWithDetails, TaskFilters } from '../stores/tasks'
import type { KanbanColumn, KanbanBoard, KanbanFilters } from '../stores/kanban'

export const useKanban = (projectId?: string) => {
  const authStore = useAuthStore()
  const { isModuleEnabled } = useModules()
  
  // Conditional notification helper
  const addNotification = (notification: any) => {
    if (isModuleEnabled('notifications')) {
      const { addNotification: notify } = useNotifications()
      notify(notification)
    }
  }
  
  const { getTaskStatuses, ensureLoaded } = useDynamicEnums()

  // Alle verfügbaren Status für das Board
  const availableStatuses = computed(() => {
    const taskStatuses = getTaskStatuses(projectId)
    return taskStatuses
      .filter(status => status.isActive)
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .map(status => ({
        status: status.id,
        key: status.key,
        title: status.label,
        color: status.color || '#6b7280',
        order: status.sortOrder
      }))
  })

  // Kanban-Board erstellen
  const createKanbanBoard = (tasks: TaskWithDetails[], filters?: KanbanFilters): KanbanBoard => {
    const columns: KanbanColumn[] = availableStatuses.value.map(({ status, title, color, order }) => ({
      id: status,
      title,
      color,
      order,
      tasks: tasks.filter(task => task.statusId === status)
    }))

    return {
      columns,
      projectId: filters?.projectId,
      assigneeId: filters?.assigneeId
    }
  }

  // Tasks für Kanban-Board laden
  const fetchKanbanTasks = async (filters?: KanbanFilters): Promise<TaskWithDetails[]> => {
    try {
      const queryParams = new URLSearchParams()
      
      if (filters?.projectId) queryParams.append('projectId', filters.projectId)
      if (filters?.assigneeId) queryParams.append('assigneeId', filters.assigneeId)
      if (filters?.priority) queryParams.append('priority', filters.priority)
      if (filters?.type) queryParams.append('type', filters.type)
      if (filters?.search) queryParams.append('search', filters.search)

      const url = `/api/tasks${queryParams.toString() ? `?${queryParams.toString()}` : ''}`
      
      const response = await $fetch<{ tasks: TaskWithDetails[]; total: number }>(url, {
        
      })

      return response.tasks
    } catch (error) {
      console.error('Error fetching kanban tasks:', error)
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: 'Aufgaben konnten nicht geladen werden'
      })
      return []
    }
  }

  // Task-Status im Kanban-Board ändern
  const moveTaskToColumn = async (taskId: string, newStatusId: string): Promise<boolean> => {
    try {
      await $fetch(`/api/tasks/${taskId}`, {
        method: 'PUT',
        body: { statusId: newStatusId }
      })

      addNotification({
        type: 'success',
        title: 'Erfolg',
        message: 'Aufgabe wurde erfolgreich verschoben'
      })

      return true
    } catch (error) {
      console.error('Error moving task:', error)
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: 'Aufgabe konnte nicht verschoben werden'
      })
      return false
    }
  }

  // Task-Position innerhalb einer Spalte ändern (für zukünftige Sortierung)
  const reorderTaskInColumn = async (taskId: string, newPosition: number): Promise<boolean> => {
    try {
      // Hier könnte später eine Position/Order-Logik implementiert werden
      return true
    } catch (error) {
      console.error('Error reordering task:', error)
      return false
    }
  }

  // Statistiken für das Kanban-Board
  const getKanbanStats = (board: KanbanBoard) => {
    const totalTasks = board.columns.reduce((sum, col) => sum + col.tasks.length, 0)
    const completedTasks = board.columns
      .filter(col => ['ERLEDIGT', 'GESCHLOSSEN'].includes(col.id))
      .reduce((sum, col) => sum + col.tasks.length, 0)
    
    const inProgressTasks = board.columns
      .filter(col => ['IN_BEARBEITUNG', 'REVIEW', 'TESTING'].includes(col.id))
      .reduce((sum, col) => sum + col.tasks.length, 0)

    const plannedTasks = board.columns
      .filter(col => ['GEPLANT', 'TECHNISCHES_DESIGN'].includes(col.id))
      .reduce((sum, col) => sum + col.tasks.length, 0)

    return {
      totalTasks,
      completedTasks,
      inProgressTasks,
      plannedTasks,
      completionRate: totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0
    }
  }

  // Kanban-Board-Filter
  const getFilteredBoard = (board: KanbanBoard, searchTerm?: string) => {
    if (!searchTerm) return board

    const filteredColumns = board.columns.map(column => ({
      ...column,
      tasks: column.tasks.filter(task =>
        task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.project.key.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }))

    return {
      ...board,
      columns: filteredColumns
    }
  }

  return {
    availableStatuses,
    createKanbanBoard,
    fetchKanbanTasks,
    moveTaskToColumn,
    reorderTaskInColumn,
    getKanbanStats,
    getFilteredBoard
  }
}
