import { ref, computed, readonly } from 'vue'
import type { Task, TaskComment, User, Project } from '@prisma/client'
import type { 
  TaskWithDetails,
  TaskCommentWithAuthor,
  TaskFilters,
  TaskListResponse,
  CreateTaskData,
  UpdateTaskData
} from '../stores/tasks'

export const useTasks = () => {
  const { addNotification } = useNotifications()
  
  // State
  const tasks = ref<TaskWithDetails[]>([])
  const currentTask = ref<TaskWithDetails | null>(null)
  const loading = ref(false)
  const error = ref<string | null>(null)

  // Task-Liste abrufen
  const fetchTasks = async (filters: TaskFilters = {}, page = 1, limit = 20) => {
    loading.value = true
    error.value = null

    try {
      const query = new URLSearchParams()
      
      if (filters.projectId) query.append('projectId', filters.projectId)
      if (filters.assigneeId) query.append('assigneeId', filters.assigneeId)
      if (filters.statusId) {
        // Handle both single status and array of statuses
        if (Array.isArray(filters.statusId)) {
          filters.statusId.forEach((status: string) => query.append('statusId', status))
        } else {
          query.append('statusId', filters.statusId)
        }
      }
      if (filters.typeId) query.append('typeId', filters.typeId)
      if (filters.priorityId) query.append('priorityId', filters.priorityId)
      if (filters.search) query.append('search', filters.search)
      
      query.append('page', page.toString())
      query.append('limit', limit.toString())

      
      const response = await $fetch<TaskListResponse>(`/api/tasks?${query.toString()}`, {
        
      })
      
      if (page === 1) {
        tasks.value = response.tasks
      } else {
        tasks.value.push(...response.tasks)
      }

      return response
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Laden der Aufgaben'
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: error.value || 'Ein unbekannter Fehler ist aufgetreten'
      })
      throw err
    } finally {
      loading.value = false
    }
  }

  // Einzelne Task abrufen
  const fetchTask = async (taskId: string) => {
    loading.value = true
    error.value = null

    try {
      
      const task = await $fetch<TaskWithDetails>(`/api/tasks/${taskId}`, {
        
      })
      currentTask.value = task
      return task
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Laden der Aufgabe'
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: error.value || 'Ein unbekannter Fehler ist aufgetreten'
      })
      throw err
    } finally {
      loading.value = false
    }
  }

  // Task erstellen
  const createTask = async (taskData: CreateTaskData) => {
    loading.value = true
    error.value = null

    try {
      
      const newTask = await $fetch<TaskWithDetails>('/api/tasks', {
        method: 'POST',
        
        body: taskData
      })

      tasks.value.unshift(newTask)
      
      addNotification({
        type: 'success',
        title: 'Erfolg',
        message: 'Aufgabe erfolgreich erstellt'
      })

      return newTask
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Erstellen der Aufgabe'
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: error.value || 'Ein unbekannter Fehler ist aufgetreten'
      })
      throw err
    } finally {
      loading.value = false
    }
  }

  // Task aktualisieren
  const updateTask = async (taskId: string, taskData: UpdateTaskData) => {
    loading.value = true
    error.value = null

    try {
      
      const updatedTask = await $fetch<TaskWithDetails>(`/api/tasks/${taskId}`, {
        method: 'PUT',
        
        body: taskData
      })

      // Task in der Liste aktualisieren
      const index = tasks.value.findIndex((t: TaskWithDetails) => t.id === taskId)
      if (index !== -1) {
        tasks.value[index] = updatedTask
      }

      // Aktuelle Task aktualisieren falls sie geladen ist
      if (currentTask.value?.id === taskId) {
        currentTask.value = updatedTask
      }

      addNotification({
        type: 'success',
        title: 'Erfolg',
        message: 'Aufgabe erfolgreich aktualisiert'
      })

      return updatedTask
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Aktualisieren der Aufgabe'
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: error.value || 'Ein unbekannter Fehler ist aufgetreten'
      })
      throw err
    } finally {
      loading.value = false
    }
  }

  // Task löschen
  const deleteTask = async (taskId: string) => {
    loading.value = true
    error.value = null

    try {
      
      await $fetch(`/api/tasks/${taskId}`, {
        method: 'DELETE',
        
      })

      // Task aus der Liste entfernen
      tasks.value = tasks.value.filter((t: TaskWithDetails) => t.id !== taskId)

      // Aktuelle Task zurücksetzen falls sie gelöscht wurde
      if (currentTask.value?.id === taskId) {
        currentTask.value = null
      }

      addNotification({
        type: 'success',
        title: 'Erfolg',
        message: 'Aufgabe erfolgreich gelöscht'
      })

      return true
    } catch (err: any) {
      error.value = err.data?.message || 'Fehler beim Löschen der Aufgabe'
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: error.value || 'Ein unbekannter Fehler ist aufgetreten'
      })
      throw err
    } finally {
      loading.value = false
    }
  }

  // Kommentar hinzufügen
  const addComment = async (taskId: string, content: string, isInternal = false) => {
    try {
      
      const newComment = await $fetch<TaskCommentWithAuthor>(`/api/tasks/${taskId}/comments`, {
        method: 'POST',
        
        body: { content, isInternal }
      })

      // Kommentar zur aktuellen Task hinzufügen
      if (currentTask.value?.id === taskId && currentTask.value.comments) {
        currentTask.value.comments.push(newComment)
      }

      addNotification({
        type: 'success',
        title: 'Erfolg',
        message: 'Kommentar hinzugefügt'
      })

      return newComment
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Hinzufügen des Kommentars'
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: errorMessage
      })
      throw err
    }
  }

  // Kommentare laden
  const fetchComments = async (taskId: string) => {
    try {
      
      const comments = await $fetch<TaskCommentWithAuthor[]>(`/api/tasks/${taskId}/comments`, {
        
      })
      
      // Kommentare zur aktuellen Task hinzufügen
      if (currentTask.value?.id === taskId) {
        currentTask.value.comments = comments
      }

      return comments
    } catch (err: any) {
      const errorMessage = err.data?.message || 'Fehler beim Laden der Kommentare'
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: errorMessage
      })
      throw err
    }
  }

  // Utility-Funktionen
  const getTasksByProject = (projectId: string) => {
    return computed(() => tasks.value.filter((task: TaskWithDetails) => task.projectId === projectId))
  }

  const getTasksByAssignee = (assigneeId: string) => {
    return computed(() => tasks.value.filter((task: TaskWithDetails) => task.assigneeId === assigneeId))
  }

  const getTasksByStatus = (statusId: string) => {
    return computed(() => tasks.value.filter((task: TaskWithDetails) => task.statusId === statusId))
  }

  // Use dynamic enums instead of hardcoded values
  const { 
    taskStatusOptions, 
    taskTypeOptions, 
    priorityOptions 
  } = useDynamicEnums()

  return {
    // State
    tasks: readonly(tasks),
    currentTask: readonly(currentTask),
    loading: readonly(loading),
    error: readonly(error),

    // Actions
    fetchTasks,
    fetchTask,
    createTask,
    updateTask,
    deleteTask,
    addComment,
    fetchComments,

    // Computed
    getTasksByProject,
    getTasksByAssignee,
    getTasksByStatus,

    // Dynamic enum options
    taskStatuses: taskStatusOptions,
    taskTypes: taskTypeOptions,
    taskPriorities: priorityOptions
  }
}
