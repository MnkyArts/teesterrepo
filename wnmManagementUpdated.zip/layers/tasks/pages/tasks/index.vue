<template>
  <div class="space-y-6">
    <!-- Header -->
    <div class="md:flex md:items-center md:justify-between mb-8">
      <div class="min-w-0 flex-1">
        <h1 class="text-2xl font-bold leading-7 text-gray-900 dark:text-white sm:truncate sm:text-3xl sm:tracking-tight">
          Aufgaben
        </h1>
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Verwalten Sie alle Aufgaben Ihrer Projekte
        </p>
      </div>
      <div class="mt-4 flex md:ml-4 md:mt-0">
        <button
          @click="showCreateModal = true"
          type="button"
          class="inline-flex items-center rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600">
          <PlusIcon class="-ml-0.5 mr-1.5 h-5 w-5" aria-hidden="true" />
          Neue Aufgabe
        </button>
      </div>
    </div>

    <!-- Filter und Suche -->
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg mb-6">
      <div class="p-6">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <!-- Suche -->
          <div class="lg:col-span-2">
            <label for="search" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Suche
            </label>
            <div class="relative">
              <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <MagnifyingGlassIcon class="h-5 w-5 text-gray-400" />
              </div>
              <input
                id="search"
                v-model="filters.search"
                type="text"
                placeholder="Titel, Beschreibung oder Schlüssel suchen..."
                class="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md leading-5 bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500">
            </div>
          </div>

          <!-- Status Filter -->
          <div>
            <label for="status-filter" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Status
            </label>
            <select
              id="status-filter"
              v-model="filters.statusId"
              class="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="">Alle Status</option>
              <option v-for="status in taskStatuses" :key="status.value" :value="status.value">
                {{ status.label }}
              </option>
            </select>
          </div>

          <!-- Typ Filter -->
          <div>
            <label for="type-filter" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Typ
            </label>
            <select
              id="type-filter"
              v-model="filters.typeId"
              class="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="">Alle Typen</option>
              <option v-for="type in taskTypes" :key="type.value" :value="type.value">
                {{ type.label }}
              </option>
            </select>
          </div>

          <!-- Priorität Filter -->
          <div>
            <label for="priority-filter" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Priorität
            </label>
            <select
              id="priority-filter"
              v-model="filters.priorityId"
              class="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="">Alle Prioritäten</option>
              <option v-for="priority in taskPriorities" :key="priority.value" :value="priority.value">
                {{ priority.label }}
              </option>
            </select>
          </div>
        </div>

        <div class="mt-4 flex items-center justify-between">
          <div class="flex items-center space-x-4">
            <!-- Projekt Filter -->
            <div class="w-64">
              <label for="project-filter" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Projekt
              </label>
              <select
                id="project-filter"
                v-model="filters.projectId"
                class="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent w-full">
                <option value="">Alle Projekte</option>
                <option v-for="project in availableProjects" :key="project.id" :value="project.id">
                  {{ project.name }}
                </option>
              </select>
            </div>

            <!-- Assignee Filter -->
            <div class="w-64">
              <label for="assignee-filter" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Zugewiesen an
              </label>
              <select
                id="assignee-filter"
                v-model="filters.assigneeId"
                class="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent w-full">
                <option value="">Alle Benutzer</option>
                <option value="me">Mir zugewiesen</option>
                <option v-for="member in availableUsers" :key="member.id" :value="member.id">
                  {{ member.firstName }} {{ member.lastName }}
                </option>
              </select>
            </div>
          </div>

          <!-- Filter zurücksetzen -->
          <button
            @click="resetFilters"
            type="button"
            class="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
            Filter zurücksetzen
          </button>
        </div>
      </div>
    </div>

    <!-- Aufgabenliste -->
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg">
      <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
        <h2 class="text-lg font-medium text-gray-900 dark:text-white">
          Aufgaben ({{ totalTasks }})
        </h2>
      </div>

      <!-- Loading State -->
      <div v-if="loading && !tasks.length" class="p-6">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div v-for="i in 6" :key="i" class="animate-pulse">
            <div class="bg-gray-200 dark:bg-gray-700 rounded-lg h-48"></div>
          </div>
        </div>
      </div>

      <!-- Task Grid -->
      <div v-else-if="tasks.length > 0" class="p-6">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <TaskCard
            v-for="task in tasks"
            :key="task.id"
            :task="task as any"
            @click="viewTask" />
        </div>

        <!-- Load More Button -->
        <div v-if="hasMore" class="mt-6 text-center">
          <button
            @click="loadMore"
            :disabled="loading"
            class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed">
            <span v-if="loading">Wird geladen...</span>
            <span v-else>Weitere laden</span>
          </button>
        </div>
      </div>

      <!-- Empty State -->
      <div v-else class="p-12 text-center">
        <ClipboardDocumentListIcon class="mx-auto h-12 w-12 text-gray-400" />
        <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">Keine Aufgaben gefunden</h3>
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Keine Aufgaben entsprechen den aktuellen Filterkriterien.
        </p>
        <div class="mt-6">
          <button
            @click="showCreateModal = true"
            type="button"
            class="inline-flex items-center rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-blue-500">
            <PlusIcon class="-ml-0.5 mr-1.5 h-5 w-5" />
            Erste Aufgabe erstellen
          </button>
        </div>
      </div>
    </div>

    <!-- Task Modal -->
    <TaskModal
      :is-open="showCreateModal"
      :available-projects="availableProjects"
      :available-users="availableUsers"
      @close="showCreateModal = false"
      @create="handleCreateTask" />
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, watch, computed } from 'vue'
import { PlusIcon, MagnifyingGlassIcon, ClipboardDocumentListIcon } from '@heroicons/vue/24/outline'
import type { TaskWithDetails, TaskFilters, CreateTaskData } from '../../stores/tasks'

// Stores
const tasksStore = useTasksStore()
const { 
  tasks, 
  loading, 
  error,
  taskStatuses, 
  taskTypes, 
  taskPriorities 
} = storeToRefs(tasksStore)
const { 
  fetchTasks, 
  createTask
} = tasksStore

const projectsStore = useProjectsStore()
const { projects, userProjects } = storeToRefs(projectsStore)
const { fetchProjects } = projectsStore

const authStore = useAuthStore()
const { user } = storeToRefs(authStore)

const teamStore = useTeamManagementStore()
const { teamMembers } = storeToRefs(teamStore)
const { fetchTeamMembers } = teamStore

// Initialize enum store for proper badge display
const enumStore = useEnumManagementStore()
const { fetchCategoriesIfNeeded, initialize } = enumStore

const router = useRouter()

// State
const showCreateModal = ref(false)
const currentPage = ref(1)
const totalTasks = ref(0)
const hasMore = ref(false)

const filters = reactive<TaskFilters>({
  search: '',
  statusId: '',
  typeId: '',
  priorityId: '',
  projectId: '',
  assigneeId: ''
})

// Computed arrays for template usage
const availableProjects = computed(() => userProjects.value || [])
const availableUsers = computed(() => 
  (teamMembers.value || []).map(member => ({
    id: member.id,
    firstName: member.firstName,
    lastName: member.lastName
  }))
)

// Methods
const loadTasks = async (page = 1, append = false) => {
  const activeFilters = { ...filters }
  
  // "Mir zugewiesen" Filter behandeln
  if (activeFilters.assigneeId === 'me' && user.value) {
    activeFilters.assigneeId = user.value.id
  }

  // Remove empty string filters
  const filterKeys = Object.keys(activeFilters) as (keyof TaskFilters)[]
  filterKeys.forEach(key => {
    if (activeFilters[key] === '') {
      delete activeFilters[key]
    }
  })

  const response = await fetchTasks(activeFilters, page, 12)
  
  if (!append) {
    currentPage.value = 1
  }
  
  totalTasks.value = response.total
  hasMore.value = response.hasNext
}

const loadMore = async () => {
  currentPage.value++
  await loadTasks(currentPage.value, true)
}

const resetFilters = () => {
  Object.assign(filters, {
    search: '',
    statusId: '',
    typeId: '',
    priorityId: '',
    projectId: '',
    assigneeId: ''
  })
}

const viewTask = (task: TaskWithDetails) => {
  router.push(`/tasks/${task.id}`)
}

const handleCreateTask = async (data: CreateTaskData) => {
  try {
    await createTask(data)
    showCreateModal.value = false
    await loadTasks() // Liste neu laden
  } catch (error) {
    console.error('Error creating task:', error)
  }
}

// Watchers
let debounceTimer: NodeJS.Timeout | null = null

watch(filters, () => {
  if (debounceTimer) {
    clearTimeout(debounceTimer)
  }
  
  debounceTimer = setTimeout(() => {
    loadTasks()
  }, 300)
}, { deep: true })

// Lifecycle
onMounted(async () => {
  // Initialize enum store first to ensure badge values are available
  await initialize()
  
  // Load initial data
  await Promise.all([
    fetchProjects(),
    fetchTeamMembers(),
    loadTasks()
  ])
})

// Meta
definePageMeta({
  layout: 'default'
})

// SEO
useHead({
  title: 'Aufgaben - wenoma',
  meta: [
    {
      name: 'description',
      content: 'Verwalten Sie alle Aufgaben Ihrer Projekte effizient und transparent.'
    }
  ]
})
</script>
