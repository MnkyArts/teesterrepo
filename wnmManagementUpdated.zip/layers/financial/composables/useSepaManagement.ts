// Types
interface SepaMandate {
  id: string
  isActive: boolean
  createdAt: string
  updatedAt: string
  validUntil: string | null
  mandateId: string
  iban: string
  bic: string | null
  accountHolder: string
  signedDate: string
  customerId: string
}

interface SepaMandateData {
  iban: string
  bic?: string
  accountHolder: string
  validUntil?: string
}

export const useSepaManagement = () => {
  const { addNotification } = useNotifications()
  

  // State
  const mandate = ref<SepaMandate | null>(null)
  const loading = ref(false)
  const hasActiveMandate = ref(false)

  // SEPA Mandate laden
  const loadMandate = async () => {
    try {
      loading.value = true
      
      
      const response = await $fetch('/api/customer/sepa/mandate')
      
      mandate.value = response.mandate
      hasActiveMandate.value = response.hasActiveMandate
      
    } catch (error) {
      console.error('Failed to load SEPA mandate:', error)
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: 'SEPA-Mandat konnte nicht geladen werden.'
      })
    } finally {
      loading.value = false
    }
  }

  // SEPA Mandate erstellen oder aktualisieren
  const saveMandate = async (mandateData: SepaMandateData) => {
    try {
      loading.value = true
      
      
      const response = await $fetch<{ mandate: SepaMandate; message: string }>('/api/customer/sepa/mandate', {
        method: 'POST',
        body: mandateData
      })
      
      mandate.value = response.mandate
      hasActiveMandate.value = response.mandate?.isActive || false
      
      addNotification({
        type: 'success',
        title: 'Erfolg',
        message: response.message
      })
      
      return response.mandate
      
    } catch (error: any) {
      console.error('Failed to save SEPA mandate:', error)
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: error.data?.message || 'SEPA-Mandat konnte nicht gespeichert werden.'
      })
      throw error
    } finally {
      loading.value = false
    }
  }

  // SEPA Mandate widerrufen
  const revokeMandate = async () => {
    try {
      loading.value = true
      
      
      const response = await $fetch<{ mandate: SepaMandate; message: string }>('/api/customer/sepa/mandate', {
        method: 'DELETE'
      })
      
      mandate.value = response.mandate
      hasActiveMandate.value = false
      
      addNotification({
        type: 'success',
        title: 'Erfolg',
        message: response.message
      })
      
      return response.mandate
      
    } catch (error: any) {
      console.error('Failed to revoke SEPA mandate:', error)
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: error.data?.message || 'SEPA-Mandat konnte nicht widerrufen werden.'
      })
      throw error
    } finally {
      loading.value = false
    }
  }

  // IBAN formatieren (Leerzeichen alle 4 Zeichen)
  const formatIban = (iban: string) => {
    if (!iban) return ''
    const cleanIban = iban.toUpperCase().replace(/\s/g, '')
    return cleanIban.match(/.{1,4}/g)?.join(' ') || cleanIban
  }

  // IBAN validieren (einfache Frontend-Validierung)
  const validateIban = (iban: string) => {
    if (!iban) return false
    const cleanIban = iban.toUpperCase().replace(/\s/g, '')
    
    // Grundlegende Format-Prüfung
    if (!/^[A-Z]{2}[0-9]{2}[A-Z0-9]+$/.test(cleanIban)) {
      return false
    }
    
    // Deutsche IBAN sollte 22 Zeichen haben
    if (cleanIban.startsWith('DE') && cleanIban.length !== 22) {
      return false
    }
    
    return true
  }

  // BIC validieren
  const validateBic = (bic: string) => {
    if (!bic) return true // BIC ist optional
    return /^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/.test(bic.toUpperCase())
  }

  // Anonymisierte IBAN für Anzeige
  const getAnonymizedIban = (iban: string) => {
    if (!iban) return ''
    const cleanIban = iban.replace(/\s/g, '')
    if (cleanIban.length < 8) return iban
    
    const start = cleanIban.substring(0, 8)
    const end = cleanIban.substring(cleanIban.length - 4)
    const middle = '*'.repeat(cleanIban.length - 12)
    
    return formatIban(start + middle + end)
  }

  // Mandate Status prüfen
  const isMandateActive = computed(() => {
    if (!mandate.value) return false
    if (!mandate.value.isActive) return false
    if (mandate.value.validUntil) {
      return new Date(mandate.value.validUntil) > new Date()
    }
    return true
  })

  // Mandate Gültigkeitsdauer prüfen
  const isExpiringSoon = computed(() => {
    if (!mandate.value || !mandate.value.validUntil) return false
    
    const validUntil = new Date(mandate.value.validUntil)
    const thirtyDaysFromNow = new Date()
    thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30)
    
    return validUntil < thirtyDaysFromNow && validUntil > new Date()
  })

  // Datum formatieren
  const formatDate = (date: string | Date) => {
    if (!date) return ''
    return new Date(date).toLocaleDateString('de-DE', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    })
  }

  return {
    // State
    mandate,
    loading,
    hasActiveMandate,
    
    // Computed
    isMandateActive,
    isExpiringSoon,
    
    // Methods
    loadMandate,
    saveMandate,
    revokeMandate,
    formatIban,
    validateIban,
    validateBic,
    getAnonymizedIban,
    formatDate
  }
}
