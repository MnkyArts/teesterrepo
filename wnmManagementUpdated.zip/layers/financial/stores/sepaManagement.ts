import { defineStore } from 'pinia'

// Types
interface SepaMandate {
  id: string
  isActive: boolean
  createdAt: string
  updatedAt: string
  validUntil: string | null
  mandateId: string
  iban: string
  bic: string | null
  accountHolder: string
  signedDate: string
  customerId: string
}

interface SepaMandateData {
  iban: string
  bic?: string
  accountHolder: string
  validUntil?: string
}

export const useSepaManagementStore = defineStore('sepaManagement', () => {
  const notificationsStore = useNotificationsStore()

  // State
  const mandate = ref<SepaMandate | null>(null)
  const loading = ref(false)
  const hasActiveMandate = ref(false)

  // SEPA Mandate laden
  const loadMandate = async () => {
    loading.value = true
    try {
      const data = await $fetch<{ mandate: SepaMandate|null, hasActiveMandate: boolean }>('/api/customer/sepa/mandate')
      mandate.value = data.mandate
      hasActiveMandate.value = data.hasActiveMandate
    } catch (error) {
      console.error('Error loading SEPA mandate:', error)
      hasActiveMandate.value = false
    } finally {
      loading.value = false
    }
  }

  // SEPA Mandate erstellen oder aktualisieren
  const saveMandate = async (mandateData: SepaMandateData) => {
    loading.value = true
    try {
      const data = await $fetch<SepaMandate>('/api/customer/sepa/mandate', {
        method: 'POST',
        body: mandateData
      })
      
      mandate.value = data
      hasActiveMandate.value = data.isActive
      
      notificationsStore.success('Erfolg', 'SEPA-Mandat wurde erfolgreich gespeichert')
      
      return data
    } catch (error: any) {
      console.error('Error saving SEPA mandate:', error)
      notificationsStore.error('Fehler', error.data?.message || 'SEPA-Mandat konnte nicht gespeichert werden')
      throw error
    } finally {
      loading.value = false
    }
  }

  // SEPA Mandate widerrufen
  const revokeMandate = async () => {
    loading.value = true
    try {
      await $fetch('/api/customer/sepa/mandate', {
        method: 'DELETE'
      })
      
      mandate.value = null
      hasActiveMandate.value = false
      
      notificationsStore.success('Erfolg', 'SEPA-Mandat wurde erfolgreich widerrufen')
    } catch (error: any) {
      console.error('Error revoking SEPA mandate:', error)
      notificationsStore.error('Fehler', error.data?.message || 'SEPA-Mandat konnte nicht widerrufen werden')
      throw error
    } finally {
      loading.value = false
    }
  }

  // IBAN formatieren (Leerzeichen alle 4 Zeichen)
  const formatIban = (iban: string) => {
    if (!iban) return ''
    const cleanIban = iban.toUpperCase().replace(/\s/g, '')
    return cleanIban.match(/.{1,4}/g)?.join(' ') || cleanIban
  }

  // IBAN validieren (einfache Frontend-Validierung)
  const validateIban = (iban: string) => {
    if (!iban) return false
    const cleanIban = iban.toUpperCase().replace(/\s/g, '')
    
    // Grundlegende Format-Prüfung
    if (!/^[A-Z]{2}[0-9]{2}[A-Z0-9]+$/.test(cleanIban)) {
      return false
    }
    
    // Deutsche IBAN sollte 22 Zeichen haben
    if (cleanIban.startsWith('DE') && cleanIban.length !== 22) {
      return false
    }
    
    return true
  }

  // BIC validieren
  const validateBic = (bic: string) => {
    if (!bic) return true // BIC ist optional
    const cleanBic = bic.toUpperCase().replace(/\s/g, '')
    
    // BIC Format: 8 oder 11 Zeichen
    return /^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/.test(cleanBic)
  }

  // Anonymisierte IBAN für Anzeige
  const getAnonymizedIban = (iban: string) => {
    if (!iban) return ''
    const cleanIban = iban.replace(/\s/g, '')
    if (cleanIban.length < 8) return iban
    
    const start = cleanIban.substring(0, 4)
    const end = cleanIban.substring(cleanIban.length - 4)
    const middle = '*'.repeat(cleanIban.length - 8)
    
    return formatIban(start + middle + end)
  }

  // Mandate Status prüfen
  const isMandateActive = computed(() => {
    if (!mandate.value) return false
    if (!mandate.value.isActive) return false
    
    // Prüfen ob Mandat noch gültig ist
    if (mandate.value.validUntil) {
      const validUntil = new Date(mandate.value.validUntil)
      const now = new Date()
      return validUntil > now
    }
    
    return true
  })

  // Mandate Gültigkeitsdauer prüfen
  const isExpiringSoon = computed(() => {
    if (!mandate.value?.validUntil) return false
    
    const validUntil = new Date(mandate.value.validUntil)
    const now = new Date()
    const daysUntilExpiry = Math.ceil((validUntil.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
    
    return daysUntilExpiry <= 30 && daysUntilExpiry > 0
  })

  // Datum formatieren
  const formatDate = (date: string | Date) => {
    if (!date) return ''
    const d = new Date(date)
    return d.toLocaleDateString('de-DE', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })
  }

  return {
    // State
    mandate: readonly(mandate),
    loading: readonly(loading),
    hasActiveMandate: readonly(hasActiveMandate),
    
    // Computed
    isMandateActive,
    isExpiringSoon,
    
    // Actions
    loadMandate,
    saveMandate,
    revokeMandate,
    
    // Utilities
    formatIban,
    validateIban,
    validateBic,
    getAnonymizedIban,
    formatDate
  }
})
