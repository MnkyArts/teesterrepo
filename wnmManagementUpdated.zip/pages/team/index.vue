<template>
  <div class="space-y-6">
    <!-- Header mit Titel und Aktionen -->
    <div class="flex items-center justify-between">
      <div>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
          {{ $t('navigation.team') }}
        </h1>
        <p class="text-gray-600 dark:text-gray-400">
          Team-Management mit Skills und erweiterten Funktionen
        </p>
      </div>
      
      <div class="flex items-center space-x-3">
        <NuxtLink
          to="/team/enhanced"
          class="inline-flex items-center px-3 py-2 border border-primary-600 text-primary-600 dark:text-primary-400 text-sm font-medium rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900 transition-colors"
        >
          <AcademicCapIcon class="h-4 w-4 mr-2" />
          Erweiterte Ansicht
        </NuxtLink>
        
        <button
          v-if="canCreateUsers"
          @click="showCreateModal = true"
          class="inline-flex items-center px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white text-sm font-medium rounded-lg transition-colors"
        >
          <PlusIcon class="h-4 w-4 mr-2" />
          Benutzer hinzufügen
        </button>
        
        <button
          @click="refreshData"
          :disabled="loading"
          class="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 text-sm font-medium rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
        >
          <ArrowPathIcon class="h-4 w-4 mr-2" :class="{ 'animate-spin': loading }" />
          Aktualisieren
        </button>
      </div>
    </div>

    <!-- Team Statistiken -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
      <StatCard
        title="Gesamt Team"
        :value="statistics?.totalMembers || 0"
        icon="users"
        color="blue"
      />
      <StatCard
        title="Aktive Mitglieder"
        :value="statistics?.activeMembers || 0"
        icon="user-check"
        color="green"
      />
      <StatCard
        title="Online"
        :value="statistics?.onlineMembers || 0"
        icon="signal"
        color="green"
      />
      <StatCard
        title="Ø Arbeitsbelastung"
        :value="`${statistics?.averageWorkload || 0} Tasks`"
        icon="chart-bar"
        color="orange"
      />
    </div>

    <!-- Filter und Suche -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Suche
          </label>
          <input
            v-model="filters.search"
            type="text"
            placeholder="Name oder E-Mail..."
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
            @input="debouncedSearch"
          />
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Rolle
          </label>
          <select
            v-model="filters.role"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
            @change="loadTeamMembers"
          >
            <option value="">Alle Rollen</option>
            <option
              v-for="role in userRoles"
              :key="role.value"
              :value="role.value"
            >
              {{ role.label }}
            </option>
          </select>
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Status
          </label>
          <select
            v-model="filters.isActive"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
            @change="loadTeamMembers"
          >
            <option value="">Alle Status</option>
            <option :value="true">Aktiv</option>
            <option :value="false">Inaktiv</option>
          </select>
        </div>
        
        <div class="flex items-end">
          <button
            @click="clearFilters"
            class="px-4 py-2 text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
          >
            Filter zurücksetzen
          </button>
        </div>
      </div>
    </div>

    <!-- Team-Mitglieder Liste -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
      <!-- Loading State -->
      <div v-if="loading" class="p-8 text-center">
        <div class="inline-flex items-center">
          <ArrowPathIcon class="animate-spin h-5 w-5 mr-3 text-gray-500" />
          Lade Team-Mitglieder...
        </div>
      </div>

      <!-- Team-Mitglieder Grid -->
      <div v-else-if="teamMembers.length > 0" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
        <TeamMemberCard
          v-for="member in teamMembers"
          :key="member.id"
          :member="member"
          :can-edit="canEditUser(member)"
          @edit="editUser"
          @toggle-status="toggleUserStatus"
          @view="viewUser"
        />
      </div>

      <!-- Empty State -->
      <div v-else class="p-8 text-center">
        <UsersIcon class="mx-auto h-12 w-12 text-gray-400" />
        <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">
          Keine Team-Mitglieder gefunden
        </h3>
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Passen Sie Ihre Filter an oder fügen Sie neue Benutzer hinzu.
        </p>
      </div>
    </div>

    <!-- Create User Modal -->
    <UserModal
      v-if="showCreateModal"
      :is-open="showCreateModal"
      @close="showCreateModal = false"
      @created="handleUserCreated"
    />

    <!-- Edit User Modal -->
    <UserModal
      v-if="showEditModal && editingUser"
      :is-open="showEditModal"
      :user="editingUser"
      @close="showEditModal = false"
      @updated="handleUserUpdated"
    />

    <!-- User Detail Modal -->
    <UserDetailModal
      v-if="showDetailModal && viewingUser"
      :is-open="showDetailModal"
      :user="viewingUser"
      @close="showDetailModal = false"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, reactive } from 'vue'
import { PlusIcon, ArrowPathIcon, UsersIcon, AcademicCapIcon } from '@heroicons/vue/24/outline'
import { useDebounceFn } from '@vueuse/core'
import type { UserRole } from '@prisma/client'

// Page Meta
definePageMeta({
  middleware: 'staff',
  layout: 'default'
})

// Stores
const authStore = useAuthStore()
const { user } = storeToRefs(authStore)
const { hasPermission } = authStore

const teamStore = useTeamManagementStore()
const {
  teamMembers,
  loading,
  userRoles
} = storeToRefs(teamStore)
const {
  fetchTeamMembers,
  fetchTeamStatistics,
  updateUser
} = teamStore

// State
const statistics = ref<any>(null)
const showCreateModal = ref(false)
const showEditModal = ref(false)
const showDetailModal = ref(false)
const editingUser = ref(null)
const viewingUser = ref(null)

// Filters
const filters = reactive({
  search: '',
  role: '',
  isActive: '',
  availability: ''
})

// Computed
const canCreateUsers = computed(() => 
  hasPermission('PROJEKTLEITER')
)

const canEditUser = (targetUser: any) => {
  if (!user.value) return false
  
  // Admins können alle bearbeiten
  if (user.value.role === 'ADMINISTRATOR') return true
  
  // Projektleiter können alle außer andere Admins bearbeiten
  if (user.value.role === 'PROJEKTLEITER' && targetUser.role !== 'ADMINISTRATOR') return true
  
  // Benutzer können sich selbst bearbeiten
  if (user.value.id === targetUser.id) return true
  
  return false
}

// Methods
const loadTeamMembers = async () => {
  const filterParams = {
    search: filters.search || undefined,
    role: filters.role as UserRole || undefined,
    isActive: filters.isActive !== '' ? filters.isActive === 'true' : undefined
  }
  
  await fetchTeamMembers(filterParams)
}

const loadStatistics = async () => {
  try {
    statistics.value = await fetchTeamStatistics()
  } catch (error) {
    console.error('Fehler beim Laden der Team-Statistiken:', error)
  }
}

const refreshData = async () => {
  await Promise.all([
    loadTeamMembers(),
    loadStatistics()
  ])
}

const debouncedSearch = useDebounceFn(() => {
  loadTeamMembers()
}, 300)

const clearFilters = () => {
  filters.search = ''
  filters.role = ''
  filters.isActive = ''
  filters.availability = ''
  loadTeamMembers()
}

const editUser = (member: any) => {
  editingUser.value = member
  showEditModal.value = true
}

const viewUser = (member: any) => {
  viewingUser.value = member
  showDetailModal.value = true
}

const toggleUserStatus = async (member: any) => {
  try {
    await updateUser(member.id, { isActive: !member.isActive })
    await loadTeamMembers()
  } catch (error) {
    console.error('Fehler beim Ändern des Benutzer-Status:', error)
  }
}

const handleUserCreated = () => {
  showCreateModal.value = false
  refreshData()
}

const handleUserUpdated = () => {
  showEditModal.value = false
  editingUser.value = null
  refreshData()
}

// Lifecycle
onMounted(() => {
  refreshData()
})
</script>
