<template>
  <div class="space-y-6">
    <!-- Header mit erweiterten Aktionen -->
    <div class="flex items-center justify-between">
      <div>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
          {{ $t('navigation.team') }}
        </h1>
        <p class="text-gray-600 dark:text-gray-400">
          Team-Management mit erweiterten Skills und Bulk-Aktionen
        </p>
      </div>
      
      <div class="flex items-center space-x-3">
        <button
          v-if="canCreateUsers"
          @click="showCreateModal = true"
          class="inline-flex items-center px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white text-sm font-medium rounded-lg transition-colors"
        >
          <PlusIcon class="h-4 w-4 mr-2" />
          Benutzer hinzufügen
        </button>
        
        <button
          @click="refreshData"
          :disabled="loading"
          class="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 text-sm font-medium rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
        >
          <ArrowPathIcon class="h-4 w-4 mr-2" :class="{ 'animate-spin': loading }" />
          Aktualisieren
        </button>
      </div>
    </div>

    <!-- Team Statistiken (erweitert) -->
    <div class="grid grid-cols-1 md:grid-cols-5 gap-6">
      <StatCard
        title="Gesamt Team"
        :value="statistics?.totalMembers || 0"
        icon="users"
        color="blue"
      />
      <StatCard
        title="Aktive Mitglieder"
        :value="statistics?.activeMembers || 0"
        icon="user-check"
        color="green"
      />
      <StatCard
        title="Skills Gesamt"
        :value="statistics?.totalSkills || 0"
        icon="academic-cap"
        color="purple"
      />
      <StatCard
        title="Verifizierungsrate"
        :value="`${(statistics?.verificationRate || 0).toFixed(0)}%`"
        icon="check-badge"
        color="green"
      />
      <StatCard
        title="Ø Skills/Person"
        :value="(statistics?.averageSkillsPerMember || 0).toFixed(1)"
        icon="chart-bar"
        color="orange"
      />
    </div>

    <!-- View Switcher -->
    <div class="flex space-x-1 bg-gray-100 dark:bg-gray-800 p-1 rounded-lg w-fit">
      <button
        v-for="view in views"
        :key="view.value"
        @click="currentView = view.value"
        :class="[
          'px-4 py-2 text-sm font-medium rounded-md transition-all flex items-center space-x-2',
          currentView === view.value
            ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
            : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
        ]"
      >
        <component :is="view.icon" class="h-4 w-4" />
        <span>{{ view.label }}</span>
      </button>
    </div>

    <!-- Team Liste View -->
    <div v-if="currentView === 'list'" class="space-y-6">
      <!-- Filter und Suche -->
      <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
          <!-- Suche -->
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Suche
            </label>
            <input
              v-model="filters.search"
              @input="debouncedSearch"
              type="text"
              placeholder="Name oder E-Mail..."
              class="w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary-500 focus:ring-primary-500 dark:bg-gray-700 dark:text-white text-sm"
            >
          </div>

          <!-- Rolle Filter -->
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Rolle
            </label>
            <select
              v-model="filters.role"
              @change="loadTeamMembers"
              class="w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary-500 focus:ring-primary-500 dark:bg-gray-700 dark:text-white text-sm"
            >
              <option value="">Alle Rollen</option>
              <option
                v-for="role in userRoles.filter(r => r.value !== 'KUNDE')"
                :key="role.value"
                :value="role.value"
              >
                {{ role.label }}
              </option>
            </select>
          </div>

          <!-- Status Filter -->
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Status
            </label>
            <select
              v-model="filters.isActive"
              @change="loadTeamMembers"
              class="w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-primary-500 focus:ring-primary-500 dark:bg-gray-700 dark:text-white text-sm"
            >
              <option value="">Alle Status</option>
              <option value="true">Aktiv</option>
              <option value="false">Inaktiv</option>
            </select>
          </div>

          <!-- Aktionen -->
          <div class="flex items-end space-x-2">
            <button
              @click="clearFilters"
              class="px-3 py-2 text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              Filter zurücksetzen
            </button>
          </div>
        </div>
      </div>

      <!-- Bulk Actions (wenn Benutzer ausgewählt) -->
      <TeamBulkActions
        v-if="canBulkActions && selectedUsers?.length > 0"
        :users="teamMembers as any || []"
        v-model:selected-user-ids="selectedUsers"
        @bulk-action-executed="handleBulkActionExecuted"
      />

      <!-- Team Member Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <EnhancedTeamMemberCard
          v-for="member in (teamMembers || [])"
          :key="member.id"
          :member="member as any"
          :selectable="canBulkActions"
          :is-selected="selectedUsers?.includes(member.id) || false"
          @selection-changed="handleMemberSelection"
          @view-details="viewMemberDetails"
          @edit-user="editMember"
          @toggle-status="toggleMemberStatus"
          @open-skill-modal="openSkillModal"
          @skill-verified="handleSkillVerified"
        />
      </div>

      <!-- Empty State -->
      <div v-if="!loading && (teamMembers?.length === 0)" class="text-center py-12">
        <UsersIcon class="mx-auto h-12 w-12 text-gray-400" />
        <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">
          Keine Team-Mitglieder gefunden
        </h3>
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Passen Sie Ihre Filter an oder fügen Sie neue Mitglieder hinzu.
        </p>
      </div>
    </div>

    <!-- Skill Matrix View -->
    <SkillMatrixOverview v-else-if="currentView === 'skills'" />

    <!-- Modals -->
    <UserModal
      v-if="showCreateModal"
      :is-open="showCreateModal"
      @close="showCreateModal = false"
      @created="handleUserCreated"
    />

    <UserModal
      v-if="showEditModal && editingUser"
      :is-open="showEditModal"
      :user="editingUser"
      @close="showEditModal = false"
      @updated="handleUserUpdated"
    />

    <UserDetailModal
      v-if="showDetailModal && viewingUser"
      :is-open="showDetailModal"
      :user="viewingUser"
      @close="showDetailModal = false"
      @open-skill-modal="handleSkillModalFromDetail"
    />

    <SkillModal
      v-if="showSkillModal && skillUser"
      :is-open="showSkillModal"
      :user-id="skillUser.id"
      @close="showSkillModal = false"
      @saved="handleSkillsUpdated"
    />
  </div>
</template>

<script setup lang="ts">
import { 
  PlusIcon, 
  ArrowPathIcon,
  UsersIcon,
  TableCellsIcon,
  AcademicCapIcon
} from '@heroicons/vue/24/outline'
import { useDebounceFn } from '@vueuse/core'
import type { UserRole } from '@prisma/client'

// Stores
const authStore = useAuthStore()
const { user } = storeToRefs(authStore)
const { hasPermission } = authStore

const teamStore = useTeamManagementStore()
const {
  teamMembers,
  loading,
  userRoles
} = storeToRefs(teamStore)
const {
  fetchTeamMembers,
  fetchTeamStatistics,
  updateUser,
  toggleUserSelection,
  clearUserSelection,
  selectedUsers // Access directly from store for v-model compatibility
} = teamStore

// State
const statistics = ref<any>(null)
const currentView = ref('list')
const showCreateModal = ref(false)
const showEditModal = ref(false)
const showDetailModal = ref(false)
const showSkillModal = ref(false)
const editingUser = ref<any>(null)
const viewingUser = ref<any>(null)
const skillUser = ref<any>(null)

// Views configuration
const views = [
  { value: 'list', label: 'Team Liste', icon: UsersIcon },
  { value: 'skills', label: 'Skill Matrix', icon: AcademicCapIcon }
]

// Filters
const filters = reactive({
  search: '',
  role: '',
  isActive: ''
})

// Computed
const canCreateUsers = computed(() => hasPermission('PROJEKTLEITER'))
const canBulkActions = computed(() => hasPermission('ADMINISTRATOR'))

// Methods
const loadTeamMembers = async () => {
  const filterParams = {
    search: filters.search || undefined,
    role: filters.role as UserRole || undefined,
    isActive: filters.isActive !== '' ? filters.isActive === 'true' : undefined
  }
  
  await fetchTeamMembers(filterParams)
}

const loadStatistics = async () => {
  try {
    const stats = await fetchTeamStatistics()
    statistics.value = stats
  } catch (error) {
    console.error('Fehler beim Laden der Team-Statistiken:', error)
  }
}

const refreshData = async () => {
  await Promise.all([
    loadTeamMembers(),
    loadStatistics()
  ])
}

const debouncedSearch = useDebounceFn(() => {
  loadTeamMembers()
}, 300)

const clearFilters = () => {
  filters.search = ''
  filters.role = ''
  filters.isActive = ''
  loadTeamMembers()
}

const handleMemberSelection = (userId: string, selected: boolean) => {
  toggleUserSelection(userId)
}

const handleBulkActionExecuted = () => {
  clearUserSelection()
  refreshData()
}

const viewMemberDetails = (member: any) => {
  viewingUser.value = member
  showDetailModal.value = true
}

const editMember = (member: any) => {
  editingUser.value = member
  showEditModal.value = true
}

const toggleMemberStatus = async (member: any) => {
  try {
    await updateUser(member.id, { isActive: !member.isActive })
    await loadTeamMembers()
  } catch (error) {
    console.error('Fehler beim Ändern des Benutzer-Status:', error)
  }
}

const openSkillModal = (member: any) => {
  skillUser.value = member
  showSkillModal.value = true
}

const handleSkillVerified = () => {
  // Refresh data to get updated verification status
  refreshData()
}

const handleUserCreated = () => {
  showCreateModal.value = false
  refreshData()
}

const handleUserUpdated = () => {
  showEditModal.value = false
  editingUser.value = null
  refreshData()
}

const handleSkillsUpdated = () => {
  showSkillModal.value = false
  skillUser.value = null
  refreshData()
  
  // Also refresh the user detail modal if it's open
  if (showDetailModal.value && viewingUser.value) {
    // Find updated user data
    const updatedUser = teamMembers.value.find((member: any) => member.id === viewingUser.value?.id)
    if (updatedUser) {
      viewingUser.value = updatedUser
    }
  }
}

const handleSkillModalFromDetail = (userId: string, skills: any[]) => {
  // Find the user object for the skill modal
  const user = teamMembers.value.find((member: any) => member.id === userId)
  if (user) {
    skillUser.value = user
    showSkillModal.value = true
  }
}

// Lifecycle
onMounted(() => {
  refreshData()
})

// Page Meta
definePageMeta({
  middleware: 'staff',
  layout: 'default'
})
</script>
