<template>
    <div>
      <!-- Header -->
      <div class="mb-8">
        <div class="flex items-center space-x-4 mb-4">
          <NuxtLink
            to="/customer/tickets"
            class="inline-flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
          >
            <Icon name="heroicons:arrow-left" class="w-4 h-4 mr-2" />
            Zurück zu Tickets
          </NuxtLink>
        </div>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
          {{ $t('tickets.newTicket') }}
        </h1>
        <p class="text-gray-600 dark:text-gray-400">
          Erstellen Sie eine neue Support-Anfrage. Unser Team wird sich so schnell wie möglich darum kümmern.
        </p>
      </div>

      <!-- Form -->
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <form @submit.prevent="submitTicket" class="p-6 space-y-6">
          <!-- Title -->
          <div>
            <label for="title" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('tickets.subject') }} <span class="text-red-500">*</span>
            </label>
            <input
              id="title"
              v-model="form.title"
              type="text"
              required
              placeholder="Kurze, aussagekräftige Beschreibung des Problems"
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
              :class="{ 'border-red-500': errors.title }"
            >
            <p v-if="errors.title" class="mt-1 text-sm text-red-600 dark:text-red-400">
              {{ errors.title }}
            </p>
          </div>

          <!-- Department -->
          <div>
            <label for="department" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('tickets.department') }} <span class="text-red-500">*</span>
            </label>
            <select
              id="department"
              v-model="form.department"
              required
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
              :class="{ 'border-red-500': errors.department }"
            >
              <option value="">Abteilung auswählen...</option>
              <option value="Support">{{ $t('tickets.departments.Support') }}</option>
              <option value="Buchhaltung">{{ $t('tickets.departments.Buchhaltung') }}</option>
              <option value="Entwicklung">{{ $t('tickets.departments.Entwicklung') }}</option>
              <option value="Vertrieb">{{ $t('tickets.departments.Vertrieb') }}</option>
              <option value="Allgemein">{{ $t('tickets.departments.Allgemein') }}</option>
            </select>
            <p v-if="errors.department" class="mt-1 text-sm text-red-600 dark:text-red-400">
              {{ errors.department }}
            </p>
            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Wählen Sie die passende Abteilung für Ihre Anfrage aus, damit wir sie an das richtige Team weiterleiten können.
            </p>
          </div>

          <!-- Priority -->
          <div>
            <label for="priority" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('tickets.priority') }}
            </label>
            <select
              id="priority"
              v-model="form.priority"
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            >
              <option value="NIEDRIG">{{ $t('common.priority.niedrig') }}</option>
              <option value="NORMAL">{{ $t('common.priority.normal') }}</option>
              <option value="HOCH">{{ $t('common.priority.hoch') }}</option>
              <option value="KRITISCH">{{ $t('common.priority.kritisch') }}</option>
            </select>
            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Bitte wählen Sie die Priorität entsprechend der Dringlichkeit Ihrer Anfrage.
            </p>
          </div>

          <!-- Description -->
          <div>
            <label for="description" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('tickets.description') }} <span class="text-red-500">*</span>
            </label>
            <textarea
              id="description"
              v-model="form.description"
              required
              rows="6"
              placeholder="Beschreiben Sie Ihr Anliegen so detailliert wie möglich. Fügen Sie relevante Informationen hinzu, wie z.B. Fehlermeldungen, Screenshots oder Schritte zur Reproduktion des Problems."
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white resize-none"
              :class="{ 'border-red-500': errors.description }"
            ></textarea>
            <p v-if="errors.description" class="mt-1 text-sm text-red-600 dark:text-red-400">
              {{ errors.description }}
            </p>
            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Je detaillierter Ihre Beschreibung, desto schneller können wir Ihnen helfen.
            </p>
          </div>

          <!-- Tips Section -->
          <div class="bg-blue-50 dark:bg-blue-900/50 border border-blue-200 dark:border-blue-800 rounded-md p-4">
            <div class="flex">
              <div class="flex-shrink-0">
                <Icon name="heroicons:information-circle" class="w-5 h-5 text-blue-400" />
              </div>
              <div class="ml-3">
                <h3 class="text-sm font-medium text-blue-800 dark:text-blue-200">
                  Tipps für eine schnelle Bearbeitung
                </h3>
                <div class="mt-2 text-sm text-blue-700 dark:text-blue-300">
                  <ul class="pl-5 space-y-1 list-disc">
                    <li>Verwenden Sie einen aussagekräftigen Betreff</li>
                    <li>Beschreiben Sie das Problem Schritt für Schritt</li>
                    <li>Geben Sie an, wann das Problem auftritt</li>
                    <li>Fügen Sie relevante Fehlermeldungen hinzu</li>
                    <li>Erwähnen Sie, was Sie bereits versucht haben</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <!-- Actions -->
          <div class="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
            <NuxtLink
              to="/customer/tickets"
              class="px-4 py-2 text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 font-medium transition-colors"
            >
              Abbrechen
            </NuxtLink>
            <button
              type="submit"
              :disabled="submitting"
              class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-medium rounded-md transition-colors"
            >
              <Icon v-if="submitting" name="heroicons:arrow-path" class="w-4 h-4 mr-2 animate-spin" />
              <Icon v-else name="heroicons:paper-airplane" class="w-4 h-4 mr-2" />
              {{ submitting ? 'Wird erstellt...' : 'Ticket erstellen' }}
            </button>
          </div>
        </form>
      </div>
    </div>
</template>

<script setup>
definePageMeta({
  layout: 'customer',
  middleware: 'customer'
})

const notificationsStore = useNotificationsStore()
const { addNotification } = notificationsStore

// Form state
const form = ref({
  title: '',
  description: '',
  department: '',
  priority: 'NORMAL'
})

const errors = ref({})
const submitting = ref(false)

// Validation
const validateForm = () => {
  errors.value = {}

  if (!form.value.title.trim()) {
    errors.value.title = 'Titel ist erforderlich'
  } else if (form.value.title.trim().length < 5) {
    errors.value.title = 'Titel muss mindestens 5 Zeichen lang sein'
  }

  if (!form.value.description.trim()) {
    errors.value.description = 'Beschreibung ist erforderlich'
  } else if (form.value.description.trim().length < 10) {
    errors.value.description = 'Beschreibung muss mindestens 10 Zeichen lang sein'
  }

  if (!form.value.department) {
    errors.value.department = 'Abteilung muss ausgewählt werden'
  }

  return Object.keys(errors.value).length === 0
}

// Submit form
const submitTicket = async () => {
  if (!validateForm()) {
    return
  }

  submitting.value = true

  try {
    const ticket = await $fetch('/api/customer/tickets', {
      method: 'POST',
      body: {
        title: form.value.title.trim(),
        description: form.value.description.trim(),
        department: form.value.department,
        priority: form.value.priority
      }
    })

    addNotification({
      type: 'success',
      title: 'Ticket erstellt',
      message: 'Ihr Ticket wurde erfolgreich erstellt. Wir werden uns so schnell wie möglich darum kümmern.'
    })

    // Redirect to ticket details
    navigateTo(`/customer/tickets/${ticket.id}`)

  } catch (error) {
    console.error('Failed to create ticket:', error)
    
    addNotification({
      type: 'error',
      title: 'Fehler',
      message: error.data?.message || 'Ticket konnte nicht erstellt werden. Bitte versuchen Sie es erneut.'
    })
  } finally {
    submitting.value = false
  }
}

// Auto-save draft (future feature)
watch(form, () => {
  // Could implement auto-save to localStorage here
}, { deep: true })
</script>
