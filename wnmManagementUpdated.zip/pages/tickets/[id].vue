<template>
  <div class="space-y-6">
    <!-- Loading State -->
    <div v-if="loading" class="space-y-6">
      <div class="animate-pulse">
        <div class="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-4"></div>
        <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3 mb-6"></div>
        <div class="bg-white dark:bg-gray-800 rounded-lg p-6">
          <div class="space-y-4">
            <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
            <div class="h-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- Ticket Content -->
    <div v-else-if="ticket" class="space-y-6">
      <!-- Header -->
      <div>
        <div class="flex items-center space-x-4 mb-4">
          <NuxtLink
            to="/tickets"
            class="inline-flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
          >
            <Icon name="heroicons:arrow-left" class="w-4 h-4 mr-2" />
            Zurück zu Tickets
          </NuxtLink>
        </div>
        
        <div class="flex items-start justify-between">
          <div class="flex-1">
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              {{ ticket.title }}
            </h1>
            <div class="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400 mb-4">
              <span>Ticket #{{ ticket.id.slice(-8) }}</span>
              <span>•</span>
              <span>{{ $t(`tickets.departments.${ticket.department}`) }}</span>
              <span>•</span>
              <span>{{ formatDate(ticket.createdAt) }}</span>
            </div>
            <div class="flex items-center space-x-3">
              <span class="text-sm text-gray-600 dark:text-gray-400">Kunde:</span>
              <span class="text-sm font-medium text-gray-900 dark:text-white">
                {{ ticket.customer.companyName }}
              </span>
              <span class="text-sm text-gray-500">
                ({{ ticket.customer.contactName }})
              </span>
            </div>
          </div>
          
          <div class="flex items-center space-x-3">
            <TaskPriorityBadge :priority="ticket.priority" size="md" />
            <TaskStatusBadge :status="ticket.status" size="md" />
          </div>
        </div>
      </div>

      <!-- Main Content Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Main Content -->
        <div class="lg:col-span-2 space-y-6">
          <!-- Ticket Details -->
          <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
            <div class="p-6">
              <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                {{ $t('tickets.description') }}
              </h2>
              <div class="prose dark:prose-invert max-w-none">
                <p class="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{{ ticket.description }}</p>
              </div>
            </div>
          </div>

          <!-- Resolution (if resolved) -->
          <div v-if="ticket.resolution" class="bg-green-50 dark:bg-green-900/50 rounded-lg border border-green-200 dark:border-green-800">
            <div class="p-6">
              <div class="flex items-center mb-4">
                <Icon name="heroicons:check-circle" class="w-6 h-6 text-green-600 mr-3" />
                <h2 class="text-lg font-semibold text-green-900 dark:text-green-100">
                  {{ $t('tickets.resolution') }}
                </h2>
              </div>
              <div class="prose dark:prose-invert max-w-none">
                <p class="text-green-800 dark:text-green-200 whitespace-pre-wrap">{{ ticket.resolution }}</p>
              </div>
            </div>
          </div>

          <!-- Comments Section -->
          <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
            <div class="p-6">
              <InternalTicketComments 
                :ticket-id="ticket.id" 
                :ticket-status="ticket.status"
                @comment-added="onCommentAdded"
                @status-updated="onStatusUpdated"
              />
            </div>
          </div>
        </div>

        <!-- Sidebar -->
        <div class="space-y-6">
          <!-- Quick Actions -->
          <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
            <div class="p-6">
              <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                {{ $t('tickets.actions.title') }}
              </h3>
              <div class="space-y-3">
                <!-- Convert to Task -->
                <button
                  v-if="canConvertToTask"
                  @click="showConversionModal = true"
                  class="w-full inline-flex items-center justify-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
                >
                  <Icon name="heroicons:arrow-path" class="w-4 h-4 mr-2" />
                  {{ $t('tickets.convertToTask') }}
                </button>

                <!-- Update Status -->
                <div class="space-y-2">
                  <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Status ändern
                  </label>
                  <select
                    v-model="selectedStatus"
                    @change="updateTicketStatus"
                    class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                  >
                    <option value="OFFEN">{{ $t('tickets.statuses.offen') }}</option>
                    <option value="IN_BEARBEITUNG">{{ $t('tickets.statuses.in_bearbeitung') }}</option>
                    <option value="WARTEN_AUF_KUNDE">{{ $t('tickets.statuses.warten_auf_kunde') }}</option>
                    <option value="GELOEST">{{ $t('tickets.statuses.geloest') }}</option>
                    <option value="GESCHLOSSEN">{{ $t('tickets.statuses.geschlossen') }}</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          <!-- Ticket Info -->
          <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
            <div class="p-6">
              <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Ticket-Informationen
              </h3>
              <dl class="space-y-3">
                <div>
                  <dt class="text-sm font-medium text-gray-600 dark:text-gray-400">Erstellt am</dt>
                  <dd class="text-sm text-gray-900 dark:text-white">{{ formatDate(ticket.createdAt) }}</dd>
                </div>
                <div>
                  <dt class="text-sm font-medium text-gray-600 dark:text-gray-400">Letzte Aktualisierung</dt>
                  <dd class="text-sm text-gray-900 dark:text-white">{{ formatDate(ticket.updatedAt) }}</dd>
                </div>
                <div>
                  <dt class="text-sm font-medium text-gray-600 dark:text-gray-400">Priorität</dt>
                  <dd>
                    <TaskPriorityBadge :priority="ticket.priority" size="sm" />
                  </dd>
                </div>
                <div>
                  <dt class="text-sm font-medium text-gray-600 dark:text-gray-400">Abteilung</dt>
                  <dd class="text-sm text-gray-900 dark:text-white">{{ $t(`tickets.departments.${ticket.department}`) }}</dd>
                </div>
              </dl>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Error State -->
    <div v-else class="text-center py-12">
      <Icon name="heroicons:exclamation-triangle" class="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-600" />
      <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
        Ticket nicht gefunden
      </h3>
      <p class="text-gray-600 dark:text-gray-400 mb-6">
        Das angeforderte Ticket existiert nicht.
      </p>
      <NuxtLink
        to="/tickets"
        class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
      >
        <Icon name="heroicons:arrow-left" class="w-4 h-4 mr-2" />
        Zurück zu Tickets
      </NuxtLink>
    </div>

    <!-- Ticket Conversion Modal -->
    <TicketConversionModal
      :show-modal="showConversionModal"
      :ticket="ticket"
      @close="showConversionModal = false"
      @converted="onTicketConverted"
    />
  </div>
</template>

<script setup>
definePageMeta({
  middleware: 'staff'
})

const route = useRoute()
const notificationsStore = useNotificationsStore()
const { addNotification } = notificationsStore

// State
const loading = ref(true)
const ticket = ref(null)
const showConversionModal = ref(false)
const selectedStatus = ref('')
const updatingStatus = ref(false)

// Computed
const canConvertToTask = computed(() => {
  return ticket.value && ticket.value.status !== 'GESCHLOSSEN'
})

// Methods
const loadTicket = async () => {
  loading.value = true
  try {
    const response = await $fetch(`/api/tickets/${route.params.id}`)
    // Extract ticket data from response structure
    ticket.value = response.data || response
    selectedStatus.value = ticket.value.status

  } catch (error) {
    console.error('Failed to load ticket:', error)
    ticket.value = null
    
    if (error.statusCode !== 404) {
      addNotification({
        type: 'error',
        title: 'Fehler',
        message: 'Ticket konnte nicht geladen werden.'
      })
    }
  } finally {
    loading.value = false
  }
}

const updateTicketStatus = async () => {
  if (updatingStatus.value || selectedStatus.value === ticket.value.status) return

  updatingStatus.value = true
  try {
    await $fetch(`/api/tickets/${route.params.id}`, {
      method: 'PUT',
      body: {
        status: selectedStatus.value
      }
    })

    ticket.value.status = selectedStatus.value
    ticket.value.updatedAt = new Date()

    addNotification({
      type: 'success',
      title: 'Erfolg',
      message: 'Ticket-Status wurde aktualisiert.'
    })

  } catch (error) {
    console.error('Failed to update ticket status:', error)
    selectedStatus.value = ticket.value.status // Revert selection
    
    addNotification({
      type: 'error',
      title: 'Fehler',
      message: 'Ticket-Status konnte nicht aktualisiert werden.'
    })
  } finally {
    updatingStatus.value = false
  }
}

const onCommentAdded = () => {
  // Comments are handled by the component
}

const onStatusUpdated = (newStatus) => {
  selectedStatus.value = newStatus
  ticket.value.status = newStatus
}

const onTicketConverted = () => {
  showConversionModal.value = false
  addNotification({
    type: 'success',
    title: 'Erfolg',
    message: 'Ticket wurde erfolgreich in eine Aufgabe konvertiert.'
  })
  // Optionally reload ticket or redirect
  loadTicket()
}

// Utility functions
const formatDate = (date) => {
  return new Date(date).toLocaleDateString('de-DE', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// Load ticket on mount
onMounted(() => {
  loadTicket()
})
</script>
