<template>
  <div class="space-y-6">
    <!-- Header -->
    <div class="md:flex md:items-center md:justify-between">
      <div class="min-w-0 flex-1">
        <h1 class="text-2xl font-bold leading-7 text-gray-900 dark:text-white sm:truncate sm:text-3xl sm:tracking-tight">
          Berichte & Analytics
        </h1>
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Umfassende Berichte und Analysen für Projekte, Teams und Zeiterfassung
        </p>
      </div>
      <div class="mt-4 flex md:ml-4 md:mt-0">
        <button
          @click="showExportModal = true"
          type="button"
          class="inline-flex items-center rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600">
          <DocumentArrowDownIcon class="-ml-0.5 mr-1.5 h-5 w-5" />
          Bericht exportieren
        </button>
      </div>
    </div>

    <!-- Report Type Selector -->
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border border-gray-200 dark:border-gray-700">
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <button
          v-for="type in reportTypes"
          :key="type.key"
          @click="activeReportType = type.key"
          :class="[
            'relative rounded-lg p-4 text-left transition-all duration-200 border-2',
            activeReportType === type.key
              ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
              : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
          ]">
          <div class="flex items-center">
            <component :is="type.icon" class="h-6 w-6 text-blue-600 dark:text-blue-400 mr-3" />
            <div>
              <h3 class="text-sm font-medium text-gray-900 dark:text-white">{{ type.title }}</h3>
              <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">{{ type.description }}</p>
            </div>
          </div>
        </button>
      </div>
    </div>

    <!-- Date Range Selector -->
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border border-gray-200 dark:border-gray-700">
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div>
          <h3 class="text-lg font-medium text-gray-900 dark:text-white">Zeitraum auswählen</h3>
          <p class="text-sm text-gray-500 dark:text-gray-400">Bestimmen Sie den Berichtszeitraum</p>
        </div>
        
        <div class="flex items-center space-x-4">
          <!-- Quick Date Buttons -->
          <div class="flex rounded-lg bg-gray-100 dark:bg-gray-700 p-1">
            <button
              v-for="period in quickPeriods"
              :key="period.key"
              @click="setQuickPeriod(period.key)"
              :class="[
                'px-3 py-1.5 text-sm font-medium rounded-md transition-colors',
                activePeriod === period.key
                  ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
              ]">
              {{ period.label }}
            </button>
          </div>
          
          <!-- Custom Date Range -->
          <div class="flex items-center space-x-2">
            <input
              v-model="dateRange.start"
              type="date"
              class="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white">
            <span class="text-gray-500 dark:text-gray-400">bis</span>
            <input
              v-model="dateRange.end"
              type="date"
              class="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white">
          </div>
          
          <button
            @click="loadReportData"
            :disabled="loading"
            class="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-lg transition-colors duration-200 flex items-center space-x-2">
            <ArrowPathIcon v-if="loading" class="h-4 w-4 animate-spin" />
            <MagnifyingGlassIcon v-else class="h-4 w-4" />
            <span>Analysieren</span>
          </button>
        </div>
      </div>
    </div>

    <!-- Report Content -->
    <div v-if="reportData" class="space-y-6">
      <!-- Time Tracking Reports -->
      <div v-if="activeReportType === 'time'" class="space-y-6">
        <!-- Time Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
          <StatCard
            title="Gesamtstunden"
            :value="formatHours(reportData.totalHours)"
            icon="ClockIcon"
            color="blue"
            :change="reportData.timeChange"
          />
          <StatCard
            title="Abrechenbare Stunden"
            :value="formatHours(reportData.billableHours)"
            icon="CurrencyDollarIcon"
            color="green"
            :change="reportData.billableChange"
          />
          <StatCard
            title="Produktivität"
            :value="`${reportData.productivity}%`"
            icon="ChartBarIcon"
            color="purple"
          />
          <StatCard
            title="Durchschnitt/Tag"
            :value="formatHours(reportData.avgHoursPerDay)"
            icon="CalendarIcon"
            color="orange"
          />
        </div>

        <!-- Time Distribution Chart -->
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Zeitverteilung nach Projekten</h3>
          <TimeDistributionChart :data="reportData.projectDistribution || []" />
        </div>

        <!-- Time Trends Chart -->
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Zeittrends</h3>
          <TimeTrendsChart :data="reportData.timeTrends || []" />
        </div>
      </div>

      <!-- Project Reports -->
      <div v-if="activeReportType === 'projects'" class="space-y-6">
        <!-- Project Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
          <StatCard
            title="Aktive Projekte"
            :value="reportData.activeProjects || 0"
            icon="FolderIcon"
            color="blue"
          />
          <StatCard
            title="Abgeschlossene Projekte"
            :value="reportData.completedProjects || 0"
            icon="CheckCircleIcon"
            color="green"
          />
          <StatCard
            title="Überfällige Projekte"
            :value="reportData.overdueProjects || 0"
            icon="ExclamationTriangleIcon"
            color="red"
          />
          <StatCard
            title="Durchschnittliche Dauer"
            :value="`${reportData.avgProjectDuration || 0} Tage`"
            icon="CalendarDaysIcon"
            color="purple"
          />
        </div>

        <!-- Project Performance Chart -->
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Projekt-Performance</h3>
          <ProjectPerformanceChart :data="reportData.projectPerformance || []" />
        </div>

        <!-- Project Status Overview -->
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Projekt-Status Übersicht</h3>
          <ProjectStatusChart :data="reportData.projectStatus || []" />
        </div>
      </div>

      <!-- Team Performance Reports -->
      <div v-if="activeReportType === 'team'" class="space-y-6">
        <!-- Team Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
          <StatCard
            title="Team-Mitglieder"
            :value="reportData.totalMembers || 0"
            icon="UsersIcon"
            color="blue"
          />
          <StatCard
            title="Durchschnittliche Auslastung"
            :value="`${reportData.avgUtilization || 0}%`"
            icon="ChartBarIcon"
            color="green"
          />
          <StatCard
            title="Abgeschlossene Tasks"
            :value="reportData.completedTasks || 0"
            icon="CheckCircleIcon"
            color="purple"
          />
          <StatCard
            title="Team-Produktivität"
            :value="`${reportData.teamProductivity || 0}%`"
            icon="ArrowTrendingUpIcon"
            color="orange"
          />
        </div>

        <!-- Team Workload Chart -->
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Team-Auslastung</h3>
          <TeamWorkloadChart :data="reportData.teamWorkload || []" />
        </div>

        <!-- Individual Performance -->
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Individuelle Performance</h3>
          <IndividualPerformanceTable :data="reportData.individualPerformance || []" />
        </div>
      </div>

      <!-- Financial Reports -->
      <div v-if="activeReportType === 'financial'" class="space-y-6">
        <!-- Financial Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
          <StatCard
            title="Gesamtumsatz"
            :value="`€${formatCurrency(reportData.totalRevenue)}`"
            icon="CurrencyEuroIcon"
            color="green"
            :change="reportData.revenueChange"
          />
          <StatCard
            title="Abrechenbare Zeit"
            :value="formatHours(reportData.billableTime)"
            icon="ClockIcon"
            color="blue"
          />
          <StatCard
            title="Durchschnitt/Stunde"
            :value="`€${formatCurrency(reportData.avgHourlyRate)}`"
            icon="CalculatorIcon"
            color="purple"
          />
          <StatCard
            title="Projektrentabilität"
            :value="`${reportData.profitability || 0}%`"
            icon="ArrowTrendingUpIcon"
            color="orange"
          />
        </div>

        <!-- Revenue Chart -->
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Umsatzentwicklung</h3>
          <RevenueChart :data="reportData.revenueData || []" />
        </div>

        <!-- Project Profitability -->
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Projektrentabilität</h3>
          <ProjectProfitabilityTable :data="reportData.profitabilityData || []" />
        </div>
      </div>
    </div>

    <!-- Loading State -->
    <div v-else-if="loading" class="flex items-center justify-center py-12">
      <div class="text-center">
        <ArrowPathIcon class="h-8 w-8 animate-spin text-blue-600 mx-auto mb-4" />
        <p class="text-gray-500 dark:text-gray-400">Bericht wird generiert...</p>
      </div>
    </div>

    <!-- Empty State -->
    <div v-else class="text-center py-12">
      <ChartBarIcon class="mx-auto h-12 w-12 text-gray-400" />
      <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">Keine Berichte</h3>
      <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
        Wählen Sie einen Berichtstyp und Zeitraum aus, um zu beginnen.
      </p>
    </div>

    <!-- Export Modal -->
    <ReportExportModal
      v-if="showExportModal"
      :is-open="showExportModal"
      :report-type="activeReportType"
      :date-range="dateRange"
      :report-data="reportData"
      @close="showExportModal = false"
      @export="handleExport"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import {
  DocumentArrowDownIcon,
  ChartBarIcon,
  ClockIcon,
  UsersIcon,
  CurrencyEuroIcon,
  MagnifyingGlassIcon,
  ArrowPathIcon,
  FolderIcon,
} from '@heroicons/vue/24/outline'

// Page Meta
definePageMeta({
  middleware: 'staff',
  layout: 'default'
})

// Types
interface ReportData {
  // Time tracking
  totalHours?: number
  billableHours?: number
  productivity?: number
  avgHoursPerDay?: number
  timeChange?: number
  billableChange?: number
  projectDistribution?: any[]
  timeTrends?: any[]
  
  // Projects
  activeProjects?: number
  completedProjects?: number
  overdueProjects?: number
  avgProjectDuration?: number
  projectPerformance?: any[]
  projectStatus?: any[]
  
  // Team
  totalMembers?: number
  avgUtilization?: number
  completedTasks?: number
  teamProductivity?: number
  teamWorkload?: any[]
  individualPerformance?: any[]
  
  // Financial
  totalRevenue?: number
  billableTime?: number
  avgHourlyRate?: number
  profitability?: number
  revenueChange?: number
  revenueData?: any[]
  profitabilityData?: any[]
}

// State
const loading = ref(false)
const reportData = ref<ReportData | null>(null)
const activeReportType = ref('time')
const activePeriod = ref('month')
const showExportModal = ref(false)

const dateRange = ref({
  start: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0],
  end: new Date().toISOString().split('T')[0]
})

// Report Types
const reportTypes = [
  {
    key: 'time',
    title: 'Zeiterfassung',
    description: 'Stundenanalyse und Produktivität',
    icon: ClockIcon
  },
  {
    key: 'projects',
    title: 'Projekte',
    description: 'Projekt-Performance und Status',
    icon: FolderIcon
  },
  {
    key: 'team',
    title: 'Team',
    description: 'Team-Auslastung und Performance',
    icon: UsersIcon
  },
  {
    key: 'financial',
    title: 'Finanzen',
    description: 'Umsatz und Rentabilität',
    icon: CurrencyEuroIcon
  }
]

// Quick Periods
const quickPeriods = [
  { key: 'week', label: 'Diese Woche' },
  { key: 'month', label: 'Dieser Monat' },
  { key: 'quarter', label: 'Dieses Quartal' },
  { key: 'year', label: 'Dieses Jahr' }
]

// Methods
const setQuickPeriod = (period: string) => {
  activePeriod.value = period
  const now = new Date()
  
  switch (period) {
    case 'week':
      const startOfWeek = new Date(now)
      startOfWeek.setDate(now.getDate() - now.getDay() + 1)
      dateRange.value.start = startOfWeek.toISOString().split('T')[0]
      dateRange.value.end = now.toISOString().split('T')[0]
      break
    case 'month':
      dateRange.value.start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0]
      dateRange.value.end = now.toISOString().split('T')[0]
      break
    case 'quarter':
      const quarterStart = new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1)
      dateRange.value.start = quarterStart.toISOString().split('T')[0]
      dateRange.value.end = now.toISOString().split('T')[0]
      break
    case 'year':
      dateRange.value.start = new Date(now.getFullYear(), 0, 1).toISOString().split('T')[0]
      dateRange.value.end = now.toISOString().split('T')[0]
      break
  }
  
  loadReportData()
}

const loadReportData = async () => {
  loading.value = true
  try {
    const endpoint = `/api/reports/${activeReportType.value}`
    const response = await $fetch(endpoint, {
      query: {
        startDate: dateRange.value.start,
        endDate: dateRange.value.end
      }
    })
    reportData.value = response as ReportData
  } catch (error) {
    console.error('Error loading report data:', error)
    // Handle error with notification
  } finally {
    loading.value = false
  }
}

const handleExport = async (format: string, options: any) => {
  try {
    const queryParams = new URLSearchParams({
      reportType: activeReportType.value,
      format,
      startDate: dateRange.value.start,
      endDate: dateRange.value.end,
      ...options
    })
    
    // Create download link
    const downloadUrl = `/api/reports/export?${queryParams.toString()}`
    
    // Create a temporary link and trigger download
    const link = document.createElement('a')
    link.href = downloadUrl
    link.download = `${activeReportType.value}_bericht_${dateRange.value.start}_${dateRange.value.end}.${format === 'excel' ? 'xlsx' : 'pdf'}`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  } catch (error) {
    console.error('Export error:', error)
  }
}

// Utility functions
const formatHours = (hours: number | undefined) => {
  return hours ? hours.toFixed(1) : '0.0'
}

const formatCurrency = (amount: number | undefined) => {
  return amount ? amount.toLocaleString('de-DE', { minimumFractionDigits: 2 }) : '0.00'
}

// Watchers
watch(activeReportType, () => {
  if (reportData.value) {
    loadReportData()
  }
})

// Lifecycle
onMounted(() => {
  setQuickPeriod('month')
})

// SEO
useHead({
  title: 'Berichte & Analytics - wnmManagement',
  meta: [
    {
      name: 'description',
      content: 'Umfassende Berichte und Analysen für Projekte, Teams und Zeiterfassung'
    }
  ]
})
</script>
