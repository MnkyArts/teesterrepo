<template>
  <div class="space-y-6">
    <!-- Page Header -->
    <div class="sm:flex sm:items-center sm:justify-between">
      <div>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
          {{ $t('timeTracking.timeTracking') }}
        </h1>
        <p class="mt-2 text-sm text-gray-700 dark:text-gray-300">
          {{ $t('timeTracking.pageDescription') }}
        </p>
      </div>
      <div class="mt-4 sm:mt-0 flex space-x-3">
        <button
          @click="showTimeEntryModal = true"
          class="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors"
        >
          <PlusIcon class="h-4 w-4 mr-2" />
          {{ $t('timeTracking.addTimeEntry') }}
        </button>
        
        <button
          @click="showStartTimer = true"
          class="inline-flex items-center px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors"
        >
          <PlayIcon class="h-4 w-4 mr-2" />
          {{ $t('timeTracking.startTimer') }}
        </button>
      </div>
    </div>

    <!-- Active Timer Banner -->
    <div v-if="isTimerRunning && activeTimer" class="bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
      <div class="flex items-center justify-between">
        <div class="flex items-center space-x-4">
          <div class="flex items-center space-x-2">
            <div class="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
            <span class="text-sm font-medium text-gray-900 dark:text-white">
              {{ $t('timeTracking.timerRunning') }}
            </span>
          </div>
          <div class="text-lg font-mono font-bold text-gray-900 dark:text-white">
            {{ formattedElapsedTime }}
          </div>
          <div class="text-sm text-gray-600 dark:text-gray-400">
            {{ activeTimer.description }}
          </div>
        </div>
        <button
          @click="() => stopTimer()"
          class="flex items-center px-3 py-1.5 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700 transition-colors"
        >
          <StopIcon class="h-4 w-4 mr-1" />
          {{ $t('timeTracking.stopTimer') }}
        </button>
      </div>
    </div>

    <!-- Stats Overview -->
    <div v-if="stats" class="grid grid-cols-1 md:grid-cols-4 gap-6">
      <StatCard
        :title="$t('timeTracking.todayTotal')"
        :value="formatHours(stats.todayTotal) + 'h'"
        :icon="ClockIcon"
        color="blue"
      />
      <StatCard
        :title="$t('timeTracking.weekTotal')"
        :value="formatHours(stats.weekTotal) + 'h'"
        :icon="CalendarIcon"
        color="green"
      />
      <StatCard
        :title="$t('timeTracking.billableToday')"
        :value="formatHours(stats.billableToday) + 'h'"
        :icon="CurrencyDollarIcon"
        color="purple"
      />
      <StatCard
        :title="$t('timeTracking.monthTotal')"
        :value="formatHours(stats.monthTotal) + 'h'"
        :icon="ChartBarIcon"
        color="orange"
      />
    </div>

    <!-- View Toggle and Filters -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow border border-gray-200 dark:border-gray-700 p-4">
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <!-- View Toggle -->
        <div class="flex rounded-lg bg-gray-100 dark:bg-gray-700 p-1">
          <button
            @click="currentView = 'week'"
            :class="[
              'px-3 py-1.5 text-sm font-medium rounded-md transition-colors',
              currentView === 'week'
                ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
            ]"
          >
            {{ $t('timeTracking.weekView') }}
          </button>
          <button
            @click="currentView = 'list'"
            :class="[
              'px-3 py-1.5 text-sm font-medium rounded-md transition-colors',
              currentView === 'list'
                ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
            ]"
          >
            {{ $t('timeTracking.listView') }}
          </button>
        </div>

        <!-- Filters and Actions -->
        <div class="flex items-center space-x-3">
          <!-- Week Navigation -->
          <div v-if="currentView === 'week'" class="flex items-center space-x-2">
            <button
              @click="previousWeek"
              class="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <ChevronLeftIcon class="h-5 w-5" />
            </button>
            <span class="text-sm font-medium text-gray-900 dark:text-white">
              {{ formatWeekRange(currentWeekStart) }}
            </span>
            <button
              @click="nextWeek"
              class="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <ChevronRightIcon class="h-5 w-5" />
            </button>
            <button
              @click="goToCurrentWeek"
              class="px-3 py-1.5 text-sm text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
            >
              {{ $t('timeTracking.currentWeek') }}
            </button>
          </div>

          <!-- Project Filter -->
          <select
            v-model="selectedProjectId"
            @change="loadTimeEntries"
            class="px-3 py-1.5 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="">{{ $t('projects.allProjects') }}</option>
            <option
              v-for="project in availableProjects"
              :key="project.id"
              :value="project.id"
            >
              {{ project.name }}
            </option>
          </select>

          <!-- Export Button -->
          <div class="relative">
            <button
              @click="showExportMenu = !showExportMenu"
              class="flex items-center px-3 py-1.5 text-sm text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors"
            >
              <ArrowDownTrayIcon class="h-4 w-4 mr-2" />
              {{ $t('common.export') }}
            </button>
            
            <!-- Export Dropdown -->
            <div
              v-if="showExportMenu"
              class="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 z-10"
            >
              <button
                @click="exportAs('csv')"
                class="block w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 first:rounded-t-lg"
              >
                {{ $t('timeTracking.exportCsv') }}
              </button>
              <button
                @click="exportAs('pdf')"
                class="block w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 last:rounded-b-lg"
              >
                {{ $t('timeTracking.exportPdf') }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Week View -->
    <div v-if="currentView === 'week'" class="bg-white dark:bg-gray-800 rounded-lg shadow border border-gray-200 dark:border-gray-700">
      <WeekTimesheet
        :week-start="currentWeekStart"
        :entries="weekEntriesFiltered"
        :is-loading="isLoading"
        @add-entry="handleAddEntry"
        @edit-entry="handleEditEntry"
        @delete-entry="handleDeleteEntry"
      />
    </div>

    <!-- List View -->
    <div v-else class="bg-white dark:bg-gray-800 rounded-lg shadow border border-gray-200 dark:border-gray-700">
      <TimeEntryList
        :entries="[...timeEntries]"
        :is-loading="isLoading"
        @edit-entry="handleEditEntry"
        @delete-entry="handleDeleteEntry"
        @load-more="loadMoreEntries"
      />
    </div>

    <!-- Modals -->
    <TimerStartModal
      v-if="showStartTimer"
      @close="showStartTimer = false"
      @start="handleStartTimer"
    />

    <TimeEntryModal
      v-if="showTimeEntryModal"
      :entry="editingEntry"
      @close="closeTimeEntryModal"
      @save="handleSaveEntry"
    />

    <ConfirmDialog
      :is-open="showDeleteConfirm"
      :title="$t('timeTracking.deleteEntryTitle')"
      :message="$t('timeTracking.deleteEntryMessage')"
      variant="danger"
      @confirm="confirmDelete"
      @cancel="showDeleteConfirm = false"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import {
  PlusIcon,
  PlayIcon,
  StopIcon,
  ClockIcon,
  CalendarIcon,
  CurrencyDollarIcon,
  ChartBarIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  ArrowDownTrayIcon
} from '@heroicons/vue/24/solid'

// Components
const WeekTimesheet = defineAsyncComponent(() => import('~/components/WeekTimesheet.vue'))
const TimeEntryList = defineAsyncComponent(() => import('~/components/TimeEntryList.vue'))
const TimerStartModal = defineAsyncComponent(() => import('~/components/TimerStartModal.vue'))
const TimeEntryModal = defineAsyncComponent(() => import('~/components/TimeEntryModal.vue'))

// Stores
const timeTrackingStore = useTimeTrackingStore()
const {
  timeEntries,
  activeTimer,
  stats,
  isTimerRunning,
  formattedElapsedTime,
  weekEntries,
  isLoading
} = storeToRefs(timeTrackingStore)
const {
  fetchTimeEntries,
  createTimeEntry,
  updateTimeEntry,
  deleteTimeEntry,
  fetchStats,
  startTimer,
  stopTimer,
  exportTimeEntries,
  formatHours,
  getWeekStart,
  getWeekEnd
} = timeTrackingStore

const projectsStore = useProjectsStore()
const { projects } = storeToRefs(projectsStore)
const { fetchProjects } = projectsStore

// Define page meta
definePageMeta({
  middleware: 'staff'
})

// State
const currentView = ref<'week' | 'list'>('week')
const initialWeekStart = getWeekStart(new Date())
initialWeekStart.setHours(0, 0, 0, 0) // Ensure start of day
const currentWeekStart = ref(initialWeekStart)
const selectedProjectId = ref('')
const availableProjects = ref<any[]>([])

// Modal states
const showStartTimer = ref(false)
const showTimeEntryModal = ref(false)
const showDeleteConfirm = ref(false)
const showExportMenu = ref(false)
const editingEntry = ref<any>(null)
const deletingEntryId = ref<string | null>(null)

// Computed
const weekEntriesFiltered = computed(() => {
  // Filter timeEntries for the current week view
  const weekStart = new Date(currentWeekStart.value)
  weekStart.setHours(0, 0, 0, 0) // Start of day
  
  const weekEnd = getWeekEnd(currentWeekStart.value)
  weekEnd.setHours(23, 59, 59, 999) // End of day
  
  const filteredByWeek = timeEntries.value.filter(entry => {
    // Convert the entry date to local timezone for comparison
    const entryDate = new Date(entry.date)
    // Create a date in local timezone using the entry's date components
    const localEntryDate = new Date(entryDate.getFullYear(), entryDate.getMonth(), entryDate.getDate())
    
    return localEntryDate >= weekStart && localEntryDate <= weekEnd
  })
  
  // Then filter by project if selected
  return filteredByWeek.filter(entry => 
    !selectedProjectId.value || entry.project.id === selectedProjectId.value
  )
})

// Methods
const formatWeekRange = (startDate: Date) => {
  const endDate = new Date(startDate)
  endDate.setDate(startDate.getDate() + 6)
  
  const options: Intl.DateTimeFormatOptions = { 
    day: 'numeric', 
    month: 'short' 
  }
  
  return `${startDate.toLocaleDateString('de-DE', options)} - ${endDate.toLocaleDateString('de-DE', options)}`
}

const previousWeek = () => {
  const newDate = new Date(currentWeekStart.value)
  newDate.setDate(newDate.getDate() - 7)
  newDate.setHours(0, 0, 0, 0) // Ensure start of day
  currentWeekStart.value = newDate
  loadTimeEntries()
}

const nextWeek = () => {
  const newDate = new Date(currentWeekStart.value)
  newDate.setDate(newDate.getDate() + 7)
  newDate.setHours(0, 0, 0, 0) // Ensure start of day
  currentWeekStart.value = newDate
  loadTimeEntries()
}

const goToCurrentWeek = () => {
  const newWeekStart = getWeekStart(new Date())
  newWeekStart.setHours(0, 0, 0, 0) // Ensure start of day
  currentWeekStart.value = newWeekStart
  loadTimeEntries()
}

const loadTimeEntries = async () => {
  const filters: any = {}
  
  if (currentView.value === 'week') {
    filters.startDate = currentWeekStart.value.toISOString().split('T')[0]
    const endDate = getWeekEnd(currentWeekStart.value)
    filters.endDate = endDate.toISOString().split('T')[0]
  }
  
  if (selectedProjectId.value) {
    filters.projectId = selectedProjectId.value
  }
  
  try {
    await fetchTimeEntries(filters)
  } catch (error) {
    console.error('Error loading time entries:', error)
  }
}

const loadMoreEntries = () => {
  // Implement pagination for list view
  // This would extend the date range or load more entries
}

const handleStartTimer = async (config: any) => {
  try {
    await startTimer(config.taskId, config.projectId, config.description, config.category)
    showStartTimer.value = false
  } catch (error) {
    console.error('Error starting timer:', error)
  }
}

const handleAddEntry = (entryData: any) => {
  editingEntry.value = entryData
  showTimeEntryModal.value = true
}

const handleEditEntry = (entry: any) => {
  editingEntry.value = entry
  showTimeEntryModal.value = true
}

const handleDeleteEntry = (entryId: string) => {
  deletingEntryId.value = entryId
  showDeleteConfirm.value = true
}

const confirmDelete = async () => {
  if (deletingEntryId.value) {
    try {
      await deleteTimeEntry(deletingEntryId.value)
      await loadTimeEntries()
      await fetchStats()
    } catch (error) {
      console.error('Error deleting time entry:', error)
    }
  }
  showDeleteConfirm.value = false
  deletingEntryId.value = null
}

const handleSaveEntry = async (entryData: any) => {
  try {
    if (editingEntry.value?.id) {
      await updateTimeEntry(editingEntry.value.id, entryData)
    } else {
      await createTimeEntry(entryData)
    }
    
    closeTimeEntryModal()
    await loadTimeEntries()
    await fetchStats()
  } catch (error) {
    console.error('Error saving time entry:', error)
  }
}

const closeTimeEntryModal = () => {
  showTimeEntryModal.value = false
  editingEntry.value = null
}

const exportAs = async (format: 'csv' | 'pdf') => {
  showExportMenu.value = false
  
  let startDate: string
  let endDate: string
  
  if (currentView.value === 'week') {
    startDate = currentWeekStart.value.toISOString().split('T')[0]
    const endOfWeek = getWeekEnd(currentWeekStart.value)
    endDate = endOfWeek.toISOString().split('T')[0]
  } else {
    // For list view, export last 30 days by default
    const end = new Date()
    const start = new Date()
    start.setDate(start.getDate() - 30)
    
    startDate = start.toISOString().split('T')[0]
    endDate = end.toISOString().split('T')[0]
  }
  
  try {
    await exportTimeEntries(startDate, endDate, format)
  } catch (error) {
    console.error('Error exporting:', error)
  }
}

// Watch for view changes
watch(currentView, () => {
  loadTimeEntries()
})

// Lifecycle
onMounted(async () => {
  try {
    await Promise.all([
      fetchProjects(),
      loadTimeEntries(),
      fetchStats()
    ])
    
    availableProjects.value = [...(projects.value || [])]
  } catch (error) {
    console.error('Error loading initial data:', error)
  }
})
</script>
