<template>
  <div>
    <EnumManagement />
  </div>
</template>

<script setup lang="ts">
// Meta
definePageMeta({
  title: 'Enum-Verwaltung',
  description: 'Verwalte dynamische Aufgaben- und Ticket-Eigenschaften',
  layout: 'default'
})

// SEO
useHead({
  title: 'Enum-Verwaltung - wnmManagement',
  meta: [
    {
      name: 'description',
      content: 'Verwalte dynamische Aufgaben- und Ticket-Eigenschaften im wnmManagement System'
    }
  ]
})
</script>
