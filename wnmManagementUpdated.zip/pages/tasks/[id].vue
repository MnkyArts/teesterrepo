<template>
  <div>
    <TaskDetails :task-id="$route.params.id as string" />
  </div>
</template>

<script setup lang="ts">
// Meta
definePageMeta({
  middleware: 'staff',
  layout: 'default'
})

// SEO
useHead({
  title: 'Aufgabe - wnmManagement',
  meta: [
    {
      name: 'description',
      content: 'Detailansicht einer Aufgabe mit allen Informationen und Kommentaren.'
    }
  ]
})
</script>
