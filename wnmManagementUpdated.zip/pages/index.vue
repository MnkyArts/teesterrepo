<template>
  <div class="space-y-6">
    <!-- Refresh Indicator -->
    <div v-if="refreshInProgress" class="fixed top-4 right-4 z-50">
      <div class="bg-blue-600 text-white px-4 py-2 rounded-lg shadow-lg flex items-center space-x-2">
        <svg class="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
        </svg>
        <span class="text-sm">Aktualisiere...</span>
      </div>
    </div>

    <!-- Error Banner -->
    <div v-if="hasErrors" class="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
      <div class="flex items-center">
        <svg class="h-5 w-5 text-red-400 mr-2" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
        </svg>
        <div>
          <h3 class="text-sm font-medium text-red-800">Einige Daten konnten nicht geladen werden</h3>
          <p class="text-sm text-red-600">Bitte versuchen Sie es später erneut oder kontaktieren Sie den Support.</p>
        </div>
        <button 
          @click="refreshAllData()" 
          class="ml-auto bg-red-100 hover:bg-red-200 text-red-800 px-3 py-1 rounded text-sm transition-colors"
        >
          Erneut versuchen
        </button>
      </div>
    </div>

    <!-- Welcome Header -->
    <div class="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg p-6 text-white">
      <h1 class="text-2xl font-bold">
        {{ $t('dashboard.welcome') }}, {{ fullName || 'Benutzer' }}!
      </h1>
      <p class="mt-2 text-blue-100">
        Hier ist eine Übersicht über Ihre aktuellen Projekte und Aufgaben.
      </p>
      <div class="mt-4 flex items-center gap-4">
        <span class="px-2 py-1 text-xs font-medium bg-white bg-opacity-20 text-white rounded-full">
          {{ $t(`roles.${user?.role?.toLowerCase()}`) }}
        </span>
        <span class="px-2 py-1 text-xs font-medium bg-white bg-opacity-20 text-white rounded-full">
          {{ getEnabledModules().length }} Module aktiv
        </span>
      </div>
    </div>

    <!-- Module Status Banner (for admins or when missing modules) -->
    <div v-if="user?.role === 'ADMINISTRATOR'" class="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
      <div class="flex items-center justify-between">
        <div>
          <h3 class="text-sm font-medium text-blue-800 dark:text-blue-200">
            Module System Status
          </h3>
          <p class="text-sm text-blue-600 dark:text-blue-300">
            {{ getEnabledModules().length }} of {{ Object.keys(modulesConfig).length }} modules are enabled
          </p>
        </div>
        <NuxtLink 
          to="/admin/modules" 
          class="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 transition-colors"
        >
          Manage Modules
        </NuxtLink>
      </div>
    </div>

    <!-- Quick Stats -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <StatCard
        v-if="isModuleEnabled('tasks')"
        title="Meine Aufgaben"
        :value="statsLoading ? '...' : myTasksCount"
        icon="ClipboardDocumentListIcon"
        color="blue"
        :change="statsLoading ? undefined : +3"
        :loading="statsLoading"
      />
      <StatCard
        v-if="isModuleEnabled('projects')"
        title="Aktive Projekte"
        :value="statsLoading ? '...' : activeProjectsCount"
        icon="FolderIcon"
        color="green"
        :change="statsLoading ? undefined : +1"
        :loading="statsLoading"
      />
      <StatCard
        v-if="isModuleEnabled('reports')"
        title="Abschlussrate"
        :value="statsLoading ? '...' : `${completionRate}%`"
        icon="ChartBarIcon"
        color="purple"
        :loading="statsLoading"
      />
      <StatCard
        v-if="isModuleEnabled('team')"
        title="Team-Mitglieder"
        :value="statsLoading ? '...' : totalUsers"
        icon="UsersIcon"
        color="orange"
        :change="statsLoading ? undefined : +1"
        :loading="statsLoading"
      />
    </div>

    <!-- Main Content Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <!-- Left Column -->
      <div class="lg:col-span-2 space-y-6">
        <!-- My Tasks -->
        <DashboardSection
          v-if="isModuleEnabled('tasks')"
          :title="$t('dashboard.myTasks')"
          icon="ClipboardDocumentListIcon"
          :action="{ label: 'Alle anzeigen', href: '/tasks' }"
          :loading="tasksLoading"
        >
          <TaskList v-if="!tasksLoading" :tasks="myTasks" :show-project="true" />
          <div v-else class="space-y-3">
            <div v-for="i in 3" :key="i" class="animate-pulse">
              <div class="h-16 bg-gray-200 dark:bg-gray-700 rounded-lg"></div>
            </div>
          </div>
        </DashboardSection>

        <!-- Recent Activity -->
        <DashboardSection
          v-if="isModuleEnabled('notifications')"
          :title="$t('dashboard.recentActivity')"
          icon="ClockIcon"
          :loading="activitiesLoading"
        >
          <ActivityFeed v-if="!activitiesLoading" :activities="recentActivities" />
          <div v-else class="space-y-3">
            <div v-for="i in 4" :key="i" class="animate-pulse flex items-center space-x-3">
              <div class="h-8 w-8 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
              <div class="flex-1">
                <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
                <div class="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
              </div>
            </div>
          </div>
        </DashboardSection>

        <!-- Fallback content when no main modules are enabled -->
        <div v-if="!isModuleEnabled('tasks') && !isModuleEnabled('notifications')" class="bg-gray-50 dark:bg-gray-800 rounded-lg p-8 text-center">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
            Keine Hauptmodule aktiviert
          </h3>
          <p class="text-gray-600 dark:text-gray-400 mb-4">
            Aktivieren Sie Module wie Aufgaben oder Benachrichtigungen für mehr Inhalte.
          </p>
          <NuxtLink 
            v-if="user?.role === 'ADMINISTRATOR'"
            to="/admin/modules" 
            class="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Module verwalten
          </NuxtLink>
        </div>
      </div>

      <!-- Right Column -->
      <div class="space-y-6">
        <!-- Time Tracking Widget -->
        <DashboardSection
          v-if="isModuleEnabled('timetracking')"
          :title="$t('dashboard.timeTracking')"
          icon="PlayIcon"
        >
          <TimeTrackingWidget />
        </DashboardSection>

        <!-- Project Overview -->
        <DashboardSection
          v-if="isModuleEnabled('projects')"
          :title="$t('dashboard.projectOverview')"
          icon="FolderIcon"
          :action="{ label: 'Alle anzeigen', href: '/projects' }"
        >
          <ProjectOverview :projects="activeProjects" />
        </DashboardSection>

        <!-- Team Activity -->
        <DashboardSection
          v-if="isModuleEnabled('team')"
          :title="$t('dashboard.teamActivity')"
          icon="UsersIcon"
          :loading="teamLoading"
        >
          <TeamActivity v-if="!teamLoading" :activities="teamActivities" />
          <div v-else class="space-y-3">
            <div v-for="i in 3" :key="i" class="animate-pulse flex items-center space-x-3">
              <div class="h-8 w-8 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
              <div class="flex-1">
                <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3 mb-2"></div>
                <div class="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
              </div>
            </div>
          </div>
        </DashboardSection>

        <!-- Fallback content for right sidebar -->
        <div v-if="!isModuleEnabled('timetracking') && !isModuleEnabled('projects') && !isModuleEnabled('team')" class="bg-gray-50 dark:bg-gray-800 rounded-lg p-6 text-center">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
            Keine Sidebar-Module aktiviert
          </h3>
          <p class="text-gray-600 dark:text-gray-400">
            Aktivieren Sie Module für zusätzliche Widgets.
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted } from 'vue'

// Meta
definePageMeta({
  title: 'Dashboard',
})

// Stores
const authStore = useAuthStore()
const { user, fullName } = storeToRefs(authStore)

// Module system
const { isModuleEnabled, getEnabledModules, modulesConfig } = useModules()

// Conditionally load stores based on enabled modules
const projectsStore = isModuleEnabled('projects') ? useProjectsStore() : null
const { projects, activeProjects } = projectsStore ? storeToRefs(projectsStore) : { projects: ref([]), activeProjects: ref([]) }
const fetchProjects = projectsStore?.fetchProjects

// Dashboard data management
const dashboardStore = isModuleEnabled('reports') ? useDashboardStore() : null
const {
  dashboardStats,
  myTasksData,
  recentActivitiesData,
  teamActivitiesData,
  statsLoading,
  tasksLoading,
  activitiesLoading,
  teamLoading,
  isLoading,
  refreshInProgress,
  hasErrors
} = dashboardStore ? storeToRefs(dashboardStore) : {
  dashboardStats: ref(null),
  myTasksData: ref([]),
  recentActivitiesData: ref([]),
  teamActivitiesData: ref([]),
  statsLoading: ref(false),
  tasksLoading: ref(false),
  activitiesLoading: ref(false),
  teamLoading: ref(false),
  isLoading: ref(false),
  refreshInProgress: ref(false),
  hasErrors: ref(false)
}
const {
  refreshAllData,
  initializeDashboard,
  cleanupDashboard
} = dashboardStore || {
  refreshAllData: () => {},
  initializeDashboard: () => {},
  cleanupDashboard: () => {}
}

// Computed values with improved fallbacks
const myTasks = computed(() => myTasksData.value || [])

// Transform DashboardActivity to Activity format
const recentActivities = computed(() => {
  return (recentActivitiesData.value || []).map(activity => ({
    id: activity.id,
    action: activity.action,
    description: activity.description,
    createdAt: activity.createdAt,
    user: activity.user,
    project: activity.project,
    task: activity.task
  }))
})

// Transform DashboardActivity to TeamActivity format
const teamActivities = computed(() => {
  return (teamActivitiesData.value || []).map(activity => ({
    id: activity.id,
    action: activity.action,
    description: activity.description,
    createdAt: activity.createdAt,
    user: activity.user,
    project: activity.project,
    task: activity.task
  }))
})

const myTasksCount = computed(() => dashboardStats.value?.myTasks || 0)
const activeProjectsCount = computed(() => dashboardStats.value?.activeProjects || 0)
const completionRate = computed(() => dashboardStats.value?.completionRate || 0)
const totalUsers = computed(() => dashboardStats.value?.totalUsers || 0)

const todayTimeSpent = ref(6.5) // Will be replaced with real time tracking API
const openTicketsCount = ref(8) // Will be replaced with real tickets API

// Optimized lifecycle management
onMounted(async () => {
  // Initialize dashboard data management only if reports module is enabled
  if (isModuleEnabled('reports')) {
    initializeDashboard()
  }
  
  // Load projects independently only if projects module is enabled
  if (isModuleEnabled('projects') && fetchProjects) {
    fetchProjects()
  }
})

onUnmounted(() => {
  // Clean up dashboard resources only if reports module is enabled
  if (isModuleEnabled('reports')) {
    cleanupDashboard()
  }
})

// Page head
useHead({
  title: 'Dashboard - wenoma'
})
</script>
