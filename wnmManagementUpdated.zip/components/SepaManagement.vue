<template>
  <div class="space-y-6">
    <!-- Header -->
    <div class="flex items-center justify-between">
      <div>
        <h2 class="text-2xl font-bold text-gray-900 dark:text-white">
          {{ $t('sepa.title') }}
        </h2>
        <p class="text-gray-600 dark:text-gray-400 mt-1">
          {{ $t('sepa.description') }}
        </p>
      </div>
      
      <div v-if="hasActiveMandate">
        <span 
          class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium"
          :class="isMandateActive ? 
            'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' : 
            'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'"
        >
          <Icon 
            :name="isMandateActive ? 'heroicons:check-circle' : 'heroicons:x-circle'" 
            class="w-4 h-4 mr-1" 
          />
          {{ isMandateActive ? $t('sepa.mandateActive') : $t('sepa.mandateInactive') }}
        </span>
      </div>
    </div>

    <!-- Warning for expiring mandate -->
    <div 
      v-if="isExpiringSoon" 
      class="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4"
    >
      <div class="flex">
        <Icon name="heroicons:exclamation-triangle" class="w-5 h-5 text-yellow-400 mt-0.5" />
        <div class="ml-3">
          <h3 class="text-sm font-medium text-yellow-800 dark:text-yellow-200">
            {{ $t('sepa.expiringWarning') }}
          </h3>
          <p class="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
            {{ $t('sepa.expiringWarningText', { date: formatDate(mandate?.validUntil) }) }}
          </p>
        </div>
      </div>
    </div>

    <!-- Existing Mandate Display -->
    <div v-if="mandate && hasActiveMandate" class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
      <div class="p-6">
        <div class="flex items-center justify-between mb-6">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white">
            {{ $t('sepa.currentMandate') }}
          </h3>
          <div class="flex space-x-3">
            <button
              @click="showEditForm = true"
              class="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-lg text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              <Icon name="heroicons:pencil" class="w-4 h-4 mr-2" />
              {{ $t('sepa.editMandate') }}
            </button>
            <button
              @click="showRevokeConfirm = true"
              class="inline-flex items-center px-4 py-2 border border-red-300 dark:border-red-600 text-sm font-medium rounded-lg text-red-700 dark:text-red-300 bg-white dark:bg-gray-800 hover:bg-red-50 dark:hover:bg-red-900/20"
            >
              <Icon name="heroicons:x-mark" class="w-4 h-4 mr-2" />
              {{ $t('sepa.revokeMandate') }}
            </button>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {{ $t('sepa.mandateId') }}
            </label>
            <p class="text-gray-900 dark:text-white">{{ mandate.mandateId }}</p>
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {{ $t('sepa.accountHolder') }}
            </label>
            <p class="text-gray-900 dark:text-white">{{ mandate.accountHolder }}</p>
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {{ $t('sepa.iban') }}
            </label>
            <p class="text-gray-900 dark:text-white font-mono">{{ getAnonymizedIban(mandate.iban) }}</p>
          </div>
          
          <div v-if="mandate.bic">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {{ $t('sepa.bic') }}
            </label>
            <p class="text-gray-900 dark:text-white font-mono">{{ mandate.bic }}</p>
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {{ $t('sepa.signedDate') }}
            </label>
            <p class="text-gray-900 dark:text-white">{{ formatDate(mandate.signedDate) }}</p>
          </div>
          
          <div v-if="mandate.validUntil">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {{ $t('sepa.validUntil') }}
            </label>
            <p class="text-gray-900 dark:text-white">{{ formatDate(mandate.validUntil) }}</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Create/Edit Form -->
    <div v-if="!hasActiveMandate || showEditForm" class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
      <div class="p-6">
        <div class="flex items-center justify-between mb-6">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white">
            {{ hasActiveMandate ? $t('sepa.editMandate') : $t('sepa.createMandate') }}
          </h3>
          <button
            v-if="showEditForm"
            @click="cancelEdit"
            class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
          >
            <Icon name="heroicons:x-mark" class="w-6 h-6" />
          </button>
        </div>

        <form @submit.prevent="submitForm" class="space-y-6">
          <!-- Account Holder -->
          <div>
            <label for="accountHolder" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('sepa.accountHolder') }} *
            </label>
            <input
              id="accountHolder"
              v-model="form.accountHolder"
              type="text"
              required
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              :placeholder="$t('sepa.accountHolderPlaceholder')"
            />
            <p v-if="errors.accountHolder" class="mt-1 text-sm text-red-600 dark:text-red-400">
              {{ errors.accountHolder }}
            </p>
          </div>

          <!-- IBAN -->
          <div>
            <label for="iban" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('sepa.iban') }} *
            </label>
            <input
              id="iban"
              v-model="form.iban"
              type="text"
              required
              maxlength="34"
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
              :placeholder="$t('sepa.ibanPlaceholder')"
              @input="formatIbanInput"
            />
            <p v-if="errors.iban" class="mt-1 text-sm text-red-600 dark:text-red-400">
              {{ errors.iban }}
            </p>
            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {{ $t('sepa.ibanHelp') }}
            </p>
          </div>

          <!-- BIC -->
          <div>
            <label for="bic" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('sepa.bic') }}
            </label>
            <input
              id="bic"
              v-model="form.bic"
              type="text"
              maxlength="11"
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
              :placeholder="$t('sepa.bicPlaceholder')"
              @input="form.bic = form.bic.toUpperCase()"
            />
            <p v-if="errors.bic" class="mt-1 text-sm text-red-600 dark:text-red-400">
              {{ errors.bic }}
            </p>
            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {{ $t('sepa.bicHelp') }}
            </p>
          </div>

          <!-- Valid Until -->
          <div>
            <label for="validUntil" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {{ $t('sepa.validUntil') }}
            </label>
            <input
              id="validUntil"
              v-model="form.validUntil"
              type="date"
              :min="minDate"
              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {{ $t('sepa.validUntilHelp') }}
            </p>
          </div>

          <!-- Agreement Checkbox -->
          <div class="flex items-start">
            <input
              id="agreement"
              v-model="form.agreement"
              type="checkbox"
              required
              class="mt-1 h-4 w-4 text-blue-600 border-gray-300 dark:border-gray-600 rounded focus:ring-blue-500"
            />
            <label for="agreement" class="ml-3 text-sm text-gray-700 dark:text-gray-300">
              {{ $t('sepa.mandateAgreement') }} *
            </label>
          </div>

          <!-- Submit Buttons -->
          <div class="flex justify-end space-x-3 pt-6 border-t border-gray-200 dark:border-gray-700">
            <button
              v-if="showEditForm"
              type="button"
              @click="cancelEdit"
              class="px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-lg text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              {{ $t('common.cancel') }}
            </button>
            <button
              type="submit"
              :disabled="loading || !isFormValid"
              class="inline-flex items-center px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-medium rounded-lg transition-colors"
            >
              <Icon v-if="loading" name="heroicons:arrow-path" class="w-4 h-4 mr-2 animate-spin" />
              {{ hasActiveMandate ? $t('sepa.updateMandate') : $t('sepa.createMandate') }}
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- Revoke Confirmation Modal -->
    <div v-if="showRevokeConfirm" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full">
        <div class="p-6">
          <div class="flex items-center mb-4">
            <div class="flex-shrink-0">
              <Icon name="heroicons:exclamation-triangle" class="w-6 h-6 text-red-600" />
            </div>
            <div class="ml-3">
              <h3 class="text-lg font-medium text-gray-900 dark:text-white">
                {{ $t('sepa.confirmRevoke') }}
              </h3>
            </div>
          </div>
          
          <p class="text-sm text-gray-600 dark:text-gray-400 mb-6">
            {{ $t('sepa.confirmRevokeText') }}
          </p>
          
          <div class="flex justify-end space-x-3">
            <button
              @click="showRevokeConfirm = false"
              class="px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-lg text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              {{ $t('common.cancel') }}
            </button>
            <button
              @click="confirmRevoke"
              :disabled="loading"
              class="inline-flex items-center px-4 py-2 bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white font-medium rounded-lg transition-colors"
            >
              <Icon v-if="loading" name="heroicons:arrow-path" class="w-4 h-4 mr-2 animate-spin" />
              {{ $t('sepa.revokeMandate') }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
const { t } = useI18n()
const sepaStore = useSepaManagementStore()

const {
  mandate,
  loading,
  hasActiveMandate,
  isMandateActive,
  isExpiringSoon,
  loadMandate,
  saveMandate,
  revokeMandate,
  formatIban,
  validateIban,
  validateBic,
  getAnonymizedIban,
  formatDate
} = sepaStore

// Local state
const showEditForm = ref(false)
const showRevokeConfirm = ref(false)
const errors = ref({})

// Form data
const form = ref({
  accountHolder: '',
  iban: '',
  bic: '',
  validUntil: '',
  agreement: false
})

// Computed
const minDate = computed(() => {
  const tomorrow = new Date()
  tomorrow.setDate(tomorrow.getDate() + 1)
  return tomorrow.toISOString().split('T')[0]
})

const isFormValid = computed(() => {
  return form.value.accountHolder.trim().length >= 2 &&
         validateIban(form.value.iban) &&
         (form.value.bic === '' || validateBic(form.value.bic)) &&
         form.value.agreement
})

// Methods
const loadMandateData = () => {
  if (mandate.value) {
    form.value = {
      accountHolder: mandate.value.accountHolder || '',
      iban: formatIban(mandate.value.iban) || '',
      bic: mandate.value.bic || '',
      validUntil: mandate.value.validUntil ? new Date(mandate.value.validUntil).toISOString().split('T')[0] : '',
      agreement: false
    }
  }
}

const formatIbanInput = (event) => {
  const value = event.target.value.toUpperCase().replace(/\s/g, '')
  form.value.iban = formatIban(value)
  validateForm()
}

const validateForm = () => {
  errors.value = {}
  
  if (form.value.accountHolder.trim().length < 2) {
    errors.value.accountHolder = t('sepa.accountHolderRequired')
  }
  
  if (form.value.iban && !validateIban(form.value.iban)) {
    errors.value.iban = t('sepa.ibanValidation')
  }
  
  if (form.value.bic && !validateBic(form.value.bic)) {
    errors.value.bic = t('sepa.bicValidation')
  }
}

const submitForm = async () => {
  validateForm()
  
  if (Object.keys(errors.value).length > 0) {
    return
  }
  
  try {
    const mandateData = {
      accountHolder: form.value.accountHolder.trim(),
      iban: form.value.iban.replace(/\s/g, ''),
      bic: form.value.bic || undefined,
      validUntil: form.value.validUntil || undefined
    }
    
    await saveMandate(mandateData)
    
    // Reset form
    if (!hasActiveMandate.value) {
      form.value = {
        accountHolder: '',
        iban: '',
        bic: '',
        validUntil: '',
        agreement: false
      }
    }
    
    showEditForm.value = false
    
  } catch (error) {
    // Error handling is done in the composable
  }
}

const confirmRevoke = async () => {
  try {
    await revokeMandate()
    showRevokeConfirm.value = false
  } catch (error) {
    // Error handling is done in the composable
  }
}

const cancelEdit = () => {
  showEditForm.value = false
  errors.value = {}
  loadMandateData() // Reset form to original values
}

// Lifecycle
onMounted(() => {
  loadMandate()
})

// Watch for mandate changes to populate form
watch(mandate, () => {
  if (showEditForm.value) {
    loadMandateData()
  }
})

// Page meta
definePageMeta({
  layout: 'customer',
  middleware: 'auth'
})
</script>
