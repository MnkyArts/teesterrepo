<template>
  <div class="space-y-6">
    <!-- Header -->
    <div class="flex justify-between items-center">
      <div>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
          Enum-Verwaltung
        </h1>
        <p class="text-gray-600 dark:text-gray-400 mt-1">
          Verwalte dynamische Aufgaben- und Ticket-Eigenschaften
        </p>
      </div>
      <button
        @click="showCreateCategoryModal = true"
        class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
      >
        <PlusIcon class="w-4 h-4" />
        Neue Kategorie
      </button>
    </div>

    <!-- Loading State -->
    <div v-if="enumStore.loading" class="flex justify-center py-8">
      <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
    </div>

    <!-- Error State -->
    <div v-else-if="enumStore.error" class="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
      <div class="flex items-center gap-2 text-red-800 dark:text-red-200">
        <ExclamationTriangleIcon class="w-5 h-5" />
        <span class="font-medium">Fehler beim Laden der Daten</span>
      </div>
      <p class="text-red-600 dark:text-red-400 mt-1">{{ enumStore.error }}</p>
    </div>

    <!-- Categories List -->
    <div v-else class="space-y-6">
      <div
        v-for="category in enumStore.categories"
        :key="category.id"
        class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden"
      >
        <!-- Category Header -->
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
          <div class="flex items-center gap-3">
            <div class="flex items-center gap-2">
              <component 
                :is="getCategoryIcon(category.name)" 
                class="w-5 h-5 text-gray-500 dark:text-gray-400"
              />
              <h3 class="text-lg font-medium text-gray-900 dark:text-white">
                {{ category.label }}
              </h3>
              <span 
                v-if="category.isSystem"
                class="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 rounded"
              >
                System
              </span>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <span class="text-sm text-gray-500 dark:text-gray-400">
              {{ category.values.length }} Werte
            </span>
            <button
              @click="openCreateValueModal(category)"
              class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm flex items-center gap-1"
            >
              <PlusIcon class="w-3 h-3" />
              Wert hinzufügen
            </button>
            <button
              v-if="!category.isSystem"
              @click="editCategory(category)"
              class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <PencilIcon class="w-4 h-4" />
            </button>
          </div>
        </div>

        <!-- Values List -->
        <div class="p-6">
          <p v-if="category.description" class="text-gray-600 dark:text-gray-400 mb-4">
            {{ category.description }}
          </p>
          
          <div v-if="category.values.length === 0" class="text-center py-8 text-gray-500 dark:text-gray-400">
            Keine Werte in dieser Kategorie
          </div>

          <div v-else class="grid gap-3">
            <div
              v-for="value in sortedValues(category.values)"
              :key="value.id"
              class="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-600 rounded-lg"
              :class="{ 'opacity-50': !value.isActive }"
            >
              <!-- Value Info -->
              <div class="flex items-center gap-3">
                <div class="flex items-center gap-2">
                  <!-- Color indicator -->
                  <div
                    v-if="value.color"
                    class="w-3 h-3 rounded-full border border-gray-300 dark:border-gray-600"
                    :style="{ backgroundColor: value.color }"
                  ></div>
                  <!-- Icon -->
                  <component
                    v-if="value.icon"
                    :is="getHeroIcon(value.icon)"
                    class="w-4 h-4 text-gray-500 dark:text-gray-400"
                  />
                  <!-- Label -->
                  <span class="font-medium text-gray-900 dark:text-white">
                    {{ value.label }}
                  </span>
                  <!-- Key -->
                  <code class="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 rounded">
                    {{ value.key }}
                  </code>
                  <!-- Default badge -->
                  <span 
                    v-if="value.isDefault"
                    class="px-2 py-1 text-xs bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 rounded"
                  >
                    Standard
                  </span>
                  <!-- Active/Inactive badge -->
                  <span 
                    class="px-2 py-1 text-xs rounded"
                    :class="value.isActive 
                      ? 'bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-300'
                      : 'bg-red-100 dark:bg-red-900 text-red-600 dark:text-red-300'
                    "
                  >
                    {{ value.isActive ? 'Aktiv' : 'Inaktiv' }}
                  </span>
                </div>
              </div>

              <!-- Actions -->
              <div class="flex items-center gap-2">
                <button
                  @click="editValue(value, category)"
                  class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <PencilIcon class="w-4 h-4" />
                </button>
                <button
                  @click="deleteValue(value, category)"
                  class="text-red-400 hover:text-red-600"
                >
                  <TrashIcon class="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Create Category Modal -->
    <EnumCategoryModal
      v-model:show="showCreateCategoryModal"
      @created="handleCategoryCreated"
    />

    <!-- Edit Category Modal -->
    <EnumCategoryModal
      v-model:show="showEditCategoryModal"
      :category="editingCategory"
      @updated="handleCategoryUpdated"
    />

    <!-- Create Value Modal -->
    <EnumValueModal
      v-model:show="showCreateValueModal"
      :category="selectedCategory"
      @created="handleValueCreated"
    />

    <!-- Edit Value Modal -->
    <EnumValueModal
      v-model:show="showEditValueModal"
      :category="selectedCategory"
      :value="editingValue"
      @updated="handleValueUpdated"
    />

    <!-- Confirm Delete Modal -->
    <ConfirmDialog
      :isOpen="showDeleteConfirm"
      :title="deleteTarget?.type === 'category' ? 'Kategorie löschen' : 'Wert löschen'"
      :message="deleteTarget?.type === 'category' 
        ? `Möchten Sie die Kategorie '${deleteTarget?.item?.label}' wirklich löschen?`
        : `Möchten Sie den Wert '${deleteTarget?.item?.label}' wirklich löschen?`
      "
      variant="danger"
      @confirm="confirmDelete"
      @cancel="showDeleteConfirm = false"
    />
  </div>
</template>

<script setup lang="ts">
import { 
  PlusIcon, 
  PencilIcon, 
  TrashIcon,
  ExclamationTriangleIcon,
  TagIcon,
  FlagIcon,
  ChartBarIcon,
  TicketIcon,
  CheckCircleIcon
} from '@heroicons/vue/24/outline'
import type { EnumCategory, EnumValue } from '@prisma/client'

// Composables
const enumStore = useEnumManagementStore()
const { success: notifySuccess, error: notifyError } = useNotifications()

// State
const showCreateCategoryModal = ref(false)
const showEditCategoryModal = ref(false)
const showCreateValueModal = ref(false)
const showEditValueModal = ref(false)
const showDeleteConfirm = ref(false)

const editingCategory = ref<EnumCategory | null>(null)
const selectedCategory = ref<EnumCategory | null>(null)
const editingValue = ref<EnumValue | null>(null)
const deleteTarget = ref<{ type: 'category' | 'value', item: any } | null>(null)

// Computed
const sortedValues = (values: readonly EnumValue[]) => {
  return [...values].sort((a, b) => a.sortOrder - b.sortOrder)
}

// Methods
const getCategoryIcon = (categoryName: string) => {
  const iconMap: Record<string, any> = {
    'task_type': TagIcon,
    'priority': FlagIcon,
    'task_status': ChartBarIcon,
    'ticket_type': TicketIcon,
    'ticket_status': CheckCircleIcon
  }
  return iconMap[categoryName] || TagIcon
}

const getHeroIcon = (iconName: string) => {
  // Hier würden Sie eine Map für alle verfügbaren Heroicons erstellen
  // Für jetzt verwenden wir ein Default-Icon
  return TagIcon
}

const openCreateValueModal = (category: EnumCategory) => {
  selectedCategory.value = category
  showCreateValueModal.value = true
}

const editCategory = (category: EnumCategory) => {
  editingCategory.value = category
  showEditCategoryModal.value = true
}

const editValue = (value: EnumValue, category: EnumCategory) => {
  editingValue.value = value
  selectedCategory.value = category
  showEditValueModal.value = true
}

const deleteValue = (value: EnumValue, category: EnumCategory) => {
  deleteTarget.value = { type: 'value', item: value }
  showDeleteConfirm.value = true
}

const handleCategoryCreated = async () => {
  showCreateCategoryModal.value = false
  await enumStore.fetchCategories()
  notifySuccess('Erfolg', 'Kategorie erfolgreich erstellt')
}

const handleCategoryUpdated = async () => {
  showEditCategoryModal.value = false
  editingCategory.value = null
  await enumStore.fetchCategories()
  notifySuccess('Erfolg', 'Kategorie erfolgreich aktualisiert')
}

const handleValueCreated = async () => {
  showCreateValueModal.value = false
  selectedCategory.value = null
  await enumStore.fetchCategories()
  notifySuccess('Erfolg', 'Wert erfolgreich erstellt')
}

const handleValueUpdated = async () => {
  showEditValueModal.value = false
  editingValue.value = null
  selectedCategory.value = null
  await enumStore.fetchCategories()
  notifySuccess('Erfolg', 'Wert erfolgreich aktualisiert')
}

const confirmDelete = async () => {
  if (!deleteTarget.value) return

  try {
    if (deleteTarget.value.type === 'category') {
      await enumStore.deleteCategory(deleteTarget.value.item.id)
      notifySuccess('Erfolg', 'Kategorie erfolgreich gelöscht')
    } else {
      await enumStore.deleteValue(deleteTarget.value.item.id)
      notifySuccess('Erfolg', 'Wert erfolgreich gelöscht')
    }
  } catch (error: any) {
    notifyError('Fehler', error.message || 'Fehler beim Löschen')
  } finally {
    showDeleteConfirm.value = false
    deleteTarget.value = null
  }
}

// Lifecycle
onMounted(async () => {
  await enumStore.fetchCategories()
})

// Meta
definePageMeta({
  title: 'Enum-Verwaltung',
  description: 'Verwalte dynamische Aufgaben- und Ticket-Eigenschaften'
})
</script>
