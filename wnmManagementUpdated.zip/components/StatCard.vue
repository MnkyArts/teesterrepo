<template>
  <div class="card p-6">
    <div class="flex items-center justify-between">
      <div class="flex items-center">
        <div class="p-2 rounded-lg" :class="iconBgColor">
          <component :is="iconComponent" class="h-6 w-6" :class="iconColor" />
        </div>
        <div class="ml-4">
          <p class="text-sm font-medium text-gray-600 dark:text-gray-400">
            {{ title }}
          </p>
          <div class="flex items-baseline">
            <p class="text-2xl font-semibold text-gray-900 dark:text-white">
              {{ value }}{{ suffix }}
            </p>
            <div v-if="change !== undefined" class="ml-2 flex items-baseline text-sm">
              <span :class="changeColor">
                {{ change > 0 ? '+' : '' }}{{ change }}
              </span>
              <ChevronUpIcon v-if="change > 0" class="h-3 w-3 text-green-500 ml-1" />
              <ChevronDownIcon v-else-if="change < 0" class="h-3 w-3 text-red-500 ml-1" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import {
  ClipboardDocumentListIcon,
  FolderIcon,
  ClockIcon,
  TicketIcon,
  ChevronUpIcon,
  ChevronDownIcon,
  UsersIcon,
  ChartBarIcon
} from '@heroicons/vue/24/outline'

interface Props {
  title: string
  value: string | number
  icon: string | any // Allow both string and component
  color: 'blue' | 'green' | 'purple' | 'orange' | 'red'
  change?: number
  suffix?: string
}

const props = defineProps<Props>()

// Icon mapping
const iconMap = {
  ClipboardDocumentListIcon,
  FolderIcon,
  ClockIcon,
  TicketIcon,
  UsersIcon,
  ChartBarIcon
}

const iconComponent = computed(() => {
  // If icon is already a component, return it directly
  if (typeof props.icon === 'object' || typeof props.icon === 'function') {
    return props.icon
  }
  // Otherwise, map string to component
  return iconMap[props.icon as keyof typeof iconMap]
})

const iconBgColor = computed(() => {
  const colors = {
    blue: 'bg-blue-100 dark:bg-blue-900',
    green: 'bg-green-100 dark:bg-green-900',
    purple: 'bg-purple-100 dark:bg-purple-900',
    orange: 'bg-orange-100 dark:bg-orange-900',
    red: 'bg-red-100 dark:bg-red-900'
  }
  return colors[props.color]
})

const iconColor = computed(() => {
  const colors = {
    blue: 'text-blue-600 dark:text-blue-400',
    green: 'text-green-600 dark:text-green-400',
    purple: 'text-purple-600 dark:text-purple-400',
    orange: 'text-orange-600 dark:text-orange-400',
    red: 'text-red-600 dark:text-red-400'
  }
  return colors[props.color]
})

const changeColor = computed(() => {
  if (props.change === undefined) return ''
  return props.change > 0 ? 'text-green-600' : props.change < 0 ? 'text-red-600' : 'text-gray-500'
})
</script>
