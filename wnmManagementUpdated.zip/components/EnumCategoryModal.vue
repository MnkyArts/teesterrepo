<template>
  <div
    v-if="show"
    class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
    @click="close"
  >
    <div
      class="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md"
      @click.stop
    >
      <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">
        {{ category ? 'Kategorie bearbeiten' : 'Neue Kategorie erstellen' }}
      </h3>

      <form @submit.prevent="save" class="space-y-4">
        <!-- Name (nur bei neuen Kategorien) -->
        <div v-if="!category">
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Interner Name *
          </label>
          <input
            v-model="form.name"
            type="text"
            required
            placeholder="z.B. task_type"
            pattern="[a-z_]+"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
          <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
            Nur Kleinbuchstaben und Unterstriche erlaubt
          </p>
        </div>

        <!-- Label -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Anzeigename *
          </label>
          <input
            v-model="form.label"
            type="text"
            required
            placeholder="z.B. Aufgabentyp"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
        </div>

        <!-- Description -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Beschreibung
          </label>
          <textarea
            v-model="form.description"
            rows="3"
            placeholder="Optionale Beschreibung der Kategorie"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          ></textarea>
        </div>

        <!-- Sort Order -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Sortierreihenfolge
          </label>
          <input
            v-model.number="form.sortOrder"
            type="number"
            min="0"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
        </div>

        <!-- System Category (nur bei neuen Kategorien) -->
        <div v-if="!category" class="flex items-center">
          <input
            v-model="form.isSystem"
            type="checkbox"
            id="isSystem"
            class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 focus:ring-2"
          >
          <label for="isSystem" class="ml-2 text-sm text-gray-700 dark:text-gray-300">
            System-Kategorie (kann nicht gelöscht werden)
          </label>
        </div>

        <!-- Actions -->
        <div class="flex justify-end gap-3 pt-4">
          <button
            type="button"
            @click="close"
            class="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"
          >
            Abbrechen
          </button>
          <button
            type="submit"
            :disabled="loading"
            class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg disabled:opacity-50 flex items-center gap-2"
          >
            <div v-if="loading" class="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            {{ category ? 'Aktualisieren' : 'Erstellen' }}
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { EnumCategory } from '@prisma/client'

interface Props {
  show: boolean
  category?: EnumCategory | null
}

interface Emits {
  (e: 'update:show', value: boolean): void
  (e: 'created'): void
  (e: 'updated'): void
}

const props = withDefaults(defineProps<Props>(), {
  category: null
})

const emit = defineEmits<Emits>()

// Composables
const enumStore = useEnumManagementStore()

// State
const loading = ref(false)
const form = ref({
  name: '',
  label: '',
  description: '',
  sortOrder: 0,
  isSystem: false
})

// Methods
const close = () => {
  emit('update:show', false)
  resetForm()
}

const resetForm = () => {
  if (props.category) {
    form.value = {
      name: props.category.name,
      label: props.category.label,
      description: props.category.description || '',
      sortOrder: props.category.sortOrder,
      isSystem: props.category.isSystem
    }
  } else {
    form.value = {
      name: '',
      label: '',
      description: '',
      sortOrder: 0,
      isSystem: false
    }
  }
}

const save = async () => {
  loading.value = true
  
  try {
    if (props.category) {
      // Update existing category
      await enumStore.updateCategory(props.category.id, {
        label: form.value.label,
        description: form.value.description || undefined,
        sortOrder: form.value.sortOrder
      })
      emit('updated')
    } else {
      // Create new category
      await enumStore.createCategory({
        name: form.value.name,
        label: form.value.label,
        description: form.value.description || undefined,
        sortOrder: form.value.sortOrder,
        isSystem: form.value.isSystem
      })
      emit('created')
    }
  } catch (error: any) {
    console.error('Error saving category:', error)
  } finally {
    loading.value = false
  }
}

// Watch for props changes
watch(() => props.show, (newShow) => {
  if (newShow) {
    resetForm()
  }
})

watch(() => props.category, () => {
  if (props.show) {
    resetForm()
  }
})
</script>
