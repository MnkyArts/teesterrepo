<template>
  <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 animate-pulse">
    <!-- Header -->
    <div class="flex items-start justify-between mb-4">
      <div class="flex-1">
        <div class="flex items-center gap-2 mb-2">
          <div class="h-6 w-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
          <div class="h-6 w-20 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
        </div>
        <div class="h-6 w-48 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
        <div class="h-4 w-32 bg-gray-200 dark:bg-gray-700 rounded"></div>
      </div>
      <div class="h-8 w-8 bg-gray-200 dark:bg-gray-700 rounded"></div>
    </div>

    <!-- Description -->
    <div class="space-y-2 mb-4">
      <div class="h-4 w-full bg-gray-200 dark:bg-gray-700 rounded"></div>
      <div class="h-4 w-3/4 bg-gray-200 dark:bg-gray-700 rounded"></div>
    </div>

    <!-- Stats -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
      <div class="text-center">
        <div class="h-6 w-8 bg-gray-200 dark:bg-gray-700 rounded mx-auto mb-1"></div>
        <div class="h-3 w-12 bg-gray-200 dark:bg-gray-700 rounded mx-auto"></div>
      </div>
      <div class="text-center">
        <div class="h-6 w-8 bg-gray-200 dark:bg-gray-700 rounded mx-auto mb-1"></div>
        <div class="h-3 w-16 bg-gray-200 dark:bg-gray-700 rounded mx-auto"></div>
      </div>
      <div class="text-center">
        <div class="h-6 w-12 bg-gray-200 dark:bg-gray-700 rounded mx-auto mb-1"></div>
        <div class="h-3 w-12 bg-gray-200 dark:bg-gray-700 rounded mx-auto"></div>
      </div>
      <div class="text-center">
        <div class="h-6 w-12 bg-gray-200 dark:bg-gray-700 rounded mx-auto mb-1"></div>
        <div class="h-3 w-16 bg-gray-200 dark:bg-gray-700 rounded mx-auto"></div>
      </div>
    </div>

    <!-- Progress Bar -->
    <div class="mb-4">
      <div class="flex justify-between mb-1">
        <div class="h-3 w-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
        <div class="h-3 w-8 bg-gray-200 dark:bg-gray-700 rounded"></div>
      </div>
      <div class="h-2 w-full bg-gray-200 dark:bg-gray-700 rounded-full"></div>
    </div>

    <!-- Team Members -->
    <div class="flex items-center justify-between">
      <div class="flex items-center gap-2">
        <div class="h-4 w-12 bg-gray-200 dark:bg-gray-700 rounded"></div>
        <div class="flex -space-x-2">
          <div class="h-6 w-6 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
          <div class="h-6 w-6 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
          <div class="h-6 w-6 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
        </div>
      </div>
      <div class="h-3 w-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
    </div>
  </div>
</template>
