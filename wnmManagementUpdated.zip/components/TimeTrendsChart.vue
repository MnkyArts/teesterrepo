<template>
  <div class="space-y-4">
    <!-- Chart Container -->
    <div class="h-64 w-full">
      <canvas ref="chartCanvas" class="w-full h-full"></canvas>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick, watch } from 'vue'

interface TimeTrendData {
  date: string
  hours: number
  billableHours: number
}

interface Props {
  data: TimeTrendData[]
}

const props = defineProps<Props>()

const chartCanvas = ref<HTMLCanvasElement>()

const renderChart = async () => {
  await nextTick()
  
  if (!chartCanvas.value || !props.data.length) return
  
  const ctx = chartCanvas.value.getContext('2d')
  if (!ctx) return
  
  const { width, height } = chartCanvas.value
  
  ctx.clearRect(0, 0, width, height)
  
  // Chart dimensions
  const padding = 40
  const chartWidth = width - 2 * padding
  const chartHeight = height - 2 * padding
  
  // Find max value for scaling
  const maxHours = Math.max(...props.data.map(d => Math.max(d.hours, d.billableHours)))
  const scale = chartHeight / (maxHours * 1.1) // Add 10% padding
  
  // Draw grid lines
  ctx.strokeStyle = '#E5E7EB'
  ctx.lineWidth = 1
  
  for (let i = 0; i <= 5; i++) {
    const y = padding + (chartHeight / 5) * i
    ctx.beginPath()
    ctx.moveTo(padding, y)
    ctx.lineTo(width - padding, y)
    ctx.stroke()
  }
  
  // Draw axes
  ctx.strokeStyle = '#374151'
  ctx.lineWidth = 2
  ctx.beginPath()
  ctx.moveTo(padding, padding)
  ctx.lineTo(padding, height - padding)
  ctx.lineTo(width - padding, height - padding)
  ctx.stroke()
  
  // Draw data lines
  const stepX = chartWidth / (props.data.length - 1)
  
  // Total hours line
  ctx.strokeStyle = '#3B82F6'
  ctx.lineWidth = 3
  ctx.beginPath()
  props.data.forEach((point, index) => {
    const x = padding + index * stepX
    const y = height - padding - (point.hours * scale)
    
    if (index === 0) {
      ctx.moveTo(x, y)
    } else {
      ctx.lineTo(x, y)
    }
  })
  ctx.stroke()
  
  // Billable hours line
  ctx.strokeStyle = '#10B981'
  ctx.lineWidth = 3
  ctx.beginPath()
  props.data.forEach((point, index) => {
    const x = padding + index * stepX
    const y = height - padding - (point.billableHours * scale)
    
    if (index === 0) {
      ctx.moveTo(x, y)
    } else {
      ctx.lineTo(x, y)
    }
  })
  ctx.stroke()
  
  // Draw data points
  props.data.forEach((point, index) => {
    const x = padding + index * stepX
    
    // Total hours point
    const totalY = height - padding - (point.hours * scale)
    ctx.fillStyle = '#3B82F6'
    ctx.beginPath()
    ctx.arc(x, totalY, 4, 0, 2 * Math.PI)
    ctx.fill()
    
    // Billable hours point
    const billableY = height - padding - (point.billableHours * scale)
    ctx.fillStyle = '#10B981'
    ctx.beginPath()
    ctx.arc(x, billableY, 4, 0, 2 * Math.PI)
    ctx.fill()
  })
  
  // Labels
  ctx.fillStyle = '#374151'
  ctx.font = '12px system-ui'
  ctx.textAlign = 'center'
  
  props.data.forEach((point, index) => {
    const x = padding + index * stepX
    const label = new Date(point.date).toLocaleDateString('de-DE', { 
      month: 'short', 
      day: 'numeric' 
    })
    ctx.fillText(label, x, height - padding + 20)
  })
}

const resizeCanvas = () => {
  if (!chartCanvas.value) return
  
  const container = chartCanvas.value.parentElement
  if (!container) return
  
  chartCanvas.value.width = container.clientWidth
  chartCanvas.value.height = container.clientHeight
  
  renderChart()
}

watch(() => props.data, () => {
  renderChart()
}, { deep: true })

onMounted(() => {
  resizeCanvas()
  window.addEventListener('resize', resizeCanvas)
})
</script>
