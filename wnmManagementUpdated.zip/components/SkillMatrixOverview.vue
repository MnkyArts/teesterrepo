<template>
  <div class="space-y-6">
    <!-- Header -->
    <div class="flex items-center justify-between">
      <div>
        <h2 class="text-xl font-semibold text-gray-900 dark:text-white">
          Skill-Matrix Übersicht
        </h2>
        <p class="text-sm text-gray-600 dark:text-gray-400">
          Vollständige Übersicht aller Team-Skills und Kompetenzen
        </p>
      </div>
      
      <div class="flex items-center space-x-3">
        <button
          @click="refreshSkillMatrix"
          :disabled="loading"
          class="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 text-sm font-medium rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
        >
          <ArrowPathIcon class="h-4 w-4 mr-2" :class="{ 'animate-spin': loading }" />
          Aktualisieren
        </button>
        
        <button
          @click="exportSkillMatrix"
          class="inline-flex items-center px-3 py-2 bg-primary-600 hover:bg-primary-700 text-white text-sm font-medium rounded-lg transition-colors"
        >
          <DocumentArrowDownIcon class="h-4 w-4 mr-2" />
          Exportieren
        </button>
      </div>
    </div>

    <!-- Loading State -->
    <div v-if="loading && !skillMatrixData" class="flex items-center justify-center h-64">
      <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
    </div>

    <!-- Skill Matrix Content -->
    <div v-else-if="skillMatrixData" class="space-y-6">
      <!-- Summary Stats -->
      <div class="grid grid-cols-1 md:grid-cols-5 gap-4">
        <StatCard
          title="Gesamt Skills"
          :value="skillMatrixData.summary.totalSkills"
          icon="academic-cap"
          color="blue"
        />
        <StatCard
          title="Kategorien"
          :value="skillMatrixData.summary.totalCategories"
          icon="folder"
          color="green"
        />
        <StatCard
          title="Team Mitglieder"
          :value="skillMatrixData.summary.totalTeamMembers"
          icon="users"
          color="purple"
        />
        <StatCard
          title="Ø Skills/Person"
          :value="skillMatrixData.summary.averageSkillsPerMember.toFixed(1)"
          icon="chart-bar"
          color="orange"
        />
        <StatCard
          title="Verifizierungsrate"
          :value="`${skillMatrixData.summary.verificationRate.toFixed(0)}%`"
          icon="check-badge"
          color="green"
        />
      </div>

      <!-- View Toggle -->
      <div class="flex space-x-1 bg-gray-100 dark:bg-gray-800 p-1 rounded-lg w-fit">
        <button
          v-for="view in views"
          :key="view.value"
          @click="currentView = view.value"
          :class="[
            'px-3 py-2 text-sm font-medium rounded-md transition-all',
            currentView === view.value
              ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
              : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
          ]"
        >
          <component :is="view.icon" class="h-4 w-4 mr-1.5 inline" />
          {{ view.label }}
        </button>
      </div>

      <!-- Skill Matrix View -->
      <div v-if="currentView === 'matrix'" class="space-y-6">
        <div
          v-for="category in skillMatrixData.skillMatrix"
          :key="category.category"
          class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden"
        >
          <!-- Category Header -->
          <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <div class="flex items-center justify-between">
              <h3 class="text-lg font-medium text-gray-900 dark:text-white">
                {{ category.category }}
              </h3>
              <span class="text-sm text-gray-500 dark:text-gray-400">
                {{ category.totalSkills }} Skills
              </span>
            </div>
          </div>

          <!-- Skills Grid -->
          <div class="p-6">
            <div class="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
              <div
                v-for="skill in category.skills"
                :key="skill.name"
                class="border border-gray-200 dark:border-gray-600 rounded-lg p-4 hover:border-primary-300 dark:hover:border-primary-600 transition-colors"
              >
                <!-- Skill Header -->
                <div class="flex items-center justify-between mb-3">
                  <h4 class="font-medium text-gray-900 dark:text-white">
                    {{ skill.name }}
                  </h4>
                  <span
                    :class="[
                      'inline-flex items-center px-2 py-1 rounded-full text-xs font-medium',
                      skill.verificationRate >= 75
                        ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                        : skill.verificationRate >= 50
                        ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                        : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                    ]"
                  >
                    {{ skill.verificationRate.toFixed(0) }}% verifiziert
                  </span>
                </div>

                <!-- Skill Stats -->
                <div class="grid grid-cols-2 gap-3 mb-3 text-sm">
                  <div>
                    <span class="text-gray-500 dark:text-gray-400">Benutzer:</span>
                    <span class="font-medium text-gray-900 dark:text-white ml-1">
                      {{ skill.totalUsers }}
                    </span>
                  </div>
                  <div>
                    <span class="text-gray-500 dark:text-gray-400">Ø Level:</span>
                    <span class="font-medium text-gray-900 dark:text-white ml-1">
                      {{ skill.averageLevel.toFixed(1) }}
                    </span>
                  </div>
                </div>

                <!-- User List -->
                <div class="space-y-2">
                  <div
                    v-for="userSkill in skill.users.slice(0, 3)"
                    :key="userSkill.user.id"
                    class="flex items-center justify-between"
                  >
                    <div class="flex items-center space-x-2">
                      <img
                        v-if="userSkill.user.avatar"
                        :src="userSkill.user.avatar"
                        :alt="`${userSkill.user.firstName} ${userSkill.user.lastName}`"
                        class="h-6 w-6 rounded-full"
                      >
                      <div
                        v-else
                        class="h-6 w-6 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center text-xs font-medium text-gray-700 dark:text-gray-300"
                      >
                        {{ getInitials(userSkill.user.firstName, userSkill.user.lastName) }}
                      </div>
                      <span class="text-sm text-gray-700 dark:text-gray-300">
                        {{ userSkill.user.firstName }} {{ userSkill.user.lastName }}
                      </span>
                    </div>
                    
                    <div class="flex items-center space-x-2">
                      <SkillLevelBadge :level="userSkill.level" size="sm" />
                      <CheckBadgeIcon
                        v-if="userSkill.verified"
                        class="h-4 w-4 text-green-500"
                        title="Verifiziert"
                      />
                      <button
                        v-if="canVerifySkills && !userSkill.verified"
                        @click="handleVerifySkill(userSkill, true)"
                        class="text-gray-400 hover:text-green-500 transition-colors"
                        title="Skill verifizieren"
                      >
                        <CheckIcon class="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  
                  <div
                    v-if="skill.users.length > 3"
                    class="text-xs text-gray-500 dark:text-gray-400 text-center pt-1"
                  >
                    +{{ skill.users.length - 3 }} weitere
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Top Skills View -->
      <div v-else-if="currentView === 'top-skills'" class="space-y-4">
        <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
          <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h3 class="text-lg font-medium text-gray-900 dark:text-white">
              Top 10 Skills im Team
            </h3>
          </div>
          
          <div class="p-6">
            <div class="space-y-4">
              <div
                v-for="(skill, index) in skillMatrixData.topSkills"
                :key="skill.name"
                class="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-600 rounded-lg"
              >
                <div class="flex items-center space-x-4">
                  <div
                    class="flex items-center justify-center w-8 h-8 bg-primary-100 dark:bg-primary-900 rounded-full text-primary-600 dark:text-primary-400 font-medium text-sm"
                  >
                    {{ index + 1 }}
                  </div>
                  <div>
                    <h4 class="font-medium text-gray-900 dark:text-white">
                      {{ skill.name }}
                    </h4>
                    <p class="text-sm text-gray-500 dark:text-gray-400">
                      {{ skill.totalUsers }} Personen • Ø Level {{ skill.averageLevel.toFixed(1) }}
                    </p>
                  </div>
                </div>
                
                <div class="flex items-center space-x-2">
                  <SkillLevelBadge :level="Math.round(skill.averageLevel)" />
                  <div class="w-24 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div
                      class="bg-primary-600 h-2 rounded-full"
                      :style="{ width: `${(skill.totalUsers / skillMatrixData.summary.totalTeamMembers) * 100}%` }"
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Coverage View -->
      <div v-else-if="currentView === 'coverage'">
        <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
          <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h3 class="text-lg font-medium text-gray-900 dark:text-white">
              Skill-Abdeckung pro Team-Mitglied
            </h3>
          </div>
          
          <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead class="bg-gray-50 dark:bg-gray-900">
                <tr>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Mitarbeiter
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Skills
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Verifiziert
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Ø Level
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Kategorien
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Abdeckung
                  </th>
                </tr>
              </thead>
              <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                <tr
                  v-for="coverage in skillMatrixData.skillCoverage"
                  :key="coverage.user.id"
                  class="hover:bg-gray-50 dark:hover:bg-gray-700"
                >
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex items-center space-x-3">
                      <img
                        v-if="coverage.user.avatar"
                        :src="coverage.user.avatar"
                        :alt="`${coverage.user.firstName} ${coverage.user.lastName}`"
                        class="h-8 w-8 rounded-full"
                      >
                      <div
                        v-else
                        class="h-8 w-8 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center text-sm font-medium text-gray-700 dark:text-gray-300"
                      >
                        {{ getInitials(coverage.user.firstName, coverage.user.lastName) }}
                      </div>
                      <div>
                        <div class="text-sm font-medium text-gray-900 dark:text-white">
                          {{ coverage.user.firstName }} {{ coverage.user.lastName }}
                        </div>
                        <UserRoleBadge :role="coverage.user.role" size="sm" />
                      </div>
                    </div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {{ coverage.totalSkills }}
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {{ coverage.verifiedSkills }}
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <SkillLevelBadge :level="Math.round(coverage.averageLevel)" />
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {{ coverage.categories.length }}
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex items-center space-x-2">
                      <div class="w-16 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div
                          class="bg-primary-600 h-2 rounded-full"
                          :style="{ width: `${Math.min(coverage.skillCoveragePercent, 100)}%` }"
                        ></div>
                      </div>
                      <span class="text-sm text-gray-500 dark:text-gray-400">
                        {{ coverage.skillCoveragePercent.toFixed(0) }}%
                      </span>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <!-- Error State -->
    <div v-else-if="error" class="text-center py-12">
      <ExclamationTriangleIcon class="mx-auto h-12 w-12 text-gray-400" />
      <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">
        Fehler beim Laden
      </h3>
      <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
        {{ error }}
      </p>
      <div class="mt-4">
        <button
          @click="refreshSkillMatrix"
          class="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
        >
          Erneut versuchen
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { 
  ArrowPathIcon, 
  DocumentArrowDownIcon,
  CheckBadgeIcon,
  CheckIcon,
  ExclamationTriangleIcon,
  TableCellsIcon,
  ChartBarIcon,
  UserGroupIcon
} from '@heroicons/vue/24/outline'

// Stores
const teamStore = useTeamManagementStore()
const { 
  skillMatrixData, 
  loading, 
  error
} = storeToRefs(teamStore)
const { 
  fetchSkillMatrix, 
  verifySkill 
} = teamStore

const authStore = useAuthStore()
const { user } = storeToRefs(authStore)
const { hasPermission } = authStore

// State
const currentView = ref('matrix')

// Views configuration
const views = [
  { value: 'matrix', label: 'Matrix', icon: TableCellsIcon },
  { value: 'top-skills', label: 'Top Skills', icon: ChartBarIcon },
  { value: 'coverage', label: 'Abdeckung', icon: UserGroupIcon }
]

// Computed
const canVerifySkills = computed(() => 
  hasPermission('PROJEKTLEITER')
)

// Methods
const refreshSkillMatrix = async () => {
  try {
    await fetchSkillMatrix()
  } catch (error) {
    console.error('Fehler beim Laden der Skill-Matrix:', error)
  }
}

const handleVerifySkill = async (userSkill: any, verified: boolean) => {
  try {
    if (verified) {
      await verifySkill(userSkill.userId, userSkill.id)
    }
    await refreshSkillMatrix()
  } catch (error) {
    console.error('Fehler bei der Skill-Verifizierung:', error)
  }
}

const exportSkillMatrix = async () => {
  try {
    // Implementation für CSV/PDF Export
    console.log('Export Skill-Matrix...')
  } catch (error) {
    console.error('Fehler beim Export:', error)
  }
}

const getInitials = (firstName: string, lastName: string) => {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
}

// Lifecycle
onMounted(() => {
  refreshSkillMatrix()
})
</script>
