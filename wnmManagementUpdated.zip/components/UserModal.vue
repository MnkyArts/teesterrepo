<template>
  <div
    v-if="isOpen"
    :class="`fixed inset-0 overflow-y-auto z-[${modalZIndex}]`"
    aria-labelledby="modal-title"
    role="dialog"
    aria-modal="true"
  >
    <!-- Backdrop -->
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
      <div
        class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
        @click="closeModal"
      ></div>

      <!-- Modal Panel -->
      <div class="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
        <!-- Header -->
        <div class="bg-white dark:bg-gray-800 px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-medium text-gray-900 dark:text-white">
              {{ isEdit ? 'Benutzer bearbeiten' : 'Neuen Benutzer erstellen' }}
            </h3>
            <button
              @click="closeModal"
              class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <XMarkIcon class="h-6 w-6" />
            </button>
          </div>

          <!-- Form -->
          <form @submit.prevent="handleSubmit" class="space-y-4">
            <!-- Vorname -->
            <div>
              <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Vorname *
              </label>
              <input
                v-model="form.firstName"
                type="text"
                required
                class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
                placeholder="Max"
              />
            </div>

            <!-- Nachname -->
            <div>
              <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Nachname *
              </label>
              <input
                v-model="form.lastName"
                type="text"
                required
                class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
                placeholder="Mustermann"
              />
            </div>

            <!-- E-Mail -->
            <div>
              <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                E-Mail-Adresse *
              </label>
              <input
                v-model="form.email"
                type="email"
                required
                class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
                placeholder="max.mustermann@beispiel.de"
              />
            </div>

            <!-- Rolle -->
            <div>
              <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Rolle *
              </label>
              <select
                v-model="form.role"
                required
                class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
              >
                <option value="">Rolle auswählen</option>
                <option
                  v-for="role in filteredRoles"
                  :key="role.value"
                  :value="role.value"
                >
                  {{ role.label }}
                </option>
              </select>
              <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                {{ getRoleDescription }}
              </p>
            </div>

            <!-- Avatar URL -->
            <div>
              <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Avatar URL (optional)
              </label>
              <input
                v-model="form.avatar"
                type="url"
                class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
                placeholder="https://beispiel.de/avatar.jpg"
              />
            </div>

            <!-- Status -->
            <div>
              <label class="flex items-center">
                <input
                  v-model="form.isActive"
                  type="checkbox"
                  class="rounded border-gray-300 text-primary-600 shadow-sm focus:ring-primary-500"
                />
                <span class="ml-2 text-sm text-gray-700 dark:text-gray-300">
                  Benutzer ist aktiv
                </span>
              </label>
            </div>

            <!-- Passwort-Hinweis für neue Benutzer -->
            <div v-if="!isEdit" class="bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
              <div class="flex">
                <InformationCircleIcon class="h-5 w-5 text-blue-400 flex-shrink-0" />
                <div class="ml-3">
                  <h3 class="text-sm font-medium text-blue-800 dark:text-blue-200">
                    Standard-Passwort
                  </h3>
                  <div class="mt-1 text-sm text-blue-700 dark:text-blue-300">
                    Neue Benutzer erhalten das Standard-Passwort <code class="bg-blue-100 dark:bg-blue-800 px-1 rounded">WnM2025!</code> und müssen es beim ersten Login ändern.
                  </div>
                </div>
              </div>
            </div>

            <!-- Error Message -->
            <div v-if="error" class="bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 rounded-lg p-3">
              <div class="flex">
                <ExclamationTriangleIcon class="h-5 w-5 text-red-400 flex-shrink-0" />
                <div class="ml-3">
                  <h3 class="text-sm font-medium text-red-800 dark:text-red-200">
                    Fehler
                  </h3>
                  <div class="mt-1 text-sm text-red-700 dark:text-red-300">
                    {{ error }}
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>

        <!-- Footer -->
        <div class="bg-gray-50 dark:bg-gray-700 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
          <button
            @click="handleSubmit"
            :disabled="loading"
            class="w-full inline-flex justify-center rounded-lg border border-transparent shadow-sm px-4 py-2 bg-primary-600 text-base font-medium text-white hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 sm:ml-3 sm:w-auto sm:text-sm disabled:opacity-50"
          >
            <ArrowPathIcon v-if="loading" class="animate-spin h-4 w-4 mr-2" />
            {{ isEdit ? 'Speichern' : 'Erstellen' }}
          </button>
          <button
            @click="closeModal"
            type="button"
            class="mt-3 w-full inline-flex justify-center rounded-lg border border-gray-300 dark:border-gray-600 shadow-sm px-4 py-2 bg-white dark:bg-gray-800 text-base font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
          >
            Abbrechen
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, reactive, watch } from 'vue'
import { XMarkIcon, ArrowPathIcon, InformationCircleIcon, ExclamationTriangleIcon } from '@heroicons/vue/24/outline'
import type { UserRole } from '@prisma/client'

interface Props {
  isOpen: boolean
  user?: any
}

const props = withDefaults(defineProps<Props>(), {
  user: null
})

const emit = defineEmits<{
  close: []
  created: [user: any]
  updated: [user: any]
}>()

// Stores
const authStore = useAuthStore()
const { user: currentUser } = storeToRefs(authStore)

const teamStore = useTeamManagementStore()
const { userRoles } = storeToRefs(teamStore)
const { createUser, updateUser } = teamStore

const uiStore = useUIStore()
const { openModal, closeModal: closeModalFromStack, getModalZIndex } = uiStore

// Modal ID for stack management
const modalId = computed(() => 
  props.user ? 'user-edit-modal' : 'user-create-modal'
)

// State
const loading = ref(false)
const error = ref('')

// Computed
const modalZIndex = computed(() => getModalZIndex(modalId.value))

// Form
const defaultForm = {
  firstName: '',
  lastName: '',
  email: '',
  role: '' as UserRole | '',
  avatar: '',
  isActive: true
}

const form = reactive({ ...defaultForm })

// Computed
const isEdit = computed(() => !!props.user)

const filteredRoles = computed(() => {
  // Normale Benutzer können keine Administratoren erstellen
  if (currentUser.value?.role !== 'ADMINISTRATOR') {
    return userRoles.value.filter((role: any) => role.value !== 'ADMINISTRATOR')
  }
  return userRoles.value
})

const getRoleDescription = computed(() => {
  const selectedRole = userRoles.value.find((role: any) => role.value === form.role)
  return selectedRole?.description || ''
})

// Methods
const resetForm = () => {
  Object.assign(form, defaultForm)
  error.value = ''
}

const closeModal = () => {
  closeModalFromStack(modalId.value)
  emit('close')
}

const handleSubmit = async () => {
  loading.value = true
  error.value = ''

  try {
    // Validate that role is selected
    if (!form.role) {
      error.value = 'Bitte wählen Sie eine Rolle aus'
      loading.value = false
      return
    }

    if (isEdit.value && props.user) {
      // Update user
      const updateData = {
        firstName: form.firstName,
        lastName: form.lastName,
        email: form.email,
        role: form.role as UserRole,
        avatar: form.avatar || undefined,
        isActive: form.isActive
      }
      
      const updatedUser = await updateUser(props.user.id, updateData)
      emit('updated', updatedUser)
    } else {
      // Create user
      const createData = {
        firstName: form.firstName,
        lastName: form.lastName,
        email: form.email,
        role: form.role as UserRole,
        avatar: form.avatar || undefined,
        isActive: form.isActive
      }
      
      const newUser = await createUser(createData)
      emit('created', newUser)
    }
    
    closeModal()
  } catch (err: any) {
    error.value = err?.data?.message || 'Ein Fehler ist aufgetreten'
  } finally {
    loading.value = false
  }
}

// Watchers
watch(() => props.isOpen, (isOpen) => {
  if (isOpen) {
    openModal(modalId.value)
    resetForm()
    if (props.user) {
      // Bearbeiten - Form mit User-Daten füllen
      form.firstName = props.user.firstName
      form.lastName = props.user.lastName
      form.email = props.user.email
      form.role = props.user.role
      form.avatar = props.user.avatar || ''
      form.isActive = props.user.isActive
    }
  } else {
    closeModalFromStack(modalId.value)
  }
}, { immediate: true })
</script>
