<template>
  <div v-if="task">
    <!-- Header -->
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg mb-6">
      <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
        <div class="flex items-center justify-between">
          <div class="flex items-center space-x-4">
            <button
              @click="$router.go(-1)"
              class="p-2 text-gray-400 hover:text-gray-500 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700">
              <ArrowLeftIcon class="h-5 w-5" />
            </button>
            <div>
              <div class="flex items-center space-x-3 mb-1">
                <span class="text-sm font-mono text-gray-500 dark:text-gray-400">{{ task.key }}</span>
                <TaskPropertyBadge :enum-value="task.status" />
                <TaskPropertyBadge :enum-value="task.priority" />
              </div>
              <h1 class="text-xl font-semibold text-gray-900 dark:text-white">{{ task.title }}</h1>
            </div>
          </div>
          
          <div class="flex items-center space-x-3">
            <button
              @click="editTask"
              class="px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600">
              <PencilIcon class="h-4 w-4 mr-1 inline" />
              Bearbeiten
            </button>
            <button
              @click="openTimeEntryModal"
              class="px-3 py-2 text-sm font-medium text-blue-700 dark:text-blue-400 bg-white dark:bg-gray-700 border border-blue-300 dark:border-blue-600 rounded-md hover:bg-blue-50 dark:hover:bg-blue-900/20">
              <ClockIcon class="h-4 w-4 mr-1 inline" />
              Arbeitszeit Buchen
            </button>
            <button
              @click="showDeleteConfirm = true"
              class="px-3 py-2 text-sm font-medium text-red-700 dark:text-red-400 bg-white dark:bg-gray-700 border border-red-300 dark:border-red-600 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20">
              <TrashIcon class="h-4 w-4 mr-1 inline" />
              Löschen
            </button>
          </div>
        </div>
      </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <!-- Hauptinhalt -->
      <div class="lg:col-span-2 space-y-6">
        
        <!-- Beschreibung -->
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6">
          <h2 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Beschreibung</h2>
          <div v-if="task.description" class="prose dark:prose-invert max-w-none">
            <p class="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{{ task.description }}</p>
          </div>
          <p v-else class="text-gray-500 dark:text-gray-400 italic">
            Keine Beschreibung verfügbar
          </p>
        </div>

        <!-- Kommentare -->
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6">
          <h2 class="text-lg font-medium text-gray-900 dark:text-white mb-4">
            Kommentare ({{ comments.length }})
          </h2>
          
          <!-- Kommentar hinzufügen -->
          <div class="mb-6">
            <form @submit.prevent="addComment" class="space-y-3">
              <textarea
                v-model="newComment"
                rows="3"
                placeholder="Kommentar hinzufügen..."
                class="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                required></textarea>
              <div class="flex items-center justify-between">
                <label class="flex items-center">
                  <input
                    v-model="isInternalComment"
                    type="checkbox"
                    class="rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500">
                  <span class="ml-2 text-sm text-gray-700 dark:text-gray-300">Interner Kommentar</span>
                </label>
                <button
                  type="submit"
                  :disabled="!newComment.trim() || loading"
                  class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed">
                  Kommentar hinzufügen
                </button>
              </div>
            </form>
          </div>

          <!-- Kommentarliste -->
          <div class="space-y-4">
            <div v-for="comment in comments" :key="comment.id" 
                 class="flex space-x-3 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div class="flex-shrink-0">
                <img v-if="comment.author.avatar" 
                     :src="comment.author.avatar"
                     :alt="`${comment.author.firstName} ${comment.author.lastName}`"
                     class="h-8 w-8 rounded-full object-cover">
                <div v-else class="h-8 w-8 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center">
                  <span class="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {{ comment.author.firstName.charAt(0) }}{{ comment.author.lastName.charAt(0) }}
                  </span>
                </div>
              </div>
              <div class="flex-1">
                <div class="flex items-center space-x-2 mb-1">
                  <h4 class="text-sm font-medium text-gray-900 dark:text-white">
                    {{ comment.author.firstName }} {{ comment.author.lastName }}
                  </h4>
                  <span class="text-xs text-gray-500 dark:text-gray-400">
                    {{ formatDate(comment.createdAt) }}
                  </span>
                  <span v-if="comment.isInternal" 
                        class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">
                    Intern
                  </span>
                </div>
                <p class="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{{ comment.content }}</p>
              </div>
            </div>
            
            <div v-if="comments.length === 0" class="text-center py-8">
              <p class="text-gray-500 dark:text-gray-400">Noch keine Kommentare vorhanden</p>
            </div>
          </div>
        </div>

        <!-- Anhänge -->
        <AttachmentManager :task-id="task.id" />

      </div>

      <!-- Seitenleiste -->
      <div class="space-y-6">
        
        <!-- Task-Details -->
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Details</h3>
          
          <div class="space-y-4">
            <!-- Projekt -->
            <div>
              <label class="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Projekt</label>
              <div class="flex items-center space-x-2">
                <FolderIcon class="h-4 w-4 text-gray-400" />
                <span class="text-sm text-gray-900 dark:text-white">{{ task.project.name }}</span>
              </div>
              <div v-if="task.project.customer" class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                {{ task.project.customer.companyName }}
              </div>
            </div>

            <!-- Ersteller -->
            <div>
              <label class="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Erstellt von</label>
              <div class="flex items-center space-x-2">
                <UserIcon class="h-4 w-4 text-gray-400" />
                <span class="text-sm text-gray-900 dark:text-white">
                  {{ task.creator.firstName }} {{ task.creator.lastName }}
                </span>
              </div>
            </div>

            <!-- Zugewiesen an -->
            <div>
              <label class="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Zugewiesen an</label>
              <div v-if="task.assignee" class="flex items-center space-x-2">
                <img v-if="task.assignee.avatar" 
                     :src="task.assignee.avatar"
                     :alt="`${task.assignee.firstName} ${task.assignee.lastName}`"
                     class="h-4 w-4 rounded-full object-cover">
                <UserIcon v-else class="h-4 w-4 text-gray-400" />
                <span class="text-sm text-gray-900 dark:text-white">
                  {{ task.assignee.firstName }} {{ task.assignee.lastName }}
                </span>
              </div>
              <div v-else class="flex items-center space-x-2">
                <UserIcon class="h-4 w-4 text-gray-400" />
                <span class="text-sm text-gray-500 dark:text-gray-400">Nicht zugewiesen</span>
              </div>
            </div>

            <!-- Fälligkeitsdatum -->
            <div v-if="task.dueDate">
              <label class="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Fälligkeitsdatum</label>
              <div class="flex items-center space-x-2">
                <CalendarIcon class="h-4 w-4 text-gray-400" />
                <span class="text-sm text-gray-900 dark:text-white"
                      :class="{ 'text-red-600 dark:text-red-400': isOverdue(task.dueDate) }">
                  {{ formatDate(task.dueDate) }}
                </span>
              </div>
            </div>

            <!-- Zeitschätzung -->
            <div v-if="task.estimatedHours">
              <label class="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Geschätzte Zeit</label>
              <div class="flex items-center space-x-2">
                <ClockIcon class="h-4 w-4 text-gray-400" />
                <span class="text-sm text-gray-900 dark:text-white">{{ task.estimatedHours }}h</span>
              </div>
            </div>

            <!-- Verbleibende Zeit -->
            <div v-if="task.remainingHours">
              <label class="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Verbleibende Zeit</label>
              <div class="flex items-center space-x-2">
                <ClockIcon class="h-4 w-4 text-gray-400" />
                <span class="text-sm text-gray-900 dark:text-white">{{ task.remainingHours }}h</span>
              </div>
            </div>

            <!-- Erstellt/Aktualisiert -->
            <div class="pt-4 border-t border-gray-200 dark:border-gray-700">
              <div class="text-xs text-gray-500 dark:text-gray-400 space-y-1">
                <div>Erstellt: {{ formatDate(task.createdAt) }}</div>
                <div>Aktualisiert: {{ formatDate(task.updatedAt) }}</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Statistiken -->
        <div v-if="task._count" class="bg-white dark:bg-gray-800 shadow rounded-lg p-6">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Statistiken</h3>
          
          <div class="space-y-3">
            <div class="flex items-center justify-between">
              <span class="text-sm text-gray-600 dark:text-gray-400">Kommentare</span>
              <span class="text-sm font-medium text-gray-900 dark:text-white">{{ task._count.comments }}</span>
            </div>
            <div class="flex items-center justify-between">
              <span class="text-sm text-gray-600 dark:text-gray-400">Zeiteinträge</span>
              <span class="text-sm font-medium text-gray-900 dark:text-white">{{ task._count.timeEntries }}</span>
            </div>
            <div class="flex items-center justify-between">
              <span class="text-sm text-gray-600 dark:text-gray-400">Anhänge</span>
              <span class="text-sm font-medium text-gray-900 dark:text-white">{{ task._count.attachments }}</span>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- Task Modal -->
    <TaskModal
      :is-open="showTaskModal"
      :task="task"
      :available-projects="[]"
      :available-users="[]"
      @close="showTaskModal = false"
      @update="handleUpdateTask" />

    <!-- Time Entry Modal -->
    <TimeEntryModal
      v-if="showTimeEntryModal"
      :task-id="task?.id"
      :project-id="task?.projectId"
      @close="showTimeEntryModal = false"
      @save="handleTimeEntrySaved" />

    <!-- Delete Confirmation -->
    <ConfirmDialog
      :is-open="showDeleteConfirm"
      title="Aufgabe löschen"
      message="Sind Sie sicher, dass Sie diese Aufgabe löschen möchten? Diese Aktion kann nicht rückgängig gemacht werden."
      confirm-text="Löschen"
      confirm-variant="danger"
      @confirm="handleDeleteTask"
      @cancel="showDeleteConfirm = false" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import {
  ArrowLeftIcon,
  PencilIcon,
  TrashIcon,
  FolderIcon,
  UserIcon,
  CalendarIcon,
  ClockIcon
} from '@heroicons/vue/24/outline'
import type { TaskWithDetails, TaskCommentWithAuthor, UpdateTaskData } from '~/stores/tasks'

// Simple interface for time entry form data
interface TimeEntryFormData {
  date: string
  hours: number
  taskId?: string
  projectId?: string
  category: string
  billable: boolean
  description?: string
  id?: string
}

interface Props {
  taskId: string
}

const props = defineProps<Props>()

// Stores
const tasksStore = useTasksStore()
const { fetchTask, updateTask, deleteTask, addComment: addTaskComment, fetchComments } = tasksStore

const timeTrackingStore = useTimeTrackingStore()
const { createTimeEntry } = timeTrackingStore

const router = useRouter()

// State
const task = ref<TaskWithDetails | null>(null)
const comments = ref<TaskCommentWithAuthor[]>([])
const loading = ref(false)
const showTaskModal = ref(false)
const showTimeEntryModal = ref(false)
const showDeleteConfirm = ref(false)
const newComment = ref('')
const isInternalComment = ref(false)

// Methods
const loadTask = async () => {
  try {
    const taskData = await fetchTask(props.taskId)
    task.value = taskData
    
    // Kommentare laden
    const taskComments = await fetchComments(props.taskId)
    comments.value = taskComments
  } catch (error) {
    console.error('Error loading task:', error)
  }
}

const editTask = () => {
  showTaskModal.value = true
}

const handleUpdateTask = async (taskId: string, data: UpdateTaskData) => {
  try {
    await updateTask(taskId, data)
    showTaskModal.value = false
    await loadTask() // Neu laden
  } catch (error) {
    console.error('Error updating task:', error)
  }
}

const handleDeleteTask = async () => {
  try {
    await deleteTask(props.taskId)
    showDeleteConfirm.value = false
    router.push('/projects') // Zurück zur Projektliste
  } catch (error) {
    console.error('Error deleting task:', error)
  }
}

const addComment = async () => {
  if (!newComment.value.trim()) return
  
  try {
    await addTaskComment(props.taskId, newComment.value, isInternalComment.value)
    // Kommentare neu laden statt manuell hinzufügen
    const taskComments = await fetchComments(props.taskId)
    comments.value = taskComments
    newComment.value = ''
    isInternalComment.value = false
  } catch (error) {
    console.error('Error adding comment:', error)
  }
}

const openTimeEntryModal = () => {
  showTimeEntryModal.value = true
}

const handleTimeEntrySaved = async (timeEntryData: TimeEntryFormData) => {
  try {
    // Create the time entry using the time tracking composable
    await createTimeEntry({
      description: timeEntryData.description,
      hours: timeEntryData.hours,
      date: timeEntryData.date,
      category: timeEntryData.category,
      billable: timeEntryData.billable,
      projectId: timeEntryData.projectId || task.value?.projectId || '',
      taskId: timeEntryData.taskId || task.value?.id || ''
    })
    
    showTimeEntryModal.value = false
    // Reload task to update statistics
    await loadTask()
  } catch (error) {
    console.error('Error saving time entry:', error)
    // Keep modal open on error so user can try again
  }
}

// Utility functions
const formatDate = (date: string | Date) => {
  return new Date(date).toLocaleString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

const isOverdue = (dueDate: string | Date) => {
  return new Date(dueDate) < new Date()
}

// Lifecycle
onMounted(() => {
  loadTask()
})
</script>
