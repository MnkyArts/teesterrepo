<template>
  <div class="bg-white dark:bg-gray-800 rounded-lg shadow border border-gray-200 dark:border-gray-700">
    <!-- Section Header -->
    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
      <div class="flex items-center justify-between">
        <div class="flex items-center">
          <component :is="iconComponent" class="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
          <div class="ml-3">
            <h3 class="text-lg font-medium text-gray-900 dark:text-white">{{ title }}</h3>
            <p class="text-sm text-gray-600 dark:text-gray-400">{{ description }}</p>
          </div>
        </div>
        <button
          @click="showAddModal = true"
          class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
        >
          <PlusIcon class="h-4 w-4 mr-2" />
          Hinzufügen
        </button>
      </div>
    </div>

    <!-- Enum Values List -->
    <div class="p-6">
      <!-- Global Values Section -->
      <div class="mb-8">
        <h4 class="text-sm font-medium text-gray-900 dark:text-white mb-4">Globale Werte</h4>
        <div class="space-y-3">
          <div
            v-for="value in settings?.globalValues || []"
            :key="value.id"
            class="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-600 rounded-lg"
          >
            <div class="flex items-center">
              <div
                v-if="value.color"
                class="w-4 h-4 rounded-full mr-3"
                :style="{ backgroundColor: value.color }"
              ></div>
              <component
                v-else-if="value.icon"
                :is="getHeroIcon(value.icon)"
                class="h-4 w-4 mr-3 text-gray-400"
              />
              <div>
                <span class="text-sm font-medium text-gray-900 dark:text-white">{{ value.label }}</span>
                <span v-if="value.description" class="block text-xs text-gray-500 dark:text-gray-400">
                  {{ value.description }}
                </span>
              </div>
            </div>
            <div class="flex items-center space-x-2">
              <!-- Override Status -->
              <div class="flex items-center">
                <label class="sr-only">Aktiviert für dieses Projekt</label>
                <input
                  :checked="isValueActiveForProject(value.id)"
                  @change="(e) => toggleValueForProject(value.id, (e.target as HTMLInputElement).checked)"
                  type="checkbox"
                  class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <span class="ml-2 text-xs text-gray-500 dark:text-gray-400">Aktiv</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Project-Specific Values Section -->
      <div v-if="settings?.projectValues && settings.projectValues.length > 0">
        <h4 class="text-sm font-medium text-gray-900 dark:text-white mb-4">Projektspezifische Werte</h4>
        <div class="space-y-3">
          <div
            v-for="value in settings.projectValues"
            :key="value.id"
            class="flex items-center justify-between p-3 border border-indigo-200 dark:border-indigo-700 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg"
          >
            <div class="flex items-center">
              <div
                v-if="value.color"
                class="w-4 h-4 rounded-full mr-3"
                :style="{ backgroundColor: value.color }"
              ></div>
              <component
                v-else-if="value.icon"
                :is="getHeroIcon(value.icon)"
                class="h-4 w-4 mr-3 text-gray-400"
              />
              <div>
                <span class="text-sm font-medium text-gray-900 dark:text-white">{{ value.label }}</span>
                <span v-if="value.description" class="block text-xs text-gray-500 dark:text-gray-400">
                  {{ value.description }}
                </span>
                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-indigo-100 text-indigo-800 dark:bg-indigo-800 dark:text-indigo-200 mt-1">
                  Projektspezifisch
                </span>
              </div>
            </div>
            <div class="flex items-center space-x-2">
              <button
                @click="editProjectValue(value)"
                class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                title="Bearbeiten"
              >
                <PencilIcon class="h-4 w-4" />
              </button>
              <button
                @click="confirmDeleteProjectValue(value)"
                class="text-red-400 hover:text-red-600"
                title="Löschen"
              >
                <TrashIcon class="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Empty State -->
      <div v-if="(!settings?.globalValues?.length && !settings?.projectValues?.length)" class="text-center py-8">
        <component :is="iconComponent" class="mx-auto h-12 w-12 text-gray-400" />
        <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">Keine Werte vorhanden</h3>
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Erstellen Sie den ersten Wert für diese Kategorie.
        </p>
      </div>
    </div>

    <!-- Add/Edit Modal -->
    <ProjectEnumValueModal
      v-if="showAddModal || showEditModal"
      :visible="showAddModal || showEditModal"
      :category-name="categoryName"
      :project-id="projectId"
      :edit-value="editingValue"
      @close="closeModals"
      @saved="handleValueSaved"
    />

    <!-- Confirm Delete Modal -->
    <ConfirmDialog
      v-if="showDeleteConfirm"
      :isOpen="showDeleteConfirm"
      title="Wert löschen"
      :message="`Sind Sie sicher, dass Sie den Wert '${valueToDelete?.label}' löschen möchten? Diese Aktion kann nicht rückgängig gemacht werden.`"
      confirm-text="Löschen"
      variant="danger"
      @confirm="handleDeleteConfirm"
      @cancel="showDeleteConfirm = false"
    />
  </div>
</template>

<script setup lang="ts">
import { PlusIcon, PencilIcon, TrashIcon, TagIcon, BugAntIcon, QueueListIcon, ExclamationTriangleIcon, ChatBubbleLeftRightIcon } from '@heroicons/vue/24/outline'
import type { ProjectEnumSettings } from '~/stores/enumManagement'
import type { EnumValue } from '@prisma/client'

// Props
interface Props {
  title: string
  description: string
  icon: string
  categoryName: string
  projectId: string
  settings?: ProjectEnumSettings
}

const props = defineProps<Props>()

// Emits
const emit = defineEmits<{
  refresh: []
}>()

// Store
const enumStore = useEnumManagementStore()

// Reactive data
const showAddModal = ref(false)
const showEditModal = ref(false)
const showDeleteConfirm = ref(false)
const editingValue = ref<EnumValue | null>(null)
const valueToDelete = ref<EnumValue | null>(null)

// Computed
const iconComponent = computed(() => {
  // Map icon names to actual imported components
  const iconMap: Record<string, any> = {
    'BugAntIcon': BugAntIcon,
    'QueueListIcon': QueueListIcon,
    'ExclamationTriangleIcon': ExclamationTriangleIcon,
    'TicketIcon': TagIcon, // Use TagIcon as fallback for TicketIcon
    'ChatBubbleLeftRightIcon': ChatBubbleLeftRightIcon
  }
  
  return iconMap[props.icon] || TagIcon
})

// Methods
const getHeroIcon = (iconName: string) => {
  // Simple icon mapping for enum value icons
  const iconMap: Record<string, any> = {
    'TagIcon': TagIcon,
    'BugAntIcon': BugAntIcon,
    'LightBulbIcon': TagIcon, // Fallback
    'ExclamationTriangleIcon': ExclamationTriangleIcon,
    'CheckCircleIcon': TagIcon, // Fallback  
    'ClockIcon': TagIcon, // Fallback
    'PauseIcon': TagIcon, // Fallback
    'XCircleIcon': TagIcon, // Fallback
    'QuestionMarkCircleIcon': TagIcon, // Fallback
    'InformationCircleIcon': TagIcon // Fallback
  }
  
  return iconMap[iconName] || TagIcon
}

const isValueActiveForProject = (valueId: string): boolean => {
  const override = props.settings?.overrides.find(o => o.enumValueId === valueId)
  return override ? override.isActive : true // Default to active if no override
}

const toggleValueForProject = async (valueId: string, isActive: boolean) => {
  try {
    if (!props.settings?.categoryId) return
    
    const category = enumStore.categoriesMap.get(props.settings.categoryId)
    if (!category) return

    await enumStore.updateProjectOverride(
      props.projectId,
      category.id,
      valueId,
      { isActive }
    )
    
    emit('refresh')
  } catch (error: any) {
    // Show error notification
    console.error('Error updating project override:', error)
  }
}

const editProjectValue = (value: EnumValue) => {
  editingValue.value = value
  showEditModal.value = true
}

const confirmDeleteProjectValue = (value: EnumValue) => {
  valueToDelete.value = value
  showDeleteConfirm.value = true
}

const handleDeleteConfirm = async () => {
  if (!valueToDelete.value) return

  try {
    await enumStore.deleteProjectValue(valueToDelete.value.id, props.projectId)
    showDeleteConfirm.value = false
    valueToDelete.value = null
    emit('refresh')
  } catch (error: any) {
    console.error('Error deleting project value:', error)
  }
}

const closeModals = () => {
  showAddModal.value = false
  showEditModal.value = false
  editingValue.value = null
}

const handleValueSaved = () => {
  closeModals()
  emit('refresh')
}
</script>
