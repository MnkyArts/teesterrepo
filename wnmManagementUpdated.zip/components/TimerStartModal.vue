<template>
  <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" @click="handleBackdropClick">
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md mx-4" @click.stop>
      <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
          {{ $t('timeTracking.startNewTimer') }}
        </h3>
      </div>

      <div class="px-6 py-4 space-y-4">
        <!-- Task Selection (Now Primary) -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {{ $t('tasks.task') }} *
          </label>
          <select
            v-model="formData.taskId"
            @change="onTaskChange"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            required
          >
            <option value="">{{ $t('tasks.selectTask') }}</option>
            <option
              v-for="task in availableTasks"
              :key="task.id"
              :value="task.id"
            >
              {{ task.key }} - {{ task.title }} ({{ task.project.name }})
            </option>
          </select>
          <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
            {{ $t('timeTracking.taskSelectionHelp') }}
          </p>
        </div>

        <!-- Project Display (Read-only, derived from task) -->
        <div v-if="selectedProject">
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {{ $t('projects.project') }}
          </label>
          <div class="w-full px-3 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300">
            {{ selectedProject.key }} - {{ selectedProject.name }}
          </div>
        </div>

        <!-- Category -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {{ $t('timeTracking.category') }}
          </label>
          <select
            v-model="formData.category"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="Entwicklung">{{ $t('timeTracking.categories.development') }}</option>
            <option value="Testing">{{ $t('timeTracking.categories.testing') }}</option>
            <option value="Meeting">{{ $t('timeTracking.categories.meeting') }}</option>
            <option value="Dokumentation">{{ $t('timeTracking.categories.documentation') }}</option>
            <option value="Support">{{ $t('timeTracking.categories.support') }}</option>
            <option value="Schulung">{{ $t('timeTracking.categories.training') }}</option>
            <option value="Planung">{{ $t('timeTracking.categories.planning') }}</option>
            <option value="Review">{{ $t('timeTracking.categories.review') }}</option>
          </select>
        </div>

        <!-- Description -->
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {{ $t('timeTracking.description') }} ({{ $t('common.optional') }})
          </label>
          <textarea
            v-model="formData.description"
            rows="3"
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white resize-none"
            :placeholder="$t('timeTracking.descriptionPlaceholder')"
          />
        </div>
      </div>

      <div class="px-6 py-4 bg-gray-50 dark:bg-gray-700 rounded-b-lg flex justify-end space-x-3">
        <button
          @click="$emit('close')"
          class="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-600 border border-gray-300 dark:border-gray-500 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-500 transition-colors"
        >
          {{ $t('common.cancel') }}
        </button>
        <button
          @click="handleStart"
          :disabled="!isFormValid || isLoading"
          class="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <span v-if="isLoading" class="flex items-center">
            <div class="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
            {{ $t('timeTracking.starting') }}
          </span>
          <span v-else class="flex items-center">
            <PlayIcon class="h-4 w-4 mr-2" />
            {{ $t('timeTracking.startTimer') }}
          </span>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { PlayIcon } from '@heroicons/vue/24/solid'

interface Project {
  id: string
  name: string
  key: string
}

interface Task {
  id: string
  title: string
  key: string
  project: {
    id: string
    name: string
    key: string
  }
}

// Emits
const emit = defineEmits<{
  close: []
  start: [config: {
    taskId: string
    projectId: string
    description?: string
    category: string
  }]
}>()

// Composables
const projectsStore = useProjectsStore()
const tasksStore = useTasksStore()
const { projects, fetchProjects } = projectsStore
const { tasks, fetchTasks } = tasksStore

// State
const availableProjects = ref<Project[]>([])
const availableTasks = ref<Task[]>([])
const isLoading = ref(false)

const formData = ref({
  taskId: '', // Task is now primary (changed from projectId)
  projectId: '', // Project is derived from task
  category: 'Entwicklung',
  description: ''
})

// Computed
const isFormValid = computed(() => {
  return (formData.value.taskId?.length || 0) > 0 // Now validates taskId instead of projectId
})

const selectedProject = computed(() => {
  if (!formData.value.taskId) return null
  const selectedTask = availableTasks.value.find(task => task.id === formData.value.taskId)
  return selectedTask?.project || null
})

// Methods
const handleBackdropClick = () => {
  emit('close')
}

const onTaskChange = () => {
  // Automatically set the project from the selected task
  const selectedTask = availableTasks.value.find(task => task.id === formData.value.taskId)
  if (selectedTask) {
    formData.value.projectId = selectedTask.project.id
  } else {
    formData.value.projectId = ''
  }
}

const handleStart = () => {
  if (!isFormValid.value) return

  const config = {
    taskId: formData.value.taskId,
    projectId: formData.value.projectId, // Still needed for API compatibility
    category: formData.value.category,
    ...(formData.value.description && { description: formData.value.description })
  }

  emit('start', config)
}

// Lifecycle
onMounted(async () => {
  try {
    // Load enums first
    const { ensureLoaded, getTaskStatuses } = useDynamicEnums()
    await ensureLoaded()
    
    // Get active task status IDs (exclude ERLEDIGT/GESCHLOSSEN)
    // Note: Using global statuses initially since no project is selected yet
    const taskStatuses = getTaskStatuses()
    const activeStatusIds = taskStatuses
      .filter(status => status.isActive && !['ERLEDIGT', 'GESCHLOSSEN'].includes(status.key))
      .map(status => status.id)
    
    // Load all active tasks (not just projects)
    await fetchTasks({
      statusId: activeStatusIds
    })
    
    // Set available tasks from the fetched data
    if (Array.isArray(tasks)) {
      availableTasks.value = tasks as Task[]
    } else {
      availableTasks.value = []
    }
  } catch (error) {
    console.error('Error loading tasks:', error)
    availableTasks.value = []
  }
})
</script>
