<template>
  <div class="group relative bg-gray-50 dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500 transition-colors">
    <!-- Bild-Vorschau -->
    <div v-if="isImage(attachment.mimeType)" class="relative">
      <img
        :src="getDownloadUrl(taskId, attachment.id)"
        :alt="attachment.originalName"
        class="w-full h-48 object-cover rounded-t-lg cursor-pointer"
        @click="openPreview"
        @error="handleImageError"
      />
      <!-- Overlay für Aktionen -->
      <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 rounded-t-lg flex items-center justify-center opacity-0 group-hover:opacity-100">
        <div class="flex space-x-2">
          <button
            type="button"
            class="p-2 bg-white rounded-full shadow-lg hover:bg-gray-100 transition-colors"
            :title="$t('attachments.preview')"
            @click="openPreview"
          >
            <EyeIcon class="h-4 w-4 text-gray-600" />
          </button>
          <button
            type="button"
            class="p-2 bg-white rounded-full shadow-lg hover:bg-gray-100 transition-colors"
            :title="$t('attachments.download')"
            @click="downloadFile"
          >
            <ArrowDownTrayIcon class="h-4 w-4 text-gray-600" />
          </button>
        </div>
      </div>
    </div>

    <!-- Datei-Icon für Nicht-Bilder -->
    <div v-else class="flex items-center justify-center h-48 bg-gray-100 dark:bg-gray-600 rounded-t-lg">
      <component 
        :is="getIconComponent(attachment.mimeType)" 
        class="h-16 w-16 text-gray-400 dark:text-gray-300"
      />
    </div>

    <!-- Datei-Informationen -->
    <div class="p-4">
      <div class="flex items-start justify-between">
        <div class="min-w-0 flex-1">
          <h4 
            class="text-sm font-medium text-gray-900 dark:text-white truncate cursor-pointer hover:text-indigo-600 dark:hover:text-indigo-400"
            :title="attachment.originalName"
            @click="downloadFile"
          >
            {{ attachment.originalName }}
          </h4>
          <div class="mt-1 flex items-center space-x-2 text-xs text-gray-500 dark:text-gray-400">
            <span>{{ formatFileSize(attachment.size) }}</span>
            <span>•</span>
            <span>{{ formatDate(attachment.createdAt || attachment.uploadedAt) }}</span>
          </div>
          <div class="mt-1">
            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-600 text-gray-800 dark:text-gray-200">
              {{ getFileTypeLabel(attachment.mimeType) }}
            </span>
          </div>
        </div>

        <!-- Aktionen -->
        <div class="ml-3 flex-shrink-0">
          <div class="flex items-center space-x-1">
            <!-- Vorschau Button (nur für unterstützte Dateien) -->
            <button
              v-if="canPreview(attachment.mimeType)"
              type="button"
              class="p-1 text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
              :title="$t('attachments.preview')"
              @click="openPreview"
            >
              <EyeIcon class="h-4 w-4" />
            </button>

            <!-- Download Button -->
            <button
              type="button"
              class="p-1 text-gray-400 hover:text-green-600 dark:hover:text-green-400 transition-colors"
              :title="$t('attachments.download')"
              @click="downloadFile"
            >
              <ArrowDownTrayIcon class="h-4 w-4" />
            </button>

            <!-- Löschen Button -->
            <button
              type="button"
              class="p-1 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
              :title="$t('attachments.delete')"
              :disabled="isDeleting"
              @click="confirmDelete"
            >
              <TrashIcon class="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Löschen-Bestätigung -->
    <ConfirmDialog
      v-if="showDeleteConfirm"
      :is-open="showDeleteConfirm"
      :title="$t('attachments.confirmDelete')"
      :message="$t('attachments.confirmDeleteMessage', { filename: attachment.originalName })"
      :confirm-text="$t('common.delete')"
      :cancel-text="$t('common.cancel')"
      variant="danger"
      @confirm="handleDelete"
      @cancel="showDeleteConfirm = false"
    />

    <!-- Vorschau Modal -->
    <AttachmentPreviewModal
      v-if="showPreview"
      :attachment="attachment"
      :task-id="taskId"
      @close="showPreview = false"
    />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { 
  EyeIcon, 
  ArrowDownTrayIcon, 
  TrashIcon,
  DocumentIcon,
  DocumentTextIcon,
  PhotoIcon,
  TableCellsIcon,
  ArchiveBoxIcon
} from '@heroicons/vue/24/outline'

interface TaskAttachment {
  id: string
  size: number
  createdAt: Date
  path: string
  filename: string
  originalName: string
  mimeType: string
  taskId: string
  uploadedAt?: Date
  uploadedBy?: string
  url?: string
}

interface Props {
  attachment: TaskAttachment
  taskId: string
}

interface Emits {
  (e: 'delete', attachmentId: string): void
}

const props = defineProps<Props>()
const emit = defineEmits<Emits>()

// Composables
const attachmentsStore = useAttachmentsStore()

const { 
  deleteAttachment, 
  getDownloadUrl, 
  formatFileSize, 
  isImage, 
  canPreview,
  getFileIcon 
} = attachmentsStore

// Refs
const showDeleteConfirm = ref(false)
const showPreview = ref(false)
const isDeleting = ref(false)

// Datei herunterladen
const downloadFile = () => {
  const url = getDownloadUrl(props.taskId, props.attachment.id)
  const link = document.createElement('a')
  link.href = url
  link.download = props.attachment.originalName
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

// Vorschau öffnen
const openPreview = () => {
  showPreview.value = true
}

// Löschen bestätigen
const confirmDelete = () => {
  showDeleteConfirm.value = true
}

// Anhang löschen
const handleDelete = async () => {
  isDeleting.value = true
  showDeleteConfirm.value = false
  
  const success = await deleteAttachment(props.taskId, props.attachment.id)
  if (success) {
    emit('delete', props.attachment.id)
  }
  
  isDeleting.value = false
}

// Bild-Fehler behandeln
const handleImageError = (event: Event) => {
  const img = event.target as HTMLImageElement
  img.style.display = 'none'
}

// Icon-Komponente basierend auf Dateityp
const getIconComponent = (mimeType: string) => {
  const iconName = getFileIcon(mimeType)
  
  switch (iconName) {
    case '🖼️': return PhotoIcon
    case '📄': return DocumentTextIcon
    case '📝': return DocumentTextIcon
    case '📊': return TableCellsIcon
    case '🗜️': return ArchiveBoxIcon
    case '📎': return DocumentIcon
    default: return DocumentIcon
  }
}

// Dateityp-Label
const getFileTypeLabel = (mimeType: string) => {
  if (mimeType.startsWith('image/')) return 'Bild'
  if (mimeType === 'application/pdf') return 'PDF'
  if (mimeType.includes('word') || mimeType.includes('document')) return 'Word'
  if (mimeType.includes('excel') || mimeType.includes('sheet')) return 'Excel'
  if (mimeType.startsWith('text/')) return 'Text'
  if (mimeType.includes('zip')) return 'ZIP'
  if (mimeType.includes('rar')) return 'RAR'
  return 'Datei'
}

// Datum formatieren
const formatDate = (date: Date | string) => {
  const dateObj = typeof date === 'string' ? new Date(date) : date
  return dateObj.toLocaleDateString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  })
}
</script>
