<template>
  <div class="overflow-x-auto">
    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
      <thead class="bg-gray-50 dark:bg-gray-800">
        <tr>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Projekt
          </th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Umsatz
          </th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Kosten
          </th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Gewinn
          </th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            ROI
          </th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Status
          </th>
        </tr>
      </thead>
      <tbody class="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
        <tr 
          v-for="project in data" 
          :key="project.id"
          class="hover:bg-gray-50 dark:hover:bg-gray-800">
          <td class="px-6 py-4 whitespace-nowrap">
            <div class="flex items-center">
              <div>
                <div class="text-sm font-medium text-gray-900 dark:text-white">
                  {{ project.name }}
                </div>
                <div class="text-sm text-gray-500 dark:text-gray-400">
                  {{ project.customer }}
                </div>
              </div>
            </div>
          </td>
          <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
            €{{ formatCurrency(project.revenue) }}
          </td>
          <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
            €{{ formatCurrency(project.costs) }}
          </td>
          <td class="px-6 py-4 whitespace-nowrap text-sm">
            <span :class="project.profit >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'">
              €{{ formatCurrency(project.profit) }}
            </span>
          </td>
          <td class="px-6 py-4 whitespace-nowrap">
            <div class="flex items-center">
              <div class="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mr-2">
                <div 
                  class="h-2 rounded-full transition-all duration-300"
                  :class="getRoiColor(project.roi)"
                  :style="{ width: `${Math.min(Math.abs(project.roi), 100)}%` }">
                </div>
              </div>
              <span 
                class="text-sm"
                :class="project.roi >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'">
                {{ project.roi >= 0 ? '+' : '' }}{{ project.roi }}%
              </span>
            </div>
          </td>
          <td class="px-6 py-4 whitespace-nowrap">
            <span 
              class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
              :class="getStatusColor(project.status)">
              {{ getStatusLabel(project.status) }}
            </span>
          </td>
        </tr>
      </tbody>
      <tfoot class="bg-gray-50 dark:bg-gray-800">
        <tr>
          <td class="px-6 py-4 text-sm font-medium text-gray-900 dark:text-white">
            Gesamt
          </td>
          <td class="px-6 py-4 text-sm font-medium text-gray-900 dark:text-white">
            €{{ formatCurrency(totalRevenue) }}
          </td>
          <td class="px-6 py-4 text-sm font-medium text-gray-900 dark:text-white">
            €{{ formatCurrency(totalCosts) }}
          </td>
          <td class="px-6 py-4 text-sm font-medium">
            <span :class="totalProfit >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'">
              €{{ formatCurrency(totalProfit) }}
            </span>
          </td>
          <td class="px-6 py-4 text-sm font-medium">
            <span :class="averageRoi >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'">
              {{ averageRoi >= 0 ? '+' : '' }}{{ averageRoi }}%
            </span>
          </td>
          <td class="px-6 py-4"></td>
        </tr>
      </tfoot>
    </table>
    
    <!-- Empty State -->
    <div v-if="!data.length" class="text-center py-8">
      <CurrencyEuroIcon class="mx-auto h-12 w-12 text-gray-400" />
      <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
        Keine Rentabilitätsdaten verfügbar
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { CurrencyEuroIcon } from '@heroicons/vue/24/outline'

interface ProjectProfitabilityData {
  id: string
  name: string
  customer: string
  revenue: number
  costs: number
  profit: number
  roi: number
  status: 'active' | 'completed' | 'on-hold' | 'cancelled'
}

interface Props {
  data: ProjectProfitabilityData[]
}

const props = defineProps<Props>()

// Computed totals
const totalRevenue = computed(() => 
  props.data.reduce((sum, project) => sum + project.revenue, 0)
)

const totalCosts = computed(() => 
  props.data.reduce((sum, project) => sum + project.costs, 0)
)

const totalProfit = computed(() => 
  props.data.reduce((sum, project) => sum + project.profit, 0)
)

const averageRoi = computed(() => {
  if (!props.data.length) return 0
  const totalRoi = props.data.reduce((sum, project) => sum + project.roi, 0)
  return Math.round(totalRoi / props.data.length)
})

// Utility functions
const formatCurrency = (amount: number): string => {
  return amount.toLocaleString('de-DE', { 
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })
}

const getRoiColor = (roi: number): string => {
  if (roi >= 20) return 'bg-green-500'
  if (roi >= 10) return 'bg-yellow-500'
  if (roi >= 0) return 'bg-orange-500'
  return 'bg-red-500'
}

const getStatusColor = (status: string): string => {
  const colors = {
    'active': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    'completed': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
    'on-hold': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
    'cancelled': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
  }
  return colors[status as keyof typeof colors] || colors.active
}

const getStatusLabel = (status: string): string => {
  const labels = {
    'active': 'Aktiv',
    'completed': 'Abgeschlossen',
    'on-hold': 'Pausiert',
    'cancelled': 'Abgebrochen'
  }
  return labels[status as keyof typeof labels] || 'Unbekannt'
}
</script>
