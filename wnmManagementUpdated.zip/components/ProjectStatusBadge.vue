<template>
  <span 
    class="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium"
    :class="statusClasses"
  >
    <div class="h-1.5 w-1.5 rounded-full" :class="dotClasses"></div>
    {{ statusText }}
  </span>
</template>

<script setup lang="ts">
// Props
const props = defineProps<{
  status: 'AKTIV' | 'PAUSIERT' | 'ABGESCHLOSSEN' | 'ARCHIVIERT'
}>()

// Computed
const statusConfig = computed(() => {
  const configs = {
    AKTIV: {
      text: 'Aktiv',
      classes: 'bg-green-50 text-green-700 border border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800',
      dotClasses: 'bg-green-500'
    },
    PAUSIERT: {
      text: 'Pausiert',
      classes: 'bg-yellow-50 text-yellow-700 border border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-400 dark:border-yellow-800',
      dotClasses: 'bg-yellow-500'
    },
    ABGESCHLOSSEN: {
      text: 'Abgeschlossen',
      classes: 'bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-900/30 dark:text-blue-400 dark:border-blue-800',
      dotClasses: 'bg-blue-500'
    },
    ARCHIVIERT: {
      text: 'Archiviert',
      classes: 'bg-gray-50 text-gray-700 border border-gray-200 dark:bg-gray-900/30 dark:text-gray-400 dark:border-gray-800',
      dotClasses: 'bg-gray-500'
    }
  }
  
  return configs[props.status] || configs.AKTIV
})

const statusClasses = computed(() => statusConfig.value.classes)
const dotClasses = computed(() => statusConfig.value.dotClasses)
const statusText = computed(() => statusConfig.value.text)
</script>
