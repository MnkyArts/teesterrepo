<template>
  <div class="space-y-6">
    <!-- Active Timer Section -->
    <div class="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-800">
      <div class="flex items-center justify-between mb-4">
        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
          {{ $t('timeTracking.activeTimer') }}
        </h3>
        <div class="flex gap-2">
          <button
            v-if="!isTimerRunning"
            @click="showStartTimer = true"
            class="flex items-center px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
          >
            <PlayIcon class="h-4 w-4 mr-2" />
            {{ $t('timeTracking.startTimer') }}
          </button>
          
          <template v-else>
            <button
              @click="pauseTimer"
              class="flex items-center px-3 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors text-sm"
            >
              <PauseIcon class="h-4 w-4 mr-2" />
              {{ $t('timeTracking.pauseTimer') }}
            </button>
            <button
              @click="() => stopTimer()"
              class="flex items-center px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm"
            >
              <StopIcon class="h-4 w-4 mr-2" />
              {{ $t('timeTracking.stopTimer') }}
            </button>
          </template>
        </div>
      </div>

      <div v-if="isTimerRunning && activeTimer" class="space-y-3">
        <!-- Running Timer Display -->
        <div class="text-center">
          <div class="text-3xl font-mono font-bold text-gray-900 dark:text-white">
            {{ formattedElapsedTime }}
          </div>
          <p class="text-sm text-gray-600 dark:text-gray-400">
            {{ $t('timeTracking.runningSince', { time: formatTime(activeTimer.startTime) }) }}
          </p>
        </div>
        
        <!-- Timer Details -->
        <div class="bg-white dark:bg-gray-800 rounded-lg p-3">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
            <div v-if="activeTimer.taskId">
              <span class="font-medium text-gray-700 dark:text-gray-300">{{ $t('tasks.task') }}:</span>
              <span class="ml-2 text-gray-900 dark:text-white">{{ getTaskDisplayName(activeTimer.taskId) }}</span>
            </div>
            <div>
              <span class="font-medium text-gray-700 dark:text-gray-300">{{ $t('projects.project') }}:</span>
              <span class="ml-2 text-gray-900 dark:text-white">{{ getProjectDisplayName(activeTimer.projectId) }}</span>
            </div>
            <div>
              <span class="font-medium text-gray-700 dark:text-gray-300">{{ $t('timeTracking.category') }}:</span>
              <span class="ml-2 text-gray-900 dark:text-white">{{ activeTimer.category }}</span>
            </div>
            <div v-if="activeTimer.description">
              <span class="font-medium text-gray-700 dark:text-gray-300">{{ $t('timeTracking.description') }}:</span>
              <span class="ml-2 text-gray-900 dark:text-white">{{ activeTimer.description }}</span>
            </div>
          </div>
        </div>
      </div>

      <div v-else class="text-center py-4">
        <ClockIcon class="h-12 w-12 text-gray-400 mx-auto mb-2" />
        <p class="text-gray-500 dark:text-gray-400">{{ $t('timeTracking.noActiveTimer') }}</p>
      </div>
    </div>

    <!-- Today's Statistics -->
    <div v-if="stats" class="space-y-4">
      <h4 class="text-base font-semibold text-gray-900 dark:text-white">
        {{ $t('timeTracking.todayStats') }}
      </h4>
      
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
          <div class="text-2xl font-bold text-blue-600 dark:text-blue-400">
            {{ formatHours(stats.todayTotal) }}h
          </div>
          <p class="text-sm text-gray-600 dark:text-gray-400">{{ $t('timeTracking.totalToday') }}</p>
        </div>
        
        <div class="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
          <div class="text-2xl font-bold text-green-600 dark:text-green-400">
            {{ formatHours(stats.billableToday) }}h
          </div>
          <p class="text-sm text-gray-600 dark:text-gray-400">{{ $t('timeTracking.billableToday') }}</p>
        </div>
        
        <div class="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
          <div class="text-2xl font-bold text-orange-600 dark:text-orange-400">
            {{ formatHours(stats.nonBillableToday) }}h
          </div>
          <p class="text-sm text-gray-600 dark:text-gray-400">{{ $t('timeTracking.nonBillableToday') }}</p>
        </div>
      </div>

      <!-- Progress Bar -->
      <div class="space-y-2">
        <div class="flex justify-between text-sm">
          <span class="text-gray-700 dark:text-gray-300">{{ $t('timeTracking.dailyProgress') }}</span>
          <span class="text-gray-500 dark:text-gray-400">
            {{ formatHours(stats.todayTotal) }}h / {{ stats.targetDailyHours }}h
          </span>
        </div>
        <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
          <div
            class="bg-gradient-to-r from-blue-500 to-blue-600 h-3 rounded-full transition-all duration-300"
            :style="{ width: `${Math.min((stats.todayTotal / stats.targetDailyHours) * 100, 100)}%` }"
          ></div>
        </div>
      </div>
    </div>

    <!-- Quick Actions -->
    <div class="flex gap-2">
      <NuxtLink
        to="/time-tracking"
        class="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm"
      >
        <ChartBarIcon class="h-4 w-4 mr-2" />
        {{ $t('timeTracking.viewTimesheet') }}
      </NuxtLink>
      
      <button
        @click="showQuickEntry = true"
        class="flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors text-sm"
      >
        <PlusIcon class="h-4 w-4 mr-2" />
        {{ $t('timeTracking.quickEntry') }}
      </button>
    </div>

    <!-- Start Timer Modal -->
    <TimerStartModal
      v-if="showStartTimer"
      @close="showStartTimer = false"
      @start="handleStartTimer"
    />

    <!-- Quick Entry Modal -->
    <TimeEntryModal
      v-if="showQuickEntry"
      @close="showQuickEntry = false"
      @save="handleQuickEntry"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import {
  PlayIcon,
  StopIcon,
  PauseIcon,
  ClockIcon,
  ChartBarIcon,
  PlusIcon
} from '@heroicons/vue/24/solid'

// Components
const TimerStartModal = defineAsyncComponent(() => import('~/components/TimerStartModal.vue'))
const TimeEntryModal = defineAsyncComponent(() => import('~/components/TimeEntryModal.vue'))

// Composables
// Stores
const timeTrackingStore = useTimeTrackingStore()
const projectsStore = useProjectsStore()
const tasksStore = useTasksStore()

// Destructure store properties
const { 
  activeTimer, 
  stats, 
  isTimerRunning, 
  formattedElapsedTime
} = storeToRefs(timeTrackingStore)

const { 
  startTimer, 
  stopTimer, 
  pauseTimer,
  createTimeEntry,
  fetchStats,
  formatHours
} = timeTrackingStore

const projects = storeToRefs(projectsStore).projects
const tasks = storeToRefs(tasksStore).tasks

// State
const showStartTimer = ref(false)
const showQuickEntry = ref(false)

// Methods
const formatTime = (date: Date | string) => {
  const d = new Date(date)
  return d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })
}

const getTaskDisplayName = (taskId: string) => {
  if (!Array.isArray(tasks.value)) return 'Loading...'
  const task = tasks.value.find((t: any) => t.id === taskId)
  return task ? `${task.key} - ${task.title}` : 'Unknown Task'
}

const getProjectDisplayName = (projectId: string) => {
  if (!Array.isArray(projects.value)) return 'Loading...'
  const project = projects.value.find((p: any) => p.id === projectId)
  return project ? `${project.key} - ${project.name}` : 'Unknown Project'
}

const handleStartTimer = async (config: any) => {
  try {
    await startTimer(config.taskId, config.projectId, config.description, config.category)
    showStartTimer.value = false
  } catch (error) {
    console.error('Error starting timer:', error)
  }
}

const handleQuickEntry = async (entry: any) => {
  try {
    await createTimeEntry(entry)
    showQuickEntry.value = false
    await fetchStats() // Refresh stats
  } catch (error) {
    console.error('Error creating time entry:', error)
  }
}

// Lifecycle
onMounted(async () => {
  // Load enums first
  const { ensureLoaded, getTaskStatuses } = useDynamicEnums()
  await ensureLoaded()
  
  // Get active task status IDs (exclude ERLEDIGT/GESCHLOSSEN)
  const taskStatuses = getTaskStatuses()
  const activeStatusIds = taskStatuses
    .filter(status => status.isActive && !['ERLEDIGT', 'GESCHLOSSEN'].includes(status.key))
    .map(status => status.id)
  
  await Promise.all([
    fetchStats(),
    projectsStore.fetchProjects(),
    tasksStore.fetchTasks({ statusId: activeStatusIds })
  ])
})
</script>
