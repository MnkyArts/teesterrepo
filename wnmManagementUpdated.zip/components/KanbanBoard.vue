<template>
  <div class="kanban-board-wrapper h-full flex flex-col">
    <!-- Kanban Header -->
    <div class="flex-shrink-0 p-6 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900">
      <div class="flex items-center justify-between">
        <div>
          <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
            <span v-if="props.projectId">Projekt Kanban Board</span>
            <span v-else>Kanban Board</span>
          </h1>
          <p class="mt-1 text-gray-600 dark:text-gray-400">
            <span v-if="props.projectId">Verwalten Sie die Aufgaben dieses Projekts per Drag & Drop</span>
            <span v-else>Verwalten Sie Ihre Aufgaben per Drag & Drop</span>
          </p>
        </div>
        
        <!-- Board Statistics -->
        <div class="flex items-center space-x-6">
          <div class="text-center">
            <div class="text-2xl font-bold text-gray-900 dark:text-white">{{ stats.totalTasks }}</div>
            <div class="text-sm text-gray-600 dark:text-gray-400">Gesamt</div>
          </div>
          <div class="text-center">
            <div class="text-2xl font-bold text-blue-600 dark:text-blue-400">{{ stats.inProgressTasks }}</div>
            <div class="text-sm text-gray-600 dark:text-gray-400">In Arbeit</div>
          </div>
          <div class="text-center">
            <div class="text-2xl font-bold text-green-600 dark:text-green-400">{{ stats.completedTasks }}</div>
            <div class="text-sm text-gray-600 dark:text-gray-400">Abgeschlossen</div>
          </div>
          <div class="text-center">
            <div class="text-2xl font-bold text-purple-600 dark:text-purple-400">{{ stats.completionRate }}%</div>
            <div class="text-sm text-gray-600 dark:text-gray-400">Fortschritt</div>
          </div>
        </div>
      </div>

      <!-- Filters -->
      <div class="mt-4 flex items-center space-x-4">
        <!-- Search -->
        <div class="flex-1 max-w-md">
          <div class="relative">
            <MagnifyingGlassIcon class="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              v-model="searchTerm"
              type="text"
              placeholder="Aufgaben durchsuchen..."
              class="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent">
          </div>
        </div>

        <!-- Project Filter -->
        <select
          v-if="!hideProjectFilter"
          v-model="filters.projectId"
          class="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent">
          <option value="">Alle Projekte</option>
          <option 
            v-for="project in projects" 
            :key="project.id" 
            :value="project.id">
            {{ project.name }}
          </option>
        </select>

        <!-- Priority Filter -->
        <select
          v-model="filters.priority"
          class="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent">
          <option value="">Alle Prioritäten</option>
          <option 
            v-for="priority in availablePriorities" 
            :key="priority.key" 
            :value="priority.key">
            {{ priority.label }}
          </option>
        </select>

        <!-- Type Filter -->
        <select
          v-model="filters.type"
          class="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent">
          <option value="">Alle Typen</option>
          <option 
            v-for="type in availableTypes" 
            :key="type.key" 
            :value="type.key">
            {{ type.label }}
          </option>
        </select>

        <!-- Refresh Button -->
        <button
          @click="refreshBoard"
          :disabled="loading"
          class="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-lg transition-colors duration-200 flex items-center space-x-2">
          <ArrowPathIcon class="h-4 w-4" :class="{ 'animate-spin': loading }" />
          <span>Aktualisieren</span>
        </button>
      </div>
    </div>

    <!-- Kanban Columns -->
    <div class="flex-1 overflow-x-auto bg-gray-50 dark:bg-gray-800">
      <div class="flex h-full" style="min-width: max-content;">
        <div
          v-for="column in displayBoard.columns"
          :key="column.id"
          class="flex-shrink-0 w-80 p-4 border-r border-gray-200 dark:border-gray-700 last:border-r-0">
          
          <!-- Column Header -->
          <div class="mb-4">
            <div class="flex items-center justify-between">
              <div class="flex items-center space-x-2">
                <div 
                  class="w-3 h-3 rounded-full"
                  :class="getColumnColorClass(column.color)"
                  :style="getColumnColorStyle(column.color)">
                </div>
                <h3 class="font-semibold text-gray-900 dark:text-white">{{ column.title }}</h3>
                <span 
                  class="inline-flex items-center justify-center w-6 h-6 text-xs font-medium rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300">
                  {{ column.tasks.length }}
                </span>
              </div>
            </div>
          </div>

          <!-- Tasks Container -->
          <div 
            :ref="el => setColumnRef(column.id, el)"
            class="space-y-3 min-h-[200px]"
            :data-column-id="column.id">
            
            <KanbanTaskCard
              v-for="task in column.tasks"
              :key="task.id"
              :task="task"
              :data-task-id="task.id"
              @edit="handleEditTask"
              @view="handleViewTask" />
            
            <!-- Empty State -->
            <div 
              v-if="column.tasks.length === 0"
              class="empty-state flex items-center justify-center h-32 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg">
              <p class="text-gray-500 dark:text-gray-400 text-sm">Keine Aufgaben</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Task Modal -->
    <TaskModal
      v-if="showTaskModal"
      :is-open="showTaskModal"
      :task="editingTask"
      @close="closeTaskModal"
      @saved="handleTaskSaved" />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch, nextTick } from 'vue'
import { MagnifyingGlassIcon, ArrowPathIcon } from '@heroicons/vue/24/outline'
import Sortable from 'sortablejs'
import type { TaskWithDetails } from '~/stores/tasks'
import type { KanbanFilters } from '~/stores/kanban'

// Props
interface Props {
  projectId?: string
  hideProjectFilter?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  projectId: '',
  hideProjectFilter: false
})

// Stores
const kanbanStore = useKanbanStore()
const projectsStore = useProjectsStore()
const tasksStore = useTasksStore()
const enumManagementStore = useEnumManagementStore()
const router = useRouter()

// Use project-specific Kanban functionality
const kanbanComposable = useKanban(props.projectId)
const { createKanbanBoard, getFilteredBoard, getKanbanStats, moveTaskToColumn, fetchKanbanTasks } = kanbanComposable

// State
const loading = ref(false)
const tasks = ref<TaskWithDetails[]>([])
const projects = storeToRefs(projectsStore).projects
const board = ref(createKanbanBoard([]))
const searchTerm = ref('')
const showTaskModal = ref(false)
const editingTask = ref<TaskWithDetails | null>(null)
const currentDragOverColumn = ref<string | null>(null)

// Column refs for drag & drop
const columnRefs = ref<Record<string, HTMLElement>>({})

// Filters
const filters = ref<KanbanFilters>({
  projectId: props.projectId || '',
  priority: '',
  type: '',
  search: ''
})

// Computed
const displayBoard = computed(() => {
  return getFilteredBoard(board.value, searchTerm.value)
})

const stats = computed(() => {
  return getKanbanStats(board.value)
})

// Dynamic enum options
const availablePriorities = computed(() => {
  const projectId = props.projectId || ''
  if (!projectId) return []
  
  return enumManagementStore.getEffectiveEnumValues(projectId, 'priority').map(value => ({
    key: value.key,
    label: value.label,
    id: value.id,
    color: value.color,
    icon: value.icon
  }))
})

const availableTypes = computed(() => {
  const projectId = props.projectId || ''
  if (!projectId) return []
  
  return enumManagementStore.getEffectiveEnumValues(projectId, 'task_type').map(value => ({
    key: value.key,
    label: value.label,
    id: value.id,
    color: value.color,
    icon: value.icon
  }))
})

// Methods
const setColumnRef = (columnId: string, el: any) => {
  if (el) {
    columnRefs.value[columnId] = el
  }
}

const getColumnColorClass = (color: string) => {
  // If it's a hex color, return empty class (will be handled by style)
  if (color && color.startsWith('#') && color.length === 7) {
    return ''
  }
  
  const colorMap = {
    gray: 'bg-gray-400',
    blue: 'bg-blue-400',
    yellow: 'bg-yellow-400',
    purple: 'bg-purple-400',
    orange: 'bg-orange-400',
    green: 'bg-green-400'
  }
  return colorMap[color as keyof typeof colorMap] || 'bg-gray-400'
}

const getColumnColorStyle = (color: string) => {
  // If it's a hex color, return dynamic style
  if (color && color.startsWith('#') && color.length === 7) {
    return {
      backgroundColor: color
    }
  }
  return {}
}

const loadData = async () => {
  loading.value = true
  try {
    // Load enum categories and project overrides first
    if (enumManagementStore.categories.length === 0) {
      await enumManagementStore.fetchCategories()
    }
    
    if (props.projectId) {
      await enumManagementStore.fetchProjectOverrides(props.projectId)
      await enumManagementStore.fetchProjectEnumSettings(props.projectId)
    }
    
    // Fetch tasks using the composable
    const fetchedTasks = await fetchKanbanTasks(filters.value)
    tasks.value = fetchedTasks
    board.value = createKanbanBoard(fetchedTasks, filters.value)
    
    // Also load projects for the filters
    await projectsStore.fetchProjects()
  } catch (error) {
    console.error('Error loading kanban data:', error)
  } finally {
    loading.value = false
  }
}

const refreshBoard = async () => {
  await loadData()
}

const handleTaskMoved = async (taskId: string, newColumnId: string) => {
  const success = await moveTaskToColumn(taskId, newColumnId as any)
  if (success) {
    // Update local state
    await loadData()
  }
}

const handleEditTask = (task: TaskWithDetails) => {
  editingTask.value = task
  showTaskModal.value = true
}

const handleViewTask = (task: TaskWithDetails) => {
  router.push(`/tasks/${task.id}`)
}

const closeTaskModal = () => {
  showTaskModal.value = false
  editingTask.value = null
}

const handleTaskSaved = async () => {
  closeTaskModal()
  await loadData()
}

// Setup drag & drop for each column
const setupDragAndDrop = async () => {
  await nextTick()
  
  // Don't setup drag & drop if we don't have any columns
  if (!board.value.columns || board.value.columns.length === 0) {
    console.warn('No columns available for drag & drop setup')
    return
  }
  
  Object.entries(columnRefs.value).forEach(([columnId, element]) => {
    if (element) {
      new Sortable(element, {
        group: 'kanban-tasks',
        animation: 200,
        ghostClass: 'sortable-ghost',
        chosenClass: 'sortable-chosen',
        dragClass: 'sortable-drag',
        filter: '.empty-state', // Exclude elements with this class from dragging
        onMove: (evt: Sortable.MoveEvent) => {
          const newColumnId = evt.to?.getAttribute('data-column-id')
          
          // If we're moving to a different column, update visibility
          if (newColumnId && newColumnId !== currentDragOverColumn.value) {
            // Show empty state in previously hovered column
            if (currentDragOverColumn.value) {
              const prevColumn = columnRefs.value[currentDragOverColumn.value]
              const prevEmptyState = prevColumn?.querySelector('.empty-state')
              if (prevEmptyState) {
                (prevEmptyState as HTMLElement).style.display = ''
              }
            }
            
            // Hide empty state in currently hovered column
            const emptyState = evt.to?.querySelector('.empty-state')
            if (emptyState) {
              (emptyState as HTMLElement).style.display = 'none'
            }
            
            currentDragOverColumn.value = newColumnId
          }
          
          return true
        },
        onEnd: (evt: Sortable.SortableEvent) => {
          // Reset drag state and show all empty states
          currentDragOverColumn.value = null
          Object.values(columnRefs.value).forEach(col => {
            const emptyState = col.querySelector('.empty-state')
            if (emptyState) {
              (emptyState as HTMLElement).style.display = ''
            }
          })
          
          const taskId = evt.item.getAttribute('data-task-id')
          const newColumnId = evt.to?.getAttribute('data-column-id')
          
          if (taskId && newColumnId && evt.from !== evt.to) {
            handleTaskMoved(taskId, newColumnId)
          }
        }
      })
    }
  })
}

// Watchers
watch(filters, async () => {
  await loadData()
}, { deep: true })

watch(() => board.value.columns, async () => {
  await setupDragAndDrop()
}, { deep: true })

// Watch for projectId prop changes
watch(() => props.projectId, (newProjectId) => {
  if (newProjectId) {
    filters.value.projectId = newProjectId
  }
}, { immediate: true })

// Lifecycle
onMounted(async () => {
  await loadData()
  await setupDragAndDrop()
})
</script>

<style scoped>
.kanban-board-wrapper {
  height: calc(100vh - 4rem); /* Adjust based on your layout */
}

/* Drag & Drop Styles */
.sortable-ghost {
  opacity: 0.5;
}

.sortable-chosen {
  transform: scale(1.05);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
}

.sortable-drag {
  transform: rotate(3deg);
}

/* Scrollbar Styling */
.overflow-x-auto::-webkit-scrollbar {
  height: 8px;
}

.overflow-x-auto::-webkit-scrollbar-track {
  background-color: #f3f4f6;
}

.dark .overflow-x-auto::-webkit-scrollbar-track {
  background-color: #1f2937;
}

.overflow-x-auto::-webkit-scrollbar-thumb {
  background-color: #d1d5db;
  border-radius: 9999px;
}

.dark .overflow-x-auto::-webkit-scrollbar-thumb {
  background-color: #4b5563;
}

.overflow-x-auto::-webkit-scrollbar-thumb:hover {
  background-color: #9ca3af;
}

.dark .overflow-x-auto::-webkit-scrollbar-thumb:hover {
  background-color: #6b7280;
}
</style>
