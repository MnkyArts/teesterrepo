<template>
  <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
    <!-- Header mit Upload-Button -->
    <div class="p-6 border-b border-gray-200 dark:border-gray-700">
      <div class="flex items-center justify-between">
        <h3 class="text-lg font-medium text-gray-900 dark:text-white">
          {{ $t('attachments.title') }}
          <span v-if="attachments.length > 0" class="ml-2 text-sm text-gray-500 dark:text-gray-400">
            ({{ attachments.length }})
          </span>
        </h3>
        
        <div class="flex items-center space-x-3">
          <!-- Upload Button -->
          <div class="relative">
            <input
              ref="fileInput"
              type="file"
              multiple
              class="hidden"
              :accept="acceptedFileTypes"
              @change="handleFileSelect"
            />
            <button
              type="button"
              class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
              :disabled="isUploading"
              @click="triggerFileSelect"
            >
              <PlusIcon class="h-4 w-4 mr-2" />
              {{ $t('attachments.uploadFiles') }}
            </button>
          </div>
        </div>
      </div>

      <!-- Upload Progress -->
      <div v-if="isUploading && uploadProgress" class="mt-4">
        <div class="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
          <span>{{ $t('attachments.uploading') }}...</span>
          <span>{{ uploadProgress.percentage }}%</span>
        </div>
        <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
          <div 
            class="bg-indigo-600 h-2 rounded-full transition-all duration-300"
            :style="{ width: `${uploadProgress.percentage}%` }"
          ></div>
        </div>
      </div>
    </div>

    <!-- Anhang-Liste -->
    <div class="p-6">
      <!-- Loading State -->
      <div v-if="isLoading" class="flex items-center justify-center py-8">
        <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>

      <!-- Leere Liste -->
      <div v-else-if="attachments.length === 0" class="text-center py-8">
        <DocumentIcon class="mx-auto h-12 w-12 text-gray-400" />
        <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">
          {{ $t('attachments.noAttachments') }}
        </h3>
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
          {{ $t('attachments.noAttachmentsDesc') }}
        </p>
      </div>

      <!-- Anhang-Grid -->
      <div v-else class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <AttachmentCard
          v-for="attachment in attachments"
          :key="attachment.id"
          :attachment="attachment"
          :task-id="taskId"
          @delete="handleDelete"
        />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { PlusIcon, DocumentIcon } from '@heroicons/vue/24/outline'

interface TaskAttachment {
  id: string
  size: number
  createdAt: Date
  path: string
  filename: string
  originalName: string
  mimeType: string
  taskId: string
  uploadedAt?: Date
  uploadedBy?: string
  url?: string
}

interface Props {
  taskId: string
}

const props = defineProps<Props>()

// Stores
const attachmentsStore = useAttachmentsStore()
const { 
  attachments, 
  isLoading, 
  isUploading, 
  uploadProgress
} = storeToRefs(attachmentsStore)
const { 
  fetchAttachments, 
  uploadFile 
} = attachmentsStore

// Refs
const fileInput = ref<HTMLInputElement>()

// Erlaubte Dateitypen für Input
const acceptedFileTypes = [
  'image/jpeg', 'image/png', 'image/gif', 'image/webp',
  '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.txt', '.csv', '.zip', '.rar'
].join(',')

// File Input triggern
const triggerFileSelect = () => {
  fileInput.value?.click()
}

// Datei-Auswahl behandeln
const handleFileSelect = async (event: Event) => {
  const target = event.target as HTMLInputElement
  const files = target.files
  
  if (!files || files.length === 0) return
  
  // Mehrere Dateien sequenziell hochladen
  for (const file of Array.from(files)) {
    await uploadFile(props.taskId, file)
  }
  
  // Input zurücksetzen
  if (fileInput.value) {
    fileInput.value.value = ''
  }
}

// Anhang löschen
const handleDelete = (attachmentId: string) => {
  // Die AttachmentCard behandelt das Löschen bereits
  // Diese Funktion ist für zukünftige Erweiterungen
}

// Watch für TaskId-Änderungen (mit immediate: true für Initial-Load)
watch(() => props.taskId, (newTaskId) => {
  if (newTaskId) {
    fetchAttachments(newTaskId)
  }
}, { immediate: true })
</script>
