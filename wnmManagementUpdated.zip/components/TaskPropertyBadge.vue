<template>
  <span 
    class="inline-flex items-center gap-1 rounded-full text-xs font-medium"
    :class="[sizeClasses, colorClasses]"
    :style="dynamicStyles"
  >
    <div 
      v-if="showDot" 
      class="rounded-full" 
      :class="[dotSizeClasses, dotColorClasses]"
      :style="dotStyles">
    </div>
    <component 
      v-if="enumIcon && showIcon" 
      :is="getIconComponent(enumIcon)"
      :class="iconSizeClasses" />
    {{ displayLabel }}
  </span>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { EnumValue } from '@prisma/client'
import { 
  BugAntIcon, 
  StarIcon, 
  ArrowUpIcon, 
  ClipboardDocumentListIcon,
  BookOpenIcon,
  FlagIcon,
  ExclamationTriangleIcon,
  ShieldExclamationIcon
} from '@heroicons/vue/24/outline'

interface Props {
  enumValue?: EnumValue | string | null
  fallbackValue?: string
  fallbackLabel?: string
  size?: 'sm' | 'md'
  showDot?: boolean
  showIcon?: boolean
  variant?: 'default' | 'outlined'
}

const props = withDefaults(defineProps<Props>(), {
  enumValue: null,
  fallbackValue: '',
  fallbackLabel: '',
  size: 'md',
  showDot: true,
  showIcon: false,
  variant: 'default'
})

// Icon mapping
const iconMap = {
  'bug': BugAntIcon,
  'star': StarIcon,
  'arrow-up': ArrowUpIcon,
  'clipboard-document-list': ClipboardDocumentListIcon,
  'book-open': BookOpenIcon,
  'flag': FlagIcon,
  'exclamation-triangle': ExclamationTriangleIcon,
  'shield-exclamation': ShieldExclamationIcon
}

// Computed
const displayLabel = computed(() => {
  if (typeof props.enumValue === 'object' && props.enumValue) {
    return props.enumValue.label
  }
  if (typeof props.enumValue === 'string') {
    return props.enumValue
  }
  return props.fallbackLabel || props.fallbackValue || 'Unbekannt'
})

const sizeClasses = computed(() => {
  return props.size === 'sm' ? 'px-2 py-0.5' : 'px-2 py-1'
})

const dotSizeClasses = computed(() => {
  return props.size === 'sm' ? 'h-1 w-1' : 'h-1.5 w-1.5'
})

const iconSizeClasses = computed(() => {
  return props.size === 'sm' ? 'h-3 w-3' : 'h-4 w-4'
})

const enumIcon = computed(() => {
  const enumObj = typeof props.enumValue === 'object' ? props.enumValue : null
  return enumObj?.icon
})

// Check if the color is a hex color (starts with #)
const isHexColor = (color: string) => {
  return color && color.startsWith('#') && color.length === 7
}

// Get dynamic color from EnumValue if available
const dynamicColor = computed(() => {
  const enumObj = typeof props.enumValue === 'object' ? props.enumValue : null
  if (enumObj?.color && isHexColor(enumObj.color)) {
    return enumObj.color
  }
  return null
})

const colorClasses = computed(() => {
  if (dynamicColor.value) {
    // Use basic classes when we have dynamic color
    return 'border'
  }

  const enumObj = typeof props.enumValue === 'object' ? props.enumValue : null
  if (!enumObj?.color) {
    return 'bg-gray-50 text-gray-700 border border-gray-200 dark:bg-gray-900/30 dark:text-gray-400 dark:border-gray-800'
  }

  const color = enumObj.color
  const colorMap = {
    'gray': 'bg-gray-50 text-gray-700 border border-gray-200 dark:bg-gray-900/30 dark:text-gray-400 dark:border-gray-800',
    'red': 'bg-red-50 text-red-700 border border-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800',
    'orange': 'bg-orange-50 text-orange-700 border border-orange-200 dark:bg-orange-900/30 dark:text-orange-400 dark:border-orange-800',
    'yellow': 'bg-yellow-50 text-yellow-700 border border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-400 dark:border-yellow-800',
    'green': 'bg-green-50 text-green-700 border border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800',
    'blue': 'bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-900/30 dark:text-blue-400 dark:border-blue-800',
    'purple': 'bg-purple-50 text-purple-700 border border-purple-200 dark:bg-purple-900/30 dark:text-purple-400 dark:border-purple-800',
    'pink': 'bg-pink-50 text-pink-700 border border-pink-200 dark:bg-pink-900/30 dark:text-pink-400 dark:border-pink-800'
  }

  return colorMap[color as keyof typeof colorMap] || colorMap.gray
})

const dotColorClasses = computed(() => {
  if (dynamicColor.value) {
    return '' // No classes needed, will use styles
  }

  const enumObj = typeof props.enumValue === 'object' ? props.enumValue : null
  if (!enumObj?.color) {
    return 'bg-gray-500'
  }

  const color = enumObj.color
  const colorMap = {
    'gray': 'bg-gray-500',
    'red': 'bg-red-500',
    'orange': 'bg-orange-500',
    'yellow': 'bg-yellow-500',
    'green': 'bg-green-500',
    'blue': 'bg-blue-500',
    'purple': 'bg-purple-500',
    'pink': 'bg-pink-500'
  }

  return colorMap[color as keyof typeof colorMap] || colorMap.gray
})

// Dynamic styles for custom colors
const dynamicStyles = computed(() => {
  if (!dynamicColor.value) return {}
  
  const color = dynamicColor.value
  // Convert hex to RGB for alpha values
  const hex = color.replace('#', '')
  const r = parseInt(hex.substr(0, 2), 16)
  const g = parseInt(hex.substr(2, 2), 16)
  const b = parseInt(hex.substr(4, 2), 16)
  
  return {
    backgroundColor: `rgba(${r}, ${g}, ${b}, 0.1)`,
    color: color, // Use the enum color directly for text
    borderColor: `rgba(${r}, ${g}, ${b}, 0.3)`
  }
})

const dotStyles = computed(() => {
  if (!dynamicColor.value) return {}
  
  return {
    backgroundColor: dynamicColor.value
  }
})

const getIconComponent = (iconName: string) => {
  return iconMap[iconName as keyof typeof iconMap] || ClipboardDocumentListIcon
}
</script>
