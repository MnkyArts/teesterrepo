<template>
  <button
    @click="toggleColorMode"
    class="p-2 text-gray-400 hover:text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors duration-200"
    :title="colorMode.value === 'dark' ? 'Hell-Modus aktivieren' : 'Dunkel-Modus aktivieren'"
  >
    <SunIcon v-if="colorMode.value === 'dark'" class="h-5 w-5" />
    <MoonIcon v-else class="h-5 w-5" />
  </button>
</template>

<script setup lang="ts">
import { SunIcon, MoonIcon } from '@heroicons/vue/24/outline'

const colorMode = useColorMode()

const toggleColorMode = () => {
  colorMode.preference = colorMode.value === 'dark' ? 'light' : 'dark'
}
</script>
