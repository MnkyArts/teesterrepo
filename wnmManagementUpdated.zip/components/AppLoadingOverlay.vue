<template>
  <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-sm w-full mx-4">
      <div class="text-center">
        <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
          {{ loadingMessage || 'Lädt...' }}
        </h3>
        <p class="text-sm text-gray-500 dark:text-gray-400">
          Bitte warten Sie einen Moment
        </p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
// Composables
const { loadingMessage } = useGlobalLoading()
</script>
