<template>
  <div
    v-if="isOpen"
    :class="`fixed inset-0 overflow-y-auto z-[${modalZIndex}]`"
    aria-labelledby="modal-title"
    role="dialog"
    aria-modal="true"
  >
    <!-- Backdrop -->
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
      <div
        class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
        @click="closeModal"
      ></div>

      <!-- Modal Panel -->
      <div 
        v-if="user"
        class="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-2xl sm:w-full"
      >
        <!-- Header -->
        <div class="bg-white dark:bg-gray-800 px-6 pt-6 pb-4">
          <div class="flex items-center justify-between">
            <div class="flex items-center space-x-4">
              <div class="relative">
                <img
                  v-if="user.avatar"
                  :src="user.avatar"
                  :alt="`${user.firstName} ${user.lastName}`"
                  class="h-16 w-16 rounded-full object-cover"
                />
                <div
                  v-else
                  class="h-16 w-16 rounded-full bg-primary-500 flex items-center justify-center text-white text-xl font-medium"
                >
                  {{ getInitials }}
                </div>
                
                <!-- Status Indicator -->
                <div 
                  class="absolute -bottom-1 -right-1 h-5 w-5 rounded-full border-2 border-white dark:border-gray-800"
                  :class="getStatusColor"
                ></div>
              </div>
              
              <div>
                <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                  {{ user.firstName }} {{ user.lastName }}
                </h3>
                <p class="text-gray-600 dark:text-gray-400">
                  {{ user.email }}
                </p>
                <div class="mt-1">
                  <UserRoleBadge :role="user.role" />
                </div>
              </div>
            </div>
            
            <button
              @click="closeModal"
              class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <XMarkIcon class="h-6 w-6" />
            </button>
          </div>
        </div>

        <!-- Content -->
        <div class="px-6 pb-6">
          <!-- Status und Informationen -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <!-- Basic Info -->
            <div class="space-y-4">
              <h4 class="text-lg font-medium text-gray-900 dark:text-white">
                Allgemeine Informationen
              </h4>
              
              <div class="space-y-3">
                <div>
                  <span class="text-sm text-gray-500 dark:text-gray-400">Status:</span>
                  <span
                    class="ml-2 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium"
                    :class="user.isActive 
                      ? 'bg-green-50 text-green-700 border border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800'
                      : 'bg-red-50 text-red-700 border border-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800'
                    "
                  >
                    {{ user.isActive ? 'Aktiv' : 'Inaktiv' }}
                  </span>
                </div>
                
                <div>
                  <span class="text-sm text-gray-500 dark:text-gray-400">Registriert:</span>
                  <span class="ml-2 text-sm text-gray-900 dark:text-white">
                    {{ formatDate(user.createdAt) }}
                  </span>
                </div>
                
                <div>
                  <span class="text-sm text-gray-500 dark:text-gray-400">Letzter Login:</span>
                  <span class="ml-2 text-sm text-gray-900 dark:text-white">
                    {{ formatLastLogin }}
                  </span>
                </div>
                
                <div>
                  <span class="text-sm text-gray-500 dark:text-gray-400">Zuletzt aktualisiert:</span>
                  <span class="ml-2 text-sm text-gray-900 dark:text-white">
                    {{ formatDate(user.updatedAt) }}
                  </span>
                </div>
              </div>
            </div>

            <!-- Activity Stats -->
            <div class="space-y-4">
              <h4 class="text-lg font-medium text-gray-900 dark:text-white">
                Aktivitäts-Statistiken
              </h4>
              
              <div class="grid grid-cols-2 gap-3">
                <div class="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                    {{ user._count?.assignedTasks || 0 }}
                  </div>
                  <div class="text-xs text-gray-500 dark:text-gray-400">
                    Zugewiesene Tasks
                  </div>
                </div>
                
                <div class="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                    {{ user._count?.createdTasks || 0 }}
                  </div>
                  <div class="text-xs text-gray-500 dark:text-gray-400">
                    Erstellte Tasks
                  </div>
                </div>
                
                <div class="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                    {{ user._count?.projectMembers || 0 }}
                  </div>
                  <div class="text-xs text-gray-500 dark:text-gray-400">
                    Projekte
                  </div>
                </div>
                
                <div class="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div class="text-2xl font-semibold text-gray-900 dark:text-white">
                    {{ user._count?.timeEntries || 0 }}
                  </div>
                  <div class="text-xs text-gray-500 dark:text-gray-400">
                    Zeiteinträge
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Skills Section -->
          <div class="mb-6">
            <SkillDisplay 
              :user-id="user.id" 
              :can-edit="canEditUser"
              @open-skill-modal="handleOpenSkillModal"
            />
          </div>

          <!-- Role Description -->
          <div class="border-t border-gray-200 dark:border-gray-700 pt-6">
            <h4 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
              Rolle & Berechtigungen
            </h4>
            <p class="text-sm text-gray-600 dark:text-gray-400">
              {{ getRoleDescription }}
            </p>
          </div>
        </div>

        <!-- Footer -->
        <div class="bg-gray-50 dark:bg-gray-700 px-6 py-3 flex justify-end">
          <button
            @click="closeModal"
            class="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700"
          >
            Schließen
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { XMarkIcon } from '@heroicons/vue/24/outline'

interface Props {
  isOpen: boolean
  user: any
}

const props = defineProps<Props>()

const emit = defineEmits<{
  close: []
  'open-skill-modal': [userId: string, skills: any[]]
}>()

// Stores
const teamStore = useTeamManagementStore()
const authStore = useAuthStore()
const { user: currentUser } = storeToRefs(authStore)

const uiStore = useUIStore()
const { openModal, closeModal: closeModalFromStack, getModalZIndex } = uiStore

// Modal ID for stack management
const modalId = 'user-detail-modal'

// Computed
const modalZIndex = computed(() => getModalZIndex(modalId))

const getInitials = computed(() => {
  if (!props.user || !props.user.firstName || !props.user.lastName) {
    return '??'
  }
  return `${props.user.firstName[0]}${props.user.lastName[0]}`.toUpperCase()
})

const getStatusColor = computed(() => {
  if (!props.user) return 'bg-gray-400'
  
  const lastLogin = props.user.lastLoginAt
  if (!lastLogin) return 'bg-gray-400'
  
  const hoursAgo = (Date.now() - new Date(lastLogin).getTime()) / (1000 * 60 * 60)
  
  if (hoursAgo < 1) return 'bg-green-500'
  if (hoursAgo < 24) return 'bg-yellow-500'
  return 'bg-gray-400'
})

const formatLastLogin = computed(() => {
  if (!props.user || !props.user.lastLoginAt) return 'Nie'
  
  const lastLogin = new Date(props.user.lastLoginAt)
  const now = new Date()
  const diffMs = now.getTime() - lastLogin.getTime()
  const diffHours = diffMs / (1000 * 60 * 60)
  const diffDays = diffMs / (1000 * 60 * 60 * 24)
  
  if (diffHours < 1) return 'Vor weniger als einer Stunde'
  if (diffHours < 24) return `Vor ${Math.floor(diffHours)} Stunden`
  if (diffDays < 7) return `Vor ${Math.floor(diffDays)} Tagen`
  
  return lastLogin.toLocaleDateString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  })
})

const skillsByCategory = computed(() => {
  if (!props.user || !props.user.skills) return {}
  
  return props.user.skills.reduce((acc: any, skill: any) => {
    if (!acc[skill.category]) {
      acc[skill.category] = []
    }
    acc[skill.category].push(skill)
    return acc
  }, {})
})

const getRoleDescription = computed(() => {
  if (!props.user || !teamStore.userRoles || !Array.isArray(teamStore.userRoles)) {
    return 'Keine Beschreibung verfügbar'
  }
  const role = teamStore.userRoles.find((r: any) => r.value === props.user.role)
  return role?.description || 'Keine Beschreibung verfügbar'
})

const canEditUser = computed(() => {
  if (!currentUser.value || !props.user) return false
  
  // Admin und Projektleiter können alle Benutzer bearbeiten
  if (['ADMINISTRATOR', 'PROJEKTLEITER'].includes(currentUser.value.role)) {
    return true
  }
  
  // Benutzer können ihre eigenen Skills bearbeiten
  return currentUser.value.id === props.user.id
})

// Watch for modal open/close
watch(() => props.isOpen, (newValue) => {
  if (newValue) {
    openModal(modalId)
  } else {
    closeModalFromStack(modalId)
  }
}, { immediate: true })

// Methods
const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

const closeModal = () => {
  closeModalFromStack(modalId)
  emit('close')
}

const handleOpenSkillModal = (userId: string, skills: any[]) => {
  emit('open-skill-modal', userId, skills)
}
</script>
