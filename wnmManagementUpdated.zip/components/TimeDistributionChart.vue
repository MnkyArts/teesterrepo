<template>
  <div class="space-y-4">
    <!-- Chart Container -->
    <div class="h-64 w-full">
      <canvas ref="chartCanvas" class="w-full h-full"></canvas>
    </div>
    
    <!-- Legend -->
    <div class="flex flex-wrap gap-4">
      <div 
        v-for="(item, index) in data" 
        :key="index"
        class="flex items-center space-x-2">
        <div 
          class="w-3 h-3 rounded-sm"
          :style="{ backgroundColor: getColor(index) }">
        </div>
        <span class="text-sm text-gray-700 dark:text-gray-300">
          {{ item.name }} ({{ formatHours(item.hours) }}h)
        </span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick, watch } from 'vue'

interface TimeDistributionData {
  name: string
  hours: number
  color?: string
}

interface Props {
  data: TimeDistributionData[]
}

const props = defineProps<Props>()

const chartCanvas = ref<HTMLCanvasElement>()
let chart: any = null

// Color palette
const colors = [
  '#3B82F6', // blue
  '#10B981', // green  
  '#F59E0B', // yellow
  '#EF4444', // red
  '#8B5CF6', // purple
  '#F97316', // orange
  '#06B6D4', // cyan
  '#84CC16', // lime
]

const getColor = (index: number) => {
  return colors[index % colors.length]
}

const formatHours = (hours: number) => {
  return hours ? hours.toFixed(1) : '0.0'
}

const renderChart = async () => {
  await nextTick()
  
  if (!chartCanvas.value || !props.data.length) return
  
  // Destroy existing chart
  if (chart) {
    chart.destroy()
  }
  
  const ctx = chartCanvas.value.getContext('2d')
  if (!ctx) return
  
  // Simple pie chart implementation
  const total = props.data.reduce((sum, item) => sum + item.hours, 0)
  let currentAngle = -Math.PI / 2 // Start from top
  
  const centerX = chartCanvas.value.width / 2
  const centerY = chartCanvas.value.height / 2
  const radius = Math.min(centerX, centerY) - 20
  
  ctx.clearRect(0, 0, chartCanvas.value.width, chartCanvas.value.height)
  
  props.data.forEach((item, index) => {
    const sliceAngle = (item.hours / total) * 2 * Math.PI
    
    // Draw slice
    ctx.fillStyle = getColor(index)
    ctx.beginPath()
    ctx.moveTo(centerX, centerY)
    ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle)
    ctx.closePath()
    ctx.fill()
    
    // Draw border
    ctx.strokeStyle = '#ffffff'
    ctx.lineWidth = 2
    ctx.stroke()
    
    currentAngle += sliceAngle
  })
}

const resizeCanvas = () => {
  if (!chartCanvas.value) return
  
  const container = chartCanvas.value.parentElement
  if (!container) return
  
  chartCanvas.value.width = container.clientWidth
  chartCanvas.value.height = container.clientHeight
  
  renderChart()
}

watch(() => props.data, () => {
  renderChart()
}, { deep: true })

onMounted(() => {
  resizeCanvas()
  window.addEventListener('resize', resizeCanvas)
})
</script>
