-- Migration: Dynamische Enums für Tasks und Tickets
-- Datum: 22.06.2025

-- 1. Erstelle neue Tabellen für dynamische Enums
CREATE TABLE enum_categories (
    id TEXT PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    label TEXT NOT NULL,
    description TEXT,
    is_system BOOLEAN DEFAULT false NOT NULL,
    sort_order INTEGER DEFAULT 0 NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE enum_values (
    id TEXT PRIMARY KEY,
    key TEXT NOT NULL,
    label TEXT NOT NULL,
    description TEXT,
    color TEXT,
    icon TEXT,
    is_default BOOLEAN DEFAULT false NOT NULL,
    is_active BOOLEAN DEFAULT true NOT NULL,
    sort_order INTEGER DEFAULT 0 NOT NULL,
    category_id TEXT NOT NULL REFERENCES enum_categories(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    UNIQUE(category_id, key)
);

CREATE TABLE project_enum_overrides (
    id TEXT PRIMARY KEY,
    is_active BOOLEAN DEFAULT true NOT NULL,
    sort_order INTEGER,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    category_id TEXT NOT NULL REFERENCES enum_categories(id) ON DELETE CASCADE,
    enum_value_id TEXT NOT NULL REFERENCES enum_values(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    UNIQUE(project_id, category_id, enum_value_id)
);

-- 2. Indices für Performance
CREATE INDEX idx_enum_values_category_active ON enum_values(category_id, is_active);
CREATE INDEX idx_enum_values_category_sort ON enum_values(category_id, sort_order);
CREATE INDEX idx_project_enum_overrides_project ON project_enum_overrides(project_id);
CREATE INDEX idx_project_enum_overrides_category ON project_enum_overrides(category_id);

-- 3. Füge neue Spalten zu Tasks und Tickets hinzu
ALTER TABLE tasks ADD COLUMN type_id TEXT REFERENCES enum_values(id);
ALTER TABLE tasks ADD COLUMN priority_id TEXT REFERENCES enum_values(id);
ALTER TABLE tasks ADD COLUMN status_id TEXT REFERENCES enum_values(id);

ALTER TABLE tickets ADD COLUMN type_id TEXT REFERENCES enum_values(id);
ALTER TABLE tickets ADD COLUMN priority_id TEXT REFERENCES enum_values(id);
ALTER TABLE tickets ADD COLUMN status_id TEXT REFERENCES enum_values(id);

-- 4. Erstelle Indices für neue Spalten
CREATE INDEX idx_tasks_type_id ON tasks(type_id);
CREATE INDEX idx_tasks_priority_id ON tasks(priority_id);
CREATE INDEX idx_tasks_status_id ON tasks(status_id);
CREATE INDEX idx_tasks_assignee_status ON tasks(assignee_id, status_id);
CREATE INDEX idx_tasks_project_status ON tasks(project_id, status_id);

CREATE INDEX idx_tickets_type_id ON tickets(type_id);
CREATE INDEX idx_tickets_priority_id ON tickets(priority_id);
CREATE INDEX idx_tickets_status_id ON tickets(status_id);

-- 5. Initialisiere Standard-Enum-Kategorien
INSERT INTO enum_categories (id, name, label, description, is_system, sort_order) VALUES
('task_type_cat', 'task_type', 'Aufgabentyp', 'Kategorien für Aufgabentypen', true, 1),
('priority_cat', 'priority', 'Priorität', 'Prioritätsstufen für Aufgaben und Tickets', true, 2),
('task_status_cat', 'task_status', 'Aufgaben-Status', 'Status-Stufen für Aufgaben', true, 3),
('ticket_type_cat', 'ticket_type', 'Ticket-Typ', 'Kategorien für Support-Tickets', true, 4),
('ticket_status_cat', 'ticket_status', 'Ticket-Status', 'Status-Stufen für Support-Tickets', true, 5);

-- 6. Initialisiere Standard Task-Typen
INSERT INTO enum_values (id, key, label, description, color, icon, is_default, sort_order, category_id) VALUES
('task_type_bug', 'BUG', 'Bug', 'Fehlerbehebung', '#ef4444', 'bug-ant', false, 1, 'task_type_cat'),
('task_type_feature', 'FEATURE', 'Feature', 'Neue Funktionalität', '#10b981', 'sparkles', true, 2, 'task_type_cat'),
('task_type_improvement', 'VERBESSERUNG', 'Verbesserung', 'Optimierung bestehender Features', '#3b82f6', 'arrow-trending-up', false, 3, 'task_type_cat'),
('task_type_task', 'AUFGABE', 'Aufgabe', 'Allgemeine Arbeitsaufgabe', '#6b7280', 'clipboard-document-list', false, 4, 'task_type_cat'),
('task_type_story', 'STORY', 'User Story', 'Benutzeranforderung', '#8b5cf6', 'user', false, 5, 'task_type_cat'),
('task_type_epic', 'EPIC', 'Epic', 'Große Anforderung mit Sub-Tasks', '#f59e0b', 'flag', false, 6, 'task_type_cat');

-- 7. Initialisiere Standard-Prioritäten
INSERT INTO enum_values (id, key, label, description, color, icon, is_default, sort_order, category_id) VALUES
('priority_low', 'NIEDRIG', 'Niedrig', 'Niedrige Priorität', '#6b7280', 'arrow-down', false, 1, 'priority_cat'),
('priority_normal', 'NORMAL', 'Normal', 'Normale Priorität', '#3b82f6', 'minus', true, 2, 'priority_cat'),
('priority_high', 'HOCH', 'Hoch', 'Hohe Priorität', '#f59e0b', 'arrow-up', false, 3, 'priority_cat'),
('priority_critical', 'KRITISCH', 'Kritisch', 'Kritische Priorität', '#ef4444', 'exclamation-triangle', false, 4, 'priority_cat'),
('priority_blocker', 'BLOCKER', 'Blocker', 'Blockierende Priorität', '#dc2626', 'no-symbol', false, 5, 'priority_cat');

-- 8. Initialisiere Standard Task-Status
INSERT INTO enum_values (id, key, label, description, color, icon, is_default, sort_order, category_id) VALUES
('task_status_planned', 'GEPLANT', 'Geplant', 'Aufgabe ist geplant', '#6b7280', 'clock', true, 1, 'task_status_cat'),
('task_status_design', 'TECHNISCHES_DESIGN', 'Technisches Design', 'In der Designphase', '#8b5cf6', 'pencil-square', false, 2, 'task_status_cat'),
('task_status_progress', 'IN_BEARBEITUNG', 'In Bearbeitung', 'Wird aktiv bearbeitet', '#3b82f6', 'play', false, 3, 'task_status_cat'),
('task_status_review', 'REVIEW', 'Review', 'Zur Überprüfung', '#f59e0b', 'eye', false, 4, 'task_status_cat'),
('task_status_testing', 'TESTING', 'Testing', 'Wird getestet', '#06b6d4', 'beaker', false, 5, 'task_status_cat'),
('task_status_done', 'ERLEDIGT', 'Erledigt', 'Erfolgreich abgeschlossen', '#10b981', 'check', false, 6, 'task_status_cat'),
('task_status_closed', 'GESCHLOSSEN', 'Geschlossen', 'Aufgabe geschlossen', '#374151', 'lock-closed', false, 7, 'task_status_cat');

-- 9. Initialisiere Standard Ticket-Typen
INSERT INTO enum_values (id, key, label, description, color, icon, is_default, sort_order, category_id) VALUES
('ticket_type_support', 'SUPPORT', 'Support-Anfrage', 'Allgemeine Support-Anfrage', '#3b82f6', 'question-mark-circle', true, 1, 'ticket_type_cat'),
('ticket_type_bug_report', 'BUG_REPORT', 'Fehlermeldung', 'Meldung eines Fehlers', '#ef4444', 'exclamation-triangle', false, 2, 'ticket_type_cat'),
('ticket_type_feature_request', 'FEATURE_REQUEST', 'Feature-Wunsch', 'Wunsch nach neuer Funktionalität', '#10b981', 'light-bulb', false, 3, 'ticket_type_cat'),
('ticket_type_billing', 'BILLING', 'Abrechnung', 'Fragen zur Rechnung oder Abrechnung', '#f59e0b', 'credit-card', false, 4, 'ticket_type_cat'),
('ticket_type_account', 'ACCOUNT', 'Konto-Verwaltung', 'Benutzerkonto und Zugangsdaten', '#8b5cf6', 'user-circle', false, 5, 'ticket_type_cat');

-- 10. Initialisiere Standard Ticket-Status
INSERT INTO enum_values (id, key, label, description, color, icon, is_default, sort_order, category_id) VALUES
('ticket_status_open', 'OFFEN', 'Offen', 'Ticket wurde erstellt', '#ef4444', 'exclamation-circle', true, 1, 'ticket_status_cat'),
('ticket_status_progress', 'IN_BEARBEITUNG', 'In Bearbeitung', 'Ticket wird bearbeitet', '#3b82f6', 'play', false, 2, 'ticket_status_cat'),
('ticket_status_waiting', 'WARTEN_AUF_KUNDE', 'Warten auf Kunde', 'Warten auf Kunden-Feedback', '#f59e0b', 'clock', false, 3, 'ticket_status_cat'),
('ticket_status_resolved', 'GELOEST', 'Gelöst', 'Problem wurde behoben', '#10b981', 'check-circle', false, 4, 'ticket_status_cat'),
('ticket_status_closed', 'GESCHLOSSEN', 'Geschlossen', 'Ticket wurde geschlossen', '#6b7280', 'x-circle', false, 5, 'ticket_status_cat');
