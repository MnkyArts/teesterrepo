#!/usr/bin/env node

/**
 * Module Management Utility
 * 
 * This script allows you to easily enable/disable modules from the command line.
 * 
 * Usage:
 *   node scripts/modules.js list                    # List all modules and their status
 *   node scripts/modules.js enable timetracking     # Enable timetracking module
 *   node scripts/modules.js disable team            # Disable team module
 *   node scripts/modules.js validate                # Validate module dependencies
 */

import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const configPath = path.join(__dirname, '..', 'modules.config.ts')

// Read the current module configuration
function readModuleConfig() {
  try {
    const content = fs.readFileSync(configPath, 'utf8')
    
    // Extract the modulesConfig object (improved regex-based parsing)
    const match = content.match(/export const modulesConfig: ModulesConfig = ({[\s\S]*?^})/m)
    if (!match) {
      throw new Error('Could not parse modulesConfig from file')
    }
    
    // This is a simplified parser - in production you might want to use a proper TypeScript parser
    const configString = match[1]
    return { content, configString }
  } catch (error) {
    console.error('Error reading module configuration:', error.message)
    process.exit(1)
  }
}

// Write the updated module configuration
function writeModuleConfig(content) {
  try {
    fs.writeFileSync(configPath, content, 'utf8')
    console.log('✓ Module configuration updated successfully')
  } catch (error) {
    console.error('Error writing module configuration:', error.message)
    process.exit(1)
  }
}

// Parse module info from the config string
function parseModules(configString) {
  const modules = {}
  // More robust regex to handle TypeScript interface syntax
  const moduleRegex = /\/\/[^\n]*\n\s*(\w+):\s*{\s*enabled:\s*(true|false)/g
  
  let match
  while ((match = moduleRegex.exec(configString)) !== null) {
    modules[match[1]] = {
      name: match[1],
      enabled: match[2] === 'true'
    }
  }
  
  // Fallback: simple module name extraction
  if (Object.keys(modules).length === 0) {
    const simpleRegex = /(\w+):\s*{\s*enabled:\s*(true|false)/g
    while ((match = simpleRegex.exec(configString)) !== null) {
      modules[match[1]] = {
        name: match[1],
        enabled: match[2] === 'true'
      }
    }
  }
  
  return modules
}

// Commands
function listModules() {
  const { configString } = readModuleConfig()
  const modules = parseModules(configString)
  
  console.log('\n📦 Module Status:\n')
  console.log('Module'.padEnd(15) + 'Status'.padEnd(10) + 'Description')
  console.log('─'.repeat(50))
  
  Object.values(modules).forEach(module => {
    const status = module.enabled ? '✓ Enabled' : '✗ Disabled'
    const statusColor = module.enabled ? '\x1b[32m' : '\x1b[31m'
    console.log(
      module.name.padEnd(15) + 
      `${statusColor}${status}\x1b[0m`.padEnd(20)
    )
  })
  
  console.log()
}

function toggleModule(moduleName, enable) {
  const { content, configString } = readModuleConfig()
  const modules = parseModules(configString)
  
  if (!modules[moduleName]) {
    console.error(`❌ Module "${moduleName}" not found`)
    console.log('Available modules:', Object.keys(modules).join(', '))
    process.exit(1)
  }
  
  if (modules[moduleName].enabled === enable) {
    const action = enable ? 'enabled' : 'disabled'
    console.log(`ℹ️  Module "${moduleName}" is already ${action}`)
    return
  }
  
  // Replace the enabled value for the specific module
  const moduleRegex = new RegExp(`(${moduleName}:\\s*{[^}]*enabled:\\s*)(true|false)`)
  const newContent = content.replace(moduleRegex, `$1${enable}`)
  
  if (newContent === content) {
    console.error(`❌ Could not update module "${moduleName}"`)
    process.exit(1)
  }
  
  writeModuleConfig(newContent)
  
  const action = enable ? 'enabled' : 'disabled'
  console.log(`✓ Module "${moduleName}" ${action}`)
  console.log('⚠️  Restart the development server to apply changes')
}

function validateModules() {
  console.log('🔍 Validating module dependencies...')
  
  // For now, just inform that validation should be done in the app
  console.log('ℹ️  Module dependency validation is performed automatically when the app starts')
  console.log('   You can also check dependencies at: http://localhost:3000/admin/modules')
}

// Main command handler
function main() {
  const args = process.argv.slice(2)
  
  if (args.length === 0) {
    console.log(`
Module Management Utility

Usage:
  node scripts/modules.js list                    # List all modules and their status
  node scripts/modules.js enable <module>         # Enable a module
  node scripts/modules.js disable <module>        # Disable a module
  node scripts/modules.js validate                # Validate module dependencies

Examples:
  node scripts/modules.js enable timetracking
  node scripts/modules.js disable team
    `)
    return
  }
  
  const command = args[0]
  
  switch (command) {
    case 'list':
      listModules()
      break
      
    case 'enable':
      if (!args[1]) {
        console.error('❌ Please specify a module name')
        process.exit(1)
      }
      toggleModule(args[1], true)
      break
      
    case 'disable':
      if (!args[1]) {
        console.error('❌ Please specify a module name')
        process.exit(1)
      }
      toggleModule(args[1], false)
      break
      
    case 'validate':
      validateModules()
      break
      
    default:
      console.error(`❌ Unknown command: ${command}`)
      process.exit(1)
  }
}

main()
