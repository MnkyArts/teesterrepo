<template>
  <div class="min-h-screen bg-gray-50 dark:bg-gray-900">
    <!-- Navigation Header -->
    <AppHeader />
    
    <!-- Main Content Area -->
    <div class="flex w-full">
      <!-- Sidebar Navigation -->
      <AppSidebar v-if="showSidebar" />
      
      <!-- Page Content -->
      <main class="flex-1 transition-all duration-300" :class="contentClasses">
        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <slot />
        </div>
      </main>
    </div>

    <!-- Global Notifications -->
    <AppNotifications v-if="isModuleEnabled('notifications')" />
    
    <!-- Loading Overlay -->
    <AppLoadingOverlay v-if="isLoading" />
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

// Stores für Layout-Zustand
const route = useRoute()
const authStore = useAuthStore()
const { isLoggedIn } = storeToRefs(authStore)
const { isLoading } = useGlobalLoading()
const { isModuleEnabled } = useModules()

// Layout-Konfiguration basierend auf Route
const showSidebar = computed(() => {
  return isLoggedIn.value && !route.path.includes('/auth/')
})

const contentClasses = computed(() => {
  return {
    'ml-64': showSidebar.value,
    'ml-0': !showSidebar.value
  }
})
</script>
