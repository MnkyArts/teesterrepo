<template>
  <div class="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center flex-col">
    <div class="max-w-md w-full space-y-8 p-8">
      <div class="text-center">
        <div class="flex items-center justify-center mb-6">
          <div class="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
            <span class="text-white font-bold text-xl">W</span>
          </div>
          <div class="ml-3">
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">wnmManagement</h1>
            <p class="text-sm text-gray-500 dark:text-gray-400">Projekt- & Kundenverwaltung</p>
          </div>
        </div>
      </div>
      
      <div class="card p-8">
        <slot />
      </div>
      
      <div class="text-center">
        <p class="text-xs text-gray-500 dark:text-gray-400">
          © 2025 wnmManagement. Alle Rechte vorbehalten.
        </p>
      </div>
    </div>
    
    <!-- Theme Toggle -->
    <ClientOnly>
      <div class="fixed top-4 right-4">
        <ColorModeToggle />
      </div>
    </ClientOnly>
  </div>
</template>

<script setup lang="ts">
// Layout für Authentifizierung (Login, Register, etc.)
</script>
