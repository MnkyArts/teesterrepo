<template>
  <div id="app" class="min-h-screen">
    <NuxtRouteAnnouncer />
    
    <!-- Show minimal loading screen during auth initialization -->
    <FastAuthLoader v-if="showAuthLoading" />
    
    <!-- Main App -->
    <template v-else>
      <NuxtLoadingIndicator />
      <NuxtLayout>
        <NuxtPage />
      </NuxtLayout>
    </template>
  </div>
</template>

<script setup lang="ts">
const authStore = useAuthStore()
const { isInitialized: isAuthInitialized, hasCheckedAuth } = storeToRefs(authStore)

// Optimized auth loading state - nur anzeigen wenn wirklich noch nicht gecheckt
const showAuthLoading = computed(() => {
  return process.client && !hasCheckedAuth.value && !isAuthInitialized.value
})

// App-weite Meta-Daten
useHead({
  title: 'wnmManagement',
  meta: [
    { name: 'description', content: 'Umfassende Projektmanagement- und Issue-Tracking-Software mit integriertem Kundencenter' },
    { name: 'viewport', content: 'width=device-width, initial-scale=1' },
    { charset: 'utf-8' }
  ],
  link: [
    { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' },
    { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
    { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossorigin: '' },
    { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap' }
  ]
})
</script>
