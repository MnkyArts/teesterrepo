import process from 'node:process';globalThis._importMeta_={url:import.meta.url,env:process.env};import { tmpdir } from 'node:os';
import { defineEventHandler, handleCacheHeaders, splitCookiesString, createEvent, fetchWithEvent, isEvent, eventHandler, setHeaders, sendRedirect, proxyRequest, getRequestHeader, setResponseHeaders, setResponseStatus, send, getRequestHeaders, setResponseHeader, getRequestURL, getResponseHeader, getResponseStatus, createError, getQuery as getQuery$1, readBody, lazyEventHandler, useBase, createApp, createRouter as createRouter$1, toNodeListener, getRouterParam, toWebRequest, assertMethod, getMethod, setHeader, sendStream, getResponseStatusText } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/h3/dist/index.mjs';
import { Server } from 'node:http';
import path, { resolve, dirname, join } from 'node:path';
import nodeCrypto from 'node:crypto';
import { parentPort, threadId } from 'node:worker_threads';
import { escapeHtml } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/@vue/shared/dist/shared.cjs.js';
import { z } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/zod/dist/esm/index.js';
import { PrismaClient } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/@prisma/client/default.js';
import ExcelJS from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/exceljs/excel.js';
import PDFDocument from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/pdfkit/js/pdfkit.js';
import fs, { readFile } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { IncomingForm } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/formidable/src/index.js';
import { betterAuth } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/better-auth/dist/index.mjs';
import { prismaAdapter } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/better-auth/dist/adapters/prisma-adapter/index.mjs';
import { createAuthMiddleware } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/better-auth/dist/api/index.mjs';
import { createRenderer, getRequestDependencies, getPreloadLinks, getPrefetchLinks } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/vue-bundle-renderer/dist/runtime.mjs';
import { renderToString } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/vue/server-renderer/index.mjs';
import destr, { destr as destr$1 } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/destr/dist/index.mjs';
import { createHooks } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/hookable/dist/index.mjs';
import { createFetch, Headers as Headers$1 } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/ofetch/dist/node.mjs';
import { fetchNodeRequestHandler, callNodeRequestHandler } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/node-mock-http/dist/index.mjs';
import { createStorage, prefixStorage } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/unstorage/dist/index.mjs';
import unstorage_47drivers_47fs from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/unstorage/drivers/fs.mjs';
import { digest, hash as hash$1 } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/ohash/dist/index.mjs';
import { klona } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/klona/dist/index.mjs';
import defu, { defuFn } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/defu/dist/defu.mjs';
import { snakeCase } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/scule/dist/index.mjs';
import { getContext } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/unctx/dist/index.mjs';
import { toRouteMatcher, createRouter } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/radix3/dist/index.mjs';
import consola, { consola as consola$1 } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/consola/dist/index.mjs';
import { ErrorParser } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/youch-core/build/index.js';
import { Youch } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/youch/build/index.js';
import { SourceMapConsumer } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/nitropack/node_modules/source-map/source-map.js';
import { AsyncLocalStorage } from 'node:async_hooks';
import { stringify, uneval } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/devalue/index.js';
import { captureRawStackTrace, parseRawStackTrace } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/errx/dist/index.js';
import { isVNode, toValue, isRef } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/vue/index.mjs';
import { basename, isAbsolute } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/pathe/dist/index.mjs';
import { getIcons } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/@iconify/utils/lib/index.mjs';
import { collections } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/.nuxt/nuxt-icon-server-bundle.mjs';
import { createHead as createHead$1, propsToString, renderSSRHead } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/unhead/dist/server.mjs';
import { DeprecationsPlugin, PromisesPlugin, TemplateParamsPlugin, AliasSortingPlugin } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/unhead/dist/plugins.mjs';
import { walkResolver } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/unhead/dist/utils.mjs';
import { fileURLToPath } from 'node:url';
import { ipxFSStorage, ipxHttpStorage, createIPX, createIPXH3Handler } from 'file:///home/liamrbsn/js-projects/wnmManagementUpdated/node_modules/ipx/dist/index.mjs';

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function decode(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodeQueryKey(text) {
  return decode(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = /* @__PURE__ */ Object.create(null);
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map(
      (_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`
    ).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return input.endsWith("/");
  }
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return input.endsWith("/") ? input : input + "/";
  }
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const trimmed = input.slice(_base.length);
  return trimmed[0] === "/" ? trimmed : "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function joinRelativeURL(..._input) {
  const JOIN_SEGMENT_SPLIT_RE = /\/(?!\/)/;
  const input = _input.filter(Boolean);
  const segments = [];
  let segmentsDepth = 0;
  for (const i of input) {
    if (!i || i === "/") {
      continue;
    }
    for (const [sindex, s] of i.split(JOIN_SEGMENT_SPLIT_RE).entries()) {
      if (!s || s === ".") {
        continue;
      }
      if (s === "..") {
        if (segments.length === 1 && hasProtocol(segments[0])) {
          continue;
        }
        segments.pop();
        segmentsDepth--;
        continue;
      }
      if (sindex === 1 && segments[segments.length - 1]?.endsWith(":/")) {
        segments[segments.length - 1] += "/" + s;
        continue;
      }
      segments.push(s);
      segmentsDepth++;
    }
  }
  let url = segments.join("/");
  if (segmentsDepth >= 0) {
    if (input[0]?.startsWith("/") && !url.startsWith("/")) {
      url = "/" + url;
    } else if (input[0]?.startsWith("./") && !url.startsWith("./")) {
      url = "./" + url;
    }
  } else {
    url = "../".repeat(-1 * segmentsDepth) + url;
  }
  if (input[input.length - 1]?.endsWith("/") && !url.endsWith("/")) {
    url += "/";
  }
  return url;
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

const serverAssets = [{"baseName":"server","dir":"/home/liamrbsn/js-projects/wnmManagementUpdated/server/assets"}];

const assets = createStorage();

for (const asset of serverAssets) {
  assets.mount(asset.baseName, unstorage_47drivers_47fs({ base: asset.dir, ignore: (asset?.ignore || []) }));
}

const storage = createStorage({});

storage.mount('/assets', assets);

storage.mount('root', unstorage_47drivers_47fs({"driver":"fs","readOnly":true,"base":"/home/liamrbsn/js-projects/wnmManagementUpdated","watchOptions":{"ignored":[null]}}));
storage.mount('src', unstorage_47drivers_47fs({"driver":"fs","readOnly":true,"base":"/home/liamrbsn/js-projects/wnmManagementUpdated/server","watchOptions":{"ignored":[null]}}));
storage.mount('build', unstorage_47drivers_47fs({"driver":"fs","readOnly":false,"base":"/home/liamrbsn/js-projects/wnmManagementUpdated/.nuxt"}));
storage.mount('cache', unstorage_47drivers_47fs({"driver":"fs","readOnly":false,"base":"/home/liamrbsn/js-projects/wnmManagementUpdated/.nuxt/cache"}));
storage.mount('data', unstorage_47drivers_47fs({"driver":"fs","base":"/home/liamrbsn/js-projects/wnmManagementUpdated/.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const inlineAppConfig = {
  "nuxt": {},
  "icon": {
    "provider": "server",
    "class": "",
    "aliases": {},
    "iconifyApiEndpoint": "https://api.iconify.design",
    "localApiEndpoint": "/api/_nuxt_icon",
    "fallbackToApi": true,
    "cssSelectorPrefix": "i-",
    "cssWherePseudo": true,
    "mode": "css",
    "attrs": {
      "aria-hidden": true
    },
    "collections": [
      "academicons",
      "akar-icons",
      "ant-design",
      "arcticons",
      "basil",
      "bi",
      "bitcoin-icons",
      "bpmn",
      "brandico",
      "bx",
      "bxl",
      "bxs",
      "bytesize",
      "carbon",
      "catppuccin",
      "cbi",
      "charm",
      "ci",
      "cib",
      "cif",
      "cil",
      "circle-flags",
      "circum",
      "clarity",
      "codicon",
      "covid",
      "cryptocurrency",
      "cryptocurrency-color",
      "dashicons",
      "devicon",
      "devicon-plain",
      "ei",
      "el",
      "emojione",
      "emojione-monotone",
      "emojione-v1",
      "entypo",
      "entypo-social",
      "eos-icons",
      "ep",
      "et",
      "eva",
      "f7",
      "fa",
      "fa-brands",
      "fa-regular",
      "fa-solid",
      "fa6-brands",
      "fa6-regular",
      "fa6-solid",
      "fad",
      "fe",
      "feather",
      "file-icons",
      "flag",
      "flagpack",
      "flat-color-icons",
      "flat-ui",
      "flowbite",
      "fluent",
      "fluent-emoji",
      "fluent-emoji-flat",
      "fluent-emoji-high-contrast",
      "fluent-mdl2",
      "fontelico",
      "fontisto",
      "formkit",
      "foundation",
      "fxemoji",
      "gala",
      "game-icons",
      "geo",
      "gg",
      "gis",
      "gravity-ui",
      "gridicons",
      "grommet-icons",
      "guidance",
      "healthicons",
      "heroicons",
      "heroicons-outline",
      "heroicons-solid",
      "hugeicons",
      "humbleicons",
      "ic",
      "icomoon-free",
      "icon-park",
      "icon-park-outline",
      "icon-park-solid",
      "icon-park-twotone",
      "iconamoon",
      "iconoir",
      "icons8",
      "il",
      "ion",
      "iwwa",
      "jam",
      "la",
      "lets-icons",
      "line-md",
      "logos",
      "ls",
      "lucide",
      "lucide-lab",
      "mage",
      "majesticons",
      "maki",
      "map",
      "marketeq",
      "material-symbols",
      "material-symbols-light",
      "mdi",
      "mdi-light",
      "medical-icon",
      "memory",
      "meteocons",
      "mi",
      "mingcute",
      "mono-icons",
      "mynaui",
      "nimbus",
      "nonicons",
      "noto",
      "noto-v1",
      "octicon",
      "oi",
      "ooui",
      "openmoji",
      "oui",
      "pajamas",
      "pepicons",
      "pepicons-pencil",
      "pepicons-pop",
      "pepicons-print",
      "ph",
      "pixelarticons",
      "prime",
      "ps",
      "quill",
      "radix-icons",
      "raphael",
      "ri",
      "rivet-icons",
      "si-glyph",
      "simple-icons",
      "simple-line-icons",
      "skill-icons",
      "solar",
      "streamline",
      "streamline-emojis",
      "subway",
      "svg-spinners",
      "system-uicons",
      "tabler",
      "tdesign",
      "teenyicons",
      "token",
      "token-branded",
      "topcoat",
      "twemoji",
      "typcn",
      "uil",
      "uim",
      "uis",
      "uit",
      "uiw",
      "unjs",
      "vaadin",
      "vs",
      "vscode-icons",
      "websymbol",
      "weui",
      "whh",
      "wi",
      "wpf",
      "zmdi",
      "zondicons"
    ],
    "fetchTimeout": 1500
  }
};



const appConfig = defuFn(inlineAppConfig);

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildId": "dev",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/": {
        "ssr": false,
        "prerender": false
      },
      "/projects/**": {
        "ssr": false,
        "prerender": false
      },
      "/tasks/**": {
        "ssr": false,
        "prerender": false
      },
      "/team/**": {
        "ssr": false,
        "prerender": false
      },
      "/tickets/**": {
        "ssr": false,
        "prerender": false
      },
      "/time-tracking": {
        "ssr": false,
        "prerender": false
      },
      "/kanban": {
        "ssr": false,
        "prerender": false
      },
      "/auth/**": {
        "ssr": false,
        "prerender": false
      },
      "/customer/**": {
        "ssr": false,
        "prerender": false
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      }
    }
  },
  "public": {
    "appName": "wnmManagement",
    "appVersion": "1.0.0",
    "appUrl": "http://localhost:3000",
    "i18n": {
      "baseUrl": "",
      "defaultLocale": "de",
      "defaultDirection": "ltr",
      "strategy": "no_prefix",
      "lazy": false,
      "rootRedirect": "",
      "routesNameSeparator": "___",
      "defaultLocaleRouteNameSuffix": "default",
      "skipSettingLocaleOnNavigate": false,
      "differentDomains": false,
      "trailingSlash": false,
      "locales": [
        {
          "code": "de",
          "iso": "de-DE",
          "name": "Deutsch",
          "files": [
            {
              "path": "/home/liamrbsn/js-projects/wnmManagementUpdated/i18n/locales/de.json",
              "cache": ""
            }
          ]
        }
      ],
      "detectBrowserLanguage": {
        "alwaysRedirect": false,
        "cookieCrossOrigin": false,
        "cookieDomain": "",
        "cookieKey": "i18n_redirected",
        "cookieSecure": false,
        "fallbackLocale": "",
        "redirectOn": "root",
        "useCookie": true
      },
      "experimental": {
        "localeDetector": "",
        "switchLocalePathLinkSSR": false,
        "autoImportTranslationFunctions": false,
        "typedPages": true,
        "typedOptionsAndMessages": false,
        "generatedLocaleFilePathFormat": "absolute",
        "alternateLinkCanonicalQueries": false,
        "hmr": true
      },
      "multiDomainLocales": false
    }
  },
  "jwtSecret": "f3d2a1e8b9c7d4f6e5a3b8c9d0f7e2a1c4b9d8e7f6a1c3b5d4e2f7a9c8b0d1e3",
  "databaseUrl": "postgresql://wnm_user:wnm_password@localhost:5432/wnm_management?schema=public",
  "redisUrl": "redis://localhost:6379",
  "smtpHost": "localhost",
  "smtpPort": "587",
  "smtpUser": "",
  "smtpPass": "",
  "icon": {
    "serverKnownCssClasses": []
  },
  "ipx": {
    "baseURL": "/_ipx",
    "alias": {},
    "fs": {
      "dir": [
        "/home/liamrbsn/js-projects/wnmManagementUpdated/public"
      ]
    },
    "http": {
      "domains": []
    }
  }
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  applyEnv(runtimeConfig, envOptions);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
const _sharedAppConfig = _deepFreeze(klona(appConfig));
function useAppConfig(event) {
  {
    return _sharedAppConfig;
  }
}
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

getContext("nitro-app", {
  asyncContext: false,
  AsyncLocalStorage: void 0
});

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

function isJsonRequest(event) {
  if (hasReqHeader(event, "accept", "text/html")) {
    return false;
  }
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}

const errorHandler$0 = (async function errorhandler(error, event, { defaultHandler }) {
  if (event.handled || isJsonRequest(event)) {
    return;
  }
  const defaultRes = await defaultHandler(error, event, { json: true });
  const statusCode = error.statusCode || 500;
  if (statusCode === 404 && defaultRes.status === 302) {
    setResponseHeaders(event, defaultRes.headers);
    setResponseStatus(event, defaultRes.status, defaultRes.statusText);
    return send(event, JSON.stringify(defaultRes.body, null, 2));
  }
  if (typeof defaultRes.body !== "string" && Array.isArray(defaultRes.body.stack)) {
    defaultRes.body.stack = defaultRes.body.stack.join("\n");
  }
  const errorObject = defaultRes.body;
  const url = new URL(errorObject.url);
  errorObject.url = withoutBase(url.pathname, useRuntimeConfig(event).app.baseURL) + url.search + url.hash;
  errorObject.message ||= "Server Error";
  errorObject.data ||= error.data;
  errorObject.statusMessage ||= error.statusMessage;
  delete defaultRes.headers["content-type"];
  delete defaultRes.headers["content-security-policy"];
  setResponseHeaders(event, defaultRes.headers);
  const reqHeaders = getRequestHeaders(event);
  const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"];
  const res = isRenderingError ? null : await useNitroApp().localFetch(
    withQuery(joinURL(useRuntimeConfig(event).app.baseURL, "/__nuxt_error"), errorObject),
    {
      headers: { ...reqHeaders, "x-nuxt-error": "true" },
      redirect: "manual"
    }
  ).catch(() => null);
  if (event.handled) {
    return;
  }
  if (!res) {
    const { template } = await Promise.resolve().then(function () { return errorDev; }) ;
    {
      errorObject.description = errorObject.message;
    }
    setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
    return send(event, template(errorObject));
  }
  const html = await res.text();
  for (const [header, value] of res.headers.entries()) {
    setResponseHeader(event, header, value);
  }
  setResponseStatus(event, res.status && res.status !== 200 ? res.status : defaultRes.status, res.statusText || defaultRes.statusText);
  return send(event, html);
});

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$1 = defineNitroErrorHandler(
  async function defaultNitroErrorHandler(error, event) {
    const res = await defaultHandler(error, event);
    if (!event.node?.res.headersSent) {
      setResponseHeaders(event, res.headers);
    }
    setResponseStatus(event, res.status, res.statusText);
    return send(
      event,
      typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2)
    );
  }
);
async function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  await loadStackTrace(error).catch(consola.error);
  const youch = new Youch();
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    const ansiError = await (await youch.toANSI(error)).replaceAll(process.cwd(), ".");
    consola.error(
      `[request error] ${tags} [${event.method}] ${url}

`,
      ansiError
    );
  }
  const useJSON = opts?.json || !getRequestHeader(event, "accept")?.includes("text/html");
  const headers = {
    "content-type": useJSON ? "application/json" : "text/html",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'self';"
  };
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = useJSON ? {
    error: true,
    url,
    statusCode,
    statusMessage,
    message: error.message,
    data: error.data,
    stack: error.stack?.split("\n").map((line) => line.trim())
  } : await youch.toHTML(error, {
    request: {
      url: url.href,
      method: event.method,
      headers: getRequestHeaders(event)
    }
  });
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}
async function loadStackTrace(error) {
  if (!(error instanceof Error)) {
    return;
  }
  const parsed = await new ErrorParser().defineSourceLoader(sourceLoader).parse(error);
  const stack = error.message + "\n" + parsed.frames.map((frame) => fmtFrame(frame)).join("\n");
  Object.defineProperty(error, "stack", { value: stack });
  if (error.cause) {
    await loadStackTrace(error.cause).catch(consola.error);
  }
}
async function sourceLoader(frame) {
  if (!frame.fileName || frame.fileType !== "fs" || frame.type === "native") {
    return;
  }
  if (frame.type === "app") {
    const rawSourceMap = await readFile(`${frame.fileName}.map`, "utf8").catch(() => {
    });
    if (rawSourceMap) {
      const consumer = await new SourceMapConsumer(rawSourceMap);
      const originalPosition = consumer.originalPositionFor({ line: frame.lineNumber, column: frame.columnNumber });
      if (originalPosition.source && originalPosition.line) {
        frame.fileName = resolve(dirname(frame.fileName), originalPosition.source);
        frame.lineNumber = originalPosition.line;
        frame.columnNumber = originalPosition.column || 0;
      }
    }
  }
  const contents = await readFile(frame.fileName, "utf8").catch(() => {
  });
  return contents ? { contents } : void 0;
}
function fmtFrame(frame) {
  if (frame.type === "native") {
    return frame.raw;
  }
  const src = `${frame.fileName || ""}:${frame.lineNumber}:${frame.columnNumber})`;
  return frame.functionName ? `at ${frame.functionName} (${src}` : `at ${src}`;
}

const errorHandlers = [errorHandler$0, errorHandler$1];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

const script$1 = `
if (!window.__NUXT_DEVTOOLS_TIME_METRIC__) {
  Object.defineProperty(window, '__NUXT_DEVTOOLS_TIME_METRIC__', {
    value: {},
    enumerable: false,
    configurable: true,
  })
}
window.__NUXT_DEVTOOLS_TIME_METRIC__.appInit = Date.now()
`;

const _ZfA9onY016TtMK5ogmx_KephYuXjxIAXED5rS_s5dhc = (function(nitro) {
  nitro.hooks.hook("render:html", (htmlContext) => {
    htmlContext.head.push(`<script>${script$1}<\/script>`);
  });
});

const rootDir = "/home/liamrbsn/js-projects/wnmManagementUpdated";

const appHead = {"meta":[{"name":"viewport","content":"width=device-width, initial-scale=1"},{"charset":"utf-8"}],"link":[],"style":[],"script":[],"noscript":[]};

const appRootTag = "div";

const appRootAttrs = {"id":"__nuxt"};

const appTeleportTag = "div";

const appTeleportAttrs = {"id":"teleports"};

const appId = "nuxt-app";

const devReducers = {
  VNode: (data) => isVNode(data) ? { type: data.type, props: data.props } : void 0,
  URL: (data) => data instanceof URL ? data.toString() : void 0
};
const asyncContext = getContext("nuxt-dev", { asyncContext: true, AsyncLocalStorage });
const _6AYrd7kh2wJ4nJwRBtftKRMmmENdXHcXLeXK0DQl8A = (nitroApp) => {
  const handler = nitroApp.h3App.handler;
  nitroApp.h3App.handler = (event) => {
    return asyncContext.callAsync({ logs: [], event }, () => handler(event));
  };
  onConsoleLog((_log) => {
    const ctx = asyncContext.tryUse();
    if (!ctx) {
      return;
    }
    const rawStack = captureRawStackTrace();
    if (!rawStack || rawStack.includes("runtime/vite-node.mjs")) {
      return;
    }
    const trace = [];
    let filename = "";
    for (const entry of parseRawStackTrace(rawStack)) {
      if (entry.source === globalThis._importMeta_.url) {
        continue;
      }
      if (EXCLUDE_TRACE_RE.test(entry.source)) {
        continue;
      }
      filename ||= entry.source.replace(withTrailingSlash(rootDir), "");
      trace.push({
        ...entry,
        source: entry.source.startsWith("file://") ? entry.source.replace("file://", "") : entry.source
      });
    }
    const log = {
      ..._log,
      // Pass along filename to allow the client to display more info about where log comes from
      filename,
      // Clean up file names in stack trace
      stack: trace
    };
    ctx.logs.push(log);
  });
  nitroApp.hooks.hook("afterResponse", () => {
    const ctx = asyncContext.tryUse();
    if (!ctx) {
      return;
    }
    return nitroApp.hooks.callHook("dev:ssr-logs", { logs: ctx.logs, path: ctx.event.path });
  });
  nitroApp.hooks.hook("render:html", (htmlContext) => {
    const ctx = asyncContext.tryUse();
    if (!ctx) {
      return;
    }
    try {
      const reducers = Object.assign(/* @__PURE__ */ Object.create(null), devReducers, ctx.event.context._payloadReducers);
      htmlContext.bodyAppend.unshift(`<script type="application/json" data-nuxt-logs="${appId}">${stringify(ctx.logs, reducers)}<\/script>`);
    } catch (e) {
      const shortError = e instanceof Error && "toString" in e ? ` Received \`${e.toString()}\`.` : "";
      console.warn(`[nuxt] Failed to stringify dev server logs.${shortError} You can define your own reducer/reviver for rich types following the instructions in https://nuxt.com/docs/api/composables/use-nuxt-app#payload.`);
    }
  });
};
const EXCLUDE_TRACE_RE = /\/node_modules\/(?:.*\/)?(?:nuxt|nuxt-nightly|nuxt-edge|nuxt3|consola|@vue)\/|core\/runtime\/nitro/;
function onConsoleLog(callback) {
  consola$1.addReporter({
    log(logObj) {
      callback(logObj);
    }
  });
  consola$1.wrapConsole();
}

const script = "\"use strict\";(()=>{const t=window,e=document.documentElement,c=[\"dark\",\"light\"],n=getStorageValue(\"localStorage\",\"nuxt-color-mode\")||\"system\";let i=n===\"system\"?u():n;const r=e.getAttribute(\"data-color-mode-forced\");r&&(i=r),l(i),t[\"__NUXT_COLOR_MODE__\"]={preference:n,value:i,getColorScheme:u,addColorScheme:l,removeColorScheme:d};function l(o){const s=\"\"+o+\"\",a=\"\";e.classList?e.classList.add(s):e.className+=\" \"+s,a&&e.setAttribute(\"data-\"+a,o)}function d(o){const s=\"\"+o+\"\",a=\"\";e.classList?e.classList.remove(s):e.className=e.className.replace(new RegExp(s,\"g\"),\"\"),a&&e.removeAttribute(\"data-\"+a)}function f(o){return t.matchMedia(\"(prefers-color-scheme\"+o+\")\")}function u(){if(t.matchMedia&&f(\"\").media!==\"not all\"){for(const o of c)if(f(\":\"+o).matches)return o}return\"light\"}})();function getStorageValue(t,e){switch(t){case\"localStorage\":return window.localStorage.getItem(e);case\"sessionStorage\":return window.sessionStorage.getItem(e);case\"cookie\":return getCookie(e);default:return null}}function getCookie(t){const c=(\"; \"+window.document.cookie).split(\"; \"+t+\"=\");if(c.length===2)return c.pop()?.split(\";\").shift()}";

const _Ek5zileP85hOZD6eUURKo0GPlGngqBVdI2Kp3hZrSwE = (function(nitro) {
  nitro.hooks.hook("render:html", (htmlContext) => {
    htmlContext.head.push(`<script>${script}<\/script>`);
  });
});

const plugins = [
  _ZfA9onY016TtMK5ogmx_KephYuXjxIAXED5rS_s5dhc,
_6AYrd7kh2wJ4nJwRBtftKRMmmENdXHcXLeXK0DQl8A,
_Ek5zileP85hOZD6eUURKo0GPlGngqBVdI2Kp3hZrSwE
];

function defineRenderHandler(render) {
  const runtimeConfig = useRuntimeConfig();
  return eventHandler(async (event) => {
    const nitroApp = useNitroApp();
    const ctx = { event, render, response: void 0 };
    await nitroApp.hooks.callHook("render:before", ctx);
    if (!ctx.response) {
      if (event.path === `${runtimeConfig.app.baseURL}favicon.ico`) {
        setResponseHeader(event, "Content-Type", "image/x-icon");
        return send(
          event,
          "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
        );
      }
      ctx.response = await ctx.render(event);
      if (!ctx.response) {
        const _currentStatus = getResponseStatus(event);
        setResponseStatus(event, _currentStatus === 200 ? 500 : _currentStatus);
        return send(
          event,
          "No response returned from render handler: " + event.path
        );
      }
    }
    await nitroApp.hooks.callHook("render:response", ctx.response, ctx);
    if (ctx.response.headers) {
      setResponseHeaders(event, ctx.response.headers);
    }
    if (ctx.response.statusCode || ctx.response.statusMessage) {
      setResponseStatus(
        event,
        ctx.response.statusCode,
        ctx.response.statusMessage
      );
    }
    return ctx.response.body;
  });
}

const scheduledTasks = false;

const tasks = {
  
};

const __runningTasks__ = {};
async function runTask(name, {
  payload = {},
  context = {}
} = {}) {
  if (__runningTasks__[name]) {
    return __runningTasks__[name];
  }
  if (!(name in tasks)) {
    throw createError({
      message: `Task \`${name}\` is not available!`,
      statusCode: 404
    });
  }
  if (!tasks[name].resolve) {
    throw createError({
      message: `Task \`${name}\` is not implemented!`,
      statusCode: 501
    });
  }
  const handler = await tasks[name].resolve();
  const taskEvent = { name, payload, context };
  __runningTasks__[name] = handler.run(taskEvent);
  try {
    const res = await __runningTasks__[name];
    return res;
  } finally {
    delete __runningTasks__[name];
  }
}

function buildAssetsDir() {
  return useRuntimeConfig().app.buildAssetsDir;
}
function buildAssetsURL(...path) {
  return joinRelativeURL(publicAssetsURL(), buildAssetsDir(), ...path);
}
function publicAssetsURL(...path) {
  const app = useRuntimeConfig().app;
  const publicBase = app.cdnURL || app.baseURL;
  return path.length ? joinRelativeURL(publicBase, ...path) : publicBase;
}

const prisma$e = new PrismaClient();
const auth = betterAuth({
  database: prismaAdapter(prisma$e, {
    provider: "postgresql"
  }),
  emailAndPassword: {
    enabled: true,
    autoSignIn: true
  },
  session: {
    cookieCache: {
      enabled: true,
      maxAge: 60 * 60 * 24 * 7
      // 7 days
    }
  },
  // Map existing User fields to Better Auth requirements
  user: {
    modelName: "user",
    fields: {
      email: "email",
      name: "name",
      image: "image"
    },
    additionalFields: {
      firstName: {
        type: "string",
        required: true
      },
      lastName: {
        type: "string",
        required: true
      },
      role: {
        type: "string",
        required: true,
        defaultValue: "ENTWICKLER"
      },
      avatar: {
        type: "string",
        required: false
      },
      isActive: {
        type: "boolean",
        required: true,
        defaultValue: true
      },
      lastLoginAt: {
        type: "date",
        required: false
      }
    }
  },
  // Hooks für automatische lastLoginAt-Aktualisierung
  hooks: {
    after: createAuthMiddleware(async (ctx) => {
      var _a;
      if (ctx.path === "/sign-in/email" || ctx.path === "/sign-up/email") {
        const newSession = ctx.context.newSession;
        if ((_a = newSession == null ? void 0 : newSession.user) == null ? void 0 : _a.id) {
          await prisma$e.user.update({
            where: { id: newSession.user.id },
            data: { lastLoginAt: /* @__PURE__ */ new Date() }
          });
          console.log(`Updated lastLoginAt for user ${newSession.user.id}`);
        }
      }
    })
  }
});

const prisma$d = new PrismaClient();
async function getUserWithCustomer(userId) {
  return await prisma$d.user.findUnique({
    where: { id: userId },
    include: {
      customer: {
        select: {
          id: true,
          companyName: true,
          email: true,
          contactName: true,
          phone: true,
          isActive: true
        }
      }
    }
  });
}
function requireAuth(requiredRole) {
  return async (event) => {
    try {
      const session = await auth.api.getSession({
        headers: event.headers || {}
      });
      if (!(session == null ? void 0 : session.user)) {
        throw createError({
          statusCode: 401,
          statusMessage: "Authentifizierung erforderlich"
        });
      }
      const userWithCustomer = await getUserWithCustomer(session.user.id);
      if (!userWithCustomer) {
        throw createError({
          statusCode: 401,
          statusMessage: "Benutzer nicht gefunden"
        });
      }
      if (requiredRole && !hasPermission(userWithCustomer.role, requiredRole)) {
        throw createError({
          statusCode: 403,
          statusMessage: "Unzureichende Berechtigung"
        });
      }
      event.context.user = userWithCustomer;
      event.context.session = session;
      return userWithCustomer;
    } catch (error) {
      if (error.statusCode) {
        throw error;
      }
      throw createError({
        statusCode: 401,
        statusMessage: "Authentifizierung fehlgeschlagen"
      });
    }
  };
}
function getCurrentUser(event) {
  return event.context.user;
}
function hasPermission(userRole, requiredRole) {
  const roleHierarchy = {
    VIEWER: 1,
    KUNDE: 2,
    SUPPORTER: 3,
    ENTWICKLER: 4,
    PROJEKTLEITER: 5,
    ADMINISTRATOR: 6
  };
  const userRoleLevel = roleHierarchy[userRole] || 0;
  const requiredRoleLevel = roleHierarchy[requiredRole] || 0;
  return userRoleLevel >= requiredRoleLevel;
}

const warnOnceSet = /* @__PURE__ */ new Set();
const DEFAULT_ENDPOINT = "https://api.iconify.design";
const _X8fyKs = defineCachedEventHandler(async (event) => {
  const url = getRequestURL(event);
  if (!url)
    return createError({ status: 400, message: "Invalid icon request" });
  const options = useAppConfig().icon;
  const collectionName = event.context.params?.collection?.replace(/\.json$/, "");
  const collection = collectionName ? await collections[collectionName]?.() : null;
  const apiEndPoint = options.iconifyApiEndpoint || DEFAULT_ENDPOINT;
  const icons = url.searchParams.get("icons")?.split(",");
  if (collection) {
    if (icons?.length) {
      const data = getIcons(
        collection,
        icons
      );
      consola$1.debug(`[Icon] serving ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from bundled collection`);
      return data;
    }
  } else {
    if (collectionName && !warnOnceSet.has(collectionName) && apiEndPoint === DEFAULT_ENDPOINT) {
      consola$1.warn([
        `[Icon] Collection \`${collectionName}\` is not found locally`,
        `We suggest to install it via \`npm i -D @iconify-json/${collectionName}\` to provide the best end-user experience.`
      ].join("\n"));
      warnOnceSet.add(collectionName);
    }
  }
  if (options.fallbackToApi === true || options.fallbackToApi === "server-only") {
    const apiUrl = new URL("./" + basename(url.pathname) + url.search, apiEndPoint);
    consola$1.debug(`[Icon] fetching ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from iconify api`);
    if (apiUrl.host !== new URL(apiEndPoint).host) {
      return createError({ status: 400, message: "Invalid icon request" });
    }
    try {
      const data = await $fetch(apiUrl.href);
      return data;
    } catch (e) {
      consola$1.error(e);
      if (e.status === 404)
        return createError({ status: 404 });
      else
        return createError({ status: 500, message: "Failed to fetch fallback icon" });
    }
  }
  return createError({ status: 404 });
}, {
  group: "nuxt",
  name: "icon",
  getKey(event) {
    const collection = event.context.params?.collection?.replace(/\.json$/, "") || "unknown";
    const icons = String(getQuery$1(event).icons || "");
    return `${collection}_${icons.split(",")[0]}_${icons.length}_${hash$1(icons)}`;
  },
  swr: true,
  maxAge: 60 * 60 * 24 * 7
  // 1 week
});

const VueResolver = (_, value) => {
  return isRef(value) ? toValue(value) : value;
};

const headSymbol = "usehead";
function vueInstall(head) {
  const plugin = {
    install(app) {
      app.config.globalProperties.$unhead = head;
      app.config.globalProperties.$head = head;
      app.provide(headSymbol, head);
    }
  };
  return plugin.install;
}

function resolveUnrefHeadInput(input) {
  return walkResolver(input, VueResolver);
}

function createHead(options = {}) {
  const head = createHead$1({
    ...options,
    propResolvers: [VueResolver]
  });
  head.install = vueInstall(head);
  return head;
}

const unheadOptions = {
  disableDefaults: true,
  disableCapoSorting: false,
  plugins: [DeprecationsPlugin, PromisesPlugin, TemplateParamsPlugin, AliasSortingPlugin],
};

function createSSRContext(event) {
  const ssrContext = {
    url: event.path,
    event,
    runtimeConfig: useRuntimeConfig(event),
    noSSR: event.context.nuxt?.noSSR || (false),
    head: createHead(unheadOptions),
    error: false,
    nuxt: void 0,
    /* NuxtApp */
    payload: {},
    _payloadReducers: /* @__PURE__ */ Object.create(null),
    modules: /* @__PURE__ */ new Set()
  };
  return ssrContext;
}
function setSSRError(ssrContext, error) {
  ssrContext.error = true;
  ssrContext.payload = { error };
  ssrContext.url = error.url;
}

const APP_ROOT_OPEN_TAG = `<${appRootTag}${propsToString(appRootAttrs)}>`;
const APP_ROOT_CLOSE_TAG = `</${appRootTag}>`;
const getServerEntry = () => import('file:///home/liamrbsn/js-projects/wnmManagementUpdated/.nuxt/dist/server/server.mjs').then((r) => r.default || r);
const getClientManifest = () => import('file:///home/liamrbsn/js-projects/wnmManagementUpdated/.nuxt/dist/server/client.manifest.mjs').then((r) => r.default || r).then((r) => typeof r === "function" ? r() : r);
const getSSRRenderer = lazyCachedFunction(async () => {
  const manifest = await getClientManifest();
  if (!manifest) {
    throw new Error("client.manifest is not available");
  }
  const createSSRApp = await getServerEntry();
  if (!createSSRApp) {
    throw new Error("Server bundle is not available");
  }
  const options = {
    manifest,
    renderToString: renderToString$1,
    buildAssetsURL
  };
  const renderer = createRenderer(createSSRApp, options);
  async function renderToString$1(input, context) {
    const html = await renderToString(input, context);
    if (process.env.NUXT_VITE_NODE_OPTIONS) {
      renderer.rendererContext.updateManifest(await getClientManifest());
    }
    return APP_ROOT_OPEN_TAG + html + APP_ROOT_CLOSE_TAG;
  }
  return renderer;
});
const getSPARenderer = lazyCachedFunction(async () => {
  const manifest = await getClientManifest();
  const spaTemplate = await Promise.resolve().then(function () { return _virtual__spaTemplate; }).then((r) => r.template).catch(() => "").then((r) => {
    {
      return APP_ROOT_OPEN_TAG + r + APP_ROOT_CLOSE_TAG;
    }
  });
  const options = {
    manifest,
    renderToString: () => spaTemplate,
    buildAssetsURL
  };
  const renderer = createRenderer(() => () => {
  }, options);
  const result = await renderer.renderToString({});
  const renderToString = (ssrContext) => {
    const config = useRuntimeConfig(ssrContext.event);
    ssrContext.modules ||= /* @__PURE__ */ new Set();
    ssrContext.payload.serverRendered = false;
    ssrContext.config = {
      public: config.public,
      app: config.app
    };
    return Promise.resolve(result);
  };
  return {
    rendererContext: renderer.rendererContext,
    renderToString
  };
});
function lazyCachedFunction(fn) {
  let res = null;
  return () => {
    if (res === null) {
      res = fn().catch((err) => {
        res = null;
        throw err;
      });
    }
    return res;
  };
}
function getRenderer(ssrContext) {
  return ssrContext.noSSR ? getSPARenderer() : getSSRRenderer();
}
const getSSRStyles = lazyCachedFunction(() => Promise.resolve().then(function () { return styles$1; }).then((r) => r.default || r));

async function renderInlineStyles(usedModules) {
  const styleMap = await getSSRStyles();
  const inlinedStyles = /* @__PURE__ */ new Set();
  for (const mod of usedModules) {
    if (mod in styleMap && styleMap[mod]) {
      for (const style of await styleMap[mod]()) {
        inlinedStyles.add(style);
      }
    }
  }
  return Array.from(inlinedStyles).map((style) => ({ innerHTML: style }));
}

const ROOT_NODE_REGEX = new RegExp(`^<${appRootTag}[^>]*>([\\s\\S]*)<\\/${appRootTag}>$`);
function getServerComponentHTML(body) {
  const match = body.match(ROOT_NODE_REGEX);
  return match?.[1] || body;
}
const SSR_SLOT_TELEPORT_MARKER = /^uid=([^;]*);slot=(.*)$/;
const SSR_CLIENT_TELEPORT_MARKER = /^uid=([^;]*);client=(.*)$/;
const SSR_CLIENT_SLOT_MARKER = /^island-slot=([^;]*);(.*)$/;
function getSlotIslandResponse(ssrContext) {
  if (!ssrContext.islandContext || !Object.keys(ssrContext.islandContext.slots).length) {
    return void 0;
  }
  const response = {};
  for (const [name, slot] of Object.entries(ssrContext.islandContext.slots)) {
    response[name] = {
      ...slot,
      fallback: ssrContext.teleports?.[`island-fallback=${name}`]
    };
  }
  return response;
}
function getClientIslandResponse(ssrContext) {
  if (!ssrContext.islandContext || !Object.keys(ssrContext.islandContext.components).length) {
    return void 0;
  }
  const response = {};
  for (const [clientUid, component] of Object.entries(ssrContext.islandContext.components)) {
    const html = ssrContext.teleports?.[clientUid]?.replaceAll("<!--teleport start anchor-->", "") || "";
    response[clientUid] = {
      ...component,
      html,
      slots: getComponentSlotTeleport(clientUid, ssrContext.teleports ?? {})
    };
  }
  return response;
}
function getComponentSlotTeleport(clientUid, teleports) {
  const entries = Object.entries(teleports);
  const slots = {};
  for (const [key, value] of entries) {
    const match = key.match(SSR_CLIENT_SLOT_MARKER);
    if (match) {
      const [, id, slot] = match;
      if (!slot || clientUid !== id) {
        continue;
      }
      slots[slot] = value;
    }
  }
  return slots;
}
function replaceIslandTeleports(ssrContext, html) {
  const { teleports, islandContext } = ssrContext;
  if (islandContext || !teleports) {
    return html;
  }
  for (const key in teleports) {
    const matchClientComp = key.match(SSR_CLIENT_TELEPORT_MARKER);
    if (matchClientComp) {
      const [, uid, clientId] = matchClientComp;
      if (!uid || !clientId) {
        continue;
      }
      html = html.replace(new RegExp(` data-island-uid="${uid}" data-island-component="${clientId}"[^>]*>`), (full) => {
        return full + teleports[key];
      });
      continue;
    }
    const matchSlot = key.match(SSR_SLOT_TELEPORT_MARKER);
    if (matchSlot) {
      const [, uid, slot] = matchSlot;
      if (!uid || !slot) {
        continue;
      }
      html = html.replace(new RegExp(` data-island-uid="${uid}" data-island-slot="${slot}"[^>]*>`), (full) => {
        return full + teleports[key];
      });
    }
  }
  return html;
}

const ISLAND_SUFFIX_RE = /\.json(\?.*)?$/;
const _SxA8c9 = defineEventHandler(async (event) => {
  const nitroApp = useNitroApp();
  setResponseHeaders(event, {
    "content-type": "application/json;charset=utf-8",
    "x-powered-by": "Nuxt"
  });
  const islandContext = await getIslandContext(event);
  const ssrContext = {
    ...createSSRContext(event),
    islandContext,
    noSSR: false,
    url: islandContext.url
  };
  const renderer = await getSSRRenderer();
  const renderResult = await renderer.renderToString(ssrContext).catch(async (error) => {
    await ssrContext.nuxt?.hooks.callHook("app:error", error);
    throw error;
  });
  const inlinedStyles = await renderInlineStyles(ssrContext.modules ?? []);
  await ssrContext.nuxt?.hooks.callHook("app:rendered", { ssrContext, renderResult });
  if (inlinedStyles.length) {
    ssrContext.head.push({ style: inlinedStyles });
  }
  {
    const { styles } = getRequestDependencies(ssrContext, renderer.rendererContext);
    const link = [];
    for (const resource of Object.values(styles)) {
      if ("inline" in getQuery(resource.file)) {
        continue;
      }
      if (resource.file.includes("scoped") && !resource.file.includes("pages/")) {
        link.push({ rel: "stylesheet", href: renderer.rendererContext.buildAssetsURL(resource.file), crossorigin: "" });
      }
    }
    if (link.length) {
      ssrContext.head.push({ link }, { mode: "server" });
    }
  }
  const islandHead = {};
  for (const entry of ssrContext.head.entries.values()) {
    for (const [key, value] of Object.entries(resolveUnrefHeadInput(entry.input))) {
      const currentValue = islandHead[key];
      if (Array.isArray(currentValue)) {
        currentValue.push(...value);
      }
      islandHead[key] = value;
    }
  }
  islandHead.link ||= [];
  islandHead.style ||= [];
  const islandResponse = {
    id: islandContext.id,
    head: islandHead,
    html: getServerComponentHTML(renderResult.html),
    components: getClientIslandResponse(ssrContext),
    slots: getSlotIslandResponse(ssrContext)
  };
  await nitroApp.hooks.callHook("render:island", islandResponse, { event, islandContext });
  return islandResponse;
});
async function getIslandContext(event) {
  let url = event.path || "";
  const componentParts = url.substring("/__nuxt_island".length + 1).replace(ISLAND_SUFFIX_RE, "").split("_");
  const hashId = componentParts.length > 1 ? componentParts.pop() : void 0;
  const componentName = componentParts.join("_");
  const context = event.method === "GET" ? getQuery$1(event) : await readBody(event);
  const ctx = {
    url: "/",
    ...context,
    id: hashId,
    name: componentName,
    props: destr$1(context.props) || {},
    slots: {},
    components: {}
  };
  return ctx;
}

const _2HOdnX = lazyEventHandler(() => {
  const opts = useRuntimeConfig().ipx || {};
  const fsDir = opts?.fs?.dir ? (Array.isArray(opts.fs.dir) ? opts.fs.dir : [opts.fs.dir]).map((dir) => isAbsolute(dir) ? dir : fileURLToPath(new URL(dir, globalThis._importMeta_.url))) : void 0;
  const fsStorage = opts.fs?.dir ? ipxFSStorage({ ...opts.fs, dir: fsDir }) : void 0;
  const httpStorage = opts.http?.domains ? ipxHttpStorage({ ...opts.http }) : void 0;
  if (!fsStorage && !httpStorage) {
    throw new Error("IPX storage is not configured!");
  }
  const ipxOptions = {
    ...opts,
    storage: fsStorage || httpStorage,
    httpStorage
  };
  const ipx = createIPX(ipxOptions);
  const ipxHandler = createIPXH3Handler(ipx);
  return useBase(opts.baseURL, ipxHandler);
});

const _lazy__HzHGI = () => Promise.resolve().then(function () { return ____all_$1; });
const _lazy_Y1atCZ = () => Promise.resolve().then(function () { return stats_get$5; });
const _lazy_7ahUX9 = () => Promise.resolve().then(function () { return index_get$9; });
const _lazy_K97Ohf = () => Promise.resolve().then(function () { return mandate_delete$1; });
const _lazy_qked6M = () => Promise.resolve().then(function () { return mandate_get$1; });
const _lazy_CmKzFS = () => Promise.resolve().then(function () { return mandate_post$1; });
const _lazy_eh6IX5 = () => Promise.resolve().then(function () { return _id__get$1; });
const _lazy_thehfM = () => Promise.resolve().then(function () { return comments_get$3; });
const _lazy_JU9n9r = () => Promise.resolve().then(function () { return comments_post$3; });
const _lazy_i0gkiX = () => Promise.resolve().then(function () { return index_get$7; });
const _lazy_suZR7J = () => Promise.resolve().then(function () { return index_post$5; });
const _lazy_xJPEs_ = () => Promise.resolve().then(function () { return index_get$5; });
const _lazy_akMWmx = () => Promise.resolve().then(function () { return activities_get$1; });
const _lazy_ycYD2L = () => Promise.resolve().then(function () { return myTasks_get$1; });
const _lazy_4y8UJF = () => Promise.resolve().then(function () { return stats_get$3; });
const _lazy_dwP6iB = () => Promise.resolve().then(function () { return teamActivities_get$1; });
const _lazy_AtXKUQ = () => Promise.resolve().then(function () { return _id_$9; });
const _lazy_lq5TZw = () => Promise.resolve().then(function () { return reorder$1; });
const _lazy_m4wAqX = () => Promise.resolve().then(function () { return index$9; });
const _lazy_sKTdQO = () => Promise.resolve().then(function () { return _id_$7; });
const _lazy_jn8GgS = () => Promise.resolve().then(function () { return index$7; });
const _lazy_9AXRIp = () => Promise.resolve().then(function () { return _id_$5; });
const _lazy_2fipmv = () => Promise.resolve().then(function () { return enumConfig; });
const _lazy_XkPukU = () => Promise.resolve().then(function () { return enumOverrides$1; });
const _lazy_KeIYSu = () => Promise.resolve().then(function () { return index_get$3; });
const _lazy_EW4gyl = () => Promise.resolve().then(function () { return index_post$3; });
const _lazy_aefjbb = () => Promise.resolve().then(function () { return export_post$1; });
const _lazy_sfIVZi = () => Promise.resolve().then(function () { return financial_get$1; });
const _lazy_8uQeCX = () => Promise.resolve().then(function () { return projects_get$1; });
const _lazy_t89yZD = () => Promise.resolve().then(function () { return team_get$1; });
const _lazy_8hHcoh = () => Promise.resolve().then(function () { return time_get$1; });
const _lazy_XX9VRC = () => Promise.resolve().then(function () { return _taskId_$1; });
const _lazy_qhajga = () => Promise.resolve().then(function () { return _attachmentId_$1; });
const _lazy_hhgqae = () => Promise.resolve().then(function () { return attachments$1; });
const _lazy_LYCUYc = () => Promise.resolve().then(function () { return comments$1; });
const _lazy_0R7CVy = () => Promise.resolve().then(function () { return index$5; });
const _lazy_wTruDf = () => Promise.resolve().then(function () { return _ticketId__delete$1; });
const _lazy_V1TLvZ = () => Promise.resolve().then(function () { return _ticketId__get$1; });
const _lazy_y6Exlz = () => Promise.resolve().then(function () { return _ticketId__put$1; });
const _lazy_1oF58y = () => Promise.resolve().then(function () { return comments_get$1; });
const _lazy_WaF2Ds = () => Promise.resolve().then(function () { return comments_post$1; });
const _lazy_aqYo7J = () => Promise.resolve().then(function () { return convertToTask_post$1; });
const _lazy_NoN6jc = () => Promise.resolve().then(function () { return index_get$1; });
const _lazy_4uG3v3 = () => Promise.resolve().then(function () { return index_post$1; });
const _lazy_rBL1X_ = () => Promise.resolve().then(function () { return _id_$3; });
const _lazy_nzrj7y = () => Promise.resolve().then(function () { return index$3; });
const _lazy_rd506a = () => Promise.resolve().then(function () { return stats_get$1; });
const _lazy_aWhRCK = () => Promise.resolve().then(function () { return _id_$1; });
const _lazy_iEK_AZ = () => Promise.resolve().then(function () { return skills$1; });
const _lazy_rn_i8c = () => Promise.resolve().then(function () { return bulkActions_post$1; });
const _lazy_0M0lHK = () => Promise.resolve().then(function () { return index$1; });
const _lazy_Ry0bJQ = () => Promise.resolve().then(function () { return skillMatrix_get$1; });
const _lazy_xLxGUm = () => Promise.resolve().then(function () { return verify_post$1; });
const _lazy_oISihp = () => Promise.resolve().then(function () { return statistics_get$1; });
const _lazy_iaFLV8 = () => Promise.resolve().then(function () { return renderer$1; });

const handlers = [
  { route: '/api/auth/**:all', handler: _lazy__HzHGI, lazy: true, middleware: false, method: undefined },
  { route: '/api/customer/dashboard/stats', handler: _lazy_Y1atCZ, lazy: true, middleware: false, method: "get" },
  { route: '/api/customer/invoices', handler: _lazy_7ahUX9, lazy: true, middleware: false, method: "get" },
  { route: '/api/customer/sepa/mandate', handler: _lazy_K97Ohf, lazy: true, middleware: false, method: "delete" },
  { route: '/api/customer/sepa/mandate', handler: _lazy_qked6M, lazy: true, middleware: false, method: "get" },
  { route: '/api/customer/sepa/mandate', handler: _lazy_CmKzFS, lazy: true, middleware: false, method: "post" },
  { route: '/api/customer/tickets/:id', handler: _lazy_eh6IX5, lazy: true, middleware: false, method: "get" },
  { route: '/api/customer/tickets/:ticketId/comments', handler: _lazy_thehfM, lazy: true, middleware: false, method: "get" },
  { route: '/api/customer/tickets/:ticketId/comments', handler: _lazy_JU9n9r, lazy: true, middleware: false, method: "post" },
  { route: '/api/customer/tickets', handler: _lazy_i0gkiX, lazy: true, middleware: false, method: "get" },
  { route: '/api/customer/tickets', handler: _lazy_suZR7J, lazy: true, middleware: false, method: "post" },
  { route: '/api/customers', handler: _lazy_xJPEs_, lazy: true, middleware: false, method: "get" },
  { route: '/api/dashboard/activities', handler: _lazy_akMWmx, lazy: true, middleware: false, method: "get" },
  { route: '/api/dashboard/my-tasks', handler: _lazy_ycYD2L, lazy: true, middleware: false, method: "get" },
  { route: '/api/dashboard/stats', handler: _lazy_4y8UJF, lazy: true, middleware: false, method: "get" },
  { route: '/api/dashboard/team-activities', handler: _lazy_dwP6iB, lazy: true, middleware: false, method: "get" },
  { route: '/api/enums/categories/:id', handler: _lazy_AtXKUQ, lazy: true, middleware: false, method: undefined },
  { route: '/api/enums/categories/:id/reorder', handler: _lazy_lq5TZw, lazy: true, middleware: false, method: undefined },
  { route: '/api/enums/categories', handler: _lazy_m4wAqX, lazy: true, middleware: false, method: undefined },
  { route: '/api/enums/values/:id', handler: _lazy_sKTdQO, lazy: true, middleware: false, method: undefined },
  { route: '/api/enums/values', handler: _lazy_jn8GgS, lazy: true, middleware: false, method: undefined },
  { route: '/api/projects/:id', handler: _lazy_9AXRIp, lazy: true, middleware: false, method: undefined },
  { route: '/api/projects/:id/enum-config', handler: _lazy_2fipmv, lazy: true, middleware: false, method: undefined },
  { route: '/api/projects/:id/enum-overrides', handler: _lazy_XkPukU, lazy: true, middleware: false, method: undefined },
  { route: '/api/projects', handler: _lazy_KeIYSu, lazy: true, middleware: false, method: "get" },
  { route: '/api/projects', handler: _lazy_EW4gyl, lazy: true, middleware: false, method: "post" },
  { route: '/api/reports/export', handler: _lazy_aefjbb, lazy: true, middleware: false, method: "post" },
  { route: '/api/reports/financial', handler: _lazy_sfIVZi, lazy: true, middleware: false, method: "get" },
  { route: '/api/reports/projects', handler: _lazy_8uQeCX, lazy: true, middleware: false, method: "get" },
  { route: '/api/reports/team', handler: _lazy_t89yZD, lazy: true, middleware: false, method: "get" },
  { route: '/api/reports/time', handler: _lazy_8hHcoh, lazy: true, middleware: false, method: "get" },
  { route: '/api/tasks/:taskId', handler: _lazy_XX9VRC, lazy: true, middleware: false, method: undefined },
  { route: '/api/tasks/:taskId/attachment/:attachmentId', handler: _lazy_qhajga, lazy: true, middleware: false, method: undefined },
  { route: '/api/tasks/:taskId/attachments', handler: _lazy_hhgqae, lazy: true, middleware: false, method: undefined },
  { route: '/api/tasks/:taskId/comments', handler: _lazy_LYCUYc, lazy: true, middleware: false, method: undefined },
  { route: '/api/tasks', handler: _lazy_0R7CVy, lazy: true, middleware: false, method: undefined },
  { route: '/api/tickets/:ticketId', handler: _lazy_wTruDf, lazy: true, middleware: false, method: "delete" },
  { route: '/api/tickets/:ticketId', handler: _lazy_V1TLvZ, lazy: true, middleware: false, method: "get" },
  { route: '/api/tickets/:ticketId', handler: _lazy_y6Exlz, lazy: true, middleware: false, method: "put" },
  { route: '/api/tickets/:ticketId/comments', handler: _lazy_1oF58y, lazy: true, middleware: false, method: "get" },
  { route: '/api/tickets/:ticketId/comments', handler: _lazy_WaF2Ds, lazy: true, middleware: false, method: "post" },
  { route: '/api/tickets/convert-to-task', handler: _lazy_aqYo7J, lazy: true, middleware: false, method: "post" },
  { route: '/api/tickets', handler: _lazy_NoN6jc, lazy: true, middleware: false, method: "get" },
  { route: '/api/tickets', handler: _lazy_4uG3v3, lazy: true, middleware: false, method: "post" },
  { route: '/api/time-entries/:id', handler: _lazy_rBL1X_, lazy: true, middleware: false, method: undefined },
  { route: '/api/time-entries', handler: _lazy_nzrj7y, lazy: true, middleware: false, method: undefined },
  { route: '/api/time-entries/stats', handler: _lazy_rd506a, lazy: true, middleware: false, method: "get" },
  { route: '/api/users/:id', handler: _lazy_aWhRCK, lazy: true, middleware: false, method: undefined },
  { route: '/api/users/:userId/skills', handler: _lazy_iEK_AZ, lazy: true, middleware: false, method: undefined },
  { route: '/api/users/bulk-actions', handler: _lazy_rn_i8c, lazy: true, middleware: false, method: "post" },
  { route: '/api/users', handler: _lazy_0M0lHK, lazy: true, middleware: false, method: undefined },
  { route: '/api/users/skill-matrix', handler: _lazy_Ry0bJQ, lazy: true, middleware: false, method: "get" },
  { route: '/api/users/skills/verify', handler: _lazy_xLxGUm, lazy: true, middleware: false, method: "post" },
  { route: '/api/users/statistics', handler: _lazy_oISihp, lazy: true, middleware: false, method: "get" },
  { route: '/__nuxt_error', handler: _lazy_iaFLV8, lazy: true, middleware: false, method: undefined },
  { route: '/api/_nuxt_icon/:collection', handler: _X8fyKs, lazy: false, middleware: false, method: undefined },
  { route: '/__nuxt_island/**', handler: _SxA8c9, lazy: false, middleware: false, method: undefined },
  { route: '/_ipx/**', handler: _2HOdnX, lazy: false, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_iaFLV8, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(true),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          _platform: fetchContext?._platform,
          // #3335
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp$1.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter$1({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => callNodeRequestHandler(nodeHandler, aRequest);
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return fetchNodeRequestHandler(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp$1 = createNitroApp();
function useNitroApp() {
  return nitroApp$1;
}
runNitroPlugins(nitroApp$1);

if (!globalThis.crypto) {
  globalThis.crypto = nodeCrypto;
}
const { NITRO_NO_UNIX_SOCKET, NITRO_DEV_WORKER_ID } = process.env;
trapUnhandledNodeErrors();
parentPort?.on("message", (msg) => {
  if (msg && msg.event === "shutdown") {
    shutdown();
  }
});
const nitroApp = useNitroApp();
const server = new Server(toNodeListener(nitroApp.h3App));
let listener;
listen().catch(() => listen(
  true
  /* use random port */
)).catch((error) => {
  console.error("Dev worker failed to listen:", error);
  return shutdown();
});
nitroApp.router.get(
  "/_nitro/tasks",
  defineEventHandler(async (event) => {
    const _tasks = await Promise.all(
      Object.entries(tasks).map(async ([name, task]) => {
        const _task = await task.resolve?.();
        return [name, { description: _task?.meta?.description }];
      })
    );
    return {
      tasks: Object.fromEntries(_tasks),
      scheduledTasks
    };
  })
);
nitroApp.router.use(
  "/_nitro/tasks/:name",
  defineEventHandler(async (event) => {
    const name = getRouterParam(event, "name");
    const payload = {
      ...getQuery$1(event),
      ...await readBody(event).then((r) => r?.payload).catch(() => ({}))
    };
    return await runTask(name, { payload });
  })
);
function listen(useRandomPort = Boolean(
  NITRO_NO_UNIX_SOCKET || process.versions.webcontainer || "Bun" in globalThis && process.platform === "win32"
)) {
  return new Promise((resolve, reject) => {
    try {
      listener = server.listen(useRandomPort ? 0 : getSocketAddress(), () => {
        const address = server.address();
        parentPort?.postMessage({
          event: "listen",
          address: typeof address === "string" ? { socketPath: address } : { host: "localhost", port: address?.port }
        });
        resolve();
      });
    } catch (error) {
      reject(error);
    }
  });
}
function getSocketAddress() {
  const socketName = `nitro-worker-${process.pid}-${threadId}-${NITRO_DEV_WORKER_ID}-${Math.round(Math.random() * 1e4)}.sock`;
  if (process.platform === "win32") {
    return join(String.raw`\\.\pipe`, socketName);
  }
  if (process.platform === "linux") {
    const nodeMajor = Number.parseInt(process.versions.node.split(".")[0], 10);
    if (nodeMajor >= 20) {
      return `\0${socketName}`;
    }
  }
  return join(tmpdir(), socketName);
}
async function shutdown() {
  server.closeAllConnections?.();
  await Promise.all([
    new Promise((resolve) => listener?.close(resolve)),
    nitroApp.hooks.callHook("close").catch(console.error)
  ]);
  parentPort?.postMessage({ event: "exit" });
}

const _messages = { "appName": "Nuxt", "version": "", "statusCode": 500, "statusMessage": "Server error", "description": "An error occurred in the application and the page could not be served. If you are the application owner, check your server logs for details.", "stack": "" };
const template$1 = (messages) => {
  messages = { ..._messages, ...messages };
  return '<!DOCTYPE html><html lang="en"><head><title>' + escapeHtml(messages.statusCode) + " - " + escapeHtml(messages.statusMessage || "Internal Server Error") + `</title><meta charset="utf-8"><meta content="width=device-width,initial-scale=1.0,minimum-scale=1.0" name="viewport"><style>.spotlight{background:linear-gradient(45deg,#00dc82,#36e4da 50%,#0047e1);bottom:-40vh;filter:blur(30vh);height:60vh;opacity:.8}*,:after,:before{border-color:var(--un-default-border-color,#e5e7eb);border-style:solid;border-width:0;box-sizing:border-box}:after,:before{--un-content:""}html{line-height:1.5;-webkit-text-size-adjust:100%;font-family:ui-sans-serif,system-ui,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;font-feature-settings:normal;font-variation-settings:normal;-moz-tab-size:4;tab-size:4;-webkit-tap-highlight-color:transparent}body{line-height:inherit;margin:0}h1{font-size:inherit;font-weight:inherit}h1,p{margin:0}*,:after,:before{--un-rotate:0;--un-rotate-x:0;--un-rotate-y:0;--un-rotate-z:0;--un-scale-x:1;--un-scale-y:1;--un-scale-z:1;--un-skew-x:0;--un-skew-y:0;--un-translate-x:0;--un-translate-y:0;--un-translate-z:0;--un-pan-x: ;--un-pan-y: ;--un-pinch-zoom: ;--un-scroll-snap-strictness:proximity;--un-ordinal: ;--un-slashed-zero: ;--un-numeric-figure: ;--un-numeric-spacing: ;--un-numeric-fraction: ;--un-border-spacing-x:0;--un-border-spacing-y:0;--un-ring-offset-shadow:0 0 transparent;--un-ring-shadow:0 0 transparent;--un-shadow-inset: ;--un-shadow:0 0 transparent;--un-ring-inset: ;--un-ring-offset-width:0px;--un-ring-offset-color:#fff;--un-ring-width:0px;--un-ring-color:rgba(147,197,253,.5);--un-blur: ;--un-brightness: ;--un-contrast: ;--un-drop-shadow: ;--un-grayscale: ;--un-hue-rotate: ;--un-invert: ;--un-saturate: ;--un-sepia: ;--un-backdrop-blur: ;--un-backdrop-brightness: ;--un-backdrop-contrast: ;--un-backdrop-grayscale: ;--un-backdrop-hue-rotate: ;--un-backdrop-invert: ;--un-backdrop-opacity: ;--un-backdrop-saturate: ;--un-backdrop-sepia: }.pointer-events-none{pointer-events:none}.fixed{position:fixed}.left-0{left:0}.right-0{right:0}.z-10{z-index:10}.mb-6{margin-bottom:1.5rem}.mb-8{margin-bottom:2rem}.h-auto{height:auto}.min-h-screen{min-height:100vh}.flex{display:flex}.flex-1{flex:1 1 0%}.flex-col{flex-direction:column}.overflow-y-auto{overflow-y:auto}.rounded-t-md{border-top-left-radius:.375rem;border-top-right-radius:.375rem}.bg-black\\/5{background-color:#0000000d}.bg-white{--un-bg-opacity:1;background-color:rgb(255 255 255/var(--un-bg-opacity))}.p-8{padding:2rem}.px-10{padding-left:2.5rem;padding-right:2.5rem}.pt-14{padding-top:3.5rem}.text-6xl{font-size:3.75rem;line-height:1}.text-xl{font-size:1.25rem;line-height:1.75rem}.text-black{--un-text-opacity:1;color:rgb(0 0 0/var(--un-text-opacity))}.font-light{font-weight:300}.font-medium{font-weight:500}.leading-tight{line-height:1.25}.font-sans{font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji}.antialiased{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}@media (prefers-color-scheme:dark){.dark\\:bg-black{--un-bg-opacity:1;background-color:rgb(0 0 0/var(--un-bg-opacity))}.dark\\:bg-white\\/10{background-color:#ffffff1a}.dark\\:text-white{--un-text-opacity:1;color:rgb(255 255 255/var(--un-text-opacity))}}@media (min-width:640px){.sm\\:text-2xl{font-size:1.5rem;line-height:2rem}.sm\\:text-8xl{font-size:6rem;line-height:1}}</style><script>!function(){const e=document.createElement("link").relList;if(!(e&&e.supports&&e.supports("modulepreload"))){for(const e of document.querySelectorAll('link[rel="modulepreload"]'))r(e);new MutationObserver((e=>{for(const o of e)if("childList"===o.type)for(const e of o.addedNodes)"LINK"===e.tagName&&"modulepreload"===e.rel&&r(e)})).observe(document,{childList:!0,subtree:!0})}function r(e){if(e.ep)return;e.ep=!0;const r=function(e){const r={};return e.integrity&&(r.integrity=e.integrity),e.referrerPolicy&&(r.referrerPolicy=e.referrerPolicy),"use-credentials"===e.crossOrigin?r.credentials="include":"anonymous"===e.crossOrigin?r.credentials="omit":r.credentials="same-origin",r}(e);fetch(e.href,r)}}();<\/script></head><body class="antialiased bg-white dark:bg-black dark:text-white flex flex-col font-sans min-h-screen pt-14 px-10 text-black"><div class="fixed left-0 pointer-events-none right-0 spotlight"></div><h1 class="font-medium mb-6 sm:text-8xl text-6xl">` + escapeHtml(messages.statusCode) + '</h1><p class="font-light leading-tight mb-8 sm:text-2xl text-xl">' + escapeHtml(messages.description) + '</p><div class="bg-black/5 bg-white dark:bg-white/10 flex-1 h-auto overflow-y-auto rounded-t-md"><div class="font-light leading-tight p-8 text-xl z-10">' + escapeHtml(messages.stack) + "</div></div></body></html>";
};

const errorDev = /*#__PURE__*/Object.freeze({
  __proto__: null,
  template: template$1
});

const template = "";

const _virtual__spaTemplate = /*#__PURE__*/Object.freeze({
  __proto__: null,
  template: template
});

const styles = {};

const styles$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: styles
});

const ____all_ = defineEventHandler((event) => {
  return auth.handler(toWebRequest(event));
});

const ____all_$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: ____all_
});

let prisma$c;
{
  if (!global.__prisma) {
    global.__prisma = new PrismaClient({
      log: ["query", "info", "warn", "error"]
    });
  }
  prisma$c = global.__prisma;
}
class DatabaseHelper {
  /**
   * Überprüft Datenbankverbindung
   */
  static async checkConnection() {
    try {
      await prisma$c.$queryRaw`SELECT 1`;
      return true;
    } catch (error) {
      console.error("Datenbankverbindung fehlgeschlagen:", error);
      return false;
    }
  }
  /**
   * Schließt Datenbankverbindung
   */
  static async disconnect() {
    await prisma$c.$disconnect();
  }
  /**
   * Führt eine Transaktion aus
   */
  static async transaction(fn) {
    return await prisma$c.$transaction(fn);
  }
  /**
   * Soft Delete für Benutzer (deaktiviert statt löscht)
   */
  static async softDeleteUser(userId) {
    await prisma$c.user.update({
      where: { id: userId },
      data: { isActive: false }
    });
  }
  /**
   * Aktiviert einen deaktivierten Benutzer
   */
  static async activateUser(userId) {
    await prisma$c.user.update({
      where: { id: userId },
      data: { isActive: true }
    });
  }
  /**
   * Holt aktive Benutzer mit Paginierung
   */
  static async getActiveUsers(page = 1, limit = 20) {
    const skip = (page - 1) * limit;
    const [users, total] = await Promise.all([
      prisma$c.user.findMany({
        where: { isActive: true },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          role: true,
          avatar: true,
          lastLoginAt: true,
          createdAt: true
        },
        skip,
        take: limit,
        orderBy: { createdAt: "desc" }
      }),
      prisma$c.user.count({ where: { isActive: true } })
    ]);
    return {
      users,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      }
    };
  }
  /**
   * Erstellt automatisch Projekt für neuen Kunden
   */
  static async createCustomerWithProject(customerData) {
    return await prisma$c.$transaction(async (tx) => {
      const customer = await tx.customer.create({
        data: customerData
      });
      const projectKey = `CUST-${customer.id.slice(-6).toUpperCase()}`;
      const project = await tx.project.create({
        data: {
          key: projectKey,
          name: `${customer.companyName} - Hauptprojekt`,
          description: `Automatisch erstelltes Projekt f\xFCr Kunde ${customer.companyName}`,
          customerId: customer.id
        }
      });
      return { customer, project };
    });
  }
  /**
   * Generiert eindeutigen Task-Key
   */
  static async generateTaskKey(projectId) {
    const project = await prisma$c.project.findUnique({
      where: { id: projectId },
      select: { key: true }
    });
    if (!project) {
      throw new Error("Projekt nicht gefunden");
    }
    const taskCount = await prisma$c.task.count({
      where: { projectId }
    });
    return `${project.key}-${String(taskCount + 1).padStart(3, "0")}`;
  }
  /**
   * Holt Dashboard-Statistiken
   */
  static async getDashboardStats(userId) {
    const [
      totalProjects,
      activeProjects,
      totalTasks,
      myTasks,
      completedTasks,
      totalUsers
    ] = await Promise.all([
      prisma$c.project.count(),
      prisma$c.project.count({ where: { status: "AKTIV" } }),
      prisma$c.task.count(),
      userId ? prisma$c.task.count({
        where: {
          assigneeId: userId,
          status: {
            key: { not: "ERLEDIGT" }
          }
        }
      }) : 0,
      prisma$c.task.count({
        where: {
          status: {
            key: "ERLEDIGT"
          }
        }
      }),
      prisma$c.user.count({ where: { isActive: true } })
    ]);
    return {
      totalProjects,
      activeProjects,
      totalTasks,
      myTasks,
      completedTasks,
      totalUsers,
      completionRate: totalTasks > 0 ? Math.round(completedTasks / totalTasks * 100) : 0
    };
  }
}

const stats_get$4 = defineEventHandler(async (event) => {
  const user = await requireAuth("KUNDE")(event);
  try {
    const userData = await prisma$c.user.findUnique({
      where: { id: user.id },
      include: {
        customer: true
      }
    });
    if (!userData || userData.role !== "KUNDE") {
      throw createError({
        statusCode: 404,
        statusMessage: "Kunde nicht gefunden"
      });
    }
    if (!userData.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: "Kundendaten nicht gefunden"
      });
    }
    const customerId = userData.customer.id;
    const [
      openTickets,
      pendingInvoices,
      totalInvoices
    ] = await Promise.all([
      // Offene Tickets zählen
      prisma$c.ticket.count({
        where: {
          customerId,
          status: {
            key: {
              in: ["OFFEN", "IN_BEARBEITUNG", "WARTEN_AUF_KUNDE"]
            }
          }
        }
      }),
      // Offene Rechnungen zählen
      prisma$c.invoice.count({
        where: {
          customerId,
          status: {
            in: ["VERSENDET", "UEBERFAELLIG"]
          }
        }
      }),
      // Gesamtzahl Rechnungen
      prisma$c.invoice.count({
        where: {
          customerId
        }
      })
    ]);
    return {
      openTickets,
      pendingInvoices,
      totalInvoices,
      customerId
    };
  } catch (error) {
    console.error("Dashboard stats error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Laden der Dashboard-Statistiken"
    });
  }
});

const stats_get$5 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: stats_get$4
});

const index_get$8 = defineEventHandler(async (event) => {
  const user = await requireAuth("KUNDE")(event);
  try {
    const userData = await prisma$c.user.findUnique({
      where: { id: user.id },
      include: {
        customer: true
      }
    });
    if (!userData || !userData.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: "Kunde nicht gefunden"
      });
    }
    const customerId = userData.customer.id;
    const query = getQuery$1(event);
    const limit = query.limit && typeof query.limit === "string" ? parseInt(query.limit) : void 0;
    const page = query.page && typeof query.page === "string" ? parseInt(query.page) : 1;
    const year = query.year && typeof query.year === "string" ? parseInt(query.year) : void 0;
    const where = {
      customerId
    };
    if (query.status && typeof query.status === "string") {
      const validStatuses = ["ENTWURF", "VERSENDET", "BEZAHLT", "UEBERFAELLIG", "STORNIERT"];
      if (validStatuses.includes(query.status)) {
        where.status = query.status;
      }
    }
    if (year) {
      where.issueDate = {
        gte: /* @__PURE__ */ new Date(`${year}-01-01`),
        lt: /* @__PURE__ */ new Date(`${year + 1}-01-01`)
      };
    }
    const [invoices, total] = await Promise.all([
      prisma$c.invoice.findMany({
        where,
        orderBy: {
          issueDate: "desc"
        },
        ...limit && { take: limit },
        ...limit && page > 1 && { skip: (page - 1) * limit }
      }),
      prisma$c.invoice.count({ where })
    ]);
    const stats = await prisma$c.invoice.groupBy({
      by: ["status"],
      where: { customerId },
      _count: {
        status: true
      },
      _sum: {
        totalAmount: true
      }
    });
    return {
      invoices,
      stats,
      pagination: {
        total,
        page,
        limit: limit || total,
        pages: limit ? Math.ceil(total / limit) : 1
      }
    };
  } catch (error) {
    console.error("Customer invoices error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Laden der Rechnungen"
    });
  }
});

const index_get$9 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index_get$8
});

const mandate_delete = defineEventHandler(async (event) => {
  try {
    assertMethod(event, "DELETE");
    const decoded = await requireAuth()(event);
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: "Authentifizierung erforderlich"
      });
    }
    const user = await prisma$c.user.findUnique({
      where: { id: decoded.id },
      include: {
        customer: {
          include: {
            sepaMandate: true
          }
        }
      }
    });
    if (!user || user.role !== "KUNDE") {
      throw createError({
        statusCode: 404,
        statusMessage: "Kunde nicht gefunden"
      });
    }
    if (!user.customer || !user.customer.sepaMandate) {
      throw createError({
        statusCode: 404,
        statusMessage: "Kein SEPA-Mandat gefunden"
      });
    }
    const mandate = user.customer.sepaMandate;
    const customerId = user.customer.id;
    const revokedMandate = await prisma$c.sepaMandate.update({
      where: { customerId },
      data: {
        isActive: false,
        validUntil: /* @__PURE__ */ new Date()
        // Sofort ungültig setzen
      }
    });
    await prisma$c.activityLog.create({
      data: {
        action: "SEPA_MANDATE_REVOKED",
        description: `SEPA-Mandat wurde widerrufen`,
        userId: decoded.id,
        details: {
          mandateId: mandate.mandateId,
          iban: mandate.iban.substring(0, 8) + "****",
          // Anonymisiert für Log
          revokedAt: /* @__PURE__ */ new Date()
        }
      }
    });
    return {
      message: "SEPA-Mandat wurde erfolgreich widerrufen",
      mandate: revokedMandate
    };
  } catch (error) {
    console.error("SEPA mandate revoke error:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Widerrufen des SEPA-Mandats"
    });
  }
});

const mandate_delete$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: mandate_delete
});

const mandate_get = defineEventHandler(async (event) => {
  var _a;
  try {
    const user = await requireAuth("KUNDE")(event);
    const userData = await prisma$c.user.findUnique({
      where: { id: user.id },
      include: {
        customer: {
          include: {
            sepaMandate: true
          }
        }
      }
    });
    if (!userData || userData.role !== "KUNDE") {
      throw createError({
        statusCode: 404,
        statusMessage: "Kunde nicht gefunden"
      });
    }
    if (!userData.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: "Kundendaten nicht gefunden"
      });
    }
    return {
      mandate: userData.customer.sepaMandate || null,
      hasActiveMandate: ((_a = userData.customer.sepaMandate) == null ? void 0 : _a.isActive) || false
    };
  } catch (error) {
    console.error("SEPA mandate get error:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Laden des SEPA-Mandats"
    });
  }
});

const mandate_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: mandate_get
});

const sepaSchema = z.object({
  iban: z.string().min(15, "IBAN muss mindestens 15 Zeichen lang sein").max(34, "IBAN darf maximal 34 Zeichen lang sein").regex(/^[A-Z]{2}[0-9]{2}[A-Z0-9]+$/, "Ung\xFCltiges IBAN-Format"),
  bic: z.string().regex(/^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/, "Ung\xFCltiges BIC-Format").optional(),
  accountHolder: z.string().min(2, "Kontoinhaber muss mindestens 2 Zeichen lang sein").max(100, "Kontoinhaber darf maximal 100 Zeichen lang sein"),
  validUntil: z.string().optional().transform((str) => str ? new Date(str) : void 0)
});
function validateIBAN(iban) {
  const normalizedIban = iban.toUpperCase().replace(/\s/g, "");
  if (normalizedIban.startsWith("DE") && normalizedIban.length !== 22) {
    return false;
  }
  const rearranged = normalizedIban.slice(4) + normalizedIban.slice(0, 4);
  const numeric = rearranged.replace(
    /[A-Z]/g,
    (char) => (char.charCodeAt(0) - "A".charCodeAt(0) + 10).toString()
  );
  let remainder = 0;
  for (let i = 0; i < numeric.length; i++) {
    remainder = (remainder * 10 + parseInt(numeric[i])) % 97;
  }
  return remainder === 1;
}
function generateMandateId(customerCompany) {
  const prefix = customerCompany.substring(0, 3).toUpperCase();
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.floor(Math.random() * 1e3).toString().padStart(3, "0");
  return `${prefix}-${timestamp}-${random}`;
}
const mandate_post = defineEventHandler(async (event) => {
  var _a, _b;
  try {
    assertMethod(event, "POST");
    const body = await readBody(event);
    const validatedData = sepaSchema.parse(body);
    if (!validateIBAN(validatedData.iban)) {
      throw createError({
        statusCode: 400,
        statusMessage: "Ung\xFCltige IBAN-Pr\xFCfziffer"
      });
    }
    const decoded = await requireAuth()(event);
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: "Authentifizierung erforderlich"
      });
    }
    const user = await prisma$c.user.findUnique({
      where: { id: decoded.id },
      include: {
        customer: {
          include: {
            sepaMandate: true
          }
        }
      }
    });
    if (!user || user.role !== "KUNDE") {
      throw createError({
        statusCode: 404,
        statusMessage: "Kunde nicht gefunden"
      });
    }
    if (!user.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: "Kundendaten nicht gefunden"
      });
    }
    const customerId = user.customer.id;
    if (user.customer.sepaMandate) {
      const updatedMandate = await prisma$c.sepaMandate.update({
        where: { customerId },
        data: {
          iban: validatedData.iban.toUpperCase().replace(/\s/g, ""),
          bic: (_a = validatedData.bic) == null ? void 0 : _a.toUpperCase(),
          accountHolder: validatedData.accountHolder.trim(),
          validUntil: validatedData.validUntil,
          isActive: true,
          signedDate: /* @__PURE__ */ new Date()
        }
      });
      await prisma$c.activityLog.create({
        data: {
          action: "SEPA_MANDATE_UPDATED",
          description: `SEPA-Mandat wurde aktualisiert`,
          userId: decoded.id,
          details: {
            mandateId: updatedMandate.mandateId,
            iban: validatedData.iban.substring(0, 8) + "****",
            // Anonymisiert für Log
            accountHolder: validatedData.accountHolder
          }
        }
      });
      return {
        mandate: updatedMandate,
        message: "SEPA-Mandat wurde erfolgreich aktualisiert"
      };
    } else {
      const mandateId = generateMandateId(user.customer.companyName);
      const newMandate = await prisma$c.sepaMandate.create({
        data: {
          mandateId,
          iban: validatedData.iban.toUpperCase().replace(/\s/g, ""),
          bic: (_b = validatedData.bic) == null ? void 0 : _b.toUpperCase(),
          accountHolder: validatedData.accountHolder.trim(),
          validUntil: validatedData.validUntil,
          isActive: true,
          signedDate: /* @__PURE__ */ new Date(),
          customerId
        }
      });
      await prisma$c.activityLog.create({
        data: {
          action: "SEPA_MANDATE_CREATED",
          description: `SEPA-Mandat wurde erstellt`,
          userId: decoded.id,
          details: {
            mandateId: newMandate.mandateId,
            iban: validatedData.iban.substring(0, 8) + "****",
            // Anonymisiert für Log
            accountHolder: validatedData.accountHolder
          }
        }
      });
      return {
        mandate: newMandate,
        message: "SEPA-Mandat wurde erfolgreich erstellt"
      };
    }
  } catch (error) {
    console.error("SEPA mandate create/update error:", error);
    if (error.statusCode) {
      throw error;
    }
    if (error.name === "ZodError") {
      throw createError({
        statusCode: 400,
        statusMessage: `Validierungsfehler: ${error.errors.map((e) => e.message).join(", ")}`
      });
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Erstellen/Aktualisieren des SEPA-Mandats"
    });
  }
});

const mandate_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: mandate_post
});

const _id__get = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const user = await requireAuth("KUNDE")(event);
  try {
    const userData = await prisma$c.user.findUnique({
      where: { id: user.id },
      include: {
        customer: true
      }
    });
    if (!userData || !userData.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: "Kunde nicht gefunden"
      });
    }
    const customerId = userData.customer.id;
    const ticketId = getRouterParam(event, "id");
    const ticket = await prisma$c.ticket.findFirst({
      where: {
        id: ticketId,
        customerId
      },
      include: {
        status: {
          select: {
            key: true,
            label: true
          }
        },
        priority: {
          select: {
            key: true,
            label: true
          }
        },
        type: {
          select: {
            key: true,
            label: true
          }
        }
      }
    });
    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: "Ticket nicht gefunden"
      });
    }
    const transformedTicket = {
      ...ticket,
      status: ((_a = ticket.status) == null ? void 0 : _a.key) || "UNKNOWN",
      priority: ((_b = ticket.priority) == null ? void 0 : _b.key) || "MEDIUM",
      type: ((_c = ticket.type) == null ? void 0 : _c.key) || "GENERAL"
    };
    return transformedTicket;
  } catch (error) {
    console.error("Customer ticket details error:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Laden des Tickets"
    });
  }
});

const _id__get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: _id__get
});

const prisma$b = new PrismaClient();
const comments_get$2 = defineEventHandler(async (event) => {
  try {
    const user = await requireAuth("KUNDE")(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Unauthorized"
      });
    }
    const ticketId = getRouterParam(event, "ticketId");
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Ticket ID is required"
      });
    }
    const ticket = await prisma$b.ticket.findUnique({
      where: { id: ticketId },
      select: {
        id: true,
        customerId: true
      }
    });
    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: "Ticket not found"
      });
    }
    if (user.role === "KUNDE") {
      if (!user.customer || ticket.customerId !== user.customer.id) {
        throw createError({
          statusCode: 403,
          statusMessage: "Access denied"
        });
      }
    }
    const comments = await prisma$b.ticketComment.findMany({
      where: {
        ticketId,
        // Customers can't see internal comments
        ...user.role === "KUNDE" ? { isInternal: false } : {}
      },
      include: {
        author: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            role: true
          }
        }
      },
      orderBy: {
        createdAt: "asc"
      }
    });
    return comments;
  } catch (error) {
    console.error("Error fetching ticket comments:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error"
    });
  }
});

const comments_get$3 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: comments_get$2
});

const prisma$a = new PrismaClient();
const commentSchema$1 = z.object({
  content: z.string().min(1, "Comment content is required").max(2e3, "Comment too long"),
  isInternal: z.boolean().optional().default(false)
});
const comments_post$2 = defineEventHandler(async (event) => {
  var _a, _b;
  try {
    const user = await requireAuth("KUNDE")(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Unauthorized"
      });
    }
    const ticketId = getRouterParam(event, "ticketId");
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Ticket ID is required"
      });
    }
    const body = await readBody(event);
    const validatedData = commentSchema$1.parse(body);
    const ticket = await prisma$a.ticket.findUnique({
      where: { id: ticketId },
      select: {
        id: true,
        customerId: true,
        status: true
      }
    });
    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: "Ticket not found"
      });
    }
    if (user.role === "KUNDE") {
      if (!user.customer || ticket.customerId !== user.customer.id) {
        throw createError({
          statusCode: 403,
          statusMessage: "Access denied"
        });
      }
      if (validatedData.isInternal) {
        throw createError({
          statusCode: 403,
          statusMessage: "Customers cannot create internal comments"
        });
      }
      if (((_a = ticket.status) == null ? void 0 : _a.key) === "GESCHLOSSEN") {
        throw createError({
          statusCode: 400,
          statusMessage: "Cannot comment on closed tickets"
        });
      }
    }
    const comment = await prisma$a.ticketComment.create({
      data: {
        content: validatedData.content,
        isInternal: validatedData.isInternal,
        ticketId,
        authorId: user.id
      },
      include: {
        author: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            role: true
          }
        }
      }
    });
    if (user.role === "KUNDE" && ((_b = ticket.status) == null ? void 0 : _b.key) === "WARTEN_AUF_KUNDE") {
      const inProgressStatus = await prisma$a.enumValue.findFirst({
        where: {
          key: "IN_BEARBEITUNG",
          category: {
            name: "ticket_status"
          }
        }
      });
      if (inProgressStatus) {
        await prisma$a.ticket.update({
          where: { id: ticketId },
          data: {
            statusId: inProgressStatus.id,
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
      }
    }
    await prisma$a.activityLog.create({
      data: {
        action: "TICKET_COMMENT_CREATED",
        description: `Comment added to ticket ${ticketId}`,
        userId: user.id,
        details: {
          ticketId,
          commentId: comment.id,
          isInternal: validatedData.isInternal
        }
      }
    });
    return {
      success: true,
      message: "Comment added successfully",
      comment
    };
  } catch (error) {
    console.error("Error creating ticket comment:", error);
    if (error.statusCode) {
      throw error;
    }
    if (error.name === "ZodError") {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid input data",
        data: error.errors
      });
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error"
    });
  }
});

const comments_post$3 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: comments_post$2
});

const index_get$6 = defineEventHandler(async (event) => {
  const user = await requireAuth("KUNDE")(event);
  try {
    const userData = await prisma$c.user.findUnique({
      where: { id: user.id },
      include: {
        customer: true
      }
    });
    if (!userData || !userData.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: "Kunde nicht gefunden"
      });
    }
    const customerId = userData.customer.id;
    const query = getQuery$1(event);
    const limit = query.limit && typeof query.limit === "string" ? parseInt(query.limit) : void 0;
    const page = query.page && typeof query.page === "string" ? parseInt(query.page) : 1;
    const where = {
      customerId
    };
    if (query.status && typeof query.status === "string") {
      where.status = {
        key: query.status
      };
    }
    if (query.department && typeof query.department === "string") {
      where.department = query.department;
    }
    const [tickets, total] = await Promise.all([
      prisma$c.ticket.findMany({
        where,
        include: {
          status: {
            select: {
              key: true,
              label: true
            }
          },
          priority: {
            select: {
              key: true,
              label: true
            }
          },
          type: {
            select: {
              key: true,
              label: true
            }
          }
        },
        orderBy: {
          createdAt: "desc"
        },
        ...limit && { take: limit },
        ...limit && page > 1 && { skip: (page - 1) * limit }
      }),
      prisma$c.ticket.count({ where })
    ]);
    const transformedTickets = tickets.map((ticket) => {
      var _a, _b, _c;
      return {
        ...ticket,
        status: ((_a = ticket.status) == null ? void 0 : _a.key) || "UNKNOWN",
        priority: ((_b = ticket.priority) == null ? void 0 : _b.key) || "MEDIUM",
        type: ((_c = ticket.type) == null ? void 0 : _c.key) || "GENERAL"
      };
    });
    return {
      tickets: transformedTickets,
      pagination: {
        total,
        page,
        limit: limit || total,
        pages: limit ? Math.ceil(total / limit) : 1
      }
    };
  } catch (error) {
    console.error("Customer tickets error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Laden der Tickets"
    });
  }
});

const index_get$7 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index_get$6
});

const index_post$4 = defineEventHandler(async (event) => {
  const user = await requireAuth("KUNDE")(event);
  try {
    const userData = await prisma$c.user.findUnique({
      where: { id: user.id },
      include: {
        customer: true
      }
    });
    if (!userData || !userData.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: "Kunde nicht gefunden"
      });
    }
    const customerId = userData.customer.id;
    const body = await readBody(event);
    const { title, description, priority, department } = body;
    if (!title || !description || !department) {
      throw createError({
        statusCode: 400,
        statusMessage: "Titel, Beschreibung und Abteilung sind erforderlich"
      });
    }
    const validDepartments = ["Support", "Buchhaltung", "Entwicklung", "Vertrieb", "Allgemein"];
    if (!validDepartments.includes(department)) {
      throw createError({
        statusCode: 400,
        statusMessage: "Ung\xFCltige Abteilung"
      });
    }
    const validPriorities = ["NIEDRIG", "NORMAL", "HOCH", "KRITISCH"];
    if (priority && !validPriorities.includes(priority)) {
      throw createError({
        statusCode: 400,
        statusMessage: "Ung\xFCltige Priorit\xE4t"
      });
    }
    const openStatus = await prisma$c.enumValue.findFirst({
      where: {
        key: "OFFEN",
        category: {
          name: "ticket_status"
        }
      }
    });
    if (!openStatus) {
      throw createError({
        statusCode: 500,
        statusMessage: "Open status not found"
      });
    }
    const priorityEnum = await prisma$c.enumValue.findFirst({
      where: {
        key: priority || "NORMAL",
        category: {
          name: "priority"
        }
      }
    });
    if (!priorityEnum) {
      throw createError({
        statusCode: 500,
        statusMessage: "Priority not found"
      });
    }
    const ticket = await prisma$c.ticket.create({
      data: {
        title: title.trim(),
        description: description.trim(),
        priorityId: priorityEnum.id,
        department,
        customerId,
        statusId: openStatus.id
      }
    });
    await prisma$c.activityLog.create({
      data: {
        action: "TICKET_CREATED",
        description: `Ticket "${title}" wurde erstellt`,
        userId: user.id,
        details: {
          ticketId: ticket.id,
          department,
          priority: priority || "NORMAL",
          customerCreated: true
        }
      }
    });
    return ticket;
  } catch (error) {
    console.error("Create ticket error:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Erstellen des Tickets"
    });
  }
});

const index_post$5 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index_post$4
});

const index_get$4 = defineEventHandler(async (event) => {
  await requireAuth("PROJEKTLEITER")(event);
  try {
    const customers = await prisma$c.customer.findMany({
      where: {
        isActive: true
      },
      select: {
        id: true,
        companyName: true,
        contactName: true,
        email: true,
        phone: true,
        city: true,
        country: true
      },
      orderBy: {
        companyName: "asc"
      }
    });
    return {
      success: true,
      data: customers
    };
  } catch (error) {
    console.error("Fehler beim Laden der Kunden:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Serverfehler"
    });
  }
});

const index_get$5 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index_get$4
});

const activities_get = defineEventHandler(async (event) => {
  assertMethod(event, "GET");
  try {
    await requireAuth()(event);
    const user = getCurrentUser(event);
    const query = getQuery$1(event);
    const { limit = "10" } = query;
    const userProjects = await prisma$c.projectMember.findMany({
      where: { userId: user.id },
      select: { projectId: true }
    });
    const projectIds = userProjects.map((pm) => pm.projectId);
    const whereCondition = user.role === "ADMINISTRATOR" ? {} : projectIds.length > 0 ? { projectId: { in: projectIds } } : { projectId: "none" };
    const activities = await prisma$c.activityLog.findMany({
      where: whereCondition,
      select: {
        id: true,
        action: true,
        description: true,
        createdAt: true,
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            avatar: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      },
      orderBy: {
        createdAt: "desc"
      },
      take: parseInt(limit)
    });
    return {
      success: true,
      data: activities
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("Recent activities error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Laden der Aktivit\xE4ten"
    });
  }
});

const activities_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: activities_get
});

const myTasks_get = defineEventHandler(async (event) => {
  assertMethod(event, "GET");
  try {
    await requireAuth()(event);
    const user = getCurrentUser(event);
    const query = getQuery$1(event);
    const { limit = "5", status = ["GEPLANT", "IN_BEARBEITUNG", "TECHNISCHES_DESIGN", "REVIEW", "TESTING"] } = query;
    const statusKeys = Array.isArray(status) ? status : [status];
    const statusEnums = await prisma$c.enumValue.findMany({
      where: {
        key: {
          in: statusKeys
        },
        category: {
          name: "task_status"
        }
      }
    });
    const statusIds = statusEnums.map((s) => s.id);
    const tasks = await prisma$c.task.findMany({
      where: {
        assigneeId: user.id,
        statusId: {
          in: statusIds
        }
      },
      select: {
        id: true,
        title: true,
        description: true,
        status: true,
        priority: true,
        dueDate: true,
        createdAt: true,
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        }
      },
      orderBy: [
        {
          priority: {
            sortOrder: "desc"
            // Higher priority values first
          }
        },
        {
          dueDate: "asc"
        },
        {
          createdAt: "desc"
        }
      ],
      take: parseInt(limit)
    });
    return {
      success: true,
      data: tasks
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("My tasks error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Laden der Aufgaben"
    });
  }
});

const myTasks_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: myTasks_get
});

const stats_get$2 = defineEventHandler(async (event) => {
  assertMethod(event, "GET");
  try {
    await requireAuth()(event);
    const user = getCurrentUser(event);
    const stats = await DatabaseHelper.getDashboardStats(user.id);
    return {
      success: true,
      data: stats
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("Dashboard stats error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Serverfehler"
    });
  }
});

const stats_get$3 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: stats_get$2
});

const teamActivities_get = defineEventHandler(async (event) => {
  assertMethod(event, "GET");
  try {
    await requireAuth()(event);
    const user = getCurrentUser(event);
    const query = getQuery$1(event);
    const { limit = "5" } = query;
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1e3);
    const userProjects = await prisma$c.projectMember.findMany({
      where: { userId: user.id },
      select: { projectId: true }
    });
    const projectIds = userProjects.map((pm) => pm.projectId);
    const whereCondition = user.role === "ADMINISTRATOR" ? { createdAt: { gte: oneDayAgo } } : projectIds.length > 0 ? {
      projectId: { in: projectIds },
      createdAt: { gte: oneDayAgo }
    } : { projectId: "none" };
    const teamActivities = await prisma$c.activityLog.findMany({
      where: {
        ...whereCondition,
        userId: { not: user.id }
        // Eigene Aktivitäten ausschließen
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            avatar: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      },
      orderBy: {
        createdAt: "desc"
      },
      take: parseInt(limit)
    });
    return {
      success: true,
      data: teamActivities
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("Team activities error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Laden der Team-Aktivit\xE4ten"
    });
  }
});

const teamActivities_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: teamActivities_get
});

const prisma$9 = new PrismaClient();
const updateCategorySchema = z.object({
  label: z.string().min(1).max(100).optional(),
  description: z.string().optional(),
  sortOrder: z.number().int().min(0).optional()
});
const _id_$8 = defineEventHandler(async (event) => {
  try {
    const method = getMethod(event);
    const categoryId = getRouterParam(event, "id");
    if (!categoryId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Kategorie-ID erforderlich"
      });
    }
    switch (method) {
      case "GET":
        return await handleGetCategory(categoryId);
      case "PUT":
        return await handleUpdateCategory(event, categoryId);
      case "DELETE":
        return await handleDeleteCategory(event, categoryId);
      default:
        throw createError({
          statusCode: 405,
          statusMessage: "Method Not Allowed"
        });
    }
  } catch (error) {
    console.error("Enum Category API Error:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || error.message || "Internal Server Error"
    });
  }
});
async function handleGetCategory(categoryId) {
  const category = await prisma$9.enumCategory.findUnique({
    where: { id: categoryId },
    include: {
      values: {
        orderBy: { sortOrder: "asc" }
      }
    }
  });
  if (!category) {
    throw createError({
      statusCode: 404,
      statusMessage: "Enum-Kategorie nicht gefunden"
    });
  }
  return category;
}
async function handleUpdateCategory(event, categoryId) {
  const body = await readBody(event);
  const validatedData = updateCategorySchema.parse(body);
  const existingCategory = await prisma$9.enumCategory.findUnique({
    where: { id: categoryId }
  });
  if (!existingCategory) {
    throw createError({
      statusCode: 404,
      statusMessage: "Enum-Kategorie nicht gefunden"
    });
  }
  if (existingCategory.isSystem && Object.keys(validatedData).some((key) => key !== "sortOrder")) {
    throw createError({
      statusCode: 403,
      statusMessage: "System-Kategorien k\xF6nnen nicht bearbeitet werden"
    });
  }
  const updatedCategory = await prisma$9.enumCategory.update({
    where: { id: categoryId },
    data: validatedData
  });
  return updatedCategory;
}
async function handleDeleteCategory(event, categoryId) {
  const existingCategory = await prisma$9.enumCategory.findUnique({
    where: { id: categoryId },
    include: {
      values: true
    }
  });
  if (!existingCategory) {
    throw createError({
      statusCode: 404,
      statusMessage: "Enum-Kategorie nicht gefunden"
    });
  }
  if (existingCategory.isSystem) {
    throw createError({
      statusCode: 403,
      statusMessage: "System-Kategorien k\xF6nnen nicht gel\xF6scht werden"
    });
  }
  const isInUse = await checkCategoryInUse(categoryId);
  if (isInUse) {
    throw createError({
      statusCode: 409,
      statusMessage: "Kategorie wird noch verwendet und kann nicht gel\xF6scht werden"
    });
  }
  await prisma$9.enumCategory.delete({
    where: { id: categoryId }
  });
  return { success: true };
}
async function checkCategoryInUse(categoryId) {
  const category = await prisma$9.enumCategory.findUnique({
    where: { id: categoryId },
    select: { name: true }
  });
  if (!category) return false;
  switch (category.name) {
    case "task_type":
      const tasksWithType = await prisma$9.task.count({
        where: {
          type: {
            categoryId
          }
        }
      });
      return tasksWithType > 0;
    case "priority":
      const tasksWithPriority = await prisma$9.task.count({
        where: {
          priority: {
            categoryId
          }
        }
      });
      const ticketsWithPriority = await prisma$9.ticket.count({
        where: {
          priority: {
            categoryId
          }
        }
      });
      return tasksWithPriority > 0 || ticketsWithPriority > 0;
    case "task_status":
      const tasksWithStatus = await prisma$9.task.count({
        where: {
          status: {
            categoryId
          }
        }
      });
      return tasksWithStatus > 0;
    case "ticket_type":
      const ticketsWithType = await prisma$9.ticket.count({
        where: {
          type: {
            categoryId
          }
        }
      });
      return ticketsWithType > 0;
    case "ticket_status":
      const ticketsWithStatus = await prisma$9.ticket.count({
        where: {
          status: {
            categoryId
          }
        }
      });
      return ticketsWithStatus > 0;
    default:
      return false;
  }
}

const _id_$9 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: _id_$8
});

const prisma$8 = new PrismaClient();
const reorderSchema = z.object({
  valueIds: z.array(z.string()).min(1)
});
const reorder = defineEventHandler(async (event) => {
  try {
    const method = getMethod(event);
    const categoryId = getRouterParam(event, "id");
    if (!categoryId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Kategorie-ID erforderlich"
      });
    }
    if (method !== "PUT") {
      throw createError({
        statusCode: 405,
        statusMessage: "Method Not Allowed"
      });
    }
    return await handleReorderValues(event, categoryId);
  } catch (error) {
    console.error("Enum Values Reorder API Error:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || error.message || "Internal Server Error"
    });
  }
});
async function handleReorderValues(event, categoryId) {
  const body = await readBody(event);
  const { valueIds } = reorderSchema.parse(body);
  const category = await prisma$8.enumCategory.findUnique({
    where: { id: categoryId },
    include: {
      values: true
    }
  });
  if (!category) {
    throw createError({
      statusCode: 404,
      statusMessage: "Enum-Kategorie nicht gefunden"
    });
  }
  const categoryValueIds = new Set(category.values.map((v) => v.id));
  const invalidIds = valueIds.filter((id) => !categoryValueIds.has(id));
  if (invalidIds.length > 0) {
    throw createError({
      statusCode: 400,
      statusMessage: `Ung\xFCltige Enum-Wert-IDs: ${invalidIds.join(", ")}`
    });
  }
  const updates = valueIds.map(
    (valueId, index) => prisma$8.enumValue.update({
      where: { id: valueId },
      data: { sortOrder: index }
    })
  );
  await prisma$8.$transaction(updates);
  return { success: true };
}

const reorder$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: reorder
});

const prisma$7 = new PrismaClient();
const createCategorySchema = z.object({
  name: z.string().min(1).max(50).regex(/^[a-z_]+$/),
  label: z.string().min(1).max(100),
  description: z.string().optional(),
  isSystem: z.boolean().optional().default(false),
  sortOrder: z.number().int().min(0).optional().default(0)
});
const index$8 = defineEventHandler(async (event) => {
  try {
    const method = getMethod(event);
    switch (method) {
      case "GET":
        return await handleGetCategories(event);
      case "POST":
        return await handleCreateCategory(event);
      default:
        throw createError({
          statusCode: 405,
          statusMessage: "Method Not Allowed"
        });
    }
  } catch (error) {
    console.error("Enum Categories API Error:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || error.message || "Internal Server Error"
    });
  }
});
async function handleGetCategories(event) {
  const query = getQuery$1(event);
  const includeValues = query.includeValues === "true";
  const categories = await prisma$7.enumCategory.findMany({
    include: {
      values: includeValues ? {
        where: {
          projectId: null
          // Only include global enum values
        },
        orderBy: { sortOrder: "asc" }
      } : false
    },
    orderBy: { sortOrder: "asc" }
  });
  return categories;
}
async function handleCreateCategory(event) {
  const body = await readBody(event);
  const validatedData = createCategorySchema.parse(body);
  const existingCategory = await prisma$7.enumCategory.findUnique({
    where: { name: validatedData.name }
  });
  if (existingCategory) {
    throw createError({
      statusCode: 409,
      statusMessage: `Enum-Kategorie mit Name '${validatedData.name}' existiert bereits`
    });
  }
  const category = await prisma$7.enumCategory.create({
    data: {
      id: `${validatedData.name}_cat`,
      ...validatedData
    }
  });
  return category;
}

const index$9 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index$8
});

const prisma$6 = new PrismaClient();
const updateValueSchema = z.object({
  label: z.string().min(1).max(100).optional(),
  description: z.string().optional(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
  icon: z.string().max(50).optional(),
  isDefault: z.boolean().optional(),
  sortOrder: z.number().int().min(0).optional(),
  isActive: z.boolean().optional()
});
const _id_$6 = defineEventHandler(async (event) => {
  try {
    const method = getMethod(event);
    const valueId = getRouterParam(event, "id");
    if (!valueId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Enum-Wert-ID erforderlich"
      });
    }
    switch (method) {
      case "GET":
        return await handleGetValue(valueId);
      case "PUT":
        return await handleUpdateValue(event, valueId);
      case "DELETE":
        return await handleDeleteValue(event, valueId);
      default:
        throw createError({
          statusCode: 405,
          statusMessage: "Method Not Allowed"
        });
    }
  } catch (error) {
    console.error("Enum Value API Error:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || error.message || "Internal Server Error"
    });
  }
});
async function handleGetValue(valueId) {
  const value = await prisma$6.enumValue.findUnique({
    where: { id: valueId },
    include: {
      category: true
    }
  });
  if (!value) {
    throw createError({
      statusCode: 404,
      statusMessage: "Enum-Wert nicht gefunden"
    });
  }
  return value;
}
async function handleUpdateValue(event, valueId) {
  const body = await readBody(event);
  const validatedData = updateValueSchema.parse(body);
  const existingValue = await prisma$6.enumValue.findUnique({
    where: { id: valueId },
    include: { category: true }
  });
  if (!existingValue) {
    throw createError({
      statusCode: 404,
      statusMessage: "Enum-Wert nicht gefunden"
    });
  }
  if (validatedData.isDefault) {
    await prisma$6.enumValue.updateMany({
      where: {
        categoryId: existingValue.categoryId,
        isDefault: true,
        id: { not: valueId }
      },
      data: { isDefault: false }
    });
  }
  const updatedValue = await prisma$6.enumValue.update({
    where: { id: valueId },
    data: validatedData
  });
  return updatedValue;
}
async function handleDeleteValue(event, valueId) {
  const query = getQuery$1(event);
  const projectId = query.projectId;
  const existingValue = await prisma$6.enumValue.findUnique({
    where: { id: valueId },
    include: { category: true }
  });
  if (!existingValue) {
    throw createError({
      statusCode: 404,
      statusMessage: "Enum-Wert nicht gefunden"
    });
  }
  if (existingValue.projectId) {
    if (projectId && existingValue.projectId !== projectId) {
      throw createError({
        statusCode: 403,
        statusMessage: "Keine Berechtigung zum L\xF6schen dieses Werts"
      });
    }
  } else {
    const isInUse = await checkValueInUse(valueId, existingValue.category.name);
    if (isInUse) {
      throw createError({
        statusCode: 409,
        statusMessage: "Enum-Wert wird noch verwendet und kann nicht gel\xF6scht werden"
      });
    }
  }
  await prisma$6.enumValue.delete({
    where: { id: valueId }
  });
  return { success: true };
}
async function checkValueInUse(valueId, categoryName) {
  switch (categoryName) {
    case "task_type":
      const tasksWithType = await prisma$6.task.count({
        where: { typeId: valueId }
      });
      return tasksWithType > 0;
    case "priority":
      const tasksWithPriority = await prisma$6.task.count({
        where: { priorityId: valueId }
      });
      const ticketsWithPriority = await prisma$6.ticket.count({
        where: { priorityId: valueId }
      });
      return tasksWithPriority > 0 || ticketsWithPriority > 0;
    case "task_status":
      const tasksWithStatus = await prisma$6.task.count({
        where: { statusId: valueId }
      });
      return tasksWithStatus > 0;
    case "ticket_type":
      const ticketsWithType = await prisma$6.ticket.count({
        where: { typeId: valueId }
      });
      return ticketsWithType > 0;
    case "ticket_status":
      const ticketsWithStatus = await prisma$6.ticket.count({
        where: { statusId: valueId }
      });
      return ticketsWithStatus > 0;
    default:
      return false;
  }
}

const _id_$7 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: _id_$6
});

const prisma$5 = new PrismaClient();
const createValueSchema = z.object({
  categoryId: z.string().min(1),
  projectId: z.string().optional(),
  // Support for project-specific enums
  key: z.string().min(1).max(50).regex(/^[A-Z_]+$/),
  label: z.string().min(1).max(100),
  description: z.string().optional(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
  icon: z.string().max(50).optional(),
  isDefault: z.boolean().optional().default(false),
  sortOrder: z.number().int().min(0).optional()
});
const filtersSchema = z.object({
  categoryId: z.string().optional(),
  projectId: z.string().optional(),
  // Filter by project
  isActive: z.enum(["true", "false"]).optional(),
  search: z.string().optional()
});
const index$6 = defineEventHandler(async (event) => {
  try {
    const method = getMethod(event);
    switch (method) {
      case "GET":
        return await handleGetValues(event);
      case "POST":
        return await handleCreateValue(event);
      default:
        throw createError({
          statusCode: 405,
          statusMessage: "Method Not Allowed"
        });
    }
  } catch (error) {
    console.error("Enum Values API Error:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || error.message || "Internal Server Error"
    });
  }
});
async function handleGetValues(event) {
  const query = getQuery$1(event);
  const filters = filtersSchema.parse(query);
  const whereClause = {};
  if (filters.categoryId) {
    whereClause.categoryId = filters.categoryId;
  }
  if (filters.projectId !== void 0) {
    if (filters.projectId === "") {
      whereClause.projectId = null;
    } else {
      whereClause.OR = [
        { projectId: null },
        // Global values
        { projectId: filters.projectId }
        // Project-specific values
      ];
    }
  }
  if (filters.isActive !== void 0) {
    whereClause.isActive = filters.isActive === "true";
  }
  if (filters.search) {
    const searchCondition = {
      OR: [
        { label: { contains: filters.search, mode: "insensitive" } },
        { key: { contains: filters.search, mode: "insensitive" } },
        { description: { contains: filters.search, mode: "insensitive" } }
      ]
    };
    if (whereClause.OR) {
      whereClause.AND = [
        { OR: whereClause.OR },
        searchCondition
      ];
      delete whereClause.OR;
    } else {
      Object.assign(whereClause, searchCondition);
    }
  }
  const values = await prisma$5.enumValue.findMany({
    where: whereClause,
    include: {
      category: true,
      project: true
      // Include project info for project-specific values
    },
    orderBy: [
      { category: { sortOrder: "asc" } },
      { projectId: "asc" },
      // Global values first, then project-specific
      { sortOrder: "asc" }
    ]
  });
  return values;
}
async function handleCreateValue(event) {
  const body = await readBody(event);
  const validatedData = createValueSchema.parse(body);
  const category = await prisma$5.enumCategory.findUnique({
    where: { id: validatedData.categoryId }
  });
  if (!category) {
    throw createError({
      statusCode: 404,
      statusMessage: "Enum-Kategorie nicht gefunden"
    });
  }
  if (validatedData.projectId) {
    const project = await prisma$5.project.findUnique({
      where: { id: validatedData.projectId }
    });
    if (!project) {
      throw createError({
        statusCode: 404,
        statusMessage: "Projekt nicht gefunden"
      });
    }
  }
  const existingValue = await prisma$5.enumValue.findFirst({
    where: {
      categoryId: validatedData.categoryId,
      key: validatedData.key,
      projectId: validatedData.projectId || null
    }
  });
  if (existingValue) {
    const scope = validatedData.projectId ? "diesem Projekt" : "global";
    throw createError({
      statusCode: 409,
      statusMessage: `Enum-Wert mit Schl\xFCssel '${validatedData.key}' existiert bereits in dieser Kategorie (${scope})`
    });
  }
  if (validatedData.isDefault) {
    await prisma$5.enumValue.updateMany({
      where: {
        categoryId: validatedData.categoryId,
        projectId: validatedData.projectId || null,
        isDefault: true
      },
      data: { isDefault: false }
    });
  }
  if (validatedData.sortOrder === void 0) {
    const maxSortOrder = await prisma$5.enumValue.aggregate({
      where: {
        categoryId: validatedData.categoryId,
        projectId: validatedData.projectId || null
      },
      _max: { sortOrder: true }
    });
    validatedData.sortOrder = (maxSortOrder._max.sortOrder || 0) + 1;
  }
  const value = await prisma$5.enumValue.create({
    data: {
      id: validatedData.projectId ? `${category.name}_${validatedData.key.toLowerCase()}_${validatedData.projectId}` : `${category.name}_${validatedData.key.toLowerCase()}`,
      projectId: validatedData.projectId || null,
      ...validatedData
    }
  });
  return value;
}

const index$7 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index$6
});

const updateProjectSchema = z.object({
  name: z.string().min(1, "Projektname ist erforderlich").max(255),
  description: z.string().optional(),
  customerId: z.string().optional().nullable(),
  status: z.enum(["AKTIV", "PAUSIERT", "ABGESCHLOSSEN", "ARCHIVIERT"]),
  startDate: z.string().optional().nullable(),
  endDate: z.string().optional().nullable(),
  budget: z.number().min(0).optional().nullable(),
  isInternal: z.boolean().default(false)
});
const _id_$4 = defineEventHandler(async (event) => {
  const method = getMethod(event);
  const projectId = getRouterParam(event, "id");
  const user = await requireAuth()(event);
  try {
    if (method === "GET") {
      const project = await prisma$c.project.findUnique({
        where: { id: projectId },
        include: {
          customer: {
            select: {
              id: true,
              companyName: true,
              contactName: true,
              email: true,
              phone: true
            }
          },
          members: {
            include: {
              user: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  avatar: true,
                  role: true
                }
              }
            }
          },
          tasks: {
            select: {
              id: true,
              key: true,
              title: true,
              status: {
                select: {
                  id: true,
                  key: true,
                  label: true,
                  color: true,
                  icon: true
                }
              },
              priority: {
                select: {
                  id: true,
                  key: true,
                  label: true,
                  color: true,
                  icon: true
                }
              },
              assignee: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  avatar: true
                }
              },
              createdAt: true,
              updatedAt: true
            },
            orderBy: {
              updatedAt: "desc"
            },
            take: 10
          },
          _count: {
            select: {
              tasks: true,
              members: true,
              timeEntries: true
            }
          }
        }
      });
      if (!project) {
        throw createError({
          statusCode: 404,
          statusMessage: "Projekt nicht gefunden"
        });
      }
      const timeEntries = await prisma$c.timeEntry.aggregate({
        where: { projectId: project.id },
        _sum: { hours: true }
      });
      const taskStats = await prisma$c.task.groupBy({
        by: ["statusId"],
        where: { projectId: project.id },
        _count: { _all: true }
      });
      const totalTasks = taskStats.reduce((sum, stat) => sum + stat._count._all, 0);
      let completedTasks = 0;
      if (taskStats.length > 0 && totalTasks > 0) {
        const statusIds = taskStats.map((stat) => stat.statusId).filter((id) => id !== null);
        if (statusIds.length > 0) {
          const statusEnums = await prisma$c.enumValue.findMany({
            where: {
              id: { in: statusIds },
              category: { name: "task_status" }
            }
          });
          const completedStatusIds = statusEnums.filter((enumValue) => {
            var _a;
            const key = enumValue.key.toLowerCase();
            const label = ((_a = enumValue.label) == null ? void 0 : _a.toLowerCase()) || "";
            return key.includes("erledigt") || key.includes("geschlossen") || key.includes("abgeschlossen") || key.includes("done") || key.includes("completed") || key.includes("finished") || label.includes("erledigt") || label.includes("geschlossen") || label.includes("abgeschlossen") || label.includes("done") || label.includes("completed");
          }).map((enumValue) => enumValue.id);
          completedTasks = taskStats.filter((stat) => stat.statusId && completedStatusIds.includes(stat.statusId)).reduce((sum, stat) => sum + stat._count._all, 0);
        }
      }
      const progress = totalTasks > 0 ? Math.round(completedTasks / totalTasks * 100) : 0;
      return {
        success: true,
        data: {
          ...project,
          totalHours: timeEntries._sum.hours || 0,
          progress,
          taskStats
        }
      };
    }
    if (method === "PUT") {
      const currentUser = await prisma$c.user.findUnique({
        where: { id: user.id }
      });
      if (!currentUser || !["ADMINISTRATOR", "PROJEKTLEITER"].includes(currentUser.role)) {
        throw createError({
          statusCode: 403,
          statusMessage: "Keine Berechtigung zum Bearbeiten von Projekten"
        });
      }
      const existingProject = await prisma$c.project.findUnique({
        where: { id: projectId }
      });
      if (!existingProject) {
        throw createError({
          statusCode: 404,
          statusMessage: "Projekt nicht gefunden"
        });
      }
      const body = await readBody(event);
      const validatedData = updateProjectSchema.parse(body);
      if (validatedData.isInternal) {
        validatedData.customerId = null;
      }
      const project = await prisma$c.project.update({
        where: { id: projectId },
        data: {
          ...validatedData,
          startDate: validatedData.startDate ? new Date(validatedData.startDate) : null,
          endDate: validatedData.endDate ? new Date(validatedData.endDate) : null
        },
        include: {
          customer: {
            select: {
              id: true,
              companyName: true,
              contactName: true
            }
          },
          members: {
            include: {
              user: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  avatar: true
                }
              }
            }
          },
          _count: {
            select: {
              tasks: true,
              members: true,
              timeEntries: true
            }
          }
        }
      });
      await prisma$c.activityLog.create({
        data: {
          action: "PROJECT_UPDATED",
          description: `Projekt "${project.name}" wurde aktualisiert`,
          userId: user.id,
          projectId: project.id,
          newValue: JSON.stringify(validatedData)
        }
      });
      return {
        success: true,
        data: project,
        message: "Projekt erfolgreich aktualisiert"
      };
    }
    if (method === "DELETE") {
      const currentUser = await prisma$c.user.findUnique({
        where: { id: user.id }
      });
      if (!currentUser || currentUser.role !== "ADMINISTRATOR") {
        throw createError({
          statusCode: 403,
          statusMessage: "Keine Berechtigung zum L\xF6schen von Projekten"
        });
      }
      const existingProject = await prisma$c.project.findUnique({
        where: { id: projectId }
      });
      if (!existingProject) {
        throw createError({
          statusCode: 404,
          statusMessage: "Projekt nicht gefunden"
        });
      }
      const taskCount = await prisma$c.task.count({
        where: { projectId }
      });
      if (taskCount > 0) {
        throw createError({
          statusCode: 400,
          statusMessage: "Projekt kann nicht gel\xF6scht werden, da es noch Aufgaben enth\xE4lt"
        });
      }
      await prisma$c.project.delete({
        where: { id: projectId }
      });
      await prisma$c.activityLog.create({
        data: {
          action: "PROJECT_DELETED",
          description: `Projekt "${existingProject.name}" wurde gel\xF6scht`,
          userId: user.id,
          oldValue: JSON.stringify({
            projectKey: existingProject.key,
            projectName: existingProject.name
          })
        }
      });
      return {
        success: true,
        message: "Projekt erfolgreich gel\xF6scht"
      };
    }
    throw createError({
      statusCode: 405,
      statusMessage: "Methode nicht erlaubt"
    });
  } catch (error) {
    console.error("Fehler in Project API:", error);
    if (error.statusCode) {
      throw error;
    }
    if (error.name === "ZodError") {
      throw createError({
        statusCode: 400,
        statusMessage: "Validierungsfehler",
        data: {
          errors: error.errors.reduce((acc, err) => {
            acc[err.path[0]] = err.message;
            return acc;
          }, {})
        }
      });
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Serverfehler"
    });
  }
});

const _id_$5 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: _id_$4
});

const enumConfig = /*#__PURE__*/Object.freeze({
  __proto__: null
});

const prisma$4 = new PrismaClient();
const updateOverrideSchema = z.object({
  categoryId: z.string().min(1),
  enumValueId: z.string().min(1),
  isActive: z.boolean(),
  sortOrder: z.number().int().min(0).optional()
});
const enumOverrides = defineEventHandler(async (event) => {
  try {
    const method = getMethod(event);
    const projectId = getRouterParam(event, "id");
    if (!projectId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Projekt-ID erforderlich"
      });
    }
    switch (method) {
      case "GET":
        return await handleGetProjectOverrides(projectId);
      case "PUT":
        return await handleUpdateProjectOverride(event, projectId);
      default:
        throw createError({
          statusCode: 405,
          statusMessage: "Method Not Allowed"
        });
    }
  } catch (error) {
    console.error("Project Enum Overrides API Error:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || error.message || "Internal Server Error"
    });
  }
});
async function handleGetProjectOverrides(projectId) {
  const project = await prisma$4.project.findUnique({
    where: { id: projectId }
  });
  if (!project) {
    throw createError({
      statusCode: 404,
      statusMessage: "Projekt nicht gefunden"
    });
  }
  const overrides = await prisma$4.projectEnumOverride.findMany({
    where: { projectId },
    include: {
      category: true,
      enumValue: true
    },
    orderBy: [
      { category: { sortOrder: "asc" } },
      { sortOrder: "asc" }
    ]
  });
  return overrides;
}
async function handleUpdateProjectOverride(event, projectId) {
  const body = await readBody(event);
  const validatedData = updateOverrideSchema.parse(body);
  const project = await prisma$4.project.findUnique({
    where: { id: projectId }
  });
  if (!project) {
    throw createError({
      statusCode: 404,
      statusMessage: "Projekt nicht gefunden"
    });
  }
  const category = await prisma$4.enumCategory.findUnique({
    where: { id: validatedData.categoryId }
  });
  if (!category) {
    throw createError({
      statusCode: 404,
      statusMessage: "Enum-Kategorie nicht gefunden"
    });
  }
  const enumValue = await prisma$4.enumValue.findUnique({
    where: { id: validatedData.enumValueId }
  });
  if (!enumValue || enumValue.categoryId !== validatedData.categoryId) {
    throw createError({
      statusCode: 404,
      statusMessage: "Enum-Wert nicht gefunden oder geh\xF6rt nicht zur angegebenen Kategorie"
    });
  }
  const override = await prisma$4.projectEnumOverride.upsert({
    where: {
      projectId_categoryId_enumValueId: {
        projectId,
        categoryId: validatedData.categoryId,
        enumValueId: validatedData.enumValueId
      }
    },
    update: {
      isActive: validatedData.isActive,
      sortOrder: validatedData.sortOrder
    },
    create: {
      projectId,
      categoryId: validatedData.categoryId,
      enumValueId: validatedData.enumValueId,
      isActive: validatedData.isActive,
      sortOrder: validatedData.sortOrder
    }
  });
  return override;
}

const enumOverrides$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: enumOverrides
});

const index_get$2 = defineEventHandler(async (event) => {
  await requireAuth()(event);
  try {
    const projects = await prisma$c.project.findMany({
      include: {
        customer: {
          select: {
            id: true,
            companyName: true,
            contactName: true
          }
        },
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                avatar: true
              }
            }
          }
        },
        _count: {
          select: {
            tasks: true,
            members: true,
            timeEntries: true
          }
        }
      },
      orderBy: {
        updatedAt: "desc"
      }
    });
    const projectsWithMetrics = await Promise.all(
      projects.map(async (project) => {
        const timeEntries = await prisma$c.timeEntry.aggregate({
          where: { projectId: project.id },
          _sum: { hours: true }
        });
        const taskStats = await prisma$c.task.groupBy({
          by: ["statusId"],
          where: { projectId: project.id },
          _count: { _all: true }
        });
        const totalTasks = taskStats.reduce((sum, stat) => sum + stat._count._all, 0);
        let completedTasks = 0;
        if (taskStats.length > 0 && totalTasks > 0) {
          const statusIds = taskStats.map((stat) => stat.statusId).filter((id) => id !== null);
          if (statusIds.length > 0) {
            const statusEnums = await prisma$c.enumValue.findMany({
              where: {
                id: { in: statusIds },
                category: { name: "task_status" }
              }
            });
            const completedStatusIds = statusEnums.filter((enumValue) => {
              var _a;
              const key = enumValue.key.toLowerCase();
              const label = ((_a = enumValue.label) == null ? void 0 : _a.toLowerCase()) || "";
              return key.includes("erledigt") || key.includes("geschlossen") || key.includes("abgeschlossen") || key.includes("done") || key.includes("completed") || key.includes("finished") || label.includes("erledigt") || label.includes("geschlossen") || label.includes("abgeschlossen") || label.includes("done") || label.includes("completed");
            }).map((enumValue) => enumValue.id);
            completedTasks = taskStats.filter((stat) => stat.statusId && completedStatusIds.includes(stat.statusId)).reduce((sum, stat) => sum + stat._count._all, 0);
          }
        }
        const progress = totalTasks > 0 ? Math.round(completedTasks / totalTasks * 100) : 0;
        return {
          ...project,
          totalHours: timeEntries._sum.hours || 0,
          progress
        };
      })
    );
    return {
      success: true,
      data: projectsWithMetrics
    };
  } catch (error) {
    console.error("Fehler beim Laden der Projekte:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Serverfehler"
    });
  }
});

const index_get$3 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index_get$2
});

const createProjectSchema = z.object({
  name: z.string().min(1, "Projektname ist erforderlich").max(255),
  key: z.string().min(1, "Projektschl\xFCssel ist erforderlich").max(50).regex(/^[A-Z0-9-]+$/, "Nur Gro\xDFbuchstaben, Zahlen und Bindestriche erlaubt"),
  description: z.string().optional(),
  customerId: z.string().optional().nullable(),
  status: z.enum(["AKTIV", "PAUSIERT", "ABGESCHLOSSEN", "ARCHIVIERT"]).default("AKTIV"),
  startDate: z.string().optional().nullable(),
  endDate: z.string().optional().nullable(),
  budget: z.number().min(0).optional().nullable(),
  isInternal: z.boolean().default(false)
});
const index_post$2 = defineEventHandler(async (event) => {
  const method = getMethod(event);
  const user = await requireAuth("PROJEKTLEITER")(event);
  try {
    if (method === "GET") {
      const projects = await prisma$c.project.findMany({
        include: {
          customer: {
            select: {
              id: true,
              companyName: true,
              contactName: true
            }
          },
          members: {
            include: {
              user: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  avatar: true
                }
              }
            }
          },
          _count: {
            select: {
              tasks: true,
              members: true,
              timeEntries: true
            }
          }
        },
        orderBy: {
          updatedAt: "desc"
        }
      });
      const projectsWithMetrics = await Promise.all(
        projects.map(async (project) => {
          const timeEntries = await prisma$c.timeEntry.aggregate({
            where: { projectId: project.id },
            _sum: { hours: true }
          });
          const taskStats = await prisma$c.task.groupBy({
            by: ["statusId"],
            where: { projectId: project.id },
            _count: { _all: true }
          });
          const totalTasks = taskStats.reduce((sum, stat) => sum + stat._count._all, 0);
          let completedTasks = 0;
          if (taskStats.length > 0) {
            const statusIds = taskStats.map((stat) => stat.statusId).filter((id) => id !== null);
            if (statusIds.length > 0) {
              const statusEnums = await prisma$c.enumValue.findMany({
                where: {
                  id: { in: statusIds },
                  category: { name: "task_status" }
                }
              });
              const completedStatusIds = statusEnums.filter(
                (enumValue) => enumValue.key.toLowerCase().includes("erledigt") || enumValue.key.toLowerCase().includes("abgeschlossen") || enumValue.key.toLowerCase().includes("done") || enumValue.key.toLowerCase().includes("completed")
              ).map((enumValue) => enumValue.id);
              completedTasks = taskStats.filter((stat) => stat.statusId && completedStatusIds.includes(stat.statusId)).reduce((sum, stat) => sum + stat._count._all, 0);
            }
          }
          const progress = totalTasks > 0 ? completedTasks / totalTasks * 100 : 0;
          return {
            ...project,
            totalHours: timeEntries._sum.hours || 0,
            progress
          };
        })
      );
      return {
        success: true,
        data: projectsWithMetrics
      };
    }
    if (method === "POST") {
      const currentUser = await prisma$c.user.findUnique({
        where: { id: user.id }
      });
      if (!currentUser || !["ADMINISTRATOR", "PROJEKTLEITER"].includes(currentUser.role)) {
        throw createError({
          statusCode: 403,
          statusMessage: "Keine Berechtigung zum Erstellen von Projekten"
        });
      }
      const body = await readBody(event);
      const validatedData = createProjectSchema.parse(body);
      const existingProject = await prisma$c.project.findUnique({
        where: { key: validatedData.key }
      });
      if (existingProject) {
        throw createError({
          statusCode: 400,
          statusMessage: "Projektschl\xFCssel bereits vergeben"
        });
      }
      if (validatedData.isInternal) {
        validatedData.customerId = null;
      }
      const project = await prisma$c.project.create({
        data: {
          ...validatedData,
          startDate: validatedData.startDate ? new Date(validatedData.startDate) : null,
          endDate: validatedData.endDate ? new Date(validatedData.endDate) : null,
          members: {
            create: {
              userId: user.id,
              role: "Projektleiter"
            }
          }
        },
        include: {
          customer: {
            select: {
              id: true,
              companyName: true,
              contactName: true
            }
          },
          members: {
            include: {
              user: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  avatar: true
                }
              }
            }
          },
          _count: {
            select: {
              tasks: true,
              members: true,
              timeEntries: true
            }
          }
        }
      });
      await prisma$c.activityLog.create({
        data: {
          action: "PROJECT_CREATED",
          description: `Projekt "${project.name}" wurde erstellt`,
          userId: user.id,
          projectId: project.id,
          newValue: JSON.stringify({
            projectKey: project.key,
            projectName: project.name
          })
        }
      });
      return {
        success: true,
        data: project,
        message: "Projekt erfolgreich erstellt"
      };
    }
    throw createError({
      statusCode: 405,
      statusMessage: "Methode nicht erlaubt"
    });
  } catch (error) {
    console.error("Fehler in Projects API:", error);
    if (error.statusCode) {
      throw error;
    }
    if (error.name === "ZodError") {
      throw createError({
        statusCode: 400,
        statusMessage: "Validierungsfehler",
        data: {
          errors: error.errors.reduce((acc, err) => {
            acc[err.path[0]] = err.message;
            return acc;
          }, {})
        }
      });
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Serverfehler"
    });
  }
});

const index_post$3 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index_post$2
});

const export_post = defineEventHandler(async (event) => {
  const user = await requireAuth()(event);
  if (!["ADMINISTRATOR", "PROJEKTLEITER"].includes(user.role)) {
    throw createError({
      statusCode: 403,
      statusMessage: "Keine Berechtigung f\xFCr diese Aktion"
    });
  }
  const query = getQuery$1(event);
  const format = query.format;
  const reportType = query.reportType;
  const startDate = query.startDate;
  const endDate = query.endDate;
  if (!format || !reportType || !startDate || !endDate) {
    throw createError({
      statusCode: 400,
      statusMessage: "Format, Berichtstyp, Start- und Enddatum sind erforderlich"
    });
  }
  try {
    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);
    let data = {};
    switch (reportType) {
      case "time":
        data = await getTimeReportData(start, end);
        break;
      case "projects":
        data = await getProjectReportData(start, end);
        break;
      case "team":
        data = await getTeamReportData(start, end);
        break;
      case "financial":
        data = await getFinancialReportData(start, end);
        break;
      default:
        throw createError({
          statusCode: 400,
          statusMessage: "Ung\xFCltiger Berichtstyp"
        });
    }
    if (format === "excel") {
      return await generateExcelReport(reportType, data, start, end, event);
    } else if (format === "pdf") {
      return await generatePDFReport(reportType, data, start, end, event);
    } else {
      throw createError({
        statusCode: 400,
        statusMessage: "Ung\xFCltiges Format. Unterst\xFCtzt: excel, pdf"
      });
    }
  } catch (error) {
    console.error("Export error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Exportieren des Berichts"
    });
  }
});
async function getTimeReportData(start, end) {
  const timeEntries = await prisma$c.timeEntry.findMany({
    where: {
      date: { gte: start, lte: end }
    },
    include: {
      user: true,
      project: true,
      task: true
    },
    orderBy: { date: "desc" }
  });
  return {
    entries: timeEntries,
    totalHours: timeEntries.reduce((sum, entry) => sum + entry.hours, 0),
    billableHours: timeEntries.filter((e) => e.billable).reduce((sum, entry) => sum + entry.hours, 0)
  };
}
async function getProjectReportData(start, end) {
  const projects = await prisma$c.project.findMany({
    include: {
      customer: true,
      timeEntries: {
        where: { date: { gte: start, lte: end } }
      },
      tasks: {
        include: {
          timeEntries: {
            where: { date: { gte: start, lte: end } }
          }
        }
      }
    }
  });
  return {
    projects: projects.map((project) => ({
      ...project,
      totalHours: project.timeEntries.reduce((sum, entry) => sum + entry.hours, 0),
      completedTasks: project.tasks.filter((task) => task.status === "ERLEDIGT").length,
      totalTasks: project.tasks.length
    }))
  };
}
async function getTeamReportData(start, end) {
  const users = await prisma$c.user.findMany({
    where: { role: { in: ["PROJEKTLEITER", "ENTWICKLER", "SUPPORTER"] } },
    include: {
      timeEntries: {
        where: { date: { gte: start, lte: end } }
      }
    }
  });
  return {
    members: users.map((user) => ({
      ...user,
      totalHours: user.timeEntries.reduce((sum, entry) => sum + entry.hours, 0),
      productivity: calculateProductivity(user.timeEntries),
      efficiency: calculateEfficiency(user.timeEntries)
    }))
  };
}
async function getFinancialReportData(start, end) {
  const timeEntries = await prisma$c.timeEntry.findMany({
    where: {
      date: { gte: start, lte: end },
      billable: true
    },
    include: {
      project: { include: { customer: true } }
    }
  });
  const standardRate = 85;
  const totalRevenue = timeEntries.reduce((sum, entry) => sum + entry.hours * standardRate, 0);
  return {
    totalRevenue,
    billableHours: timeEntries.reduce((sum, entry) => sum + entry.hours, 0),
    averageRate: standardRate,
    entries: timeEntries
  };
}
function calculateProductivity(timeEntries) {
  const totalHours = timeEntries.reduce((sum, entry) => sum + entry.hours, 0);
  const workDays = 22;
  const expectedHours = workDays * 8;
  return totalHours > 0 ? Math.round(totalHours / expectedHours * 100) : 0;
}
function calculateEfficiency(timeEntries) {
  const billableHours = timeEntries.filter((e) => e.billable).reduce((sum, entry) => sum + entry.hours, 0);
  const totalHours = timeEntries.reduce((sum, entry) => sum + entry.hours, 0);
  return totalHours > 0 ? Math.round(billableHours / totalHours * 100) : 0;
}
async function generateExcelReport(reportType, data, start, end, event) {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet("Bericht");
  const headerStyle = {
    font: { bold: true, color: { argb: "FFFFFF" } },
    fill: { type: "pattern", pattern: "solid", fgColor: { argb: "366092" } },
    alignment: { horizontal: "center" }
  };
  worksheet.mergeCells("A1:F1");
  worksheet.getCell("A1").value = `${getReportTitle(reportType)} (${formatDate(start)} - ${formatDate(end)})`;
  worksheet.getCell("A1").style = headerStyle;
  switch (reportType) {
    case "time":
      const timeHeaderRow = worksheet.addRow(["Datum", "Benutzer", "Projekt", "Aufgabe", "Stunden", "Abrechenbar"]);
      timeHeaderRow.eachCell((cell) => {
        cell.font = { bold: true, color: { argb: "FFFFFF" } };
        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "366092" } };
        cell.alignment = { horizontal: "center" };
      });
      data.entries.forEach((entry) => {
        var _a, _b, _c;
        worksheet.addRow([
          formatDate(entry.date),
          ((_a = entry.user) == null ? void 0 : _a.name) || "Unbekannt",
          ((_b = entry.project) == null ? void 0 : _b.name) || "Ohne Projekt",
          ((_c = entry.task) == null ? void 0 : _c.title) || "Ohne Aufgabe",
          entry.hours,
          entry.billable ? "Ja" : "Nein"
        ]);
      });
      break;
    case "projects":
      const projectHeaderRow = worksheet.addRow(["Projekt", "Kunde", "Status", "Stunden", "Aufgaben erledigt", "Aufgaben gesamt"]);
      projectHeaderRow.eachCell((cell) => {
        cell.font = { bold: true, color: { argb: "FFFFFF" } };
        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "366092" } };
        cell.alignment = { horizontal: "center" };
      });
      data.projects.forEach((project) => {
        var _a;
        worksheet.addRow([
          project.name,
          ((_a = project.customer) == null ? void 0 : _a.companyName) || "Unbekannt",
          project.status,
          project.totalHours,
          project.completedTasks,
          project.totalTasks
        ]);
      });
      break;
    case "team":
      const teamHeaderRow = worksheet.addRow(["Name", "E-Mail", "Rolle", "Stunden", "Produktivit\xE4t (%)", "Effizienz (%)"]);
      teamHeaderRow.eachCell((cell) => {
        cell.font = { bold: true, color: { argb: "FFFFFF" } };
        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "366092" } };
        cell.alignment = { horizontal: "center" };
      });
      data.members.forEach((member) => {
        worksheet.addRow([
          member.name,
          member.email,
          member.role,
          member.totalHours,
          member.productivity,
          member.efficiency
        ]);
      });
      break;
    case "financial":
      const financialHeaderRow = worksheet.addRow(["Datum", "Projekt", "Kunde", "Stunden", "Stundensatz", "Umsatz"]);
      financialHeaderRow.eachCell((cell) => {
        cell.font = { bold: true, color: { argb: "FFFFFF" } };
        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "366092" } };
        cell.alignment = { horizontal: "center" };
      });
      data.entries.forEach((entry) => {
        var _a, _b, _c;
        worksheet.addRow([
          formatDate(entry.date),
          ((_a = entry.project) == null ? void 0 : _a.name) || "Ohne Projekt",
          ((_c = (_b = entry.project) == null ? void 0 : _b.customer) == null ? void 0 : _c.companyName) || "Unbekannt",
          entry.hours,
          `\u20AC${data.averageRate}`,
          `\u20AC${entry.hours * data.averageRate}`
        ]);
      });
      break;
  }
  worksheet.columns.forEach((column) => {
    column.width = 15;
  });
  const buffer = await workbook.xlsx.writeBuffer();
  setHeader(event, "Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  setHeader(event, "Content-Disposition", `attachment; filename="${reportType}_bericht_${formatDate(start)}_${formatDate(end)}.xlsx"`);
  return buffer;
}
async function generatePDFReport(reportType, data, start, end, event) {
  const doc = new PDFDocument();
  const chunks = [];
  doc.on("data", (chunk) => chunks.push(chunk));
  doc.fontSize(20).text(`${getReportTitle(reportType)}`, { align: "center" });
  doc.fontSize(12).text(`Zeitraum: ${formatDate(start)} - ${formatDate(end)}`, { align: "center" });
  doc.moveDown(2);
  switch (reportType) {
    case "time":
      doc.fontSize(14).text(`Gesamtstunden: ${data.totalHours}`);
      doc.text(`Abrechenbare Stunden: ${data.billableHours}`);
      doc.moveDown();
      data.entries.slice(0, 20).forEach((entry) => {
        var _a, _b;
        doc.fontSize(10);
        doc.text(`${formatDate(entry.date)} | ${(_a = entry.user) == null ? void 0 : _a.name} | ${((_b = entry.project) == null ? void 0 : _b.name) || "Ohne Projekt"} | ${entry.hours}h`);
      });
      break;
    case "projects":
      data.projects.slice(0, 15).forEach((project) => {
        var _a;
        doc.fontSize(12).text(project.name, { underline: true });
        doc.fontSize(10);
        doc.text(`Kunde: ${((_a = project.customer) == null ? void 0 : _a.name) || "Unbekannt"}`);
        doc.text(`Status: ${project.status}`);
        doc.text(`Stunden: ${project.totalHours}`);
        doc.text(`Aufgaben: ${project.completedTasks}/${project.totalTasks}`);
        doc.moveDown();
      });
      break;
    case "team":
      data.members.forEach((member) => {
        doc.fontSize(12).text(member.name, { underline: true });
        doc.fontSize(10);
        doc.text(`E-Mail: ${member.email}`);
        doc.text(`Rolle: ${member.role}`);
        doc.text(`Stunden: ${member.totalHours}`);
        doc.text(`Produktivit\xE4t: ${member.productivity}%`);
        doc.text(`Effizienz: ${member.efficiency}%`);
        doc.moveDown();
      });
      break;
    case "financial":
      doc.fontSize(14).text(`Gesamtumsatz: \u20AC${data.totalRevenue}`);
      doc.text(`Abrechenbare Stunden: ${data.billableHours}`);
      doc.text(`Durchschnittlicher Stundensatz: \u20AC${data.averageRate}`);
      doc.moveDown();
      break;
  }
  doc.end();
  await new Promise((resolve) => {
    doc.on("end", resolve);
  });
  const buffer = Buffer.concat(chunks);
  setHeader(event, "Content-Type", "application/pdf");
  setHeader(event, "Content-Disposition", `attachment; filename="${reportType}_bericht_${formatDate(start)}_${formatDate(end)}.pdf"`);
  return buffer;
}
function getReportTitle(reportType) {
  const titles = {
    time: "Zeiterfassung Bericht",
    projects: "Projekt Bericht",
    team: "Team Bericht",
    financial: "Finanzbericht"
  };
  return titles[reportType] || "Bericht";
}
function formatDate(date) {
  return date.toLocaleDateString("de-DE");
}

const export_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: export_post
});

const financial_get = defineEventHandler(async (event) => {
  const user = await requireAuth()(event);
  if (!["ADMINISTRATOR", "PROJEKTLEITER"].includes(user.role)) {
    throw createError({
      statusCode: 403,
      statusMessage: "Keine Berechtigung f\xFCr diese Aktion"
    });
  }
  const query = getQuery$1(event);
  const startDate = query.startDate;
  const endDate = query.endDate;
  if (!startDate || !endDate) {
    throw createError({
      statusCode: 400,
      statusMessage: "Start- und Enddatum sind erforderlich"
    });
  }
  try {
    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);
    const timeEntries = await prisma$c.timeEntry.findMany({
      where: {
        date: {
          gte: start,
          lte: end
        },
        billable: true
      },
      include: {
        project: {
          include: {
            customer: true
          }
        }
      }
    });
    const standardHourlyRate = 85;
    const billableTime = timeEntries.reduce((sum, entry) => sum + entry.hours, 0);
    const totalRevenue = billableTime * standardHourlyRate;
    const totalCosts = totalRevenue * 0.6;
    const avgHourlyRate = standardHourlyRate;
    const profitability = totalRevenue > 0 ? Math.round((totalRevenue - totalCosts) / totalRevenue * 100) : 0;
    const revenueData = [];
    const currentDate = new Date(start);
    while (currentDate <= end) {
      const dayStart = new Date(currentDate);
      const dayEnd = new Date(currentDate);
      dayEnd.setHours(23, 59, 59, 999);
      const dayEntries = timeEntries.filter((entry) => {
        const entryDate = new Date(entry.date);
        return entryDate >= dayStart && entryDate <= dayEnd;
      });
      const dayHours = dayEntries.reduce((sum, entry) => sum + entry.hours, 0);
      const dayRevenue = dayHours * standardHourlyRate;
      const dayTarget = standardHourlyRate * 8 * 5;
      revenueData.push({
        date: currentDate.toISOString().split("T")[0],
        revenue: dayRevenue,
        target: dayTarget
      });
      currentDate.setDate(currentDate.getDate() + 1);
    }
    const projectRevenue = timeEntries.reduce((acc, entry) => {
      var _a, _b, _c, _d;
      const projectId = ((_a = entry.project) == null ? void 0 : _a.id) || "unknown";
      const projectName = ((_b = entry.project) == null ? void 0 : _b.name) || "Ohne Projekt";
      const customerName = ((_d = (_c = entry.project) == null ? void 0 : _c.customer) == null ? void 0 : _d.companyName) || "Unbekannt";
      if (!acc[projectId]) {
        acc[projectId] = {
          id: projectId,
          name: projectName,
          customer: customerName,
          hours: 0,
          revenue: 0
        };
      }
      acc[projectId].hours += entry.hours;
      acc[projectId].revenue += entry.hours * standardHourlyRate;
      return acc;
    }, {});
    const profitabilityData = Object.values(projectRevenue).map((project) => {
      const costs = project.revenue * 0.6;
      const profit = project.revenue - costs;
      const roi = costs > 0 ? Math.round(profit / costs * 100) : 0;
      return {
        id: project.id,
        name: project.name,
        customer: project.customer,
        revenue: Math.round(project.revenue),
        costs: Math.round(costs),
        profit: Math.round(profit),
        roi,
        status: "active"
      };
    }).sort((a, b) => b.revenue - a.revenue);
    const periodLength = end.getTime() - start.getTime();
    const previousStart = new Date(start.getTime() - periodLength);
    const previousEnd = new Date(start.getTime() - 1);
    const previousTimeEntries = await prisma$c.timeEntry.findMany({
      where: {
        date: {
          gte: previousStart,
          lte: previousEnd
        },
        billable: true
      }
    });
    const previousRevenue = previousTimeEntries.reduce((sum, entry) => sum + entry.hours, 0) * standardHourlyRate;
    const revenueChange = previousRevenue > 0 ? Math.round((totalRevenue - previousRevenue) / previousRevenue * 100) : 0;
    return {
      totalRevenue: Math.round(totalRevenue),
      billableTime: Math.round(billableTime * 10) / 10,
      avgHourlyRate,
      profitability,
      revenueChange,
      revenueData,
      profitabilityData: profitabilityData.slice(0, 10)
      // Top 10 projects
    };
  } catch (error) {
    console.error("Financial report error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Laden des Finanzberichts"
    });
  }
});

const financial_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: financial_get
});

const projects_get = defineEventHandler(async (event) => {
  const user = await requireAuth()(event);
  if (!["ADMINISTRATOR", "PROJEKTLEITER"].includes(user.role)) {
    throw createError({
      statusCode: 403,
      statusMessage: "Keine Berechtigung f\xFCr diese Aktion"
    });
  }
  const query = getQuery$1(event);
  const startDate = query.startDate;
  const endDate = query.endDate;
  if (!startDate || !endDate) {
    throw createError({
      statusCode: 400,
      statusMessage: "Start- und Enddatum sind erforderlich"
    });
  }
  try {
    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);
    const projects = await prisma$c.project.findMany({
      include: {
        tasks: {
          include: {
            timeEntries: {
              where: {
                date: {
                  gte: start,
                  lte: end
                }
              }
            }
          }
        },
        customer: {
          select: {
            companyName: true
          }
        },
        members: {
          include: {
            user: {
              select: {
                firstName: true,
                lastName: true
              }
            }
          }
        }
      }
    });
    const activeProjects = projects.filter((p) => p.status === "AKTIV").length;
    const completedProjects = projects.filter((p) => p.status === "ABGESCHLOSSEN").length;
    const overdueProjects = projects.filter((p) => {
      return p.endDate && new Date(p.endDate) < /* @__PURE__ */ new Date() && p.status !== "ABGESCHLOSSEN";
    }).length;
    const completedProjectsWithDates = projects.filter(
      (p) => p.status === "ABGESCHLOSSEN" && p.startDate && p.endDate
    );
    const avgProjectDuration = completedProjectsWithDates.length > 0 ? Math.round(
      completedProjectsWithDates.reduce((sum, p) => {
        const duration = (new Date(p.endDate).getTime() - new Date(p.startDate).getTime()) / (1e3 * 60 * 60 * 24);
        return sum + duration;
      }, 0) / completedProjectsWithDates.length
    ) : 0;
    const projectPerformance = projects.map((project) => {
      var _a, _b;
      const totalTimeEntries = ((_a = project.tasks) == null ? void 0 : _a.flatMap((task) => task.timeEntries)) || [];
      const actualHours = totalTimeEntries.reduce((sum, entry) => sum + entry.hours, 0);
      const estimatedHours = ((_b = project.tasks) == null ? void 0 : _b.reduce((sum, task) => sum + (task.estimatedHours || 0), 0)) || 0;
      return {
        name: project.name,
        estimatedHours: estimatedHours || 0,
        actualHours: actualHours || 0,
        efficiency: estimatedHours > 0 ? Math.round(estimatedHours / actualHours * 100) : 0
      };
    }).filter((p) => p.estimatedHours > 0 || p.actualHours > 0);
    const statusCounts = projects.reduce((acc, project) => {
      acc[project.status] = (acc[project.status] || 0) + 1;
      return acc;
    }, {});
    const projectStatus = Object.entries(statusCounts).map(([status, count]) => ({
      status,
      count,
      color: getStatusColor(status)
    }));
    return {
      activeProjects,
      completedProjects,
      overdueProjects,
      avgProjectDuration,
      projectPerformance: projectPerformance.slice(0, 10),
      // Top 10
      projectStatus
    };
  } catch (error) {
    console.error("Project report error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Laden des Projektberichts"
    });
  }
});
function getStatusColor(status) {
  const colors = {
    "GEPLANT": "#6B7280",
    "AKTIV": "#3B82F6",
    "PAUSIERT": "#F59E0B",
    "ABGESCHLOSSEN": "#10B981",
    "ABGEBROCHEN": "#EF4444"
  };
  return colors[status] || "#6B7280";
}

const projects_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: projects_get
});

const team_get = defineEventHandler(async (event) => {
  const user = await requireAuth()(event);
  if (!["ADMINISTRATOR", "PROJEKTLEITER"].includes(user.role)) {
    throw createError({
      statusCode: 403,
      statusMessage: "Keine Berechtigung f\xFCr diese Aktion"
    });
  }
  const query = getQuery$1(event);
  const startDate = query.startDate;
  const endDate = query.endDate;
  if (!startDate || !endDate) {
    throw createError({
      statusCode: 400,
      statusMessage: "Start- und Enddatum sind erforderlich"
    });
  }
  try {
    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);
    const teamMembers = await prisma$c.user.findMany({
      where: {
        role: {
          in: ["ADMINISTRATOR", "PROJEKTLEITER", "ENTWICKLER", "SUPPORTER"]
        },
        isActive: true
      },
      include: {
        timeEntries: {
          where: {
            date: {
              gte: start,
              lte: end
            }
          }
        },
        assignedTasks: {
          where: {
            updatedAt: {
              gte: start,
              lte: end
            },
            status: {
              key: "ERLEDIGT"
            }
          }
        },
        skills: true
      }
    });
    const totalMembers = teamMembers.length;
    const totalHours = teamMembers.reduce(
      (sum, member) => sum + member.timeEntries.reduce((memberSum, entry) => memberSum + entry.hours, 0),
      0
    );
    const workingDays = Math.ceil((end.getTime() - start.getTime()) / (1e3 * 60 * 60 * 24));
    const targetHours = totalMembers * workingDays * 8;
    const avgUtilization = targetHours > 0 ? Math.round(totalHours / targetHours * 100) : 0;
    const completedTasks = teamMembers.reduce((sum, member) => sum + member.assignedTasks.length, 0);
    const teamProductivity = totalHours > 0 ? Math.round(completedTasks / totalHours * 10) : 0;
    const teamWorkload = teamMembers.map((member) => {
      const memberHours = member.timeEntries.reduce((sum, entry) => sum + entry.hours, 0);
      const memberTargetHours = workingDays * 8;
      const utilization = memberTargetHours > 0 ? Math.round(memberHours / memberTargetHours * 100) : 0;
      return {
        name: `${member.firstName} ${member.lastName}`,
        utilization,
        capacity: 100
      };
    }).sort((a, b) => b.utilization - a.utilization);
    const individualPerformance = teamMembers.map((member) => {
      const memberHours = member.timeEntries.reduce((sum, entry) => sum + entry.hours, 0);
      const memberTasks = member.assignedTasks.length;
      const efficiency = memberHours > 0 ? Math.round(memberTasks / memberHours * 100) : 0;
      let performance;
      if (efficiency >= 90) performance = "excellent";
      else if (efficiency >= 70) performance = "good";
      else if (efficiency >= 50) performance = "average";
      else performance = "below-average";
      return {
        id: member.id,
        name: `${member.firstName} ${member.lastName}`,
        role: getRoleDisplayName(member.role),
        avatar: null,
        completedTasks: memberTasks,
        hoursWorked: memberHours,
        efficiency,
        performance
      };
    }).sort((a, b) => b.efficiency - a.efficiency);
    return {
      totalMembers,
      avgUtilization,
      completedTasks,
      teamProductivity,
      teamWorkload: teamWorkload.slice(0, 10),
      // Top 10
      individualPerformance
    };
  } catch (error) {
    console.error("Team report error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Laden des Team-Berichts"
    });
  }
});
function getRoleDisplayName(role) {
  const roles = {
    "ADMINISTRATOR": "Administrator",
    "PROJEKTLEITER": "Projektleiter",
    "ENTWICKLER": "Entwickler",
    "SUPPORTER": "Supporter",
    "VIEWER": "Betrachter"
  };
  return roles[role] || role;
}

const team_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: team_get
});

const time_get = defineEventHandler(async (event) => {
  const user = await requireAuth()(event);
  if (!["ADMINISTRATOR", "PROJEKTLEITER"].includes(user.role)) {
    throw createError({
      statusCode: 403,
      statusMessage: "Keine Berechtigung f\xFCr diese Aktion"
    });
  }
  const query = getQuery$1(event);
  const startDate = query.startDate;
  const endDate = query.endDate;
  if (!startDate || !endDate) {
    throw createError({
      statusCode: 400,
      statusMessage: "Start- und Enddatum sind erforderlich"
    });
  }
  try {
    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);
    const timeEntries = await prisma$c.timeEntry.findMany({
      where: {
        date: {
          gte: start,
          lte: end
        }
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      }
    });
    const totalHours = timeEntries.reduce((sum, entry) => sum + entry.hours, 0);
    const billableHours = timeEntries.filter((entry) => entry.billable).reduce((sum, entry) => sum + entry.hours, 0);
    const productivity = totalHours > 0 ? Math.round(billableHours / totalHours * 100) : 0;
    const daysDiff = Math.ceil((end.getTime() - start.getTime()) / (1e3 * 60 * 60 * 24));
    const avgHoursPerDay = daysDiff > 0 ? totalHours / daysDiff : 0;
    const projectDistribution = timeEntries.reduce((acc, entry) => {
      var _a;
      const projectName = ((_a = entry.project) == null ? void 0 : _a.name) || "Ohne Projekt";
      const existing = acc.find((p) => p.name === projectName);
      if (existing) {
        existing.hours += entry.hours;
      } else {
        acc.push({
          name: projectName,
          hours: entry.hours
        });
      }
      return acc;
    }, []);
    const timeTrends = [];
    const currentDate = new Date(start);
    while (currentDate <= end) {
      const dayStart = new Date(currentDate);
      const dayEnd = new Date(currentDate);
      dayEnd.setHours(23, 59, 59, 999);
      const dayEntries = timeEntries.filter((entry) => {
        const entryDate = new Date(entry.date);
        return entryDate >= dayStart && entryDate <= dayEnd;
      });
      const dayTotalHours = dayEntries.reduce((sum, entry) => sum + entry.hours, 0);
      const dayBillableHours = dayEntries.filter((entry) => entry.billable).reduce((sum, entry) => sum + entry.hours, 0);
      timeTrends.push({
        date: currentDate.toISOString().split("T")[0],
        hours: dayTotalHours,
        billableHours: dayBillableHours
      });
      currentDate.setDate(currentDate.getDate() + 1);
    }
    const periodLength = end.getTime() - start.getTime();
    const previousStart = new Date(start.getTime() - periodLength);
    const previousEnd = new Date(start.getTime() - 1);
    const previousTimeEntries = await prisma$c.timeEntry.findMany({
      where: {
        date: {
          gte: previousStart,
          lte: previousEnd
        }
      }
    });
    const previousTotalHours = previousTimeEntries.reduce((sum, entry) => sum + entry.hours, 0);
    const previousBillableHours = previousTimeEntries.filter((entry) => entry.billable).reduce((sum, entry) => sum + entry.hours, 0);
    const timeChange = previousTotalHours > 0 ? Math.round((totalHours - previousTotalHours) / previousTotalHours * 100) : 0;
    const billableChange = previousBillableHours > 0 ? Math.round((billableHours - previousBillableHours) / previousBillableHours * 100) : 0;
    return {
      totalHours: Math.round(totalHours * 10) / 10,
      billableHours: Math.round(billableHours * 10) / 10,
      productivity,
      avgHoursPerDay: Math.round(avgHoursPerDay * 10) / 10,
      timeChange,
      billableChange,
      projectDistribution: projectDistribution.sort((a, b) => b.hours - a.hours),
      timeTrends
    };
  } catch (error) {
    console.error("Time report error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Laden des Zeitberichts"
    });
  }
});

const time_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: time_get
});

const createTaskSchema$1 = z.object({
  title: z.string().min(1, "Titel ist erforderlich"),
  description: z.string().optional(),
  typeId: z.string().optional(),
  priorityId: z.string().optional(),
  statusId: z.string().optional(),
  projectId: z.string(),
  assigneeId: z.string().optional(),
  dueDate: z.string().optional(),
  estimatedHours: z.number().positive().optional(),
  remainingHours: z.number().positive().optional()
});
const updateTaskSchema = createTaskSchema$1.partial().omit({ projectId: true });
const _taskId_ = defineEventHandler(async (event) => {
  const method = getMethod(event);
  try {
    const user = await requireAuth()(event);
    const taskId = getRouterParam(event, "taskId");
    if (method === "GET") {
      const task = await prisma$c.task.findUnique({
        where: { id: taskId },
        include: {
          project: {
            select: {
              id: true,
              name: true,
              key: true,
              customer: {
                select: {
                  id: true,
                  companyName: true
                }
              }
            }
          },
          assignee: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              avatar: true
            }
          },
          creator: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              avatar: true
            }
          },
          type: {
            select: {
              id: true,
              key: true,
              label: true,
              color: true,
              icon: true
            }
          },
          priority: {
            select: {
              id: true,
              key: true,
              label: true,
              color: true,
              icon: true
            }
          },
          status: {
            select: {
              id: true,
              key: true,
              label: true,
              color: true,
              icon: true
            }
          },
          comments: {
            include: {
              author: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  avatar: true
                }
              }
            },
            orderBy: { createdAt: "desc" }
          },
          attachments: true,
          timeEntries: {
            include: {
              user: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true
                }
              }
            },
            orderBy: { createdAt: "desc" }
          },
          _count: {
            select: {
              comments: true,
              timeEntries: true
            }
          }
        }
      });
      if (!task) {
        throw createError({
          statusCode: 404,
          statusMessage: "Aufgabe nicht gefunden"
        });
      }
      if (user.role !== "ADMINISTRATOR") {
        const isMember = await prisma$c.projectMember.findFirst({
          where: {
            projectId: task.projectId,
            userId: user.id
          }
        });
        if (!isMember) {
          throw createError({
            statusCode: 403,
            statusMessage: "Keine Berechtigung f\xFCr diese Aufgabe"
          });
        }
      }
      return task;
    }
    if (method === "PUT") {
      const body = await readBody(event);
      const validatedData = updateTaskSchema.parse(body);
      const existingTask = await prisma$c.task.findUnique({
        where: { id: taskId },
        include: { project: true }
      });
      if (!existingTask) {
        throw createError({
          statusCode: 404,
          statusMessage: "Aufgabe nicht gefunden"
        });
      }
      if (user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER") {
        const isMember = await prisma$c.projectMember.findFirst({
          where: {
            projectId: existingTask.projectId,
            userId: user.id
          }
        });
        if (!isMember) {
          throw createError({
            statusCode: 403,
            statusMessage: "Keine Berechtigung zum Bearbeiten dieser Aufgabe"
          });
        }
      }
      try {
        const updatedTask = await prisma$c.task.update({
          where: { id: taskId },
          data: {
            ...validatedData,
            dueDate: validatedData.dueDate ? new Date(validatedData.dueDate) : void 0,
            updatedAt: /* @__PURE__ */ new Date()
          },
          include: {
            project: {
              select: {
                id: true,
                name: true,
                key: true,
                customer: {
                  select: {
                    id: true,
                    companyName: true
                  }
                }
              }
            },
            assignee: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                avatar: true
              }
            },
            creator: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                avatar: true
              }
            },
            type: {
              select: {
                id: true,
                key: true,
                label: true,
                color: true,
                icon: true
              }
            },
            priority: {
              select: {
                id: true,
                key: true,
                label: true,
                color: true,
                icon: true
              }
            },
            status: {
              select: {
                id: true,
                key: true,
                label: true,
                color: true,
                icon: true
              }
            },
            _count: {
              select: {
                comments: true,
                timeEntries: true,
                attachments: true
              }
            }
          }
        });
        await prisma$c.activityLog.create({
          data: {
            action: "TASK_UPDATED",
            description: `Aufgabe "${updatedTask.title}" wurde aktualisiert`,
            userId: user.id,
            projectId: updatedTask.projectId,
            taskId: updatedTask.id
          }
        });
        return updatedTask;
      } catch (dbError) {
        console.error("Database update error:", dbError.message);
        throw createError({
          statusCode: 500,
          statusMessage: "Fehler beim Aktualisieren der Aufgabe"
        });
      }
    }
    if (method === "DELETE") {
      const existingTask = await prisma$c.task.findUnique({
        where: { id: taskId }
      });
      if (!existingTask) {
        throw createError({
          statusCode: 404,
          statusMessage: "Aufgabe nicht gefunden"
        });
      }
      if (user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER") {
        throw createError({
          statusCode: 403,
          statusMessage: "Keine Berechtigung zum L\xF6schen von Aufgaben"
        });
      }
      await prisma$c.task.delete({
        where: { id: taskId }
      });
      await prisma$c.activityLog.create({
        data: {
          action: "TASK_DELETED",
          description: `Aufgabe "${existingTask.title}" wurde gel\xF6scht`,
          userId: user.id,
          projectId: existingTask.projectId
        }
      });
      return { message: "Aufgabe erfolgreich gel\xF6scht" };
    }
    throw createError({
      statusCode: 405,
      statusMessage: "Methode nicht erlaubt"
    });
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("Task API Error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Server-Fehler"
    });
  }
});

const _taskId_$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: _taskId_
});

const prisma$3 = new PrismaClient();
const _attachmentId_ = defineEventHandler(async (event) => {
  const method = getMethod(event);
  const taskId = getRouterParam(event, "taskId");
  const attachmentId = getRouterParam(event, "attachmentId");
  if (!taskId || !attachmentId) {
    throw createError({
      statusCode: 400,
      statusMessage: "Task-ID und Attachment-ID sind erforderlich"
    });
  }
  const user = await requireAuth()(event);
  if (!user) {
    throw createError({
      statusCode: 401,
      statusMessage: "Authentifizierung erforderlich"
    });
  }
  try {
    const attachment = await prisma$3.taskAttachment.findFirst({
      where: {
        id: attachmentId,
        taskId
      }
    });
    if (!attachment) {
      throw createError({
        statusCode: 404,
        statusMessage: "Anhang nicht gefunden"
      });
    }
    switch (method) {
      case "GET":
        return await downloadAttachment(event, attachment);
      case "DELETE":
        return await deleteAttachment(attachment, user.id);
      default:
        throw createError({
          statusCode: 405,
          statusMessage: "Method not allowed"
        });
    }
  } catch (error) {
    console.error("Fehler bei Anhang-Operation:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Interner Serverfehler"
    });
  }
});
async function downloadAttachment(event, attachment) {
  try {
    await fs.access(attachment.path);
    setHeader(event, "Content-Type", attachment.mimeType);
    setHeader(event, "Content-Disposition", `attachment; filename="${encodeURIComponent(attachment.originalName)}"`);
    setHeader(event, "Content-Length", attachment.size.toString());
    return sendStream(event, createReadStream(attachment.path));
  } catch (error) {
    throw createError({
      statusCode: 404,
      statusMessage: "Datei nicht gefunden"
    });
  }
}
async function deleteAttachment(attachment, userId) {
  try {
    try {
      await fs.unlink(attachment.path);
    } catch (error) {
      console.warn("Datei konnte nicht aus Dateisystem gel\xF6scht werden:", error);
    }
    await prisma$3.taskAttachment.delete({
      where: { id: attachment.id }
    });
    await prisma$3.activityLog.create({
      data: {
        action: "ATTACHMENT_DELETED",
        description: `Datei "${attachment.originalName}" wurde gel\xF6scht`,
        userId,
        taskId: attachment.taskId
      }
    });
    return { success: true, message: "Anhang erfolgreich gel\xF6scht" };
  } catch (error) {
    console.error("Fehler beim L\xF6schen des Anhangs:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim L\xF6schen des Anhangs"
    });
  }
}

const _attachmentId_$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: _attachmentId_
});

const prisma$2 = new PrismaClient();
const ALLOWED_MIME_TYPES = [
  "image/jpeg",
  "image/png",
  "image/gif",
  "image/webp",
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "text/plain",
  "text/csv",
  "application/zip",
  "application/x-rar-compressed"
];
const MAX_FILE_SIZE = 10 * 1024 * 1024;
const UPLOAD_DIR = path.join(process.cwd(), "uploads", "tasks");
async function ensureUploadDir() {
  try {
    await fs.access(UPLOAD_DIR);
  } catch {
    await fs.mkdir(UPLOAD_DIR, { recursive: true });
  }
}
const attachments = defineEventHandler(async (event) => {
  const method = getMethod(event);
  const taskId = getRouterParam(event, "taskId");
  if (!taskId) {
    throw createError({
      statusCode: 400,
      statusMessage: "Task-ID ist erforderlich"
    });
  }
  const user = await requireAuth()(event);
  try {
    const task = await prisma$2.task.findUnique({
      where: {
        id: taskId
      }
    });
    if (!task) {
      throw createError({
        statusCode: 404,
        statusMessage: "Task nicht gefunden"
      });
    }
    switch (method) {
      case "GET":
        return await getAttachments(taskId);
      case "POST":
        return await uploadAttachment(event, taskId, user.id);
      default:
        throw createError({
          statusCode: 405,
          statusMessage: "Method not allowed"
        });
    }
  } catch (error) {
    console.error("Fehler bei Anhang-Operation:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Interner Serverfehler"
    });
  }
});
async function getAttachments(taskId) {
  const attachments = await prisma$2.taskAttachment.findMany({
    where: { taskId },
    orderBy: { createdAt: "desc" }
  });
  return attachments;
}
async function uploadAttachment(event, taskId, userId) {
  await ensureUploadDir();
  const form = new IncomingForm({
    uploadDir: UPLOAD_DIR,
    keepExtensions: true,
    maxFileSize: MAX_FILE_SIZE,
    filter: ({ mimetype }) => {
      return ALLOWED_MIME_TYPES.includes(mimetype || "");
    }
  });
  return new Promise((resolve, reject) => {
    form.parse(event.node.req, async (err, fields, files) => {
      if (err) {
        reject(createError({
          statusCode: 400,
          statusMessage: `Upload-Fehler: ${err.message}`
        }));
        return;
      }
      const file = Array.isArray(files.file) ? files.file[0] : files.file;
      if (!file) {
        reject(createError({
          statusCode: 400,
          statusMessage: "Keine Datei hochgeladen"
        }));
        return;
      }
      try {
        const timestamp = Date.now();
        const randomSuffix = Math.random().toString(36).substring(2, 8);
        const extension = path.extname(file.originalFilename || "");
        const filename = `${timestamp}_${randomSuffix}${extension}`;
        const filePath = path.join(UPLOAD_DIR, filename);
        await fs.rename(file.filepath, filePath);
        const attachment = await prisma$2.taskAttachment.create({
          data: {
            filename,
            originalName: file.originalFilename || filename,
            mimeType: file.mimetype || "application/octet-stream",
            size: file.size || 0,
            path: filePath,
            taskId
          }
        });
        await prisma$2.activityLog.create({
          data: {
            action: "ATTACHMENT_ADDED",
            description: `Datei "${attachment.originalName}" wurde hinzugef\xFCgt`,
            userId,
            taskId
          }
        });
        resolve(attachment);
      } catch (dbError) {
        console.error("Datenbank-Fehler:", dbError);
        reject(createError({
          statusCode: 500,
          statusMessage: "Fehler beim Speichern der Datei"
        }));
      }
    });
  });
}

const attachments$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: attachments
});

const createCommentSchema = z.object({
  content: z.string().min(1, "Kommentar darf nicht leer sein"),
  isInternal: z.boolean().default(false)
});
const comments = defineEventHandler(async (event) => {
  const method = getMethod(event);
  try {
    const user = await requireAuth()(event);
    const taskId = getRouterParam(event, "taskId");
    if (!taskId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Task-ID ist erforderlich"
      });
    }
    const task = await prisma$c.task.findUnique({
      where: { id: taskId },
      include: { project: true }
    });
    if (!task) {
      throw createError({
        statusCode: 404,
        statusMessage: "Aufgabe nicht gefunden"
      });
    }
    if (user.role !== "ADMINISTRATOR") {
      const isMember = await prisma$c.projectMember.findFirst({
        where: {
          projectId: task.projectId,
          userId: user.id
        }
      });
      if (!isMember) {
        throw createError({
          statusCode: 403,
          statusMessage: "Keine Berechtigung f\xFCr diese Aufgabe"
        });
      }
    }
    if (method === "GET") {
      const comments = await prisma$c.taskComment.findMany({
        where: { taskId },
        include: {
          author: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              avatar: true
            }
          }
        },
        orderBy: { createdAt: "asc" }
      });
      return comments;
    }
    if (method === "POST") {
      const body = await readBody(event);
      const validatedData = createCommentSchema.parse(body);
      const newComment = await prisma$c.taskComment.create({
        data: {
          content: validatedData.content,
          isInternal: validatedData.isInternal,
          taskId,
          authorId: user.id
        },
        include: {
          author: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              avatar: true
            }
          }
        }
      });
      await prisma$c.activityLog.create({
        data: {
          action: "COMMENT_ADDED",
          description: `Kommentar zu Aufgabe "${task.title}" hinzugef\xFCgt`,
          userId: user.id,
          projectId: task.projectId,
          taskId: task.id
        }
      });
      return newComment;
    }
    throw createError({
      statusCode: 405,
      statusMessage: "Methode nicht erlaubt"
    });
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("Task Comments API Error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Server-Fehler"
    });
  }
});

const comments$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: comments
});

const createTaskSchema = z.object({
  title: z.string().min(1, "Titel ist erforderlich"),
  description: z.string().optional(),
  typeId: z.string().optional(),
  priorityId: z.string().optional(),
  statusId: z.string().optional(),
  projectId: z.string(),
  assigneeId: z.string().optional(),
  dueDate: z.string().optional(),
  estimatedHours: z.number().positive().optional(),
  remainingHours: z.number().positive().optional()
});
const index$4 = defineEventHandler(async (event) => {
  const method = getMethod(event);
  try {
    const user = await requireAuth()(event);
    if (method === "GET") {
      const query = getQuery$1(event);
      const {
        projectId,
        assigneeId,
        statusId,
        typeId,
        priorityId,
        search,
        page = "1",
        limit = "20",
        sortBy = "createdAt",
        sortOrder = "desc"
      } = query;
      const where = {};
      if (projectId) {
        where.projectId = projectId;
      }
      if (assigneeId) {
        where.assigneeId = assigneeId;
      }
      if (statusId) {
        const statusArray = Array.isArray(statusId) ? statusId : [statusId];
        where.statusId = {
          in: statusArray
        };
      }
      if (typeId) {
        where.typeId = typeId;
      }
      if (priorityId) {
        where.priorityId = priorityId;
      }
      if (search) {
        where.OR = [
          { title: { contains: search, mode: "insensitive" } },
          { description: { contains: search, mode: "insensitive" } },
          { key: { contains: search, mode: "insensitive" } }
        ];
      }
      if (user.role !== "ADMINISTRATOR") {
        const userProjects = await prisma$c.projectMember.findMany({
          where: { userId: user.id },
          select: { projectId: true }
        });
        const projectIds = userProjects.map((pm) => pm.projectId);
        if (projectIds.length === 0) {
          return {
            tasks: [],
            total: 0,
            page: parseInt(page),
            totalPages: 0
          };
        }
        where.projectId = {
          in: projectIds
        };
      }
      const pageNum = parseInt(page);
      const limitNum = parseInt(limit);
      const skip = (pageNum - 1) * limitNum;
      const [tasks, total] = await Promise.all([
        prisma$c.task.findMany({
          where,
          include: {
            project: {
              select: {
                id: true,
                name: true,
                key: true,
                customer: {
                  select: {
                    id: true,
                    companyName: true
                  }
                }
              }
            },
            assignee: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                avatar: true
              }
            },
            creator: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true
              }
            },
            type: {
              select: {
                id: true,
                key: true,
                label: true,
                color: true,
                icon: true
              }
            },
            priority: {
              select: {
                id: true,
                key: true,
                label: true,
                color: true,
                icon: true
              }
            },
            status: {
              select: {
                id: true,
                key: true,
                label: true,
                color: true,
                icon: true
              }
            },
            _count: {
              select: {
                comments: true,
                timeEntries: true,
                attachments: true
              }
            }
          },
          orderBy: {
            [sortBy]: sortOrder
          },
          skip,
          take: limitNum
        }),
        prisma$c.task.count({ where })
      ]);
      const totalPages = Math.ceil(total / limitNum);
      return {
        tasks,
        total,
        page: pageNum,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrev: pageNum > 1
      };
    }
    if (method === "POST") {
      const body = await readBody(event);
      const validatedData = createTaskSchema.parse(body);
      const project = await prisma$c.project.findUnique({
        where: { id: validatedData.projectId }
      });
      if (!project) {
        throw createError({
          statusCode: 404,
          statusMessage: "Projekt nicht gefunden"
        });
      }
      if (user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER") {
        const isMember = await prisma$c.projectMember.findFirst({
          where: {
            projectId: validatedData.projectId,
            userId: user.id
          }
        });
        if (!isMember) {
          throw createError({
            statusCode: 403,
            statusMessage: "Keine Berechtigung Tasks in diesem Projekt zu erstellen"
          });
        }
      }
      const taskCount = await prisma$c.task.count({
        where: { projectId: validatedData.projectId }
      });
      const taskKey = `${project.key}-${(taskCount + 1).toString().padStart(3, "0")}`;
      const newTask = await prisma$c.task.create({
        data: {
          key: taskKey,
          title: validatedData.title,
          description: validatedData.description,
          typeId: validatedData.typeId,
          priorityId: validatedData.priorityId,
          statusId: validatedData.statusId,
          projectId: validatedData.projectId,
          assigneeId: validatedData.assigneeId,
          creatorId: user.id,
          dueDate: validatedData.dueDate ? new Date(validatedData.dueDate) : null,
          estimatedHours: validatedData.estimatedHours,
          remainingHours: validatedData.remainingHours || validatedData.estimatedHours
        },
        include: {
          project: {
            select: {
              id: true,
              name: true,
              key: true
            }
          },
          assignee: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true
            }
          },
          creator: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true
            }
          }
        }
      });
      await prisma$c.activityLog.create({
        data: {
          action: "TASK_CREATED",
          description: `Aufgabe "${newTask.title}" wurde erstellt`,
          userId: user.id,
          projectId: newTask.projectId,
          taskId: newTask.id
        }
      });
      return newTask;
    }
    throw createError({
      statusCode: 405,
      statusMessage: "Methode nicht erlaubt"
    });
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("Tasks API Error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Server-Fehler"
    });
  }
});

const index$5 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index$4
});

const _ticketId__delete = defineEventHandler(async (event) => {
  var _a;
  try {
    const decoded = await requireAuth()(event);
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: "Authentifizierung erforderlich"
      });
    }
    const ticketId = getRouterParam(event, "ticketId");
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Ticket-ID ist erforderlich"
      });
    }
    const user = await prisma$c.user.findUnique({
      where: { id: decoded.id }
    });
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Benutzer nicht gefunden"
      });
    }
    if (!["ADMINISTRATOR", "PROJEKTLEITER"].includes(user.role)) {
      throw createError({
        statusCode: 403,
        statusMessage: "Keine Berechtigung zum L\xF6schen von Tickets"
      });
    }
    const existingTicket = await prisma$c.ticket.findUnique({
      where: { id: ticketId },
      include: {
        comments: true,
        status: true
      }
    });
    if (!existingTicket) {
      throw createError({
        statusCode: 404,
        statusMessage: "Ticket nicht gefunden"
      });
    }
    if (existingTicket.statusId && ((_a = existingTicket.status) == null ? void 0 : _a.key) === "GESCHLOSSEN") {
      console.warn(`Attempt to delete closed ticket ${ticketId} by user ${user.id}`);
    }
    await prisma$c.ticket.delete({
      where: { id: ticketId }
    });
    return {
      success: true,
      message: "Ticket erfolgreich gel\xF6scht"
    };
  } catch (error) {
    console.error("Fehler beim L\xF6schen des Tickets:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Serverfehler beim L\xF6schen des Tickets"
    });
  }
});

const _ticketId__delete$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: _ticketId__delete
});

const _ticketId__get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g;
  try {
    const decoded = await requireAuth()(event);
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: "Authentifizierung erforderlich"
      });
    }
    const ticketId = getRouterParam(event, "ticketId");
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Ticket-ID ist erforderlich"
      });
    }
    const user = await prisma$c.user.findUnique({
      where: { id: decoded.id }
    });
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Benutzer nicht gefunden"
      });
    }
    const ticket = await prisma$c.ticket.findUnique({
      where: { id: ticketId },
      include: {
        customer: {
          select: {
            id: true,
            companyName: true,
            contactName: true,
            email: true,
            phone: true,
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true
              }
            }
          }
        },
        status: {
          select: {
            id: true,
            key: true,
            label: true,
            color: true,
            icon: true
          }
        },
        priority: {
          select: {
            id: true,
            key: true,
            label: true,
            color: true,
            icon: true
          }
        },
        type: {
          select: {
            id: true,
            key: true,
            label: true,
            color: true,
            icon: true
          }
        },
        comments: {
          include: {
            author: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                role: true
              }
            }
          },
          orderBy: {
            createdAt: "asc"
          }
        }
      }
    });
    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: "Ticket nicht gefunden"
      });
    }
    const isCustomer = user.role === "KUNDE";
    const isInternalStaff = ["ADMINISTRATOR", "PROJEKTLEITER", "ENTWICKLER"].includes(user.role);
    if (isCustomer) {
      if (ticket.customerId !== user.id) {
        const customerBelongsToUser = ((_a = ticket.customer.user) == null ? void 0 : _a.id) === user.id;
        if (!customerBelongsToUser) {
          throw createError({
            statusCode: 403,
            statusMessage: "Keine Berechtigung f\xFCr dieses Ticket"
          });
        }
      }
      const filteredComments = ticket.comments.filter((comment) => !comment.isInternal);
      return {
        success: true,
        data: {
          ...ticket,
          status: ((_b = ticket.status) == null ? void 0 : _b.key) || "UNKNOWN",
          priority: ((_c = ticket.priority) == null ? void 0 : _c.key) || "MEDIUM",
          type: ((_d = ticket.type) == null ? void 0 : _d.key) || "GENERAL",
          comments: filteredComments
        }
      };
    } else if (!isInternalStaff) {
      throw createError({
        statusCode: 403,
        statusMessage: "Keine Berechtigung f\xFCr Ticket-Verwaltung"
      });
    }
    return {
      success: true,
      data: {
        ...ticket,
        status: ((_e = ticket.status) == null ? void 0 : _e.key) || "UNKNOWN",
        priority: ((_f = ticket.priority) == null ? void 0 : _f.key) || "MEDIUM",
        type: ((_g = ticket.type) == null ? void 0 : _g.key) || "GENERAL"
      }
    };
  } catch (error) {
    console.error("Fehler beim Laden des Tickets:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Serverfehler beim Laden des Tickets"
    });
  }
});

const _ticketId__get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: _ticketId__get
});

const updateTicketSchema = z.object({
  title: z.string().min(1).max(255).optional(),
  description: z.string().optional(),
  statusId: z.string().optional(),
  priorityId: z.string().optional(),
  department: z.string().optional(),
  resolution: z.string().optional().nullable()
});
const _ticketId__put = defineEventHandler(async (event) => {
  try {
    const decoded = await requireAuth()(event);
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: "Authentifizierung erforderlich"
      });
    }
    const ticketId = getRouterParam(event, "ticketId");
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Ticket-ID ist erforderlich"
      });
    }
    const user = await prisma$c.user.findUnique({
      where: { id: decoded.id }
    });
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Benutzer nicht gefunden"
      });
    }
    if (!["ADMINISTRATOR", "PROJEKTLEITER", "ENTWICKLER"].includes(user.role)) {
      throw createError({
        statusCode: 403,
        statusMessage: "Keine Berechtigung f\xFCr Ticket-Bearbeitung"
      });
    }
    const existingTicket = await prisma$c.ticket.findUnique({
      where: { id: ticketId }
    });
    if (!existingTicket) {
      throw createError({
        statusCode: 404,
        statusMessage: "Ticket nicht gefunden"
      });
    }
    const body = await readBody(event);
    const validatedData = updateTicketSchema.parse(body);
    const updatedTicket = await prisma$c.ticket.update({
      where: { id: ticketId },
      data: {
        ...validatedData,
        updatedAt: /* @__PURE__ */ new Date()
      },
      include: {
        customer: {
          select: {
            id: true,
            companyName: true,
            contactName: true,
            email: true,
            phone: true,
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true
              }
            }
          }
        }
      }
    });
    return {
      success: true,
      message: "Ticket erfolgreich aktualisiert",
      data: updatedTicket
    };
  } catch (error) {
    console.error("Fehler beim Aktualisieren des Tickets:", error);
    if (error.statusCode) {
      throw error;
    }
    if (error.name === "ZodError") {
      throw createError({
        statusCode: 400,
        statusMessage: "Ung\xFCltige Eingabedaten",
        data: error.errors
      });
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Serverfehler beim Aktualisieren des Tickets"
    });
  }
});

const _ticketId__put$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: _ticketId__put
});

const prisma$1 = new PrismaClient();
const comments_get = defineEventHandler(async (event) => {
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Unauthorized"
      });
    }
    const ticketId = getRouterParam(event, "ticketId");
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Ticket ID is required"
      });
    }
    const currentUser = await prisma$1.user.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        role: true
      }
    });
    if (!currentUser) {
      throw createError({
        statusCode: 401,
        statusMessage: "User not found"
      });
    }
    if (user.role === "KUNDE") {
      throw createError({
        statusCode: 403,
        statusMessage: "Access denied"
      });
    }
    const ticket = await prisma$1.ticket.findUnique({
      where: { id: ticketId },
      select: {
        id: true
      }
    });
    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: "Ticket not found"
      });
    }
    const comments = await prisma$1.ticketComment.findMany({
      where: {
        ticketId
      },
      include: {
        author: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            role: true
          }
        }
      },
      orderBy: {
        createdAt: "asc"
      }
    });
    return comments;
  } catch (error) {
    console.error("Error fetching ticket comments:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error"
    });
  }
});

const comments_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: comments_get
});

const prisma = new PrismaClient();
const commentSchema = z.object({
  content: z.string().min(1, "Comment content is required").max(2e3, "Comment too long"),
  isInternal: z.boolean().optional().default(false),
  updateStatusId: z.string().optional()
});
const comments_post = defineEventHandler(async (event) => {
  var _a;
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Unauthorized"
      });
    }
    const ticketId = getRouterParam(event, "ticketId");
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Ticket ID is required"
      });
    }
    const body = await readBody(event);
    const validatedData = commentSchema.parse(body);
    const currentUser = await prisma.user.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        role: true,
        firstName: true,
        lastName: true
      }
    });
    if (!currentUser) {
      throw createError({
        statusCode: 401,
        statusMessage: "User not found"
      });
    }
    if (user.role === "KUNDE") {
      throw createError({
        statusCode: 403,
        statusMessage: "Access denied"
      });
    }
    const ticket = await prisma.ticket.findUnique({
      where: { id: ticketId },
      include: {
        status: true
      }
    });
    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: "Ticket not found"
      });
    }
    const comment = await prisma.ticketComment.create({
      data: {
        content: validatedData.content,
        isInternal: validatedData.isInternal,
        ticketId,
        authorId: user.id
      },
      include: {
        author: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            role: true
          }
        }
      }
    });
    let statusUpdated = false;
    if (validatedData.updateStatusId) {
      await prisma.ticket.update({
        where: { id: ticketId },
        data: {
          statusId: validatedData.updateStatusId,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      statusUpdated = true;
    } else if (((_a = ticket.status) == null ? void 0 : _a.key) === "OFFEN" && !validatedData.isInternal) {
      const inProgressStatus = await prisma.enumValue.findFirst({
        where: {
          category: { name: "ticket_status" },
          key: "IN_BEARBEITUNG"
        }
      });
      if (inProgressStatus) {
        await prisma.ticket.update({
          where: { id: ticketId },
          data: {
            statusId: inProgressStatus.id,
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
        statusUpdated = true;
      }
    }
    await prisma.activityLog.create({
      data: {
        action: "TICKET_COMMENT_CREATED",
        description: `Comment added to ticket ${ticketId}`,
        userId: user.id,
        details: {
          ticketId,
          commentId: comment.id,
          isInternal: validatedData.isInternal
        }
      }
    });
    return {
      success: true,
      message: statusUpdated ? "Comment added and status updated successfully" : "Comment added successfully",
      comment,
      statusUpdated
    };
  } catch (error) {
    console.error("Error creating ticket comment:", error);
    if (error.statusCode) {
      throw error;
    }
    if (error.name === "ZodError") {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid input data",
        data: error.errors
      });
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error"
    });
  }
});

const comments_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: comments_post
});

const conversionSchema = z.object({
  ticketId: z.string().min(1, "Ticket-ID ist erforderlich"),
  projectId: z.string().min(1, "Projekt ist erforderlich"),
  assigneeId: z.string().optional(),
  priorityId: z.string().optional(),
  estimatedHours: z.number().min(0).optional(),
  internalNotes: z.string().optional()
});
const convertToTask_post = defineEventHandler(async (event) => {
  try {
    assertMethod(event, "POST");
    const body = await readBody(event);
    const validatedData = conversionSchema.parse(body);
    const decoded = await requireAuth()(event);
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: "Authentifizierung erforderlich"
      });
    }
    const user = await prisma$c.user.findUnique({
      where: { id: decoded.id }
    });
    if (!user || !["ADMIN", "PROJEKTLEITER", "ENTWICKLER"].includes(user.role)) {
      throw createError({
        statusCode: 403,
        statusMessage: "Keine Berechtigung f\xFCr Ticket-Konvertierung"
      });
    }
    const ticket = await prisma$c.ticket.findUnique({
      where: { id: validatedData.ticketId },
      include: {
        customer: {
          include: {
            projects: true
          }
        },
        priority: true
      }
    });
    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: "Ticket nicht gefunden"
      });
    }
    const existingTask = await prisma$c.task.findFirst({
      where: {
        description: {
          contains: `Ticket #${ticket.id}`
        }
      }
    });
    if (existingTask) {
      throw createError({
        statusCode: 400,
        statusMessage: "Ticket wurde bereits in einen Task konvertiert"
      });
    }
    const project = await prisma$c.project.findUnique({
      where: { id: validatedData.projectId },
      include: {
        members: {
          where: { userId: decoded.id }
        }
      }
    });
    if (!project) {
      throw createError({
        statusCode: 404,
        statusMessage: "Projekt nicht gefunden"
      });
    }
    if (user.role !== "ADMINISTRATOR" && project.members.length === 0) {
      throw createError({
        statusCode: 403,
        statusMessage: "Keine Berechtigung f\xFCr dieses Projekt"
      });
    }
    const taskCount = await prisma$c.task.count({
      where: { projectId: validatedData.projectId }
    });
    const taskKey = `${project.key}-${(taskCount + 1).toString().padStart(3, "0")}`;
    const taskDescription = `**Kundenanfrage von Ticket #${ticket.id}**

**Kunde:** ${ticket.customer.companyName}
**Abteilung:** ${ticket.department}
**Urspr\xFCngliche Beschreibung:**
${ticket.description}

${validatedData.internalNotes ? `**Interne Notizen:**
${validatedData.internalNotes}` : ""}

---
*Automatisch konvertiert von Ticket #${ticket.id} am ${(/* @__PURE__ */ new Date()).toLocaleDateString("de-DE")}*`;
    const result = await prisma$c.$transaction(async (tx) => {
      var _a;
      const taskTypeEnum = await tx.enumValue.findFirst({
        where: {
          category: { name: "task_type" },
          key: "AUFGABE"
        }
      });
      const taskStatusEnum = await tx.enumValue.findFirst({
        where: {
          category: { name: "task_status" },
          key: "GEPLANT"
        }
      });
      const newTask = await tx.task.create({
        data: {
          key: taskKey,
          title: `[Kunde] ${ticket.title}`,
          description: taskDescription,
          typeId: taskTypeEnum == null ? void 0 : taskTypeEnum.id,
          priorityId: validatedData.priorityId || ticket.priorityId,
          statusId: taskStatusEnum == null ? void 0 : taskStatusEnum.id,
          estimatedHours: validatedData.estimatedHours,
          projectId: validatedData.projectId,
          assigneeId: validatedData.assigneeId,
          creatorId: decoded.id
        }
      });
      const ticketInProgressStatus = await tx.enumValue.findFirst({
        where: {
          category: { name: "ticket_status" },
          key: "IN_BEARBEITUNG"
        }
      });
      const updatedTicket = await tx.ticket.update({
        where: { id: ticket.id },
        data: {
          statusId: ticketInProgressStatus == null ? void 0 : ticketInProgressStatus.id,
          resolution: `Konvertiert zu Task ${taskKey}`
        }
      });
      await tx.activityLog.createMany({
        data: [
          {
            action: "TICKET_CONVERTED_TO_TASK",
            description: `Ticket "${ticket.title}" wurde zu Task ${taskKey} konvertiert`,
            userId: decoded.id,
            projectId: validatedData.projectId,
            taskId: newTask.id,
            details: {
              ticketId: ticket.id,
              ticketTitle: ticket.title,
              customerName: ticket.customer.companyName,
              department: ticket.department,
              originalPriority: ((_a = ticket.priority) == null ? void 0 : _a.label) || "Unbekannt",
              newTaskKey: taskKey
            }
          },
          {
            action: "TASK_CREATED_FROM_TICKET",
            description: `Task ${taskKey} wurde aus Ticket #${ticket.id} erstellt`,
            userId: decoded.id,
            projectId: validatedData.projectId,
            taskId: newTask.id,
            details: {
              ticketId: ticket.id,
              customerName: ticket.customer.companyName,
              conversionUser: user.email
            }
          }
        ]
      });
      return { task: newTask, ticket: updatedTicket };
    });
    return {
      success: true,
      message: `Ticket wurde erfolgreich zu Task ${taskKey} konvertiert`,
      task: result.task,
      ticket: result.ticket
    };
  } catch (error) {
    console.error("Ticket conversion error:", error);
    if (error.statusCode) {
      throw error;
    }
    if (error.name === "ZodError") {
      throw createError({
        statusCode: 400,
        statusMessage: `Validierungsfehler: ${error.errors.map((e) => e.message).join(", ")}`
      });
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler bei der Ticket-Konvertierung"
    });
  }
});

const convertToTask_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: convertToTask_post
});

const index_get = defineEventHandler(async (event) => {
  try {
    const decoded = await requireAuth()(event);
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: "Authentifizierung erforderlich"
      });
    }
    const user = await prisma$c.user.findUnique({
      where: { id: decoded.id }
    });
    if (!user || !["ADMINISTRATOR", "PROJEKTLEITER", "ENTWICKLER"].includes(user.role)) {
      throw createError({
        statusCode: 403,
        statusMessage: "Keine Berechtigung f\xFCr Ticket-Verwaltung"
      });
    }
    const query = getQuery$1(event);
    const page = parseInt(query.page) || 1;
    const limit = parseInt(query.limit) || 20;
    const search = query.search;
    const status = query.status;
    const department = query.department;
    const priority = query.priority;
    const where = {};
    if (search) {
      where.OR = [
        { title: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
        { customer: { companyName: { contains: search, mode: "insensitive" } } }
      ];
    }
    if (status) {
      where.status = {
        key: status
      };
    }
    if (department) {
      where.department = department;
    }
    if (priority) {
      where.priority = {
        key: priority
      };
    }
    const [tickets, total] = await Promise.all([
      prisma$c.ticket.findMany({
        where,
        include: {
          customer: {
            select: {
              id: true,
              companyName: true,
              contactName: true,
              email: true
            }
          },
          status: {
            select: {
              id: true,
              key: true,
              label: true,
              color: true,
              icon: true
            }
          },
          priority: {
            select: {
              id: true,
              key: true,
              label: true,
              color: true,
              icon: true
            }
          },
          type: {
            select: {
              id: true,
              key: true,
              label: true,
              color: true,
              icon: true
            }
          }
        },
        orderBy: {
          createdAt: "desc"
        },
        take: limit,
        skip: (page - 1) * limit
      }),
      prisma$c.ticket.count({ where })
    ]);
    const transformedTickets = tickets.map((ticket) => {
      var _a, _b, _c;
      return {
        ...ticket,
        status: ((_a = ticket.status) == null ? void 0 : _a.key) || "UNKNOWN",
        priority: ((_b = ticket.priority) == null ? void 0 : _b.key) || "MEDIUM",
        type: ((_c = ticket.type) == null ? void 0 : _c.key) || "GENERAL"
      };
    });
    const stats = await prisma$c.ticket.groupBy({
      by: ["statusId"],
      _count: {
        statusId: true
      }
    });
    return {
      tickets: transformedTickets,
      stats,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit)
      }
    };
  } catch (error) {
    console.error("Internal tickets error:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Fehler beim Laden der Tickets"
    });
  }
});

const index_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index_get
});

const createTicketSchema = z.object({
  title: z.string().min(1, "Titel ist erforderlich").max(255, "Titel zu lang"),
  description: z.string().min(1, "Beschreibung ist erforderlich"),
  priority: z.enum(["NIEDRIG", "NORMAL", "HOCH", "KRITISCH", "BLOCKER"]).default("NORMAL"),
  department: z.string().default("Allgemein"),
  customerId: z.string().optional()
  // Nur für interne Mitarbeiter
});
const index_post = defineEventHandler(async (event) => {
  try {
    const decoded = await requireAuth()(event);
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: "Authentifizierung erforderlich"
      });
    }
    const user = await prisma$c.user.findUnique({
      where: { id: decoded.id }
    });
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Benutzer nicht gefunden"
      });
    }
    const body = await readBody(event);
    const validatedData = createTicketSchema.parse(body);
    let customerId;
    const isInternalStaff = ["ADMINISTRATOR", "PROJEKTLEITER", "ENTWICKLER"].includes(user.role);
    if (user.role === "KUNDE") {
      const customerRecord = await prisma$c.customer.findFirst({
        where: { userId: user.id }
      });
      if (!customerRecord) {
        throw createError({
          statusCode: 400,
          statusMessage: "Kein Kundeneintrag f\xFCr diesen Benutzer gefunden"
        });
      }
      customerId = customerRecord.id;
    } else if (isInternalStaff) {
      if (validatedData.customerId) {
        const customer = await prisma$c.customer.findUnique({
          where: { id: validatedData.customerId }
        });
        if (!customer) {
          throw createError({
            statusCode: 400,
            statusMessage: "Ung\xFCltiger Kunde"
          });
        }
        customerId = validatedData.customerId;
      } else {
        const customerRecord = await prisma$c.customer.findFirst({
          where: { userId: user.id }
        });
        if (customerRecord) {
          customerId = customerRecord.id;
        } else {
          throw createError({
            statusCode: 400,
            statusMessage: "Kein Kunde angegeben und kein Kundeneintrag f\xFCr Benutzer gefunden"
          });
        }
      }
    } else {
      throw createError({
        statusCode: 403,
        statusMessage: "Keine Berechtigung zum Erstellen von Tickets"
      });
    }
    const defaultPriority = await prisma$c.enumValue.findFirst({
      where: {
        category: { name: "priority" },
        isDefault: true
      }
    });
    const defaultStatus = await prisma$c.enumValue.findFirst({
      where: {
        category: { name: "ticket_status" },
        isDefault: true
      }
    });
    const newTicket = await prisma$c.ticket.create({
      data: {
        title: validatedData.title,
        description: validatedData.description,
        priorityId: defaultPriority == null ? void 0 : defaultPriority.id,
        department: validatedData.department,
        statusId: defaultStatus == null ? void 0 : defaultStatus.id,
        customerId
      },
      include: {
        customer: {
          select: {
            id: true,
            companyName: true,
            contactName: true,
            email: true,
            phone: true,
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true
              }
            }
          }
        }
      }
    });
    return {
      success: true,
      message: "Ticket erfolgreich erstellt",
      data: newTicket
    };
  } catch (error) {
    console.error("Fehler beim Erstellen des Tickets:", error);
    if (error.statusCode) {
      throw error;
    }
    if (error.name === "ZodError") {
      throw createError({
        statusCode: 400,
        statusMessage: "Ung\xFCltige Eingabedaten",
        data: error.errors
      });
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Serverfehler beim Erstellen des Tickets"
    });
  }
});

const index_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index_post
});

const _id_$2 = defineEventHandler(async (event) => {
  if (event.node.req.method === "GET") {
    return await getTimeEntry(event);
  } else if (event.node.req.method === "PUT") {
    return await updateTimeEntry(event);
  } else if (event.node.req.method === "DELETE") {
    return await deleteTimeEntry(event);
  }
});
async function getTimeEntry(event) {
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Nicht authentifiziert"
      });
    }
    const timeEntryId = getRouterParam(event, "id");
    if (!timeEntryId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Zeiteintrag-ID erforderlich"
      });
    }
    const timeEntry = await prisma$c.timeEntry.findFirst({
      where: {
        id: timeEntryId,
        // Users can only access their own time entries unless admin/projektleiter
        ...user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER" ? { userId: user.id } : {}
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      }
    });
    if (!timeEntry) {
      throw createError({
        statusCode: 404,
        statusMessage: "Zeiteintrag nicht gefunden"
      });
    }
    return {
      timeEntry
    };
  } catch (error) {
    console.error("Error fetching time entry:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Fehler beim Laden des Zeiteintrags"
    });
  }
}
async function updateTimeEntry(event) {
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Nicht authentifiziert"
      });
    }
    const timeEntryId = getRouterParam(event, "id");
    if (!timeEntryId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Zeiteintrag-ID erforderlich"
      });
    }
    const existingEntry = await prisma$c.timeEntry.findFirst({
      where: {
        id: timeEntryId,
        // Users can only update their own time entries unless admin/projektleiter
        ...user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER" ? { userId: user.id } : {}
      }
    });
    if (!existingEntry) {
      throw createError({
        statusCode: 404,
        statusMessage: "Zeiteintrag nicht gefunden oder keine Berechtigung"
      });
    }
    const body = await readBody(event);
    const { description, hours, date, category, billable, projectId, taskId } = body;
    if (hours !== void 0 && hours <= 0) {
      throw createError({
        statusCode: 400,
        statusMessage: "Stunden m\xFCssen gr\xF6\xDFer als 0 sein"
      });
    }
    if (projectId && projectId !== existingEntry.projectId) {
      const project = await prisma$c.project.findFirst({
        where: {
          id: projectId
        }
      });
      if (!project) {
        throw createError({
          statusCode: 404,
          statusMessage: "Projekt nicht gefunden"
        });
      }
    }
    if (taskId) {
      const task = await prisma$c.task.findFirst({
        where: {
          id: taskId,
          projectId: projectId || existingEntry.projectId
        }
      });
      if (!task) {
        throw createError({
          statusCode: 400,
          statusMessage: "Aufgabe nicht gefunden oder geh\xF6rt nicht zum Projekt"
        });
      }
    }
    const updateData = {};
    if (description !== void 0) updateData.description = description;
    if (hours !== void 0) updateData.hours = parseFloat(hours);
    if (date !== void 0) updateData.date = new Date(date);
    if (category !== void 0) updateData.category = category;
    if (billable !== void 0) updateData.billable = billable;
    if (projectId !== void 0) updateData.projectId = projectId;
    if (taskId !== void 0) updateData.taskId = taskId;
    const timeEntry = await prisma$c.timeEntry.update({
      where: { id: timeEntryId },
      data: updateData,
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      }
    });
    await prisma$c.activityLog.create({
      data: {
        action: "time_entry_updated",
        description: `Zeiteintrag aktualisiert: ${timeEntry.hours}h f\xFCr ${timeEntry.project.name}`,
        userId: user.id,
        projectId: timeEntry.projectId,
        taskId: timeEntry.taskId
      }
    });
    return {
      timeEntry
    };
  } catch (error) {
    console.error("Error updating time entry:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Fehler beim Aktualisieren des Zeiteintrags"
    });
  }
}
async function deleteTimeEntry(event) {
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Nicht authentifiziert"
      });
    }
    const timeEntryId = getRouterParam(event, "id");
    if (!timeEntryId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Zeiteintrag-ID erforderlich"
      });
    }
    const existingEntry = await prisma$c.timeEntry.findFirst({
      where: {
        id: timeEntryId,
        // Users can only delete their own time entries unless admin/projektleiter
        ...user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER" ? { userId: user.id } : {}
      },
      include: {
        project: {
          select: {
            name: true
          }
        }
      }
    });
    if (!existingEntry) {
      throw createError({
        statusCode: 404,
        statusMessage: "Zeiteintrag nicht gefunden oder keine Berechtigung"
      });
    }
    await prisma$c.timeEntry.delete({
      where: { id: timeEntryId }
    });
    await prisma$c.activityLog.create({
      data: {
        action: "time_entry_deleted",
        description: `Zeiteintrag gel\xF6scht: ${existingEntry.hours}h f\xFCr ${existingEntry.project.name}`,
        userId: user.id,
        projectId: existingEntry.projectId,
        taskId: existingEntry.taskId
      }
    });
    return {
      success: true
    };
  } catch (error) {
    console.error("Error deleting time entry:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Fehler beim L\xF6schen des Zeiteintrags"
    });
  }
}

const _id_$3 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: _id_$2
});

const index$2 = defineEventHandler(async (event) => {
  if (event.node.req.method === "GET") {
    return await getTimeEntries(event);
  } else if (event.node.req.method === "POST") {
    return await createTimeEntry(event);
  }
});
async function getTimeEntries(event) {
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Nicht authentifiziert"
      });
    }
    const query = getQuery$1(event);
    const { startDate, endDate, projectId, userId } = query;
    const whereConditions = {};
    if (user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER") {
      whereConditions.userId = user.id;
    } else if (userId) {
      whereConditions.userId = userId;
    } else {
      whereConditions.userId = user.id;
    }
    if (projectId) {
      whereConditions.projectId = projectId;
    }
    if (startDate || endDate) {
      whereConditions.date = {};
      if (startDate) {
        whereConditions.date.gte = new Date(startDate);
      }
      if (endDate) {
        whereConditions.date.lte = new Date(endDate);
      }
    }
    const timeEntries = await prisma$c.timeEntry.findMany({
      where: whereConditions,
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      },
      orderBy: {
        date: "desc"
      }
    });
    return {
      timeEntries
    };
  } catch (error) {
    console.error("Error fetching time entries:", error);
    throw createError({
      statusCode: 500,
      statusMessage: error.message || "Fehler beim Laden der Zeiteintr\xE4ge"
    });
  }
}
async function createTimeEntry(event) {
  var _a;
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Nicht authentifiziert"
      });
    }
    const body = await readBody(event);
    const { description, hours, date, category, billable, projectId, taskId } = body;
    if (!hours || hours <= 0) {
      throw createError({
        statusCode: 400,
        statusMessage: "Stunden m\xFCssen gr\xF6\xDFer als 0 sein"
      });
    }
    if (!date) {
      throw createError({
        statusCode: 400,
        statusMessage: "Datum ist erforderlich"
      });
    }
    if (!projectId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Projekt ist erforderlich"
      });
    }
    if (!taskId) {
      console.warn("Time entry created without task assignment - consider assigning to a task");
    }
    const project = await prisma$c.project.findFirst({
      where: {
        id: projectId
      }
    });
    if (!project) {
      throw createError({
        statusCode: 404,
        statusMessage: "Projekt nicht gefunden"
      });
    }
    if (taskId) {
      const task = await prisma$c.task.findFirst({
        where: {
          id: taskId,
          projectId
        }
      });
      if (!task) {
        throw createError({
          statusCode: 400,
          statusMessage: "Aufgabe nicht gefunden oder geh\xF6rt nicht zum Projekt"
        });
      }
    }
    const timeEntry = await prisma$c.timeEntry.create({
      data: {
        description: description || "",
        hours: parseFloat(hours),
        date: new Date(date),
        category: category || "Entwicklung",
        billable: billable !== false,
        // Default to true
        userId: user.id,
        projectId,
        taskId: taskId || null
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      }
    });
    await prisma$c.activityLog.create({
      data: {
        action: "time_entry_created",
        description: `Zeiteintrag erstellt: ${hours}h f\xFCr ${project.name}${taskId ? ` (${(_a = timeEntry.task) == null ? void 0 : _a.key})` : ""}`,
        userId: user.id,
        projectId,
        taskId: taskId || null
      }
    });
    return {
      timeEntry
    };
  } catch (error) {
    console.error("Error creating time entry:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Fehler beim Erstellen des Zeiteintrags"
    });
  }
}

const index$3 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index$2
});

const stats_get = defineEventHandler(async (event) => {
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Nicht authentifiziert"
      });
    }
    const query = getQuery$1(event);
    const userId = query.userId || user.id;
    if (user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER" && userId !== user.id) {
      throw createError({
        statusCode: 403,
        statusMessage: "Keine Berechtigung f\xFCr diese Statistiken"
      });
    }
    const today = /* @__PURE__ */ new Date();
    const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const endOfToday = new Date(startOfToday);
    endOfToday.setDate(endOfToday.getDate() + 1);
    const startOfWeek = getStartOfWeek(today);
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 7);
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 1);
    const todayEntries = await prisma$c.timeEntry.findMany({
      where: {
        userId,
        date: {
          gte: startOfToday,
          lt: endOfToday
        }
      }
    });
    const weekEntries = await prisma$c.timeEntry.findMany({
      where: {
        userId,
        date: {
          gte: startOfWeek,
          lt: endOfWeek
        }
      }
    });
    const monthEntries = await prisma$c.timeEntry.findMany({
      where: {
        userId,
        date: {
          gte: startOfMonth,
          lt: endOfMonth
        }
      }
    });
    const projectBreakdown = await prisma$c.timeEntry.groupBy({
      by: ["projectId"],
      where: {
        userId,
        date: {
          gte: startOfMonth,
          lt: endOfMonth
        }
      },
      _sum: {
        hours: true
      }
    });
    const projectIds = projectBreakdown.map((p) => p.projectId);
    const projects = await prisma$c.project.findMany({
      where: {
        id: { in: projectIds }
      },
      select: {
        id: true,
        name: true,
        key: true
      }
    });
    const todayTotal = todayEntries.reduce((sum, entry) => sum + entry.hours, 0);
    const weekTotal = weekEntries.reduce((sum, entry) => sum + entry.hours, 0);
    const monthTotal = monthEntries.reduce((sum, entry) => sum + entry.hours, 0);
    const billableToday = todayEntries.filter((entry) => entry.billable).reduce((sum, entry) => sum + entry.hours, 0);
    const nonBillableToday = todayTotal - billableToday;
    const totalMonthHours = monthTotal;
    const projectBreakdownWithDetails = projectBreakdown.map((breakdown) => {
      const project = projects.find((p) => p.id === breakdown.projectId);
      const hours = breakdown._sum.hours || 0;
      const percentage = totalMonthHours > 0 ? hours / totalMonthHours * 100 : 0;
      return {
        projectId: breakdown.projectId,
        projectName: (project == null ? void 0 : project.name) || "Unbekanntes Projekt",
        projectKey: (project == null ? void 0 : project.key) || "",
        hours: Math.round(hours * 100) / 100,
        percentage: Math.round(percentage * 10) / 10
      };
    }).sort((a, b) => b.hours - a.hours);
    const stats = {
      todayTotal: Math.round(todayTotal * 100) / 100,
      weekTotal: Math.round(weekTotal * 100) / 100,
      monthTotal: Math.round(monthTotal * 100) / 100,
      billableToday: Math.round(billableToday * 100) / 100,
      nonBillableToday: Math.round(nonBillableToday * 100) / 100,
      targetDailyHours: 8,
      // Default 8 hours target - can be made configurable
      projectBreakdown: projectBreakdownWithDetails
    };
    return {
      stats
    };
  } catch (error) {
    console.error("Error fetching time tracking stats:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Fehler beim Laden der Zeiterfassungsstatistiken"
    });
  }
});
function getStartOfWeek(date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(d.setDate(diff));
}

const stats_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: stats_get
});

const updateUserSchema = z.object({
  firstName: z.string().min(1).optional(),
  lastName: z.string().min(1).optional(),
  email: z.string().email().optional(),
  role: z.enum(["ADMINISTRATOR", "PROJEKTLEITER", "ENTWICKLER", "SUPPORTER", "VIEWER", "KUNDE"]).optional(),
  avatar: z.string().url().optional(),
  isActive: z.boolean().optional()
});
const _id_ = defineEventHandler(async (event) => {
  const method = getMethod(event);
  const userId = getRouterParam(event, "id");
  if (!userId) {
    throw createError({
      statusCode: 400,
      statusMessage: "Benutzer-ID ist erforderlich"
    });
  }
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Nicht authentifiziert"
      });
    }
    if (method === "GET") {
      const targetUser = await prisma$c.user.findUnique({
        where: { id: userId },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          avatar: true,
          role: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
          _count: {
            select: {
              assignedTasks: true,
              createdTasks: true,
              timeEntries: true,
              projectMembers: true,
              taskComments: true
            }
          }
        }
      });
      if (!targetUser) {
        throw createError({
          statusCode: 404,
          statusMessage: "Benutzer nicht gefunden"
        });
      }
      if (user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER" && user.id !== userId) {
        throw createError({
          statusCode: 403,
          statusMessage: "Keine Berechtigung"
        });
      }
      return targetUser;
    }
    if (method === "PUT") {
      if (user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER" && user.id !== userId) {
        throw createError({
          statusCode: 403,
          statusMessage: "Keine Berechtigung zum Bearbeiten"
        });
      }
      const body = await readBody(event);
      const validatedData = updateUserSchema.parse(body);
      const existingUser = await prisma$c.user.findUnique({
        where: { id: userId }
      });
      if (!existingUser) {
        throw createError({
          statusCode: 404,
          statusMessage: "Benutzer nicht gefunden"
        });
      }
      if (validatedData.role && user.role !== "ADMINISTRATOR") {
        throw createError({
          statusCode: 403,
          statusMessage: "Keine Berechtigung zum \xC4ndern der Rolle"
        });
      }
      if (validatedData.email && validatedData.email !== existingUser.email) {
        const emailExists = await prisma$c.user.findUnique({
          where: { email: validatedData.email }
        });
        if (emailExists) {
          throw createError({
            statusCode: 400,
            statusMessage: "E-Mail-Adresse bereits vergeben"
          });
        }
      }
      const updatedUser = await prisma$c.user.update({
        where: { id: userId },
        data: {
          ...validatedData,
          updatedAt: /* @__PURE__ */ new Date()
        },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          avatar: true,
          role: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
          _count: {
            select: {
              assignedTasks: true,
              createdTasks: true,
              timeEntries: true,
              projectMembers: true,
              taskComments: true
            }
          }
        }
      });
      await prisma$c.activityLog.create({
        data: {
          action: "USER_UPDATED",
          description: `Benutzer ${updatedUser.firstName} ${updatedUser.lastName} wurde aktualisiert`,
          userId: user.id
        }
      });
      return updatedUser;
    }
    if (method === "DELETE") {
      if (user.role !== "ADMINISTRATOR") {
        throw createError({
          statusCode: 403,
          statusMessage: "Keine Berechtigung zum L\xF6schen"
        });
      }
      const existingUser = await prisma$c.user.findUnique({
        where: { id: userId }
      });
      if (!existingUser) {
        throw createError({
          statusCode: 404,
          statusMessage: "Benutzer nicht gefunden"
        });
      }
      const deactivatedUser = await prisma$c.user.update({
        where: { id: userId },
        data: { isActive: false }
      });
      await prisma$c.activityLog.create({
        data: {
          action: "USER_DEACTIVATED",
          description: `Benutzer ${deactivatedUser.firstName} ${deactivatedUser.lastName} wurde deaktiviert`,
          userId: user.id
        }
      });
      return { message: "Benutzer erfolgreich deaktiviert" };
    }
    throw createError({
      statusCode: 405,
      statusMessage: "Methode nicht erlaubt"
    });
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("User API Error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Server-Fehler"
    });
  }
});

const _id_$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: _id_
});

const createSkillSchema = z.object({
  skills: z.array(z.object({
    name: z.string().min(1, "Skill-Name ist erforderlich"),
    category: z.string().min(1, "Kategorie ist erforderlich"),
    level: z.number().min(1).max(5, "Level muss zwischen 1 und 5 liegen"),
    experience: z.string().optional()
  }))
});
const skills = defineEventHandler(async (event) => {
  const method = getMethod(event);
  const userId = getRouterParam(event, "userId");
  if (!userId) {
    throw createError({
      statusCode: 400,
      statusMessage: "Benutzer-ID ist erforderlich"
    });
  }
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Nicht authentifiziert"
      });
    }
    const targetUser = await prisma$c.user.findUnique({
      where: { id: userId }
    });
    if (!targetUser) {
      throw createError({
        statusCode: 404,
        statusMessage: "Benutzer nicht gefunden"
      });
    }
    if (method === "GET") {
      const skills = await prisma$c.userSkill.findMany({
        where: { userId },
        orderBy: [
          { category: "asc" },
          { name: "asc" }
        ]
      });
      return { skills };
    }
    if (method === "POST") {
      const body = await readBody(event);
      const { skills } = createSkillSchema.parse(body);
      if (user.id !== userId && !["ADMINISTRATOR", "PROJEKTLEITER"].includes(user.role)) {
        throw createError({
          statusCode: 403,
          statusMessage: "Keine Berechtigung zum Bearbeiten von Skills"
        });
      }
      await prisma$c.userSkill.deleteMany({
        where: { userId }
      });
      const createdSkills = await prisma$c.userSkill.createMany({
        data: skills.map((skill) => ({
          userId,
          ...skill
        }))
      });
      const updatedSkills = await prisma$c.userSkill.findMany({
        where: { userId },
        orderBy: [
          { category: "asc" },
          { name: "asc" }
        ]
      });
      await prisma$c.activityLog.create({
        data: {
          action: "USER_SKILL_UPDATE",
          description: `Skills f\xFCr Benutzer ${targetUser.firstName} ${targetUser.lastName} aktualisiert`,
          userId: user.id,
          projectId: null,
          taskId: null,
          details: JSON.stringify({
            targetUserId: userId,
            skillsCount: skills.length,
            categories: [...new Set(skills.map((s) => s.category))]
          })
        }
      });
      return {
        skills: updatedSkills,
        message: `${skills.length} Skills erfolgreich aktualisiert`
      };
    }
    if (method === "DELETE") {
      if (user.id !== userId && !["ADMINISTRATOR", "PROJEKTLEITER"].includes(user.role)) {
        throw createError({
          statusCode: 403,
          statusMessage: "Keine Berechtigung zum L\xF6schen von Skills"
        });
      }
      await prisma$c.userSkill.deleteMany({
        where: { userId }
      });
      await prisma$c.activityLog.create({
        data: {
          action: "USER_SKILL_DELETE",
          description: `Alle Skills f\xFCr Benutzer ${targetUser.firstName} ${targetUser.lastName} gel\xF6scht`,
          userId: user.id,
          projectId: null,
          taskId: null,
          details: JSON.stringify({
            targetUserId: userId
          })
        }
      });
      return {
        message: "Alle Skills erfolgreich gel\xF6scht"
      };
    }
    throw createError({
      statusCode: 405,
      statusMessage: "Methode nicht erlaubt"
    });
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("User Skills API Error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Server-Fehler"
    });
  }
});

const skills$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: skills
});

const bulkActionSchema = z.object({
  action: z.enum(["activate", "deactivate", "change_role", "delete"]),
  userIds: z.array(z.string().cuid()),
  data: z.object({
    role: z.enum(["ADMINISTRATOR", "PROJEKTLEITER", "ENTWICKLER", "SUPPORTER", "VIEWER"]).optional(),
    isActive: z.boolean().optional()
  }).optional()
});
const bulkActions_post = defineEventHandler(async (event) => {
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Nicht authentifiziert"
      });
    }
    if (user.role !== "ADMINISTRATOR") {
      throw createError({
        statusCode: 403,
        statusMessage: "Keine Berechtigung f\xFCr Bulk-Aktionen"
      });
    }
    const body = await readBody(event);
    const { action, userIds, data } = bulkActionSchema.parse(body);
    const existingUsers = await prisma$c.user.findMany({
      where: {
        id: { in: userIds },
        role: { not: "KUNDE" }
        // Keine Kunden bearbeiten
      },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        role: true,
        isActive: true
      }
    });
    if (existingUsers.length !== userIds.length) {
      throw createError({
        statusCode: 400,
        statusMessage: "Einige Benutzer wurden nicht gefunden oder k\xF6nnen nicht bearbeitet werden"
      });
    }
    const isTargetingAdmin = existingUsers.some((u) => u.id === user.id);
    if (isTargetingAdmin && (action === "deactivate" || action === "delete" || action === "change_role" && (data == null ? void 0 : data.role) !== "ADMINISTRATOR")) {
      throw createError({
        statusCode: 400,
        statusMessage: "Administrator kann sich nicht selbst deaktivieren oder degradieren"
      });
    }
    let updateData = {};
    let actionDescription = "";
    switch (action) {
      case "activate":
        updateData = { isActive: true };
        actionDescription = "aktiviert";
        break;
      case "deactivate":
        updateData = { isActive: false };
        actionDescription = "deaktiviert";
        break;
      case "change_role":
        if (!(data == null ? void 0 : data.role)) {
          throw createError({
            statusCode: 400,
            statusMessage: "Rolle ist erforderlich f\xFCr Rollen-\xC4nderung"
          });
        }
        updateData = { role: data.role };
        actionDescription = `Rolle ge\xE4ndert zu ${data.role}`;
        break;
      case "delete":
        updateData = { isActive: false };
        actionDescription = "gel\xF6scht (deaktiviert)";
        break;
    }
    await prisma$c.user.updateMany({
      where: {
        id: { in: userIds }
      },
      data: updateData
    });
    const activityLogs = existingUsers.map((targetUser) => ({
      action: `bulk_user_${action}`,
      description: `Benutzer ${targetUser.firstName} ${targetUser.lastName} (${targetUser.email}) ${actionDescription}`,
      details: {
        bulkAction: action,
        targetUserId: targetUser.id,
        previousData: {
          role: targetUser.role,
          isActive: targetUser.isActive
        },
        newData: updateData
      },
      userId: user.id
    }));
    await prisma$c.activityLog.createMany({
      data: activityLogs
    });
    return {
      success: true,
      affectedUsers: existingUsers.length,
      action: actionDescription,
      message: `${existingUsers.length} Benutzer erfolgreich ${actionDescription}`
    };
  } catch (error) {
    console.error("Fehler bei Bulk-Aktion:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Server-Fehler"
    });
  }
});

const bulkActions_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: bulkActions_post
});

const createUserSchema = z.object({
  email: z.string().email("Ung\xFCltige E-Mail-Adresse"),
  firstName: z.string().min(1, "Vorname ist erforderlich"),
  lastName: z.string().min(1, "Nachname ist erforderlich"),
  role: z.enum(["ADMINISTRATOR", "PROJEKTLEITER", "ENTWICKLER", "SUPPORTER", "VIEWER", "KUNDE"]),
  avatar: z.string().url().optional(),
  isActive: z.boolean().default(true),
  skills: z.array(z.object({
    name: z.string().min(1),
    category: z.string().min(1),
    level: z.number().min(1).max(5),
    experience: z.string().optional()
  })).optional()
});
z.object({
  firstName: z.string().min(1).optional(),
  lastName: z.string().min(1).optional(),
  email: z.string().email().optional(),
  role: z.enum(["ADMINISTRATOR", "PROJEKTLEITER", "ENTWICKLER", "SUPPORTER", "VIEWER", "KUNDE"]).optional(),
  avatar: z.string().url().optional(),
  isActive: z.boolean().optional()
});
const index = defineEventHandler(async (event) => {
  const method = getMethod(event);
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Nicht authentifiziert"
      });
    }
    if (method === "GET") {
      const query = getQuery$1(event);
      const {
        role,
        isActive,
        search,
        skills,
        availability,
        page = "1",
        limit = "50"
      } = query;
      const where = {};
      if (role) {
        where.role = role;
      }
      if (isActive !== void 0) {
        where.isActive = isActive === "true";
      }
      if (search) {
        where.OR = [
          { firstName: { contains: search, mode: "insensitive" } },
          { lastName: { contains: search, mode: "insensitive" } },
          { email: { contains: search, mode: "insensitive" } }
        ];
      }
      if (user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER") {
        where.isActive = true;
        where.role = { not: "KUNDE" };
      }
      const pageNum = parseInt(page);
      const limitNum = parseInt(limit);
      const skip = (pageNum - 1) * limitNum;
      const [users, total] = await Promise.all([
        prisma$c.user.findMany({
          where,
          select: {
            id: true,
            email: true,
            firstName: true,
            lastName: true,
            avatar: true,
            role: true,
            isActive: true,
            lastLoginAt: true,
            createdAt: true,
            updatedAt: true,
            _count: {
              select: {
                assignedTasks: true,
                timeEntries: true,
                projectMembers: true
              }
            }
          },
          orderBy: [
            { lastName: "asc" },
            { firstName: "asc" }
          ],
          skip,
          take: limitNum
        }),
        prisma$c.user.count({ where })
      ]);
      const totalPages = Math.ceil(total / limitNum);
      return {
        users,
        total,
        page: pageNum,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrev: pageNum > 1
      };
    }
    if (method === "POST") {
      if (user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER") {
        throw createError({
          statusCode: 403,
          statusMessage: "Keine Berechtigung zum Erstellen von Benutzern"
        });
      }
      const body = await readBody(event);
      const validatedData = createUserSchema.parse(body);
      const existingUser = await prisma$c.user.findUnique({
        where: { email: validatedData.email }
      });
      if (existingUser) {
        throw createError({
          statusCode: 400,
          statusMessage: "E-Mail-Adresse bereits vergeben"
        });
      }
      const newUser = await prisma$c.user.create({
        data: {
          email: validatedData.email,
          name: `${validatedData.firstName} ${validatedData.lastName}`,
          // Add required name field
          firstName: validatedData.firstName,
          lastName: validatedData.lastName,
          role: validatedData.role,
          avatar: validatedData.avatar,
          isActive: validatedData.isActive
        },
        include: {
          _count: {
            select: {
              assignedTasks: true,
              timeEntries: true,
              projectMembers: true
            }
          }
        }
      });
      await prisma$c.activityLog.create({
        data: {
          action: "USER_CREATED",
          description: `Benutzer ${newUser.firstName} ${newUser.lastName} wurde erstellt`,
          userId: user.id
        }
      });
      return newUser;
    }
    throw createError({
      statusCode: 405,
      statusMessage: "Methode nicht erlaubt"
    });
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("Users API Error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Server-Fehler"
    });
  }
});

const index$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index
});

const skillMatrix_get = defineEventHandler(async (event) => {
  var _a;
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Nicht authentifiziert"
      });
    }
    if (user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER") {
      throw createError({
        statusCode: 403,
        statusMessage: "Keine Berechtigung f\xFCr Skill-Matrix-Ansicht"
      });
    }
    const [
      skillCategories,
      teamSkills,
      skillStatistics,
      verificationStats
    ] = await Promise.all([
      // Skill-Kategorien
      prisma$c.userSkill.groupBy({
        by: ["category"],
        _count: {
          id: true
        },
        where: {
          user: {
            isActive: true,
            role: { not: "KUNDE" }
          }
        }
      }),
      // Team-Skills mit Benutzerdaten
      prisma$c.userSkill.findMany({
        where: {
          user: {
            isActive: true,
            role: { not: "KUNDE" }
          }
        },
        include: {
          user: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              role: true,
              avatar: true
            }
          }
        },
        orderBy: [
          { category: "asc" },
          { name: "asc" },
          { level: "desc" }
        ]
      }),
      // Skill-Level-Statistiken
      prisma$c.userSkill.groupBy({
        by: ["name", "level"],
        _count: {
          id: true
        },
        where: {
          user: {
            isActive: true,
            role: { not: "KUNDE" }
          }
        }
      }),
      // Verifizierungs-Statistiken
      prisma$c.userSkill.groupBy({
        by: ["verified"],
        _count: {
          id: true
        },
        where: {
          user: {
            isActive: true,
            role: { not: "KUNDE" }
          }
        }
      })
    ]);
    const skillMatrix = skillCategories.map((category) => {
      const categorySkills = teamSkills.filter((skill) => skill.category === category.category);
      const skillsGrouped = categorySkills.reduce((acc, skill) => {
        if (!acc[skill.name]) {
          acc[skill.name] = [];
        }
        acc[skill.name].push(skill);
        return acc;
      }, {});
      return {
        category: category.category,
        totalSkills: category._count.id,
        skills: Object.entries(skillsGrouped).map(([skillName, skillInstances]) => ({
          name: skillName,
          totalUsers: skillInstances.length,
          averageLevel: skillInstances.reduce((sum, s) => sum + s.level, 0) / skillInstances.length,
          maxLevel: Math.max(...skillInstances.map((s) => s.level)),
          verifiedCount: skillInstances.filter((s) => s.verified).length,
          verificationRate: skillInstances.filter((s) => s.verified).length / skillInstances.length * 100,
          users: skillInstances.map((skill) => ({
            user: skill.user,
            level: skill.level,
            verified: skill.verified,
            verifiedBy: skill.verifiedBy,
            verifiedAt: skill.verifiedAt,
            experience: skill.experience
          }))
        }))
      };
    });
    const topSkills = skillStatistics.reduce((acc, stat) => {
      if (!acc[stat.name]) {
        acc[stat.name] = { totalUsers: 0, weightedScore: 0 };
      }
      acc[stat.name].totalUsers += stat._count.id;
      acc[stat.name].weightedScore += stat._count.id * stat.level;
      return acc;
    }, {});
    const topSkillsList = Object.entries(topSkills).map(([name, data]) => ({
      name,
      totalUsers: data.totalUsers,
      averageLevel: data.weightedScore / data.totalUsers,
      weightedScore: data.weightedScore
    })).sort((a, b) => b.weightedScore - a.weightedScore).slice(0, 10);
    const allUniqueSkills = [...new Set(teamSkills.map((s) => s.name))];
    const allUsers = [...new Set(teamSkills.map((s) => s.user.id))];
    const skillCoverage = allUsers.map((userId) => {
      var _a2;
      const userSkills = teamSkills.filter((s) => s.user.id === userId);
      const user2 = (_a2 = userSkills[0]) == null ? void 0 : _a2.user;
      return {
        user: user2,
        totalSkills: userSkills.length,
        verifiedSkills: userSkills.filter((s) => s.verified).length,
        averageLevel: userSkills.reduce((sum, s) => sum + s.level, 0) / userSkills.length || 0,
        categories: [...new Set(userSkills.map((s) => s.category))],
        skillCoveragePercent: userSkills.length / allUniqueSkills.length * 100
      };
    }).sort((a, b) => b.totalSkills - a.totalSkills);
    const totalVerified = ((_a = verificationStats.find((v) => v.verified)) == null ? void 0 : _a._count.id) || 0;
    const totalSkillsCount = verificationStats.reduce((sum, v) => sum + v._count.id, 0);
    const summary = {
      totalSkills: allUniqueSkills.length,
      totalCategories: skillCategories.length,
      totalTeamMembers: allUsers.length,
      averageSkillsPerMember: teamSkills.length / allUsers.length,
      verificationRate: totalSkillsCount > 0 ? totalVerified / totalSkillsCount * 100 : 0
    };
    return {
      success: true,
      data: {
        skillMatrix,
        topSkills: topSkillsList,
        skillCoverage,
        summary,
        lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
      }
    };
  } catch (error) {
    console.error("Fehler beim Laden der Skill-Matrix:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Server-Fehler"
    });
  }
});

const skillMatrix_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: skillMatrix_get
});

const verifySkillSchema = z.object({
  skillId: z.string().cuid(),
  verified: z.boolean(),
  notes: z.string().optional()
});
const verify_post = defineEventHandler(async (event) => {
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Nicht authentifiziert"
      });
    }
    if (user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER") {
      throw createError({
        statusCode: 403,
        statusMessage: "Keine Berechtigung f\xFCr Skill-Verifizierung"
      });
    }
    const body = await readBody(event);
    const { skillId, verified, notes } = verifySkillSchema.parse(body);
    const skill = await prisma$c.userSkill.findUnique({
      where: { id: skillId },
      include: { user: true }
    });
    if (!skill) {
      throw createError({
        statusCode: 404,
        statusMessage: "Skill nicht gefunden"
      });
    }
    const updatedSkill = await prisma$c.userSkill.update({
      where: { id: skillId },
      data: {
        verified,
        verifiedBy: verified ? user.id : null,
        verifiedAt: verified ? /* @__PURE__ */ new Date() : null
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true
          }
        }
      }
    });
    await prisma$c.activityLog.create({
      data: {
        action: verified ? "skill_verified" : "skill_unverified",
        description: `Skill "${skill.name}" f\xFCr ${skill.user.firstName} ${skill.user.lastName} ${verified ? "verifiziert" : "Verifizierung entfernt"}`,
        details: {
          skillId: skill.id,
          skillName: skill.name,
          skillLevel: skill.level,
          targetUserId: skill.userId,
          notes
        },
        userId: user.id
      }
    });
    return {
      success: true,
      skill: updatedSkill,
      message: verified ? "Skill erfolgreich verifiziert" : "Verifizierung entfernt"
    };
  } catch (error) {
    console.error("Fehler bei Skill-Verifizierung:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Server-Fehler"
    });
  }
});

const verify_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: verify_post
});

const statistics_get = defineEventHandler(async (event) => {
  try {
    const user = await requireAuth()(event);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Nicht authentifiziert"
      });
    }
    if (user.role !== "ADMINISTRATOR" && user.role !== "PROJEKTLEITER") {
      throw createError({
        statusCode: 403,
        statusMessage: "Keine Berechtigung f\xFCr Team-Statistiken"
      });
    }
    const [
      totalUsers,
      activeUsers,
      usersByRole,
      recentActivity
    ] = await Promise.all([
      // Gesamtanzahl Benutzer
      prisma$c.user.count({
        where: { role: { not: "KUNDE" } }
      }),
      // Aktive Benutzer
      prisma$c.user.count({
        where: {
          isActive: true,
          role: { not: "KUNDE" }
        }
      }),
      // Benutzer nach Rollen
      prisma$c.user.groupBy({
        by: ["role"],
        where: { role: { not: "KUNDE" } },
        _count: true
      }),
      // Kürzliche Aktivitäten (letzte 30 Tage)
      prisma$c.user.count({
        where: {
          lastLoginAt: {
            gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1e3)
          },
          role: { not: "KUNDE" }
        }
      })
    ]);
    const roleDistribution = {
      ADMINISTRATOR: 0,
      PROJEKTLEITER: 0,
      ENTWICKLER: 0,
      SUPPORTER: 0,
      VIEWER: 0
    };
    usersByRole.forEach((roleGroup) => {
      if (roleGroup.role !== "KUNDE") {
        roleDistribution[roleGroup.role] = roleGroup._count;
      }
    });
    const usersWithTasks = await prisma$c.user.findMany({
      where: {
        isActive: true,
        role: { not: "KUNDE" }
      },
      select: {
        id: true,
        _count: {
          select: {
            assignedTasks: {
              where: {
                status: {
                  key: {
                    in: ["GEPLANT", "TECHNISCHES_DESIGN", "IN_BEARBEITUNG", "REVIEW", "TESTING"]
                  }
                }
              }
            }
          }
        }
      }
    });
    const totalActiveTasks = usersWithTasks.reduce(
      (sum, user2) => sum + user2._count.assignedTasks,
      0
    );
    const averageWorkload = activeUsers > 0 ? totalActiveTasks / activeUsers : 0;
    const onlineMembers = Math.floor(activeUsers * 0.7);
    const statistics = {
      totalMembers: totalUsers,
      activeMembers: activeUsers,
      onlineMembers,
      averageWorkload: Math.round(averageWorkload * 10) / 10,
      recentlyActive: recentActivity,
      roleDistribution,
      // Skill-Verteilung (placeholder - würde aus UserSkill-Tabelle kommen)
      skillDistribution: {
        "Frontend": Math.floor(totalUsers * 0.6),
        "Backend": Math.floor(totalUsers * 0.8),
        "Database": Math.floor(totalUsers * 0.4),
        "DevOps": Math.floor(totalUsers * 0.3),
        "Testing": Math.floor(totalUsers * 0.5)
      }
    };
    return statistics;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("User Statistics API Error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Interner Server-Fehler"
    });
  }
});

const statistics_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: statistics_get
});

function renderPayloadJsonScript(opts) {
  const contents = opts.data ? stringify(opts.data, opts.ssrContext._payloadReducers) : "";
  const payload = {
    "type": "application/json",
    "innerHTML": contents,
    "data-nuxt-data": appId,
    "data-ssr": !(opts.ssrContext.noSSR)
  };
  {
    payload.id = "__NUXT_DATA__";
  }
  if (opts.src) {
    payload["data-src"] = opts.src;
  }
  const config = uneval(opts.ssrContext.config);
  return [
    payload,
    {
      innerHTML: `window.__NUXT__={};window.__NUXT__.config=${config}`
    }
  ];
}

const renderSSRHeadOptions = {"omitLineBreaks":false};

globalThis.__buildAssetsURL = buildAssetsURL;
globalThis.__publicAssetsURL = publicAssetsURL;
const HAS_APP_TELEPORTS = !!(appTeleportAttrs.id);
const APP_TELEPORT_OPEN_TAG = HAS_APP_TELEPORTS ? `<${appTeleportTag}${propsToString(appTeleportAttrs)}>` : "";
const APP_TELEPORT_CLOSE_TAG = HAS_APP_TELEPORTS ? `</${appTeleportTag}>` : "";
const renderer = defineRenderHandler(async (event) => {
  const nitroApp = useNitroApp();
  const ssrError = event.path.startsWith("/__nuxt_error") ? getQuery$1(event) : null;
  if (ssrError && !("__unenv__" in event.node.req)) {
    throw createError({
      statusCode: 404,
      statusMessage: "Page Not Found: /__nuxt_error"
    });
  }
  const ssrContext = createSSRContext(event);
  const headEntryOptions = { mode: "server" };
  ssrContext.head.push(appHead, headEntryOptions);
  if (ssrError) {
    ssrError.statusCode &&= Number.parseInt(ssrError.statusCode);
    setSSRError(ssrContext, ssrError);
  }
  const routeOptions = getRouteRules(event);
  if (routeOptions.ssr === false) {
    ssrContext.noSSR = true;
  }
  const renderer = await getRenderer(ssrContext);
  const _rendered = await renderer.renderToString(ssrContext).catch(async (error) => {
    if (ssrContext._renderResponse && error.message === "skipping render") {
      return {};
    }
    const _err = !ssrError && ssrContext.payload?.error || error;
    await ssrContext.nuxt?.hooks.callHook("app:error", _err);
    throw _err;
  });
  const inlinedStyles = [];
  await ssrContext.nuxt?.hooks.callHook("app:rendered", { ssrContext, renderResult: _rendered });
  if (ssrContext._renderResponse) {
    return ssrContext._renderResponse;
  }
  if (ssrContext.payload?.error && !ssrError) {
    throw ssrContext.payload.error;
  }
  const NO_SCRIPTS = routeOptions.noScripts;
  const { styles, scripts } = getRequestDependencies(ssrContext, renderer.rendererContext);
  if (ssrContext._preloadManifest && !NO_SCRIPTS) {
    ssrContext.head.push({
      link: [
        { rel: "preload", as: "fetch", fetchpriority: "low", crossorigin: "anonymous", href: buildAssetsURL(`builds/meta/${ssrContext.runtimeConfig.app.buildId}.json`) }
      ]
    }, { ...headEntryOptions, tagPriority: "low" });
  }
  if (inlinedStyles.length) {
    ssrContext.head.push({ style: inlinedStyles });
  }
  const link = [];
  for (const resource of Object.values(styles)) {
    if ("inline" in getQuery(resource.file)) {
      continue;
    }
    link.push({ rel: "stylesheet", href: renderer.rendererContext.buildAssetsURL(resource.file), crossorigin: "" });
  }
  if (link.length) {
    ssrContext.head.push({ link }, headEntryOptions);
  }
  if (!NO_SCRIPTS) {
    ssrContext.head.push({
      link: getPreloadLinks(ssrContext, renderer.rendererContext)
    }, headEntryOptions);
    ssrContext.head.push({
      link: getPrefetchLinks(ssrContext, renderer.rendererContext)
    }, headEntryOptions);
    ssrContext.head.push({
      script: renderPayloadJsonScript({ ssrContext, data: ssrContext.payload }) 
    }, {
      ...headEntryOptions,
      // this should come before another end of body scripts
      tagPosition: "bodyClose",
      tagPriority: "high"
    });
  }
  if (!routeOptions.noScripts) {
    ssrContext.head.push({
      script: Object.values(scripts).map((resource) => ({
        type: resource.module ? "module" : null,
        src: renderer.rendererContext.buildAssetsURL(resource.file),
        defer: resource.module ? null : true,
        // if we are rendering script tag payloads that import an async payload
        // we need to ensure this resolves before executing the Nuxt entry
        tagPosition: "head",
        crossorigin: ""
      }))
    }, headEntryOptions);
  }
  const { headTags, bodyTags, bodyTagsOpen, htmlAttrs, bodyAttrs } = await renderSSRHead(ssrContext.head, renderSSRHeadOptions);
  const htmlContext = {
    htmlAttrs: htmlAttrs ? [htmlAttrs] : [],
    head: normalizeChunks([headTags]),
    bodyAttrs: bodyAttrs ? [bodyAttrs] : [],
    bodyPrepend: normalizeChunks([bodyTagsOpen, ssrContext.teleports?.body]),
    body: [
      replaceIslandTeleports(ssrContext, _rendered.html) ,
      APP_TELEPORT_OPEN_TAG + (HAS_APP_TELEPORTS ? joinTags([ssrContext.teleports?.[`#${appTeleportAttrs.id}`]]) : "") + APP_TELEPORT_CLOSE_TAG
    ],
    bodyAppend: [bodyTags]
  };
  await nitroApp.hooks.callHook("render:html", htmlContext, { event });
  return {
    body: renderHTMLDocument(htmlContext),
    statusCode: getResponseStatus(event),
    statusMessage: getResponseStatusText(event),
    headers: {
      "content-type": "text/html;charset=utf-8",
      "x-powered-by": "Nuxt"
    }
  };
});
function normalizeChunks(chunks) {
  return chunks.filter(Boolean).map((i) => i.trim());
}
function joinTags(tags) {
  return tags.join("");
}
function joinAttrs(chunks) {
  if (chunks.length === 0) {
    return "";
  }
  return " " + chunks.join(" ");
}
function renderHTMLDocument(html) {
  return `<!DOCTYPE html><html${joinAttrs(html.htmlAttrs)}><head>${joinTags(html.head)}</head><body${joinAttrs(html.bodyAttrs)}>${joinTags(html.bodyPrepend)}${joinTags(html.body)}${joinTags(html.bodyAppend)}</body></html>`;
}

const renderer$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: renderer
});
//# sourceMappingURL=index.mjs.map
