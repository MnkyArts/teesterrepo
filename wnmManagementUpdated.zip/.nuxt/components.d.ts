
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T extends DefineComponent> = T & DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>>
type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = (T & DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }>)
interface _GlobalComponents {
      'ActivityFeed': typeof import("../components/ActivityFeed.vue")['default']
    'AppHeader': typeof import("../components/AppHeader.vue")['default']
    'AppLoadingOverlay': typeof import("../components/AppLoadingOverlay.vue")['default']
    'AppNotifications': typeof import("../components/AppNotifications.vue")['default']
    'AppSidebar': typeof import("../components/AppSidebar.vue")['default']
    'AttachmentCard': typeof import("../components/AttachmentCard.vue")['default']
    'AttachmentManager': typeof import("../components/AttachmentManager.vue")['default']
    'AttachmentPreviewModal': typeof import("../components/AttachmentPreviewModal.vue")['default']
    'AuthLoadingScreen': typeof import("../components/AuthLoadingScreen.vue")['default']
    'ColorModeToggle': typeof import("../components/ColorModeToggle.vue")['default']
    'ConfirmDialog': typeof import("../components/ConfirmDialog.vue")['default']
    'DashboardSection': typeof import("../components/DashboardSection.vue")['default']
    'EnhancedTeamMemberCard': typeof import("../components/EnhancedTeamMemberCard.vue")['default']
    'EnumCategoryModal': typeof import("../components/EnumCategoryModal.vue")['default']
    'EnumManagement': typeof import("../components/EnumManagement.vue")['default']
    'EnumValueModal': typeof import("../components/EnumValueModal.vue")['default']
    'FastAuthLoader': typeof import("../components/FastAuthLoader.vue")['default']
    'IndividualPerformanceTable': typeof import("../components/IndividualPerformanceTable.vue")['default']
    'InternalTicketComments': typeof import("../components/InternalTicketComments.vue")['default']
    'KanbanBoard': typeof import("../components/KanbanBoard.vue")['default']
    'KanbanTaskCard': typeof import("../components/KanbanTaskCard.vue")['default']
    'NotificationsDropdown': typeof import("../components/NotificationsDropdown.vue")['default']
    'PdfViewer': typeof import("../components/PdfViewer.vue")['default']
    'ProjectCard': typeof import("../components/ProjectCard.vue")['default']
    'ProjectCardSkeleton': typeof import("../components/ProjectCardSkeleton.vue")['default']
    'ProjectDetailSkeleton': typeof import("../components/ProjectDetailSkeleton.vue")['default']
    'ProjectEnumSection': typeof import("../components/ProjectEnumSection.vue")['default']
    'ProjectEnumValueModal': typeof import("../components/ProjectEnumValueModal.vue")['default']
    'ProjectModal': typeof import("../components/ProjectModal.vue")['default']
    'ProjectOverview': typeof import("../components/ProjectOverview.vue")['default']
    'ProjectPerformanceChart': typeof import("../components/ProjectPerformanceChart.vue")['default']
    'ProjectProfitabilityTable': typeof import("../components/ProjectProfitabilityTable.vue")['default']
    'ProjectStatusBadge': typeof import("../components/ProjectStatusBadge.vue")['default']
    'ProjectStatusChart': typeof import("../components/ProjectStatusChart.vue")['default']
    'ReportExportModal': typeof import("../components/ReportExportModal.vue")['default']
    'RevenueChart': typeof import("../components/RevenueChart.vue")['default']
    'SepaManagement': typeof import("../components/SepaManagement.vue")['default']
    'SidebarItem': typeof import("../components/SidebarItem.vue")['default']
    'SidebarProjectItem': typeof import("../components/SidebarProjectItem.vue")['default']
    'SkillDisplay': typeof import("../components/SkillDisplay.vue")['default']
    'SkillLevelBadge': typeof import("../components/SkillLevelBadge.vue")['default']
    'SkillMatrixOverview': typeof import("../components/SkillMatrixOverview.vue")['default']
    'SkillModal': typeof import("../components/SkillModal.vue")['default']
    'StatCard': typeof import("../components/StatCard.vue")['default']
    'TaskCard': typeof import("../components/TaskCard.vue")['default']
    'TaskDetails': typeof import("../components/TaskDetails.vue")['default']
    'TaskList': typeof import("../components/TaskList.vue")['default']
    'TaskModal': typeof import("../components/TaskModal.vue")['default']
    'TaskPriorityBadge': typeof import("../components/TaskPriorityBadge.vue")['default']
    'TaskPropertyBadge': typeof import("../components/TaskPropertyBadge.vue")['default']
    'TaskStatusBadge': typeof import("../components/TaskStatusBadge.vue")['default']
    'TeamActivity': typeof import("../components/TeamActivity.vue")['default']
    'TeamBulkActions': typeof import("../components/TeamBulkActions.vue")['default']
    'TeamMemberCard': typeof import("../components/TeamMemberCard.vue")['default']
    'TeamWorkloadChart': typeof import("../components/TeamWorkloadChart.vue")['default']
    'TicketComments': typeof import("../components/TicketComments.vue")['default']
    'TicketConversionModal': typeof import("../components/TicketConversionModal.vue")['default']
    'TimeDistributionChart': typeof import("../components/TimeDistributionChart.vue")['default']
    'TimeEntryList': typeof import("../components/TimeEntryList.vue")['default']
    'TimeEntryModal': typeof import("../components/TimeEntryModal.vue")['default']
    'TimeTrackingWidget': typeof import("../components/TimeTrackingWidget.vue")['default']
    'TimeTrendsChart': typeof import("../components/TimeTrendsChart.vue")['default']
    'TimerStartModal': typeof import("../components/TimerStartModal.vue")['default']
    'UserDetailModal': typeof import("../components/UserDetailModal.vue")['default']
    'UserMenu': typeof import("../components/UserMenu.vue")['default']
    'UserModal': typeof import("../components/UserModal.vue")['default']
    'UserRoleBadge': typeof import("../components/UserRoleBadge.vue")['default']
    'WeekTimesheet': typeof import("../components/WeekTimesheet.vue")['default']
    'NuxtWelcome': typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
    'NuxtLayout': typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
    'NuxtErrorBoundary': typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
    'ClientOnly': typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
    'DevOnly': typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
    'ServerPlaceholder': typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'NuxtLink': typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
    'NuxtLoadingIndicator': typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
    'NuxtTime': typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
    'NuxtRouteAnnouncer': typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
    'NuxtImg': typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue")['default']
    'NuxtPicture': typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue")['default']
    'Icon': typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']
    'NuxtLinkLocale': typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale")['default']
    'SwitchLocalePathLink': typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/SwitchLocalePathLink")['default']
    'ColorScheme': typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue")['default']
    'NuxtPage': typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
    'NoScript': typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
    'Link': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
    'Base': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
    'Title': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
    'Meta': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
    'Style': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
    'Head': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
    'Html': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
    'Body': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
    'NuxtIsland': typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
    'NuxtRouteAnnouncer': IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
      'LazyActivityFeed': LazyComponent<typeof import("../components/ActivityFeed.vue")['default']>
    'LazyAppHeader': LazyComponent<typeof import("../components/AppHeader.vue")['default']>
    'LazyAppLoadingOverlay': LazyComponent<typeof import("../components/AppLoadingOverlay.vue")['default']>
    'LazyAppNotifications': LazyComponent<typeof import("../components/AppNotifications.vue")['default']>
    'LazyAppSidebar': LazyComponent<typeof import("../components/AppSidebar.vue")['default']>
    'LazyAttachmentCard': LazyComponent<typeof import("../components/AttachmentCard.vue")['default']>
    'LazyAttachmentManager': LazyComponent<typeof import("../components/AttachmentManager.vue")['default']>
    'LazyAttachmentPreviewModal': LazyComponent<typeof import("../components/AttachmentPreviewModal.vue")['default']>
    'LazyAuthLoadingScreen': LazyComponent<typeof import("../components/AuthLoadingScreen.vue")['default']>
    'LazyColorModeToggle': LazyComponent<typeof import("../components/ColorModeToggle.vue")['default']>
    'LazyConfirmDialog': LazyComponent<typeof import("../components/ConfirmDialog.vue")['default']>
    'LazyDashboardSection': LazyComponent<typeof import("../components/DashboardSection.vue")['default']>
    'LazyEnhancedTeamMemberCard': LazyComponent<typeof import("../components/EnhancedTeamMemberCard.vue")['default']>
    'LazyEnumCategoryModal': LazyComponent<typeof import("../components/EnumCategoryModal.vue")['default']>
    'LazyEnumManagement': LazyComponent<typeof import("../components/EnumManagement.vue")['default']>
    'LazyEnumValueModal': LazyComponent<typeof import("../components/EnumValueModal.vue")['default']>
    'LazyFastAuthLoader': LazyComponent<typeof import("../components/FastAuthLoader.vue")['default']>
    'LazyIndividualPerformanceTable': LazyComponent<typeof import("../components/IndividualPerformanceTable.vue")['default']>
    'LazyInternalTicketComments': LazyComponent<typeof import("../components/InternalTicketComments.vue")['default']>
    'LazyKanbanBoard': LazyComponent<typeof import("../components/KanbanBoard.vue")['default']>
    'LazyKanbanTaskCard': LazyComponent<typeof import("../components/KanbanTaskCard.vue")['default']>
    'LazyNotificationsDropdown': LazyComponent<typeof import("../components/NotificationsDropdown.vue")['default']>
    'LazyPdfViewer': LazyComponent<typeof import("../components/PdfViewer.vue")['default']>
    'LazyProjectCard': LazyComponent<typeof import("../components/ProjectCard.vue")['default']>
    'LazyProjectCardSkeleton': LazyComponent<typeof import("../components/ProjectCardSkeleton.vue")['default']>
    'LazyProjectDetailSkeleton': LazyComponent<typeof import("../components/ProjectDetailSkeleton.vue")['default']>
    'LazyProjectEnumSection': LazyComponent<typeof import("../components/ProjectEnumSection.vue")['default']>
    'LazyProjectEnumValueModal': LazyComponent<typeof import("../components/ProjectEnumValueModal.vue")['default']>
    'LazyProjectModal': LazyComponent<typeof import("../components/ProjectModal.vue")['default']>
    'LazyProjectOverview': LazyComponent<typeof import("../components/ProjectOverview.vue")['default']>
    'LazyProjectPerformanceChart': LazyComponent<typeof import("../components/ProjectPerformanceChart.vue")['default']>
    'LazyProjectProfitabilityTable': LazyComponent<typeof import("../components/ProjectProfitabilityTable.vue")['default']>
    'LazyProjectStatusBadge': LazyComponent<typeof import("../components/ProjectStatusBadge.vue")['default']>
    'LazyProjectStatusChart': LazyComponent<typeof import("../components/ProjectStatusChart.vue")['default']>
    'LazyReportExportModal': LazyComponent<typeof import("../components/ReportExportModal.vue")['default']>
    'LazyRevenueChart': LazyComponent<typeof import("../components/RevenueChart.vue")['default']>
    'LazySepaManagement': LazyComponent<typeof import("../components/SepaManagement.vue")['default']>
    'LazySidebarItem': LazyComponent<typeof import("../components/SidebarItem.vue")['default']>
    'LazySidebarProjectItem': LazyComponent<typeof import("../components/SidebarProjectItem.vue")['default']>
    'LazySkillDisplay': LazyComponent<typeof import("../components/SkillDisplay.vue")['default']>
    'LazySkillLevelBadge': LazyComponent<typeof import("../components/SkillLevelBadge.vue")['default']>
    'LazySkillMatrixOverview': LazyComponent<typeof import("../components/SkillMatrixOverview.vue")['default']>
    'LazySkillModal': LazyComponent<typeof import("../components/SkillModal.vue")['default']>
    'LazyStatCard': LazyComponent<typeof import("../components/StatCard.vue")['default']>
    'LazyTaskCard': LazyComponent<typeof import("../components/TaskCard.vue")['default']>
    'LazyTaskDetails': LazyComponent<typeof import("../components/TaskDetails.vue")['default']>
    'LazyTaskList': LazyComponent<typeof import("../components/TaskList.vue")['default']>
    'LazyTaskModal': LazyComponent<typeof import("../components/TaskModal.vue")['default']>
    'LazyTaskPriorityBadge': LazyComponent<typeof import("../components/TaskPriorityBadge.vue")['default']>
    'LazyTaskPropertyBadge': LazyComponent<typeof import("../components/TaskPropertyBadge.vue")['default']>
    'LazyTaskStatusBadge': LazyComponent<typeof import("../components/TaskStatusBadge.vue")['default']>
    'LazyTeamActivity': LazyComponent<typeof import("../components/TeamActivity.vue")['default']>
    'LazyTeamBulkActions': LazyComponent<typeof import("../components/TeamBulkActions.vue")['default']>
    'LazyTeamMemberCard': LazyComponent<typeof import("../components/TeamMemberCard.vue")['default']>
    'LazyTeamWorkloadChart': LazyComponent<typeof import("../components/TeamWorkloadChart.vue")['default']>
    'LazyTicketComments': LazyComponent<typeof import("../components/TicketComments.vue")['default']>
    'LazyTicketConversionModal': LazyComponent<typeof import("../components/TicketConversionModal.vue")['default']>
    'LazyTimeDistributionChart': LazyComponent<typeof import("../components/TimeDistributionChart.vue")['default']>
    'LazyTimeEntryList': LazyComponent<typeof import("../components/TimeEntryList.vue")['default']>
    'LazyTimeEntryModal': LazyComponent<typeof import("../components/TimeEntryModal.vue")['default']>
    'LazyTimeTrackingWidget': LazyComponent<typeof import("../components/TimeTrackingWidget.vue")['default']>
    'LazyTimeTrendsChart': LazyComponent<typeof import("../components/TimeTrendsChart.vue")['default']>
    'LazyTimerStartModal': LazyComponent<typeof import("../components/TimerStartModal.vue")['default']>
    'LazyUserDetailModal': LazyComponent<typeof import("../components/UserDetailModal.vue")['default']>
    'LazyUserMenu': LazyComponent<typeof import("../components/UserMenu.vue")['default']>
    'LazyUserModal': LazyComponent<typeof import("../components/UserModal.vue")['default']>
    'LazyUserRoleBadge': LazyComponent<typeof import("../components/UserRoleBadge.vue")['default']>
    'LazyWeekTimesheet': LazyComponent<typeof import("../components/WeekTimesheet.vue")['default']>
    'LazyNuxtWelcome': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
    'LazyNuxtLayout': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
    'LazyNuxtErrorBoundary': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
    'LazyClientOnly': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
    'LazyDevOnly': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
    'LazyServerPlaceholder': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyNuxtLink': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
    'LazyNuxtLoadingIndicator': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
    'LazyNuxtTime': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
    'LazyNuxtRouteAnnouncer': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
    'LazyNuxtImg': LazyComponent<typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue")['default']>
    'LazyNuxtPicture': LazyComponent<typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue")['default']>
    'LazyIcon': LazyComponent<typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']>
    'LazyNuxtLinkLocale': LazyComponent<typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale")['default']>
    'LazySwitchLocalePathLink': LazyComponent<typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/SwitchLocalePathLink")['default']>
    'LazyColorScheme': LazyComponent<typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue")['default']>
    'LazyNuxtPage': LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
    'LazyNoScript': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
    'LazyLink': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
    'LazyBase': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
    'LazyTitle': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
    'LazyMeta': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
    'LazyStyle': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
    'LazyHead': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
    'LazyHtml': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
    'LazyBody': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
    'LazyNuxtIsland': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>
    'LazyNuxtRouteAnnouncer': LazyComponent<IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>>
}

declare module 'vue' {
  export interface GlobalComponents extends _GlobalComponents { }
}

export const ActivityFeed: typeof import("../components/ActivityFeed.vue")['default']
export const AppHeader: typeof import("../components/AppHeader.vue")['default']
export const AppLoadingOverlay: typeof import("../components/AppLoadingOverlay.vue")['default']
export const AppNotifications: typeof import("../components/AppNotifications.vue")['default']
export const AppSidebar: typeof import("../components/AppSidebar.vue")['default']
export const AttachmentCard: typeof import("../components/AttachmentCard.vue")['default']
export const AttachmentManager: typeof import("../components/AttachmentManager.vue")['default']
export const AttachmentPreviewModal: typeof import("../components/AttachmentPreviewModal.vue")['default']
export const AuthLoadingScreen: typeof import("../components/AuthLoadingScreen.vue")['default']
export const ColorModeToggle: typeof import("../components/ColorModeToggle.vue")['default']
export const ConfirmDialog: typeof import("../components/ConfirmDialog.vue")['default']
export const DashboardSection: typeof import("../components/DashboardSection.vue")['default']
export const EnhancedTeamMemberCard: typeof import("../components/EnhancedTeamMemberCard.vue")['default']
export const EnumCategoryModal: typeof import("../components/EnumCategoryModal.vue")['default']
export const EnumManagement: typeof import("../components/EnumManagement.vue")['default']
export const EnumValueModal: typeof import("../components/EnumValueModal.vue")['default']
export const FastAuthLoader: typeof import("../components/FastAuthLoader.vue")['default']
export const IndividualPerformanceTable: typeof import("../components/IndividualPerformanceTable.vue")['default']
export const InternalTicketComments: typeof import("../components/InternalTicketComments.vue")['default']
export const KanbanBoard: typeof import("../components/KanbanBoard.vue")['default']
export const KanbanTaskCard: typeof import("../components/KanbanTaskCard.vue")['default']
export const NotificationsDropdown: typeof import("../components/NotificationsDropdown.vue")['default']
export const PdfViewer: typeof import("../components/PdfViewer.vue")['default']
export const ProjectCard: typeof import("../components/ProjectCard.vue")['default']
export const ProjectCardSkeleton: typeof import("../components/ProjectCardSkeleton.vue")['default']
export const ProjectDetailSkeleton: typeof import("../components/ProjectDetailSkeleton.vue")['default']
export const ProjectEnumSection: typeof import("../components/ProjectEnumSection.vue")['default']
export const ProjectEnumValueModal: typeof import("../components/ProjectEnumValueModal.vue")['default']
export const ProjectModal: typeof import("../components/ProjectModal.vue")['default']
export const ProjectOverview: typeof import("../components/ProjectOverview.vue")['default']
export const ProjectPerformanceChart: typeof import("../components/ProjectPerformanceChart.vue")['default']
export const ProjectProfitabilityTable: typeof import("../components/ProjectProfitabilityTable.vue")['default']
export const ProjectStatusBadge: typeof import("../components/ProjectStatusBadge.vue")['default']
export const ProjectStatusChart: typeof import("../components/ProjectStatusChart.vue")['default']
export const ReportExportModal: typeof import("../components/ReportExportModal.vue")['default']
export const RevenueChart: typeof import("../components/RevenueChart.vue")['default']
export const SepaManagement: typeof import("../components/SepaManagement.vue")['default']
export const SidebarItem: typeof import("../components/SidebarItem.vue")['default']
export const SidebarProjectItem: typeof import("../components/SidebarProjectItem.vue")['default']
export const SkillDisplay: typeof import("../components/SkillDisplay.vue")['default']
export const SkillLevelBadge: typeof import("../components/SkillLevelBadge.vue")['default']
export const SkillMatrixOverview: typeof import("../components/SkillMatrixOverview.vue")['default']
export const SkillModal: typeof import("../components/SkillModal.vue")['default']
export const StatCard: typeof import("../components/StatCard.vue")['default']
export const TaskCard: typeof import("../components/TaskCard.vue")['default']
export const TaskDetails: typeof import("../components/TaskDetails.vue")['default']
export const TaskList: typeof import("../components/TaskList.vue")['default']
export const TaskModal: typeof import("../components/TaskModal.vue")['default']
export const TaskPriorityBadge: typeof import("../components/TaskPriorityBadge.vue")['default']
export const TaskPropertyBadge: typeof import("../components/TaskPropertyBadge.vue")['default']
export const TaskStatusBadge: typeof import("../components/TaskStatusBadge.vue")['default']
export const TeamActivity: typeof import("../components/TeamActivity.vue")['default']
export const TeamBulkActions: typeof import("../components/TeamBulkActions.vue")['default']
export const TeamMemberCard: typeof import("../components/TeamMemberCard.vue")['default']
export const TeamWorkloadChart: typeof import("../components/TeamWorkloadChart.vue")['default']
export const TicketComments: typeof import("../components/TicketComments.vue")['default']
export const TicketConversionModal: typeof import("../components/TicketConversionModal.vue")['default']
export const TimeDistributionChart: typeof import("../components/TimeDistributionChart.vue")['default']
export const TimeEntryList: typeof import("../components/TimeEntryList.vue")['default']
export const TimeEntryModal: typeof import("../components/TimeEntryModal.vue")['default']
export const TimeTrackingWidget: typeof import("../components/TimeTrackingWidget.vue")['default']
export const TimeTrendsChart: typeof import("../components/TimeTrendsChart.vue")['default']
export const TimerStartModal: typeof import("../components/TimerStartModal.vue")['default']
export const UserDetailModal: typeof import("../components/UserDetailModal.vue")['default']
export const UserMenu: typeof import("../components/UserMenu.vue")['default']
export const UserModal: typeof import("../components/UserModal.vue")['default']
export const UserRoleBadge: typeof import("../components/UserRoleBadge.vue")['default']
export const WeekTimesheet: typeof import("../components/WeekTimesheet.vue")['default']
export const NuxtWelcome: typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
export const NuxtLayout: typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
export const NuxtErrorBoundary: typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
export const ClientOnly: typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
export const DevOnly: typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
export const ServerPlaceholder: typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const NuxtLink: typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
export const NuxtLoadingIndicator: typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
export const NuxtTime: typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
export const NuxtRouteAnnouncer: typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
export const NuxtImg: typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue")['default']
export const NuxtPicture: typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue")['default']
export const Icon: typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']
export const NuxtLinkLocale: typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale")['default']
export const SwitchLocalePathLink: typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/SwitchLocalePathLink")['default']
export const ColorScheme: typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue")['default']
export const NuxtPage: typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
export const NoScript: typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
export const Link: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
export const Base: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
export const Title: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
export const Meta: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
export const Style: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
export const Head: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
export const Html: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
export const Body: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
export const NuxtIsland: typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
export const NuxtRouteAnnouncer: IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyActivityFeed: LazyComponent<typeof import("../components/ActivityFeed.vue")['default']>
export const LazyAppHeader: LazyComponent<typeof import("../components/AppHeader.vue")['default']>
export const LazyAppLoadingOverlay: LazyComponent<typeof import("../components/AppLoadingOverlay.vue")['default']>
export const LazyAppNotifications: LazyComponent<typeof import("../components/AppNotifications.vue")['default']>
export const LazyAppSidebar: LazyComponent<typeof import("../components/AppSidebar.vue")['default']>
export const LazyAttachmentCard: LazyComponent<typeof import("../components/AttachmentCard.vue")['default']>
export const LazyAttachmentManager: LazyComponent<typeof import("../components/AttachmentManager.vue")['default']>
export const LazyAttachmentPreviewModal: LazyComponent<typeof import("../components/AttachmentPreviewModal.vue")['default']>
export const LazyAuthLoadingScreen: LazyComponent<typeof import("../components/AuthLoadingScreen.vue")['default']>
export const LazyColorModeToggle: LazyComponent<typeof import("../components/ColorModeToggle.vue")['default']>
export const LazyConfirmDialog: LazyComponent<typeof import("../components/ConfirmDialog.vue")['default']>
export const LazyDashboardSection: LazyComponent<typeof import("../components/DashboardSection.vue")['default']>
export const LazyEnhancedTeamMemberCard: LazyComponent<typeof import("../components/EnhancedTeamMemberCard.vue")['default']>
export const LazyEnumCategoryModal: LazyComponent<typeof import("../components/EnumCategoryModal.vue")['default']>
export const LazyEnumManagement: LazyComponent<typeof import("../components/EnumManagement.vue")['default']>
export const LazyEnumValueModal: LazyComponent<typeof import("../components/EnumValueModal.vue")['default']>
export const LazyFastAuthLoader: LazyComponent<typeof import("../components/FastAuthLoader.vue")['default']>
export const LazyIndividualPerformanceTable: LazyComponent<typeof import("../components/IndividualPerformanceTable.vue")['default']>
export const LazyInternalTicketComments: LazyComponent<typeof import("../components/InternalTicketComments.vue")['default']>
export const LazyKanbanBoard: LazyComponent<typeof import("../components/KanbanBoard.vue")['default']>
export const LazyKanbanTaskCard: LazyComponent<typeof import("../components/KanbanTaskCard.vue")['default']>
export const LazyNotificationsDropdown: LazyComponent<typeof import("../components/NotificationsDropdown.vue")['default']>
export const LazyPdfViewer: LazyComponent<typeof import("../components/PdfViewer.vue")['default']>
export const LazyProjectCard: LazyComponent<typeof import("../components/ProjectCard.vue")['default']>
export const LazyProjectCardSkeleton: LazyComponent<typeof import("../components/ProjectCardSkeleton.vue")['default']>
export const LazyProjectDetailSkeleton: LazyComponent<typeof import("../components/ProjectDetailSkeleton.vue")['default']>
export const LazyProjectEnumSection: LazyComponent<typeof import("../components/ProjectEnumSection.vue")['default']>
export const LazyProjectEnumValueModal: LazyComponent<typeof import("../components/ProjectEnumValueModal.vue")['default']>
export const LazyProjectModal: LazyComponent<typeof import("../components/ProjectModal.vue")['default']>
export const LazyProjectOverview: LazyComponent<typeof import("../components/ProjectOverview.vue")['default']>
export const LazyProjectPerformanceChart: LazyComponent<typeof import("../components/ProjectPerformanceChart.vue")['default']>
export const LazyProjectProfitabilityTable: LazyComponent<typeof import("../components/ProjectProfitabilityTable.vue")['default']>
export const LazyProjectStatusBadge: LazyComponent<typeof import("../components/ProjectStatusBadge.vue")['default']>
export const LazyProjectStatusChart: LazyComponent<typeof import("../components/ProjectStatusChart.vue")['default']>
export const LazyReportExportModal: LazyComponent<typeof import("../components/ReportExportModal.vue")['default']>
export const LazyRevenueChart: LazyComponent<typeof import("../components/RevenueChart.vue")['default']>
export const LazySepaManagement: LazyComponent<typeof import("../components/SepaManagement.vue")['default']>
export const LazySidebarItem: LazyComponent<typeof import("../components/SidebarItem.vue")['default']>
export const LazySidebarProjectItem: LazyComponent<typeof import("../components/SidebarProjectItem.vue")['default']>
export const LazySkillDisplay: LazyComponent<typeof import("../components/SkillDisplay.vue")['default']>
export const LazySkillLevelBadge: LazyComponent<typeof import("../components/SkillLevelBadge.vue")['default']>
export const LazySkillMatrixOverview: LazyComponent<typeof import("../components/SkillMatrixOverview.vue")['default']>
export const LazySkillModal: LazyComponent<typeof import("../components/SkillModal.vue")['default']>
export const LazyStatCard: LazyComponent<typeof import("../components/StatCard.vue")['default']>
export const LazyTaskCard: LazyComponent<typeof import("../components/TaskCard.vue")['default']>
export const LazyTaskDetails: LazyComponent<typeof import("../components/TaskDetails.vue")['default']>
export const LazyTaskList: LazyComponent<typeof import("../components/TaskList.vue")['default']>
export const LazyTaskModal: LazyComponent<typeof import("../components/TaskModal.vue")['default']>
export const LazyTaskPriorityBadge: LazyComponent<typeof import("../components/TaskPriorityBadge.vue")['default']>
export const LazyTaskPropertyBadge: LazyComponent<typeof import("../components/TaskPropertyBadge.vue")['default']>
export const LazyTaskStatusBadge: LazyComponent<typeof import("../components/TaskStatusBadge.vue")['default']>
export const LazyTeamActivity: LazyComponent<typeof import("../components/TeamActivity.vue")['default']>
export const LazyTeamBulkActions: LazyComponent<typeof import("../components/TeamBulkActions.vue")['default']>
export const LazyTeamMemberCard: LazyComponent<typeof import("../components/TeamMemberCard.vue")['default']>
export const LazyTeamWorkloadChart: LazyComponent<typeof import("../components/TeamWorkloadChart.vue")['default']>
export const LazyTicketComments: LazyComponent<typeof import("../components/TicketComments.vue")['default']>
export const LazyTicketConversionModal: LazyComponent<typeof import("../components/TicketConversionModal.vue")['default']>
export const LazyTimeDistributionChart: LazyComponent<typeof import("../components/TimeDistributionChart.vue")['default']>
export const LazyTimeEntryList: LazyComponent<typeof import("../components/TimeEntryList.vue")['default']>
export const LazyTimeEntryModal: LazyComponent<typeof import("../components/TimeEntryModal.vue")['default']>
export const LazyTimeTrackingWidget: LazyComponent<typeof import("../components/TimeTrackingWidget.vue")['default']>
export const LazyTimeTrendsChart: LazyComponent<typeof import("../components/TimeTrendsChart.vue")['default']>
export const LazyTimerStartModal: LazyComponent<typeof import("../components/TimerStartModal.vue")['default']>
export const LazyUserDetailModal: LazyComponent<typeof import("../components/UserDetailModal.vue")['default']>
export const LazyUserMenu: LazyComponent<typeof import("../components/UserMenu.vue")['default']>
export const LazyUserModal: LazyComponent<typeof import("../components/UserModal.vue")['default']>
export const LazyUserRoleBadge: LazyComponent<typeof import("../components/UserRoleBadge.vue")['default']>
export const LazyWeekTimesheet: LazyComponent<typeof import("../components/WeekTimesheet.vue")['default']>
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue")['default']>
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue")['default']>
export const LazyIcon: LazyComponent<typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']>
export const LazyNuxtLinkLocale: LazyComponent<typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale")['default']>
export const LazySwitchLocalePathLink: LazyComponent<typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/SwitchLocalePathLink")['default']>
export const LazyColorScheme: LazyComponent<typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue")['default']>
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
export const LazyLink: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
export const LazyBase: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
export const LazyTitle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
export const LazyMeta: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
export const LazyStyle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
export const LazyHead: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
export const LazyHtml: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
export const LazyBody: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>>

export const componentNames: string[]
