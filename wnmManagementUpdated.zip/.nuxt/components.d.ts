
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T extends DefineComponent> = T & DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>>
type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = (T & DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }>)
interface _GlobalComponents {
      'ActivityFeed': typeof import("../components/ActivityFeed.vue")['default']
    'DashboardSection': typeof import("../components/DashboardSection.vue")['default']
    'StatCard': typeof import("../components/StatCard.vue")['default']
    'AppHeader': typeof import("../layers/core/components/AppHeader.vue")['default']
    'AppLoadingOverlay': typeof import("../layers/core/components/AppLoadingOverlay.vue")['default']
    'AppSidebar': typeof import("../layers/core/components/AppSidebar.vue")['default']
    'ColorModeToggle': typeof import("../layers/core/components/ColorModeToggle.vue")['default']
    'ConfirmDialog': typeof import("../layers/core/components/ConfirmDialog.vue")['default']
    'SidebarItem': typeof import("../layers/core/components/SidebarItem.vue")['default']
    'UserMenu': typeof import("../layers/core/components/UserMenu.vue")['default']
    'AuthLoadingScreen': typeof import("../layers/auth/components/AuthLoadingScreen.vue")['default']
    'FastAuthLoader': typeof import("../layers/auth/components/FastAuthLoader.vue")['default']
    'ProjectCard': typeof import("../layers/projects/components/ProjectCard.vue")['default']
    'ProjectCardSkeleton': typeof import("../layers/projects/components/ProjectCardSkeleton.vue")['default']
    'ProjectDetailSkeleton': typeof import("../layers/projects/components/ProjectDetailSkeleton.vue")['default']
    'ProjectEnumSection': typeof import("../layers/projects/components/ProjectEnumSection.vue")['default']
    'ProjectEnumValueModal': typeof import("../layers/projects/components/ProjectEnumValueModal.vue")['default']
    'ProjectModal': typeof import("../layers/projects/components/ProjectModal.vue")['default']
    'ProjectOverview': typeof import("../layers/projects/components/ProjectOverview.vue")['default']
    'ProjectPerformanceChart': typeof import("../layers/projects/components/ProjectPerformanceChart.vue")['default']
    'ProjectProfitabilityTable': typeof import("../layers/projects/components/ProjectProfitabilityTable.vue")['default']
    'ProjectStatusBadge': typeof import("../layers/projects/components/ProjectStatusBadge.vue")['default']
    'ProjectStatusChart': typeof import("../layers/projects/components/ProjectStatusChart.vue")['default']
    'SidebarProjectItem': typeof import("../layers/projects/components/SidebarProjectItem.vue")['default']
    'KanbanBoard': typeof import("../layers/tasks/components/KanbanBoard.vue")['default']
    'KanbanTaskCard': typeof import("../layers/tasks/components/KanbanTaskCard.vue")['default']
    'TaskCard': typeof import("../layers/tasks/components/TaskCard.vue")['default']
    'TaskDetails': typeof import("../layers/tasks/components/TaskDetails.vue")['default']
    'TaskList': typeof import("../layers/tasks/components/TaskList.vue")['default']
    'TaskModal': typeof import("../layers/tasks/components/TaskModal.vue")['default']
    'TaskPriorityBadge': typeof import("../layers/tasks/components/TaskPriorityBadge.vue")['default']
    'TaskPropertyBadge': typeof import("../layers/tasks/components/TaskPropertyBadge.vue")['default']
    'TaskStatusBadge': typeof import("../layers/tasks/components/TaskStatusBadge.vue")['default']
    'TimeDistributionChart': typeof import("../layers/timetracking/components/TimeDistributionChart.vue")['default']
    'TimeEntryList': typeof import("../layers/timetracking/components/TimeEntryList.vue")['default']
    'TimeEntryModal': typeof import("../layers/timetracking/components/TimeEntryModal.vue")['default']
    'TimeTrackingWidget': typeof import("../layers/timetracking/components/TimeTrackingWidget.vue")['default']
    'TimeTrendsChart': typeof import("../layers/timetracking/components/TimeTrendsChart.vue")['default']
    'TimerStartModal': typeof import("../layers/timetracking/components/TimerStartModal.vue")['default']
    'WeekTimesheet': typeof import("../layers/timetracking/components/WeekTimesheet.vue")['default']
    'ReportExportModal': typeof import("../layers/reports/components/ReportExportModal.vue")['default']
    'RevenueChart': typeof import("../layers/reports/components/RevenueChart.vue")['default']
    'AppNotifications': typeof import("../layers/notifications/components/AppNotifications.vue")['default']
    'NotificationsDropdown': typeof import("../layers/notifications/components/NotificationsDropdown.vue")['default']
    'SepaManagement': typeof import("../layers/financial/components/SepaManagement.vue")['default']
    'TicketComments': typeof import("../layers/tickets/components/TicketComments.vue")['default']
    'TicketConversionModal': typeof import("../layers/tickets/components/TicketConversionModal.vue")['default']
    'AttachmentCard': typeof import("../layers/admin/components/AttachmentCard.vue")['default']
    'AttachmentManager': typeof import("../layers/admin/components/AttachmentManager.vue")['default']
    'AttachmentPreviewModal': typeof import("../layers/admin/components/AttachmentPreviewModal.vue")['default']
    'BanUserForm': typeof import("../layers/admin/components/BanUserForm.vue")['default']
    'CreateUserForm': typeof import("../layers/admin/components/CreateUserForm.vue")['default']
    'EditUserForm': typeof import("../layers/admin/components/EditUserForm.vue")['default']
    'EnumCategoryModal': typeof import("../layers/admin/components/EnumCategoryModal.vue")['default']
    'EnumManagement': typeof import("../layers/admin/components/EnumManagement.vue")['default']
    'EnumValueModal': typeof import("../layers/admin/components/EnumValueModal.vue")['default']
    'ImpersonationBanner': typeof import("../layers/admin/components/ImpersonationBanner.vue")['default']
    'PdfViewer': typeof import("../layers/admin/components/PdfViewer.vue")['default']
    'UserSessionsView': typeof import("../layers/admin/components/UserSessionsView.vue")['default']
    'EnhancedTeamMemberCard': typeof import("../layers/team/components/EnhancedTeamMemberCard.vue")['default']
    'IndividualPerformanceTable': typeof import("../layers/team/components/IndividualPerformanceTable.vue")['default']
    'SkillDisplay': typeof import("../layers/team/components/SkillDisplay.vue")['default']
    'SkillLevelBadge': typeof import("../layers/team/components/SkillLevelBadge.vue")['default']
    'SkillMatrixOverview': typeof import("../layers/team/components/SkillMatrixOverview.vue")['default']
    'SkillModal': typeof import("../layers/team/components/SkillModal.vue")['default']
    'TeamActivity': typeof import("../layers/team/components/TeamActivity.vue")['default']
    'TeamBulkActions': typeof import("../layers/team/components/TeamBulkActions.vue")['default']
    'TeamMemberCard': typeof import("../layers/team/components/TeamMemberCard.vue")['default']
    'TeamWorkloadChart': typeof import("../layers/team/components/TeamWorkloadChart.vue")['default']
    'UserDetailModal': typeof import("../layers/team/components/UserDetailModal.vue")['default']
    'UserModal': typeof import("../layers/team/components/UserModal.vue")['default']
    'UserRoleBadge': typeof import("../layers/team/components/UserRoleBadge.vue")['default']
    'NuxtWelcome': typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
    'NuxtLayout': typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
    'NuxtErrorBoundary': typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
    'ClientOnly': typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
    'DevOnly': typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
    'ServerPlaceholder': typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'NuxtLink': typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
    'NuxtLoadingIndicator': typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
    'NuxtTime': typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
    'NuxtRouteAnnouncer': typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
    'NuxtImg': typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue")['default']
    'NuxtPicture': typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue")['default']
    'Icon': typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']
    'NuxtLinkLocale': typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale")['default']
    'SwitchLocalePathLink': typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/SwitchLocalePathLink")['default']
    'ColorScheme': typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue")['default']
    'NuxtPage': typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
    'NoScript': typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
    'Link': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
    'Base': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
    'Title': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
    'Meta': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
    'Style': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
    'Head': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
    'Html': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
    'Body': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
    'NuxtIsland': typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
    'NuxtRouteAnnouncer': IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
      'LazyActivityFeed': LazyComponent<typeof import("../components/ActivityFeed.vue")['default']>
    'LazyDashboardSection': LazyComponent<typeof import("../components/DashboardSection.vue")['default']>
    'LazyStatCard': LazyComponent<typeof import("../components/StatCard.vue")['default']>
    'LazyAppHeader': LazyComponent<typeof import("../layers/core/components/AppHeader.vue")['default']>
    'LazyAppLoadingOverlay': LazyComponent<typeof import("../layers/core/components/AppLoadingOverlay.vue")['default']>
    'LazyAppSidebar': LazyComponent<typeof import("../layers/core/components/AppSidebar.vue")['default']>
    'LazyColorModeToggle': LazyComponent<typeof import("../layers/core/components/ColorModeToggle.vue")['default']>
    'LazyConfirmDialog': LazyComponent<typeof import("../layers/core/components/ConfirmDialog.vue")['default']>
    'LazySidebarItem': LazyComponent<typeof import("../layers/core/components/SidebarItem.vue")['default']>
    'LazyUserMenu': LazyComponent<typeof import("../layers/core/components/UserMenu.vue")['default']>
    'LazyAuthLoadingScreen': LazyComponent<typeof import("../layers/auth/components/AuthLoadingScreen.vue")['default']>
    'LazyFastAuthLoader': LazyComponent<typeof import("../layers/auth/components/FastAuthLoader.vue")['default']>
    'LazyProjectCard': LazyComponent<typeof import("../layers/projects/components/ProjectCard.vue")['default']>
    'LazyProjectCardSkeleton': LazyComponent<typeof import("../layers/projects/components/ProjectCardSkeleton.vue")['default']>
    'LazyProjectDetailSkeleton': LazyComponent<typeof import("../layers/projects/components/ProjectDetailSkeleton.vue")['default']>
    'LazyProjectEnumSection': LazyComponent<typeof import("../layers/projects/components/ProjectEnumSection.vue")['default']>
    'LazyProjectEnumValueModal': LazyComponent<typeof import("../layers/projects/components/ProjectEnumValueModal.vue")['default']>
    'LazyProjectModal': LazyComponent<typeof import("../layers/projects/components/ProjectModal.vue")['default']>
    'LazyProjectOverview': LazyComponent<typeof import("../layers/projects/components/ProjectOverview.vue")['default']>
    'LazyProjectPerformanceChart': LazyComponent<typeof import("../layers/projects/components/ProjectPerformanceChart.vue")['default']>
    'LazyProjectProfitabilityTable': LazyComponent<typeof import("../layers/projects/components/ProjectProfitabilityTable.vue")['default']>
    'LazyProjectStatusBadge': LazyComponent<typeof import("../layers/projects/components/ProjectStatusBadge.vue")['default']>
    'LazyProjectStatusChart': LazyComponent<typeof import("../layers/projects/components/ProjectStatusChart.vue")['default']>
    'LazySidebarProjectItem': LazyComponent<typeof import("../layers/projects/components/SidebarProjectItem.vue")['default']>
    'LazyKanbanBoard': LazyComponent<typeof import("../layers/tasks/components/KanbanBoard.vue")['default']>
    'LazyKanbanTaskCard': LazyComponent<typeof import("../layers/tasks/components/KanbanTaskCard.vue")['default']>
    'LazyTaskCard': LazyComponent<typeof import("../layers/tasks/components/TaskCard.vue")['default']>
    'LazyTaskDetails': LazyComponent<typeof import("../layers/tasks/components/TaskDetails.vue")['default']>
    'LazyTaskList': LazyComponent<typeof import("../layers/tasks/components/TaskList.vue")['default']>
    'LazyTaskModal': LazyComponent<typeof import("../layers/tasks/components/TaskModal.vue")['default']>
    'LazyTaskPriorityBadge': LazyComponent<typeof import("../layers/tasks/components/TaskPriorityBadge.vue")['default']>
    'LazyTaskPropertyBadge': LazyComponent<typeof import("../layers/tasks/components/TaskPropertyBadge.vue")['default']>
    'LazyTaskStatusBadge': LazyComponent<typeof import("../layers/tasks/components/TaskStatusBadge.vue")['default']>
    'LazyTimeDistributionChart': LazyComponent<typeof import("../layers/timetracking/components/TimeDistributionChart.vue")['default']>
    'LazyTimeEntryList': LazyComponent<typeof import("../layers/timetracking/components/TimeEntryList.vue")['default']>
    'LazyTimeEntryModal': LazyComponent<typeof import("../layers/timetracking/components/TimeEntryModal.vue")['default']>
    'LazyTimeTrackingWidget': LazyComponent<typeof import("../layers/timetracking/components/TimeTrackingWidget.vue")['default']>
    'LazyTimeTrendsChart': LazyComponent<typeof import("../layers/timetracking/components/TimeTrendsChart.vue")['default']>
    'LazyTimerStartModal': LazyComponent<typeof import("../layers/timetracking/components/TimerStartModal.vue")['default']>
    'LazyWeekTimesheet': LazyComponent<typeof import("../layers/timetracking/components/WeekTimesheet.vue")['default']>
    'LazyReportExportModal': LazyComponent<typeof import("../layers/reports/components/ReportExportModal.vue")['default']>
    'LazyRevenueChart': LazyComponent<typeof import("../layers/reports/components/RevenueChart.vue")['default']>
    'LazyAppNotifications': LazyComponent<typeof import("../layers/notifications/components/AppNotifications.vue")['default']>
    'LazyNotificationsDropdown': LazyComponent<typeof import("../layers/notifications/components/NotificationsDropdown.vue")['default']>
    'LazySepaManagement': LazyComponent<typeof import("../layers/financial/components/SepaManagement.vue")['default']>
    'LazyTicketComments': LazyComponent<typeof import("../layers/tickets/components/TicketComments.vue")['default']>
    'LazyTicketConversionModal': LazyComponent<typeof import("../layers/tickets/components/TicketConversionModal.vue")['default']>
    'LazyAttachmentCard': LazyComponent<typeof import("../layers/admin/components/AttachmentCard.vue")['default']>
    'LazyAttachmentManager': LazyComponent<typeof import("../layers/admin/components/AttachmentManager.vue")['default']>
    'LazyAttachmentPreviewModal': LazyComponent<typeof import("../layers/admin/components/AttachmentPreviewModal.vue")['default']>
    'LazyBanUserForm': LazyComponent<typeof import("../layers/admin/components/BanUserForm.vue")['default']>
    'LazyCreateUserForm': LazyComponent<typeof import("../layers/admin/components/CreateUserForm.vue")['default']>
    'LazyEditUserForm': LazyComponent<typeof import("../layers/admin/components/EditUserForm.vue")['default']>
    'LazyEnumCategoryModal': LazyComponent<typeof import("../layers/admin/components/EnumCategoryModal.vue")['default']>
    'LazyEnumManagement': LazyComponent<typeof import("../layers/admin/components/EnumManagement.vue")['default']>
    'LazyEnumValueModal': LazyComponent<typeof import("../layers/admin/components/EnumValueModal.vue")['default']>
    'LazyImpersonationBanner': LazyComponent<typeof import("../layers/admin/components/ImpersonationBanner.vue")['default']>
    'LazyPdfViewer': LazyComponent<typeof import("../layers/admin/components/PdfViewer.vue")['default']>
    'LazyUserSessionsView': LazyComponent<typeof import("../layers/admin/components/UserSessionsView.vue")['default']>
    'LazyEnhancedTeamMemberCard': LazyComponent<typeof import("../layers/team/components/EnhancedTeamMemberCard.vue")['default']>
    'LazyIndividualPerformanceTable': LazyComponent<typeof import("../layers/team/components/IndividualPerformanceTable.vue")['default']>
    'LazySkillDisplay': LazyComponent<typeof import("../layers/team/components/SkillDisplay.vue")['default']>
    'LazySkillLevelBadge': LazyComponent<typeof import("../layers/team/components/SkillLevelBadge.vue")['default']>
    'LazySkillMatrixOverview': LazyComponent<typeof import("../layers/team/components/SkillMatrixOverview.vue")['default']>
    'LazySkillModal': LazyComponent<typeof import("../layers/team/components/SkillModal.vue")['default']>
    'LazyTeamActivity': LazyComponent<typeof import("../layers/team/components/TeamActivity.vue")['default']>
    'LazyTeamBulkActions': LazyComponent<typeof import("../layers/team/components/TeamBulkActions.vue")['default']>
    'LazyTeamMemberCard': LazyComponent<typeof import("../layers/team/components/TeamMemberCard.vue")['default']>
    'LazyTeamWorkloadChart': LazyComponent<typeof import("../layers/team/components/TeamWorkloadChart.vue")['default']>
    'LazyUserDetailModal': LazyComponent<typeof import("../layers/team/components/UserDetailModal.vue")['default']>
    'LazyUserModal': LazyComponent<typeof import("../layers/team/components/UserModal.vue")['default']>
    'LazyUserRoleBadge': LazyComponent<typeof import("../layers/team/components/UserRoleBadge.vue")['default']>
    'LazyNuxtWelcome': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
    'LazyNuxtLayout': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
    'LazyNuxtErrorBoundary': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
    'LazyClientOnly': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
    'LazyDevOnly': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
    'LazyServerPlaceholder': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyNuxtLink': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
    'LazyNuxtLoadingIndicator': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
    'LazyNuxtTime': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
    'LazyNuxtRouteAnnouncer': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
    'LazyNuxtImg': LazyComponent<typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue")['default']>
    'LazyNuxtPicture': LazyComponent<typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue")['default']>
    'LazyIcon': LazyComponent<typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']>
    'LazyNuxtLinkLocale': LazyComponent<typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale")['default']>
    'LazySwitchLocalePathLink': LazyComponent<typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/SwitchLocalePathLink")['default']>
    'LazyColorScheme': LazyComponent<typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue")['default']>
    'LazyNuxtPage': LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
    'LazyNoScript': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
    'LazyLink': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
    'LazyBase': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
    'LazyTitle': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
    'LazyMeta': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
    'LazyStyle': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
    'LazyHead': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
    'LazyHtml': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
    'LazyBody': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
    'LazyNuxtIsland': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>
    'LazyNuxtRouteAnnouncer': LazyComponent<IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>>
}

declare module 'vue' {
  export interface GlobalComponents extends _GlobalComponents { }
}

export const ActivityFeed: typeof import("../components/ActivityFeed.vue")['default']
export const DashboardSection: typeof import("../components/DashboardSection.vue")['default']
export const StatCard: typeof import("../components/StatCard.vue")['default']
export const AppHeader: typeof import("../layers/core/components/AppHeader.vue")['default']
export const AppLoadingOverlay: typeof import("../layers/core/components/AppLoadingOverlay.vue")['default']
export const AppSidebar: typeof import("../layers/core/components/AppSidebar.vue")['default']
export const ColorModeToggle: typeof import("../layers/core/components/ColorModeToggle.vue")['default']
export const ConfirmDialog: typeof import("../layers/core/components/ConfirmDialog.vue")['default']
export const SidebarItem: typeof import("../layers/core/components/SidebarItem.vue")['default']
export const UserMenu: typeof import("../layers/core/components/UserMenu.vue")['default']
export const AuthLoadingScreen: typeof import("../layers/auth/components/AuthLoadingScreen.vue")['default']
export const FastAuthLoader: typeof import("../layers/auth/components/FastAuthLoader.vue")['default']
export const ProjectCard: typeof import("../layers/projects/components/ProjectCard.vue")['default']
export const ProjectCardSkeleton: typeof import("../layers/projects/components/ProjectCardSkeleton.vue")['default']
export const ProjectDetailSkeleton: typeof import("../layers/projects/components/ProjectDetailSkeleton.vue")['default']
export const ProjectEnumSection: typeof import("../layers/projects/components/ProjectEnumSection.vue")['default']
export const ProjectEnumValueModal: typeof import("../layers/projects/components/ProjectEnumValueModal.vue")['default']
export const ProjectModal: typeof import("../layers/projects/components/ProjectModal.vue")['default']
export const ProjectOverview: typeof import("../layers/projects/components/ProjectOverview.vue")['default']
export const ProjectPerformanceChart: typeof import("../layers/projects/components/ProjectPerformanceChart.vue")['default']
export const ProjectProfitabilityTable: typeof import("../layers/projects/components/ProjectProfitabilityTable.vue")['default']
export const ProjectStatusBadge: typeof import("../layers/projects/components/ProjectStatusBadge.vue")['default']
export const ProjectStatusChart: typeof import("../layers/projects/components/ProjectStatusChart.vue")['default']
export const SidebarProjectItem: typeof import("../layers/projects/components/SidebarProjectItem.vue")['default']
export const KanbanBoard: typeof import("../layers/tasks/components/KanbanBoard.vue")['default']
export const KanbanTaskCard: typeof import("../layers/tasks/components/KanbanTaskCard.vue")['default']
export const TaskCard: typeof import("../layers/tasks/components/TaskCard.vue")['default']
export const TaskDetails: typeof import("../layers/tasks/components/TaskDetails.vue")['default']
export const TaskList: typeof import("../layers/tasks/components/TaskList.vue")['default']
export const TaskModal: typeof import("../layers/tasks/components/TaskModal.vue")['default']
export const TaskPriorityBadge: typeof import("../layers/tasks/components/TaskPriorityBadge.vue")['default']
export const TaskPropertyBadge: typeof import("../layers/tasks/components/TaskPropertyBadge.vue")['default']
export const TaskStatusBadge: typeof import("../layers/tasks/components/TaskStatusBadge.vue")['default']
export const TimeDistributionChart: typeof import("../layers/timetracking/components/TimeDistributionChart.vue")['default']
export const TimeEntryList: typeof import("../layers/timetracking/components/TimeEntryList.vue")['default']
export const TimeEntryModal: typeof import("../layers/timetracking/components/TimeEntryModal.vue")['default']
export const TimeTrackingWidget: typeof import("../layers/timetracking/components/TimeTrackingWidget.vue")['default']
export const TimeTrendsChart: typeof import("../layers/timetracking/components/TimeTrendsChart.vue")['default']
export const TimerStartModal: typeof import("../layers/timetracking/components/TimerStartModal.vue")['default']
export const WeekTimesheet: typeof import("../layers/timetracking/components/WeekTimesheet.vue")['default']
export const ReportExportModal: typeof import("../layers/reports/components/ReportExportModal.vue")['default']
export const RevenueChart: typeof import("../layers/reports/components/RevenueChart.vue")['default']
export const AppNotifications: typeof import("../layers/notifications/components/AppNotifications.vue")['default']
export const NotificationsDropdown: typeof import("../layers/notifications/components/NotificationsDropdown.vue")['default']
export const SepaManagement: typeof import("../layers/financial/components/SepaManagement.vue")['default']
export const TicketComments: typeof import("../layers/tickets/components/TicketComments.vue")['default']
export const TicketConversionModal: typeof import("../layers/tickets/components/TicketConversionModal.vue")['default']
export const AttachmentCard: typeof import("../layers/admin/components/AttachmentCard.vue")['default']
export const AttachmentManager: typeof import("../layers/admin/components/AttachmentManager.vue")['default']
export const AttachmentPreviewModal: typeof import("../layers/admin/components/AttachmentPreviewModal.vue")['default']
export const BanUserForm: typeof import("../layers/admin/components/BanUserForm.vue")['default']
export const CreateUserForm: typeof import("../layers/admin/components/CreateUserForm.vue")['default']
export const EditUserForm: typeof import("../layers/admin/components/EditUserForm.vue")['default']
export const EnumCategoryModal: typeof import("../layers/admin/components/EnumCategoryModal.vue")['default']
export const EnumManagement: typeof import("../layers/admin/components/EnumManagement.vue")['default']
export const EnumValueModal: typeof import("../layers/admin/components/EnumValueModal.vue")['default']
export const ImpersonationBanner: typeof import("../layers/admin/components/ImpersonationBanner.vue")['default']
export const PdfViewer: typeof import("../layers/admin/components/PdfViewer.vue")['default']
export const UserSessionsView: typeof import("../layers/admin/components/UserSessionsView.vue")['default']
export const EnhancedTeamMemberCard: typeof import("../layers/team/components/EnhancedTeamMemberCard.vue")['default']
export const IndividualPerformanceTable: typeof import("../layers/team/components/IndividualPerformanceTable.vue")['default']
export const SkillDisplay: typeof import("../layers/team/components/SkillDisplay.vue")['default']
export const SkillLevelBadge: typeof import("../layers/team/components/SkillLevelBadge.vue")['default']
export const SkillMatrixOverview: typeof import("../layers/team/components/SkillMatrixOverview.vue")['default']
export const SkillModal: typeof import("../layers/team/components/SkillModal.vue")['default']
export const TeamActivity: typeof import("../layers/team/components/TeamActivity.vue")['default']
export const TeamBulkActions: typeof import("../layers/team/components/TeamBulkActions.vue")['default']
export const TeamMemberCard: typeof import("../layers/team/components/TeamMemberCard.vue")['default']
export const TeamWorkloadChart: typeof import("../layers/team/components/TeamWorkloadChart.vue")['default']
export const UserDetailModal: typeof import("../layers/team/components/UserDetailModal.vue")['default']
export const UserModal: typeof import("../layers/team/components/UserModal.vue")['default']
export const UserRoleBadge: typeof import("../layers/team/components/UserRoleBadge.vue")['default']
export const NuxtWelcome: typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
export const NuxtLayout: typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
export const NuxtErrorBoundary: typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
export const ClientOnly: typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
export const DevOnly: typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
export const ServerPlaceholder: typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const NuxtLink: typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
export const NuxtLoadingIndicator: typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
export const NuxtTime: typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
export const NuxtRouteAnnouncer: typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
export const NuxtImg: typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue")['default']
export const NuxtPicture: typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue")['default']
export const Icon: typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']
export const NuxtLinkLocale: typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale")['default']
export const SwitchLocalePathLink: typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/SwitchLocalePathLink")['default']
export const ColorScheme: typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue")['default']
export const NuxtPage: typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
export const NoScript: typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
export const Link: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
export const Base: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
export const Title: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
export const Meta: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
export const Style: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
export const Head: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
export const Html: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
export const Body: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
export const NuxtIsland: typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
export const NuxtRouteAnnouncer: IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyActivityFeed: LazyComponent<typeof import("../components/ActivityFeed.vue")['default']>
export const LazyDashboardSection: LazyComponent<typeof import("../components/DashboardSection.vue")['default']>
export const LazyStatCard: LazyComponent<typeof import("../components/StatCard.vue")['default']>
export const LazyAppHeader: LazyComponent<typeof import("../layers/core/components/AppHeader.vue")['default']>
export const LazyAppLoadingOverlay: LazyComponent<typeof import("../layers/core/components/AppLoadingOverlay.vue")['default']>
export const LazyAppSidebar: LazyComponent<typeof import("../layers/core/components/AppSidebar.vue")['default']>
export const LazyColorModeToggle: LazyComponent<typeof import("../layers/core/components/ColorModeToggle.vue")['default']>
export const LazyConfirmDialog: LazyComponent<typeof import("../layers/core/components/ConfirmDialog.vue")['default']>
export const LazySidebarItem: LazyComponent<typeof import("../layers/core/components/SidebarItem.vue")['default']>
export const LazyUserMenu: LazyComponent<typeof import("../layers/core/components/UserMenu.vue")['default']>
export const LazyAuthLoadingScreen: LazyComponent<typeof import("../layers/auth/components/AuthLoadingScreen.vue")['default']>
export const LazyFastAuthLoader: LazyComponent<typeof import("../layers/auth/components/FastAuthLoader.vue")['default']>
export const LazyProjectCard: LazyComponent<typeof import("../layers/projects/components/ProjectCard.vue")['default']>
export const LazyProjectCardSkeleton: LazyComponent<typeof import("../layers/projects/components/ProjectCardSkeleton.vue")['default']>
export const LazyProjectDetailSkeleton: LazyComponent<typeof import("../layers/projects/components/ProjectDetailSkeleton.vue")['default']>
export const LazyProjectEnumSection: LazyComponent<typeof import("../layers/projects/components/ProjectEnumSection.vue")['default']>
export const LazyProjectEnumValueModal: LazyComponent<typeof import("../layers/projects/components/ProjectEnumValueModal.vue")['default']>
export const LazyProjectModal: LazyComponent<typeof import("../layers/projects/components/ProjectModal.vue")['default']>
export const LazyProjectOverview: LazyComponent<typeof import("../layers/projects/components/ProjectOverview.vue")['default']>
export const LazyProjectPerformanceChart: LazyComponent<typeof import("../layers/projects/components/ProjectPerformanceChart.vue")['default']>
export const LazyProjectProfitabilityTable: LazyComponent<typeof import("../layers/projects/components/ProjectProfitabilityTable.vue")['default']>
export const LazyProjectStatusBadge: LazyComponent<typeof import("../layers/projects/components/ProjectStatusBadge.vue")['default']>
export const LazyProjectStatusChart: LazyComponent<typeof import("../layers/projects/components/ProjectStatusChart.vue")['default']>
export const LazySidebarProjectItem: LazyComponent<typeof import("../layers/projects/components/SidebarProjectItem.vue")['default']>
export const LazyKanbanBoard: LazyComponent<typeof import("../layers/tasks/components/KanbanBoard.vue")['default']>
export const LazyKanbanTaskCard: LazyComponent<typeof import("../layers/tasks/components/KanbanTaskCard.vue")['default']>
export const LazyTaskCard: LazyComponent<typeof import("../layers/tasks/components/TaskCard.vue")['default']>
export const LazyTaskDetails: LazyComponent<typeof import("../layers/tasks/components/TaskDetails.vue")['default']>
export const LazyTaskList: LazyComponent<typeof import("../layers/tasks/components/TaskList.vue")['default']>
export const LazyTaskModal: LazyComponent<typeof import("../layers/tasks/components/TaskModal.vue")['default']>
export const LazyTaskPriorityBadge: LazyComponent<typeof import("../layers/tasks/components/TaskPriorityBadge.vue")['default']>
export const LazyTaskPropertyBadge: LazyComponent<typeof import("../layers/tasks/components/TaskPropertyBadge.vue")['default']>
export const LazyTaskStatusBadge: LazyComponent<typeof import("../layers/tasks/components/TaskStatusBadge.vue")['default']>
export const LazyTimeDistributionChart: LazyComponent<typeof import("../layers/timetracking/components/TimeDistributionChart.vue")['default']>
export const LazyTimeEntryList: LazyComponent<typeof import("../layers/timetracking/components/TimeEntryList.vue")['default']>
export const LazyTimeEntryModal: LazyComponent<typeof import("../layers/timetracking/components/TimeEntryModal.vue")['default']>
export const LazyTimeTrackingWidget: LazyComponent<typeof import("../layers/timetracking/components/TimeTrackingWidget.vue")['default']>
export const LazyTimeTrendsChart: LazyComponent<typeof import("../layers/timetracking/components/TimeTrendsChart.vue")['default']>
export const LazyTimerStartModal: LazyComponent<typeof import("../layers/timetracking/components/TimerStartModal.vue")['default']>
export const LazyWeekTimesheet: LazyComponent<typeof import("../layers/timetracking/components/WeekTimesheet.vue")['default']>
export const LazyReportExportModal: LazyComponent<typeof import("../layers/reports/components/ReportExportModal.vue")['default']>
export const LazyRevenueChart: LazyComponent<typeof import("../layers/reports/components/RevenueChart.vue")['default']>
export const LazyAppNotifications: LazyComponent<typeof import("../layers/notifications/components/AppNotifications.vue")['default']>
export const LazyNotificationsDropdown: LazyComponent<typeof import("../layers/notifications/components/NotificationsDropdown.vue")['default']>
export const LazySepaManagement: LazyComponent<typeof import("../layers/financial/components/SepaManagement.vue")['default']>
export const LazyTicketComments: LazyComponent<typeof import("../layers/tickets/components/TicketComments.vue")['default']>
export const LazyTicketConversionModal: LazyComponent<typeof import("../layers/tickets/components/TicketConversionModal.vue")['default']>
export const LazyAttachmentCard: LazyComponent<typeof import("../layers/admin/components/AttachmentCard.vue")['default']>
export const LazyAttachmentManager: LazyComponent<typeof import("../layers/admin/components/AttachmentManager.vue")['default']>
export const LazyAttachmentPreviewModal: LazyComponent<typeof import("../layers/admin/components/AttachmentPreviewModal.vue")['default']>
export const LazyBanUserForm: LazyComponent<typeof import("../layers/admin/components/BanUserForm.vue")['default']>
export const LazyCreateUserForm: LazyComponent<typeof import("../layers/admin/components/CreateUserForm.vue")['default']>
export const LazyEditUserForm: LazyComponent<typeof import("../layers/admin/components/EditUserForm.vue")['default']>
export const LazyEnumCategoryModal: LazyComponent<typeof import("../layers/admin/components/EnumCategoryModal.vue")['default']>
export const LazyEnumManagement: LazyComponent<typeof import("../layers/admin/components/EnumManagement.vue")['default']>
export const LazyEnumValueModal: LazyComponent<typeof import("../layers/admin/components/EnumValueModal.vue")['default']>
export const LazyImpersonationBanner: LazyComponent<typeof import("../layers/admin/components/ImpersonationBanner.vue")['default']>
export const LazyPdfViewer: LazyComponent<typeof import("../layers/admin/components/PdfViewer.vue")['default']>
export const LazyUserSessionsView: LazyComponent<typeof import("../layers/admin/components/UserSessionsView.vue")['default']>
export const LazyEnhancedTeamMemberCard: LazyComponent<typeof import("../layers/team/components/EnhancedTeamMemberCard.vue")['default']>
export const LazyIndividualPerformanceTable: LazyComponent<typeof import("../layers/team/components/IndividualPerformanceTable.vue")['default']>
export const LazySkillDisplay: LazyComponent<typeof import("../layers/team/components/SkillDisplay.vue")['default']>
export const LazySkillLevelBadge: LazyComponent<typeof import("../layers/team/components/SkillLevelBadge.vue")['default']>
export const LazySkillMatrixOverview: LazyComponent<typeof import("../layers/team/components/SkillMatrixOverview.vue")['default']>
export const LazySkillModal: LazyComponent<typeof import("../layers/team/components/SkillModal.vue")['default']>
export const LazyTeamActivity: LazyComponent<typeof import("../layers/team/components/TeamActivity.vue")['default']>
export const LazyTeamBulkActions: LazyComponent<typeof import("../layers/team/components/TeamBulkActions.vue")['default']>
export const LazyTeamMemberCard: LazyComponent<typeof import("../layers/team/components/TeamMemberCard.vue")['default']>
export const LazyTeamWorkloadChart: LazyComponent<typeof import("../layers/team/components/TeamWorkloadChart.vue")['default']>
export const LazyUserDetailModal: LazyComponent<typeof import("../layers/team/components/UserDetailModal.vue")['default']>
export const LazyUserModal: LazyComponent<typeof import("../layers/team/components/UserModal.vue")['default']>
export const LazyUserRoleBadge: LazyComponent<typeof import("../layers/team/components/UserRoleBadge.vue")['default']>
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue")['default']>
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue")['default']>
export const LazyIcon: LazyComponent<typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']>
export const LazyNuxtLinkLocale: LazyComponent<typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale")['default']>
export const LazySwitchLocalePathLink: LazyComponent<typeof import("../node_modules/@nuxtjs/i18n/dist/runtime/components/SwitchLocalePathLink")['default']>
export const LazyColorScheme: LazyComponent<typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue")['default']>
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
export const LazyLink: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
export const LazyBase: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
export const LazyTitle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
export const LazyMeta: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
export const LazyStyle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
export const LazyHead: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
export const LazyHtml: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
export const LazyBody: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>>

export const componentNames: string[]
