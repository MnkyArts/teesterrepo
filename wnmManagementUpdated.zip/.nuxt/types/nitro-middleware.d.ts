export type MiddlewareKey = "auth" | "customer" | "fast-auth" | "guest" | "staff"
declare module 'nitropack' {
  interface NitroRouteConfig {
    appMiddleware?: MiddlewareKey | MiddlewareKey[] | Record<MiddlewareKey, boolean>
  }
}