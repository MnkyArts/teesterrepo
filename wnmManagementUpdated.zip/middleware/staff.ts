export default defineNuxtRouteMiddleware(async (to, from) => {
  // Ensure Pinia is available before using stores
  if (process.client) {
    // Wait for app to be fully mounted on client side
    await nextTick()
  }
  
  let authStore, isLoggedIn, user, isInitialized, initializeAuth
  
  try {
    authStore = useAuthStore()
    const refs = storeToRefs(authStore)
    isLoggedIn = refs.isLoggedIn
    user = refs.user
    isInitialized = refs.isInitialized
    initializeAuth = authStore.initializeAuth
    
    // Auf Server-Seite: Kein sofortiger Redirect, SSR übernimmt
    if (process.server) {
      return
    }
    
    // Auf Client-Seite: Optimierte Authentifizierung prüfen
    if (!isInitialized.value) {
      await initializeAuth()
    }
  } catch (error) {
    console.warn('Auth store not available in middleware, navigation will continue')
    return
  }
  
  // Nur weiterleiten wenn definitiv nicht eingeloggt
  if (!isLoggedIn.value) {
    return navigateTo('/auth/login', { replace: true })
  }
  
  // Wenn Benutzer ein Kunde ist, zum Kundenbereich weiterleiten
  if (user.value?.role === 'KUNDE') {
    return navigateTo('/customer', { replace: true })
  }
})
