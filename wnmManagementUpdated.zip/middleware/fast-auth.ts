/**
 * Performance-optimized auth middleware
 * Cached checks und minimale Redirects für bessere UX
 */

// Cache für Auth-Status um wiederholte Checks zu vermeiden
let authCache: { 
  isLoggedIn: boolean | null
  role: string | null
  lastCheck: number
} = {
  isLoggedIn: null,
  role: null,
  lastCheck: 0
}

const CACHE_DURATION = 1000 // 1 Sekunde Cache für Auth-Status

export default defineNuxtRouteMiddleware(async (to, from) => {
  // Ensure Pinia is available before using stores
  if (process.client) {
    await nextTick()
  }
  
  let authStore, isLoggedIn, user, isInitialized, initializeAuth
  
  try {
    authStore = useAuthStore()
    const refs = storeToRefs(authStore)
    isLoggedIn = refs.isLoggedIn
    user = refs.user
    isInitialized = refs.isInitialized
    initializeAuth = authStore.initializeAuth
    
    // Server-side: Kein Redirect
    if (process.server) {
      return
    }
  } catch (error) {
    console.warn('Auth store not available in fast-auth middleware, navigation will continue')
    return
  }
  
  // Cache-Check für bessere Performance
  const now = Date.now()
  const cacheValid = (now - authCache.lastCheck) < CACHE_DURATION
  
  if (cacheValid && authCache.isLoggedIn !== null) {
    // Verwende gecachten Status
    if (!authCache.isLoggedIn) {
      return navigateTo('/auth/login', { replace: true })
    }
    return // User ist eingeloggt, weiter
  }
  
  // Auth initialisieren falls nötig
  if (!isInitialized.value) {
    await initializeAuth()
  }
  
  // Cache aktualisieren
  authCache = {
    isLoggedIn: isLoggedIn.value,
    role: user.value?.role || null,
    lastCheck: now
  }
  
  // Auth-Check
  if (!isLoggedIn.value) {
    return navigateTo('/auth/login', { replace: true })
  }
})
