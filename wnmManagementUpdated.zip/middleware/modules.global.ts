import { modulesConfig, isModuleEnabled } from '~/modules.config'

// Dynamically generate route-to-module mapping based on module config
const routeToModuleMap: Record<string, string> = Object.keys(modulesConfig).reduce((map, moduleKey) => {
  // Convert module key to route (e.g., 'timetracking' -> '/timetracking')
  map[`/${moduleKey}`] = moduleKey
  return map
}, {} as Record<string, string>)

export default defineNuxtRouteMiddleware((to) => {
  // Skip module checks for API routes and static assets
  if (to.path.startsWith('/api') || to.path.startsWith('/_') || to.path.startsWith('/public')) {
    return
  }

  // Check if the route belongs to a specific module
  for (const [routePrefix, moduleName] of Object.entries(routeToModuleMap)) {
    if (to.path.startsWith(routePrefix)) {
      // Check if the module is enabled
      if (!isModuleEnabled(moduleName)) {
        // Return 404 for disabled modules
        throw createError({
          statusCode: 404,
          statusMessage: `Module "${moduleName}" is currently disabled`
        })
      }
      break
    }
  }
})
