export default defineNuxtRouteMiddleware(async (to, from) => {
  // Ensure Pinia is available before using stores
  if (process.client) {
    await nextTick()
  }
  
  let authStore, isLoggedIn, user, isInitialized, initializeAuth
  
  try {
    authStore = useAuthStore()
    const refs = storeToRefs(authStore)
    isLoggedIn = refs.isLoggedIn
    user = refs.user
    isInitialized = refs.isInitialized
    initializeAuth = authStore.initializeAuth
    
    // Auf Server-Seite: Kein sofortiger Redirect, SSR übernimmt
    if (process.server) {
      return
    }
    
    // Auf Client-Seite: Optimierte Authentifizierung prüfen
    if (!isInitialized.value) {
      await initializeAuth()
    }
  } catch (error) {
    console.warn('Auth store not available in customer middleware, navigation will continue')
    return
  }
  
  // Nur weiterleiten wenn definitiv nicht eingeloggt
  if (!isLoggedIn.value) {
    return navigateTo('/auth/login', { replace: true })
  }
  
  // Wenn Benutzer kein Kunde ist, zum Haupt-Dashboard weiterleiten
  if (user.value?.role !== 'KUNDE') {
    return navigateTo('/', { replace: true })
  }
})
