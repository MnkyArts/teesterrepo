export default defineNuxtRouteMiddleware(async (to, from) => {
  // Ensure Pinia is available before using stores
  if (process.client) {
    await nextTick()
  }
  
  let authStore, isLoggedIn, isInitialized, initializeAuth
  
  try {
    authStore = useAuthStore()
    const refs = storeToRefs(authStore)
    isLoggedIn = refs.isLoggedIn
    isInitialized = refs.isInitialized
    initializeAuth = authStore.initializeAuth
    
    // Auf Server-Seite: Kein Redirect (SSR für Auth-Seiten)
    if (process.server) {
      return
    }
    
    // Auf Client-Seite: Authentifizierung prüfen
    if (!isInitialized.value) {
      await initializeAuth()
    }
  } catch (error) {
    console.warn('Auth store not available in guest middleware, navigation will continue')
    return
  }
  
  // If user is already logged in, redirect to dashboard
  if (isLoggedIn.value) {
    return navigateTo('/')
  }
})
