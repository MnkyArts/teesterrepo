export default defineNuxtRouteMiddleware(async (to, from) => {
  // Ensure Pinia is available before using stores
  if (process.client) {
    await nextTick()
  }
  
  let authStore, isLoggedIn, isInitialized, initializeAuth
  
  try {
    authStore = useAuthStore()
    const refs = storeToRefs(authStore)
    isLoggedIn = refs.isLoggedIn
    isInitialized = refs.isInitialized
    initializeAuth = authStore.initializeAuth
    
    // Auf Server-Seite: Kein sofortiger Redirect, SSR übernimmt
    if (process.server) {
      return
    }
    
    // Auf Client-Seite: Optimierte Authentifizierung prüfen
    if (!isInitialized.value) {
      // Zeige Loading-State während Auth-Initialisierung
      await initializeAuth()
    }
  } catch (error) {
    console.warn('Auth store not available in auth middleware, navigation will continue')
    return
  }
  
  // Nur weiterleiten wenn definitiv nicht eingeloggt
  if (!isLoggedIn.value) {
    return navigateTo('/auth/login', { replace: true })
  }
})
