import { z } from 'zod'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

// Validation schemas
const createCategorySchema = z.object({
  name: z.string().min(1).max(50).regex(/^[a-z_]+$/),
  label: z.string().min(1).max(100),
  description: z.string().optional(),
  isSystem: z.boolean().optional().default(false),
  sortOrder: z.number().int().min(0).optional().default(0)
})

export default defineEventHandler(async (event) => {
  try {
    const method = getMethod(event)

    switch (method) {
      case 'GET':
        return await handleGetCategories(event)
      case 'POST':
        return await handleCreateCategory(event)
      default:
        throw createError({
          statusCode: 405,
          statusMessage: 'Method Not Allowed'
        })
    }
  } catch (error: any) {
    console.error('Enum Categories API Error:', error)
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || error.message || 'Internal Server Error'
    })
  }
})

async function handleGetCategories(event: any) {
  const query = getQuery(event)
  const includeValues = query.includeValues === 'true'

  const categories = await prisma.enumCategory.findMany({
    include: {
      values: includeValues ? {
        where: {
          projectId: null // Only include global enum values
        },
        orderBy: { sortOrder: 'asc' }
      } : false
    },
    orderBy: { sortOrder: 'asc' }
  })

  return categories
}

async function handleCreateCategory(event: any) {
  const body = await readBody(event)
  const validatedData = createCategorySchema.parse(body)

  // Check if category name already exists
  const existingCategory = await prisma.enumCategory.findUnique({
    where: { name: validatedData.name }
  })

  if (existingCategory) {
    throw createError({
      statusCode: 409,
      statusMessage: `Enum-Kategorie mit Name '${validatedData.name}' existiert bereits`
    })
  }

  const category = await prisma.enumCategory.create({
    data: {
      id: `${validatedData.name}_cat`,
      ...validatedData
    }
  })

  // Log activity
  // await logActivity({
  //   userId: event.context.user?.id,
  //   action: 'enum_category_created',
  //   description: `Enum-Kategorie '${category.label}' erstellt`,
  //   details: { categoryId: category.id }
  // })

  return category
}
