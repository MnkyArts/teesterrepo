import { z } from 'zod'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

// Validation schema
const updateCategorySchema = z.object({
  label: z.string().min(1).max(100).optional(),
  description: z.string().optional(),
  sortOrder: z.number().int().min(0).optional()
})

export default defineEventHandler(async (event) => {
  try {
    const method = getMethod(event)
    const categoryId = getRouterParam(event, 'id')

    if (!categoryId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Kategorie-ID erforderlich'
      })
    }

    switch (method) {
      case 'GET':
        return await handleGetCategory(categoryId)
      case 'PUT':
        return await handleUpdateCategory(event, categoryId)
      case 'DELETE':
        return await handleDeleteCategory(event, categoryId)
      default:
        throw createError({
          statusCode: 405,
          statusMessage: 'Method Not Allowed'
        })
    }
  } catch (error: any) {
    console.error('Enum Category API Error:', error)
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || error.message || 'Internal Server Error'
    })
  }
})

async function handleGetCategory(categoryId: string) {
  const category = await prisma.enumCategory.findUnique({
    where: { id: categoryId },
    include: {
      values: {
        orderBy: { sortOrder: 'asc' }
      }
    }
  })

  if (!category) {
    throw createError({
      statusCode: 404,
      statusMessage: 'Enum-Kategorie nicht gefunden'
    })
  }

  return category
}

async function handleUpdateCategory(event: any, categoryId: string) {
  const body = await readBody(event)
  const validatedData = updateCategorySchema.parse(body)

  // Check if category exists
  const existingCategory = await prisma.enumCategory.findUnique({
    where: { id: categoryId }
  })

  if (!existingCategory) {
    throw createError({
      statusCode: 404,
      statusMessage: 'Enum-Kategorie nicht gefunden'
    })
  }

  // Prevent modification of system categories
  if (existingCategory.isSystem && Object.keys(validatedData).some(key => key !== 'sortOrder')) {
    throw createError({
      statusCode: 403,
      statusMessage: 'System-Kategorien können nicht bearbeitet werden'
    })
  }

  const updatedCategory = await prisma.enumCategory.update({
    where: { id: categoryId },
    data: validatedData
  })

  // Log activity
  // await logActivity({
  //   userId: event.context.user?.id,
  //   action: 'enum_category_updated',
  //   description: `Enum-Kategorie '${updatedCategory.label}' aktualisiert`,
  //   details: { categoryId: updatedCategory.id, changes: validatedData }
  // })

  return updatedCategory
}

async function handleDeleteCategory(event: any, categoryId: string) {
  // Check if category exists
  const existingCategory = await prisma.enumCategory.findUnique({
    where: { id: categoryId },
    include: {
      values: true
    }
  })

  if (!existingCategory) {
    throw createError({
      statusCode: 404,
      statusMessage: 'Enum-Kategorie nicht gefunden'
    })
  }

  // Prevent deletion of system categories
  if (existingCategory.isSystem) {
    throw createError({
      statusCode: 403,
      statusMessage: 'System-Kategorien können nicht gelöscht werden'
    })
  }

  // Check if any values are currently in use
  const isInUse = await checkCategoryInUse(categoryId)
  if (isInUse) {
    throw createError({
      statusCode: 409,
      statusMessage: 'Kategorie wird noch verwendet und kann nicht gelöscht werden'
    })
  }

  await prisma.enumCategory.delete({
    where: { id: categoryId }
  })

  // Log activity
  // await logActivity({
  //   userId: event.context.user?.id,
  //   action: 'enum_category_deleted',
  //   description: `Enum-Kategorie '${existingCategory.label}' gelöscht`,
  //   details: { categoryId: existingCategory.id }
  // })

  return { success: true }
}

async function checkCategoryInUse(categoryId: string): Promise<boolean> {
  const category = await prisma.enumCategory.findUnique({
    where: { id: categoryId },
    select: { name: true }
  })

  if (!category) return false

  // Check based on category name
  switch (category.name) {
    case 'task_type':
      const tasksWithType = await prisma.task.count({
        where: { 
          type: { 
            categoryId: categoryId 
          } 
        }
      })
      return tasksWithType > 0

    case 'priority':
      const tasksWithPriority = await prisma.task.count({
        where: { 
          priority: { 
            categoryId: categoryId 
          } 
        }
      })
      const ticketsWithPriority = await prisma.ticket.count({
        where: { 
          priority: { 
            categoryId: categoryId 
          } 
        }
      })
      return tasksWithPriority > 0 || ticketsWithPriority > 0

    case 'task_status':
      const tasksWithStatus = await prisma.task.count({
        where: { 
          status: { 
            categoryId: categoryId 
          } 
        }
      })
      return tasksWithStatus > 0

    case 'ticket_type':
      const ticketsWithType = await prisma.ticket.count({
        where: { 
          type: { 
            categoryId: categoryId 
          } 
        }
      })
      return ticketsWithType > 0

    case 'ticket_status':
      const ticketsWithStatus = await prisma.ticket.count({
        where: { 
          status: { 
            categoryId: categoryId 
          } 
        }
      })
      return ticketsWithStatus > 0

    default:
      return false
  }
}
