import { z } from 'zod'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

// Validation schema
const updateValueSchema = z.object({
  label: z.string().min(1).max(100).optional(),
  description: z.string().optional(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
  icon: z.string().max(50).optional(),
  isDefault: z.boolean().optional(),
  sortOrder: z.number().int().min(0).optional(),
  isActive: z.boolean().optional()
})

export default defineEventHandler(async (event) => {
  try {
    const method = getMethod(event)
    const valueId = getRouterParam(event, 'id')

    if (!valueId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Enum-Wert-ID erforderlich'
      })
    }

    switch (method) {
      case 'GET':
        return await handleGetValue(valueId)
      case 'PUT':
        return await handleUpdateValue(event, valueId)
      case 'DELETE':
        return await handleDeleteValue(event, valueId)
      default:
        throw createError({
          statusCode: 405,
          statusMessage: 'Method Not Allowed'
        })
    }
  } catch (error: any) {
    console.error('Enum Value API Error:', error)
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || error.message || 'Internal Server Error'
    })
  }
})

async function handleGetValue(valueId: string) {
  const value = await prisma.enumValue.findUnique({
    where: { id: valueId },
    include: {
      category: true
    }
  })

  if (!value) {
    throw createError({
      statusCode: 404,
      statusMessage: 'Enum-Wert nicht gefunden'
    })
  }

  return value
}

async function handleUpdateValue(event: any, valueId: string) {
  const body = await readBody(event)
  const validatedData = updateValueSchema.parse(body)

  // Check if value exists
  const existingValue = await prisma.enumValue.findUnique({
    where: { id: valueId },
    include: { category: true }
  })

  if (!existingValue) {
    throw createError({
      statusCode: 404,
      statusMessage: 'Enum-Wert nicht gefunden'
    })
  }

  // If setting as default, unset other defaults in the same category
  if (validatedData.isDefault) {
    await prisma.enumValue.updateMany({
      where: {
        categoryId: existingValue.categoryId,
        isDefault: true,
        id: { not: valueId }
      },
      data: { isDefault: false }
    })
  }

  const updatedValue = await prisma.enumValue.update({
    where: { id: valueId },
    data: validatedData
  })

  // Log activity
  // await logActivity({
  //   userId: event.context.user?.id,
  //   action: 'enum_value_updated',
  //   description: `Enum-Wert '${updatedValue.label}' aktualisiert`,
  //   details: { valueId: updatedValue.id, changes: validatedData }
  // })

  return updatedValue
}

async function handleDeleteValue(event: any, valueId: string) {
  const query = getQuery(event)
  const projectId = query.projectId as string | undefined

  // Check if value exists
  const existingValue = await prisma.enumValue.findUnique({
    where: { id: valueId },
    include: { category: true }
  })

  if (!existingValue) {
    throw createError({
      statusCode: 404,
      statusMessage: 'Enum-Wert nicht gefunden'
    })
  }

  // Only allow deletion of project-specific values or check usage for global values
  if (existingValue.projectId) {
    // Project-specific value - check if user has permission for this project
    if (projectId && existingValue.projectId !== projectId) {
      throw createError({
        statusCode: 403,
        statusMessage: 'Keine Berechtigung zum Löschen dieses Werts'
      })
    }
  } else {
    // Global value - check if it's in use
    const isInUse = await checkValueInUse(valueId, existingValue.category.name)
    if (isInUse) {
      throw createError({
        statusCode: 409,
        statusMessage: 'Enum-Wert wird noch verwendet und kann nicht gelöscht werden'
      })
    }
  }

  await prisma.enumValue.delete({
    where: { id: valueId }
  })

  // Log activity
  // await logActivity({
  //   userId: event.context.user?.id,
  //   action: 'enum_value_deleted',
  //   description: `Enum-Wert '${existingValue.label}' gelöscht`,
  //   details: { 
  //     valueId: existingValue.id, 
  //     categoryId: existingValue.categoryId,
  //     projectId: existingValue.projectId
  //   }
  // })

  return { success: true }
}

async function checkValueInUse(valueId: string, categoryName: string): Promise<boolean> {
  // Check based on category name
  switch (categoryName) {
    case 'task_type':
      const tasksWithType = await prisma.task.count({
        where: { typeId: valueId }
      })
      return tasksWithType > 0

    case 'priority':
      const tasksWithPriority = await prisma.task.count({
        where: { priorityId: valueId }
      })
      const ticketsWithPriority = await prisma.ticket.count({
        where: { priorityId: valueId }
      })
      return tasksWithPriority > 0 || ticketsWithPriority > 0

    case 'task_status':
      const tasksWithStatus = await prisma.task.count({
        where: { statusId: valueId }
      })
      return tasksWithStatus > 0

    case 'ticket_type':
      const ticketsWithType = await prisma.ticket.count({
        where: { typeId: valueId }
      })
      return ticketsWithType > 0

    case 'ticket_status':
      const ticketsWithStatus = await prisma.ticket.count({
        where: { statusId: valueId }
      })
      return ticketsWithStatus > 0

    default:
      return false
  }
}
