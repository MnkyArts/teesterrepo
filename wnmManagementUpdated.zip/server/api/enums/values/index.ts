import { z } from 'zod'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

// Validation schemas
const createValueSchema = z.object({
  categoryId: z.string().min(1),
  projectId: z.string().optional(), // Support for project-specific enums
  key: z.string().min(1).max(50).regex(/^[A-Z_]+$/),
  label: z.string().min(1).max(100),
  description: z.string().optional(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
  icon: z.string().max(50).optional(),
  isDefault: z.boolean().optional().default(false),
  sortOrder: z.number().int().min(0).optional()
})

const filtersSchema = z.object({
  categoryId: z.string().optional(),
  projectId: z.string().optional(), // Filter by project
  isActive: z.enum(['true', 'false']).optional(),
  search: z.string().optional()
})

export default defineEventHandler(async (event) => {
  try {
    const method = getMethod(event)

    switch (method) {
      case 'GET':
        return await handleGetValues(event)
      case 'POST':
        return await handleCreateValue(event)
      default:
        throw createError({
          statusCode: 405,
          statusMessage: 'Method Not Allowed'
        })
    }
  } catch (error: any) {
    console.error('Enum Values API Error:', error)
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || error.message || 'Internal Server Error'
    })
  }
})

async function handleGetValues(event: any) {
  const query = getQuery(event)
  const filters = filtersSchema.parse(query)

  const whereClause: any = {}

  if (filters.categoryId) {
    whereClause.categoryId = filters.categoryId
  }

  if (filters.projectId !== undefined) {
    // If projectId is provided, include both global (null) and project-specific values
    if (filters.projectId === '') {
      whereClause.projectId = null // Only global values
    } else {
      whereClause.OR = [
        { projectId: null }, // Global values
        { projectId: filters.projectId } // Project-specific values
      ]
    }
  }

  if (filters.isActive !== undefined) {
    whereClause.isActive = filters.isActive === 'true'
  }

  if (filters.search) {
    const searchCondition = {
      OR: [
        { label: { contains: filters.search, mode: 'insensitive' } },
        { key: { contains: filters.search, mode: 'insensitive' } },
        { description: { contains: filters.search, mode: 'insensitive' } }
      ]
    }
    
    if (whereClause.OR) {
      // Combine with existing OR conditions
      whereClause.AND = [
        { OR: whereClause.OR },
        searchCondition
      ]
      delete whereClause.OR
    } else {
      Object.assign(whereClause, searchCondition)
    }
  }

  const values = await prisma.enumValue.findMany({
    where: whereClause,
    include: {
      category: true,
      project: true // Include project info for project-specific values
    },
    orderBy: [
      { category: { sortOrder: 'asc' } },
      { projectId: 'asc' }, // Global values first, then project-specific
      { sortOrder: 'asc' }
    ]
  })

  return values
}

async function handleCreateValue(event: any) {
  const body = await readBody(event)
  const validatedData = createValueSchema.parse(body)

  // Check if category exists
  const category = await prisma.enumCategory.findUnique({
    where: { id: validatedData.categoryId }
  })

  if (!category) {
    throw createError({
      statusCode: 404,
      statusMessage: 'Enum-Kategorie nicht gefunden'
    })
  }

  // If projectId is provided, check if project exists
  if (validatedData.projectId) {
    const project = await prisma.project.findUnique({
      where: { id: validatedData.projectId }
    })

    if (!project) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Projekt nicht gefunden'
      })
    }
  }

  // Check if key already exists in this category and project scope
  const existingValue = await prisma.enumValue.findFirst({
    where: {
      categoryId: validatedData.categoryId,
      key: validatedData.key,
      projectId: validatedData.projectId || null
    }
  })

  if (existingValue) {
    const scope = validatedData.projectId ? 'diesem Projekt' : 'global'
    throw createError({
      statusCode: 409,
      statusMessage: `Enum-Wert mit Schlüssel '${validatedData.key}' existiert bereits in dieser Kategorie (${scope})`
    })
  }

  // If this is set as default, unset other defaults in the same category and project scope
  if (validatedData.isDefault) {
    await prisma.enumValue.updateMany({
      where: {
        categoryId: validatedData.categoryId,
        projectId: validatedData.projectId || null,
        isDefault: true
      },
      data: { isDefault: false }
    })
  }

  // Set sort order if not provided
  if (validatedData.sortOrder === undefined) {
    const maxSortOrder = await prisma.enumValue.aggregate({
      where: { 
        categoryId: validatedData.categoryId,
        projectId: validatedData.projectId || null
      },
      _max: { sortOrder: true }
    })
    validatedData.sortOrder = (maxSortOrder._max.sortOrder || 0) + 1
  }

  const value = await prisma.enumValue.create({
    data: {
      id: validatedData.projectId 
        ? `${category.name}_${validatedData.key.toLowerCase()}_${validatedData.projectId}`
        : `${category.name}_${validatedData.key.toLowerCase()}`,
      projectId: validatedData.projectId || null,
      ...validatedData
    }
  })

  // Log activity
  // await logActivity({
  //   userId: event.context.user?.id,
  //   action: 'enum_value_created',
  //   description: `Enum-Wert '${value.label}' in Kategorie '${category.label}' erstellt`,
  //   details: { valueId: value.id, categoryId: category.id }
  // })

  return value
}
