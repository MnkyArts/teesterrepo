import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'
import { z } from 'zod'

const bulkActionSchema = z.object({
  action: z.enum(['activate', 'deactivate', 'change_role', 'delete']),
  userIds: z.array(z.string().cuid()),
  data: z.object({
    role: z.enum(['ADMINISTRATOR', 'PROJEKTLEITER', 'ENTWICKLER', 'SUPPORTER', 'VIEWER']).optional(),
    isActive: z.boolean().optional()
  }).optional()
})

export default defineEventHandler(async (event) => {
  try {
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Nicht authentifiziert'
      })
    }

    // Berechtigung prüfen - nur Administratoren können Bulk-Aktionen durchführen
    if (user.role !== 'ADMINISTRATOR') {
      throw createError({
        statusCode: 403,
        statusMessage: 'Keine Berechtigung für Bulk-Aktionen'
      })
    }

    const body = await readBody(event)
    const { action, userIds, data } = bulkActionSchema.parse(body)

    // Prüfen ob Benutzer existieren
    const existingUsers = await prisma.user.findMany({
      where: {
        id: { in: userIds },
        role: { not: 'KUNDE' } // Keine Kunden bearbeiten
      },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        role: true,
        isActive: true
      }
    })

    if (existingUsers.length !== userIds.length) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Einige Benutzer wurden nicht gefunden oder können nicht bearbeitet werden'
      })
    }

    // Admin-Protection: Admin kann nicht selbst verändert werden
    const isTargetingAdmin = existingUsers.some(u => u.id === user.id)
    if (isTargetingAdmin && (action === 'deactivate' || action === 'delete' || 
        (action === 'change_role' && data?.role !== 'ADMINISTRATOR'))) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Administrator kann sich nicht selbst deaktivieren oder degradieren'
      })
    }

    let updateData: any = {}
    let actionDescription = ''

    switch (action) {
      case 'activate':
        updateData = { isActive: true }
        actionDescription = 'aktiviert'
        break
      
      case 'deactivate':
        updateData = { isActive: false }
        actionDescription = 'deaktiviert'
        break
      
      case 'change_role':
        if (!data?.role) {
          throw createError({
            statusCode: 400,
            statusMessage: 'Rolle ist erforderlich für Rollen-Änderung'
          })
        }
        updateData = { role: data.role }
        actionDescription = `Rolle geändert zu ${data.role}`
        break
      
      case 'delete':
        // Soft delete - wir setzen nur isActive auf false
        updateData = { isActive: false }
        actionDescription = 'gelöscht (deaktiviert)'
        break
    }

    // Bulk-Update durchführen
    await prisma.user.updateMany({
      where: {
        id: { in: userIds }
      },
      data: updateData
    })

    // Aktivitätslogs für alle Benutzer erstellen
    const activityLogs = existingUsers.map(targetUser => ({
      action: `bulk_user_${action}`,
      description: `Benutzer ${targetUser.firstName} ${targetUser.lastName} (${targetUser.email}) ${actionDescription}`,
      details: {
        bulkAction: action,
        targetUserId: targetUser.id,
        previousData: {
          role: targetUser.role,
          isActive: targetUser.isActive
        },
        newData: updateData
      },
      userId: user.id
    }))

    await prisma.activityLog.createMany({
      data: activityLogs
    })

    return {
      success: true,
      affectedUsers: existingUsers.length,
      action: actionDescription,
      message: `${existingUsers.length} Benutzer erfolgreich ${actionDescription}`
    }

  } catch (error: any) {
    console.error('Fehler bei Bulk-Aktion:', error)
    
    if (error.statusCode) {
      throw error
    }

    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Server-Fehler'
    })
  }
})
