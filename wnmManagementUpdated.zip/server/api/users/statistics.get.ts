import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  try {
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Nicht authentifiziert'
      })
    }

    // Berechtigung prüfen
    if (user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER') {
      throw createError({
        statusCode: 403,
        statusMessage: 'Keine Berechtigung für Team-Statistiken'
      })
    }

    // Gesamt-Statistiken laden
    const [
      totalUsers,
      activeUsers,
      usersByRole,
      recentActivity
    ] = await Promise.all([
      // Gesamtanzahl Benutzer
      prisma.user.count({
        where: { role: { not: 'KUNDE' } }
      }),

      // Aktive Benutzer
      prisma.user.count({
        where: { 
          isActive: true,
          role: { not: 'KUNDE' }
        }
      }),

      // Benutzer nach Rollen
      prisma.user.groupBy({
        by: ['role'],
        where: { role: { not: 'KUNDE' } },
        _count: true
      }),

      // Kürzliche Aktivitäten (letzte 30 Tage)
      prisma.user.count({
        where: {
          lastLoginAt: {
            gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
          },
          role: { not: 'KUNDE' }
        }
      })
    ])

    // Rollen-Verteilung formatieren
    const roleDistribution: Record<string, number> = {
      ADMINISTRATOR: 0,
      PROJEKTLEITER: 0,
      ENTWICKLER: 0,
      SUPPORTER: 0,
      VIEWER: 0
    }

    usersByRole.forEach(roleGroup => {
      if (roleGroup.role !== 'KUNDE') {
        roleDistribution[roleGroup.role] = roleGroup._count
      }
    })

    // Task-Auslastung berechnen
    const usersWithTasks = await prisma.user.findMany({
      where: { 
        isActive: true,
        role: { not: 'KUNDE' }
      },
      select: {
        id: true,
        _count: {
          select: {
            assignedTasks: {
              where: {
                status: {
                  key: {
                    in: ['GEPLANT', 'TECHNISCHES_DESIGN', 'IN_BEARBEITUNG', 'REVIEW', 'TESTING']
                  }
                }
              }
            }
          }
        }
      }
    })

    const totalActiveTasks = usersWithTasks.reduce((sum, user) => 
      sum + user._count.assignedTasks, 0
    )
    const averageWorkload = activeUsers > 0 ? totalActiveTasks / activeUsers : 0

    // Online-Status (simuliert - in echter Anwendung würde man WebSocket/Session-Daten verwenden)
    const onlineMembers = Math.floor(activeUsers * 0.7) // Simuliert 70% online

    const statistics = {
      totalMembers: totalUsers,
      activeMembers: activeUsers,
      onlineMembers,
      averageWorkload: Math.round(averageWorkload * 10) / 10,
      recentlyActive: recentActivity,
      roleDistribution,
      // Skill-Verteilung (placeholder - würde aus UserSkill-Tabelle kommen)
      skillDistribution: {
        'Frontend': Math.floor(totalUsers * 0.6),
        'Backend': Math.floor(totalUsers * 0.8),
        'Database': Math.floor(totalUsers * 0.4),
        'DevOps': Math.floor(totalUsers * 0.3),
        'Testing': Math.floor(totalUsers * 0.5)
      }
    }

    return statistics

  } catch (error: any) {
    if (error.statusCode) {
      throw error
    }

    console.error('User Statistics API Error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Server-Fehler'
    })
  }
})
