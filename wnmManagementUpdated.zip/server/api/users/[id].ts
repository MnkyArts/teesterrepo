import { z } from 'zod'
import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

// Schema für Benutzer-Update  
const updateUserSchema = z.object({
  firstName: z.string().min(1).optional(),
  lastName: z.string().min(1).optional(),
  email: z.string().email().optional(),
  role: z.enum(['ADMINISTRATOR', 'PROJEKTLEITER', 'ENTWICKLER', 'SUPPORTER', 'VIEWER', 'KUNDE']).optional(),
  avatar: z.string().url().optional(),
  isActive: z.boolean().optional()
})

export default defineEventHandler(async (event) => {
  const method = getMethod(event)
  const userId = getRouterParam(event, 'id')

  if (!userId) {
    throw createError({
      statusCode: 400,
      statusMessage: 'Benutzer-ID ist erforderlich'
    })
  }

  try {
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Nicht authentifiziert'
      })
    }

    if (method === 'GET') {
      // Einzelnen Benutzer laden
      const targetUser = await prisma.user.findUnique({
        where: { id: userId },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          avatar: true,
          role: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
          _count: {
            select: {
              assignedTasks: true,
              createdTasks: true,
              timeEntries: true,
              projectMembers: true,
              taskComments: true
            }
          }
        }
      })

      if (!targetUser) {
        throw createError({
          statusCode: 404,
          statusMessage: 'Benutzer nicht gefunden'
        })
      }

      // Berechtigung prüfen
      if (user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER' && user.id !== userId) {
        // Normale Benutzer dürfen nur ihre eigenen Details sehen
        throw createError({
          statusCode: 403,
          statusMessage: 'Keine Berechtigung'
        })
      }

      return targetUser
    }

    if (method === 'PUT') {
      // Benutzer aktualisieren
      if (user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER' && user.id !== userId) {
        throw createError({
          statusCode: 403,
          statusMessage: 'Keine Berechtigung zum Bearbeiten'
        })
      }

      const body = await readBody(event)
      const validatedData = updateUserSchema.parse(body)

      // Prüfen ob Benutzer existiert
      const existingUser = await prisma.user.findUnique({
        where: { id: userId }
      })

      if (!existingUser) {
        throw createError({
          statusCode: 404,
          statusMessage: 'Benutzer nicht gefunden'
        })
      }

      // Rolle kann nur von Administratoren geändert werden
      if (validatedData.role && user.role !== 'ADMINISTRATOR') {
        throw createError({
          statusCode: 403,
          statusMessage: 'Keine Berechtigung zum Ändern der Rolle'
        })
      }

      // E-Mail Eindeutigkeit prüfen
      if (validatedData.email && validatedData.email !== existingUser.email) {
        const emailExists = await prisma.user.findUnique({
          where: { email: validatedData.email }
        })

        if (emailExists) {
          throw createError({
            statusCode: 400,
            statusMessage: 'E-Mail-Adresse bereits vergeben'
          })
        }
      }

      // Benutzer aktualisieren
      const updatedUser = await prisma.user.update({
        where: { id: userId },
        data: {
          ...validatedData,
          updatedAt: new Date()
        },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          avatar: true,
          role: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
          _count: {
            select: {
              assignedTasks: true,
              createdTasks: true,
              timeEntries: true,
              projectMembers: true,
              taskComments: true
            }
          }
        }
      })

      // Aktivitätslog erstellen
      await prisma.activityLog.create({
        data: {
          action: 'USER_UPDATED',
          description: `Benutzer ${updatedUser.firstName} ${updatedUser.lastName} wurde aktualisiert`,
          userId: user.id
        }
      })

      return updatedUser
    }

    if (method === 'DELETE') {
      // Benutzer deaktivieren (Soft Delete)
      if (user.role !== 'ADMINISTRATOR') {
        throw createError({
          statusCode: 403,
          statusMessage: 'Keine Berechtigung zum Löschen'
        })
      }

      // Prüfen ob Benutzer existiert
      const existingUser = await prisma.user.findUnique({
        where: { id: userId }
      })

      if (!existingUser) {
        throw createError({
          statusCode: 404,
          statusMessage: 'Benutzer nicht gefunden'
        })
      }

      // Benutzer deaktivieren
      const deactivatedUser = await prisma.user.update({
        where: { id: userId },
        data: { isActive: false }
      })

      // Aktivitätslog erstellen
      await prisma.activityLog.create({
        data: {
          action: 'USER_DEACTIVATED',
          description: `Benutzer ${deactivatedUser.firstName} ${deactivatedUser.lastName} wurde deaktiviert`,
          userId: user.id
        }
      })

      return { message: 'Benutzer erfolgreich deaktiviert' }
    }

    throw createError({
      statusCode: 405,
      statusMessage: 'Methode nicht erlaubt'
    })

  } catch (error: any) {
    if (error.statusCode) {
      throw error
    }

    console.error('User API Error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Server-Fehler'
    })
  }
})
