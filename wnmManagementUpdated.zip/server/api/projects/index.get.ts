import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  // Better Auth authentication
  const user = await requireAuth()(event)

  try {
    // Projekte auflisten
    const projects = await prisma.project.findMany({
      include: {
        customer: {
          select: {
            id: true,
            companyName: true,
            contactName: true
          }
        },
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                avatar: true
              }
            }
          }
        },
        _count: {
          select: {
            tasks: true,
            members: true,
            timeEntries: true
          }
        }
      },
      orderBy: {
        updatedAt: 'desc'
      }
    })

    // Calculate additional metrics for each project
    const projectsWithMetrics = await Promise.all(
      projects.map(async (project) => {
        // Calculate total hours
        const timeEntries = await prisma.timeEntry.aggregate({
          where: { projectId: project.id },
          _sum: { hours: true }
        })

        // Calculate progress based on completed tasks
        const taskStats = await prisma.task.groupBy({
          by: ['statusId'],
          where: { projectId: project.id },
          _count: { _all: true }
        })

        // Get total tasks count
        const totalTasks = taskStats.reduce((sum, stat) => sum + stat._count._all, 0)
        
        // Get completed tasks by checking enum values
        let completedTasks = 0
        if (taskStats.length > 0 && totalTasks > 0) {
          // Get the status enum values to find "completed" statuses
          const statusIds = taskStats.map(stat => stat.statusId).filter((id): id is string => id !== null)
          if (statusIds.length > 0) {
            const statusEnums = await prisma.enumValue.findMany({
              where: {
                id: { in: statusIds },
                category: { name: 'task_status' }
              }
            })
            
            // Look for completed status - enhanced German keyword matching
            const completedStatusIds = statusEnums
              .filter(enumValue => {
                const key = enumValue.key.toLowerCase()
                const label = enumValue.label?.toLowerCase() || ''
                return (
                  key.includes('erledigt') || 
                  key.includes('geschlossen') ||
                  key.includes('abgeschlossen') ||
                  key.includes('done') ||
                  key.includes('completed') ||
                  key.includes('finished') ||
                  label.includes('erledigt') ||
                  label.includes('geschlossen') ||
                  label.includes('abgeschlossen') ||
                  label.includes('done') ||
                  label.includes('completed')
                )
              })
              .map(enumValue => enumValue.id)
            
            completedTasks = taskStats
              .filter(stat => stat.statusId && completedStatusIds.includes(stat.statusId))
              .reduce((sum, stat) => sum + stat._count._all, 0)
          }
        }
        
        const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0

        return {
          ...project,
          totalHours: timeEntries._sum.hours || 0,
          progress
        }
      })
    )

    return {
      success: true,
      data: projectsWithMetrics
    }

  } catch (error) {
    console.error('Fehler beim Laden der Projekte:', error)

    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Serverfehler'
    })
  }
})
