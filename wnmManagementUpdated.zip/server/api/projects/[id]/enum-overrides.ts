import { z } from 'zod'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

// Validation schema
const updateOverrideSchema = z.object({
  categoryId: z.string().min(1),
  enumValueId: z.string().min(1),
  isActive: z.boolean(),
  sortOrder: z.number().int().min(0).optional()
})

export default defineEventHandler(async (event) => {
  try {
    const method = getMethod(event)
    const projectId = getRouterParam(event, 'id')

    if (!projectId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Projekt-ID erforderlich'
      })
    }

    switch (method) {
      case 'GET':
        return await handleGetProjectOverrides(projectId)
      case 'PUT':
        return await handleUpdateProjectOverride(event, projectId)
      default:
        throw createError({
          statusCode: 405,
          statusMessage: 'Method Not Allowed'
        })
    }
  } catch (error: any) {
    console.error('Project Enum Overrides API Error:', error)
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || error.message || 'Internal Server Error'
    })
  }
})

async function handleGetProjectOverrides(projectId: string) {
  // Check if project exists
  const project = await prisma.project.findUnique({
    where: { id: projectId }
  })

  if (!project) {
    throw createError({
      statusCode: 404,
      statusMessage: 'Projekt nicht gefunden'
    })
  }

  const overrides = await prisma.projectEnumOverride.findMany({
    where: { projectId },
    include: {
      category: true,
      enumValue: true
    },
    orderBy: [
      { category: { sortOrder: 'asc' } },
      { sortOrder: 'asc' }
    ]
  })

  return overrides
}

async function handleUpdateProjectOverride(event: any, projectId: string) {
  const body = await readBody(event)
  const validatedData = updateOverrideSchema.parse(body)

  // Check if project exists
  const project = await prisma.project.findUnique({
    where: { id: projectId }
  })

  if (!project) {
    throw createError({
      statusCode: 404,
      statusMessage: 'Projekt nicht gefunden'
    })
  }

  // Check if category and enum value exist
  const category = await prisma.enumCategory.findUnique({
    where: { id: validatedData.categoryId }
  })

  if (!category) {
    throw createError({
      statusCode: 404,
      statusMessage: 'Enum-Kategorie nicht gefunden'
    })
  }

  const enumValue = await prisma.enumValue.findUnique({
    where: { id: validatedData.enumValueId }
  })

  if (!enumValue || enumValue.categoryId !== validatedData.categoryId) {
    throw createError({
      statusCode: 404,
      statusMessage: 'Enum-Wert nicht gefunden oder gehört nicht zur angegebenen Kategorie'
    })
  }

  // Create or update the override
  const override = await prisma.projectEnumOverride.upsert({
    where: {
      projectId_categoryId_enumValueId: {
        projectId,
        categoryId: validatedData.categoryId,
        enumValueId: validatedData.enumValueId
      }
    },
    update: {
      isActive: validatedData.isActive,
      sortOrder: validatedData.sortOrder
    },
    create: {
      projectId,
      categoryId: validatedData.categoryId,
      enumValueId: validatedData.enumValueId,
      isActive: validatedData.isActive,
      sortOrder: validatedData.sortOrder
    }
  })

  // Log activity
  // await logActivity({
  //   userId: event.context.user?.id,
  //   action: 'project_enum_override_updated',
  //   description: `Projekt-Enum-Konfiguration für '${enumValue.label}' in Projekt '${project.name}' aktualisiert`,
  //   details: { projectId, categoryId: validatedData.categoryId, enumValueId: validatedData.enumValueId }
  // })

  return override
}
