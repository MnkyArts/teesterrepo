import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  // Require staff authentication
  const user = await requireAuth()(event)
  
  // Check if user has required role
  if (!['ADMINISTRATOR', 'PROJEKTLEITER'].includes(user.role)) {
    throw createError({
      statusCode: 403,
      statusMessage: 'Keine Berechtigung für diese Aktion'
    })
  }
  
  const query = getQuery(event)
  const startDate = query.startDate as string
  const endDate = query.endDate as string
  
  if (!startDate || !endDate) {
    throw createError({
      statusCode: 400,
      statusMessage: 'Start- und Enddatum sind erforderlich'
    })
  }

  try {
    const start = new Date(startDate)
    const end = new Date(endDate)
    end.setHours(23, 59, 59, 999)

    // Get billable time entries for the period
    const timeEntries = await prisma.timeEntry.findMany({
      where: {
        date: {
          gte: start,
          lte: end
        },
        billable: true
      },
      include: {
        project: {
          include: {
            customer: true
          }
        }
      }
    })

    // Standard hourly rate (this could be configurable)
    const standardHourlyRate = 85 // €85/hour

    // Calculate financial metrics
    const billableTime = timeEntries.reduce((sum, entry) => sum + entry.hours, 0)
    const totalRevenue = billableTime * standardHourlyRate

    // Calculate costs (assuming 60% of revenue as costs)
    const totalCosts = totalRevenue * 0.6
    const avgHourlyRate = standardHourlyRate
    const profitability = totalRevenue > 0 ? Math.round(((totalRevenue - totalCosts) / totalRevenue) * 100) : 0

    // Revenue data (daily aggregation)
    const revenueData = []
    const currentDate = new Date(start)
    
    while (currentDate <= end) {
      const dayStart = new Date(currentDate)
      const dayEnd = new Date(currentDate)
      dayEnd.setHours(23, 59, 59, 999)
      
      const dayEntries = timeEntries.filter(entry => {
        const entryDate = new Date(entry.date)
        return entryDate >= dayStart && entryDate <= dayEnd
      })
      
      const dayHours = dayEntries.reduce((sum, entry) => sum + entry.hours, 0)
      const dayRevenue = dayHours * standardHourlyRate
      const dayTarget = standardHourlyRate * 8 * 5 // Assuming 5 team members working 8h per day
      
      revenueData.push({
        date: currentDate.toISOString().split('T')[0],
        revenue: dayRevenue,
        target: dayTarget
      })
      
      currentDate.setDate(currentDate.getDate() + 1)
    }

    // Project profitability
    const projectRevenue = timeEntries.reduce((acc, entry) => {
      const projectId = entry.project?.id || 'unknown'
      const projectName = entry.project?.name || 'Ohne Projekt'
      const customerName = entry.project?.customer?.companyName || 'Unbekannt'
      
      if (!acc[projectId]) {
        acc[projectId] = {
          id: projectId,
          name: projectName,
          customer: customerName,
          hours: 0,
          revenue: 0
        }
      }
      
      acc[projectId].hours += entry.hours
      acc[projectId].revenue += entry.hours * standardHourlyRate
      
      return acc
    }, {} as Record<string, any>)

    const profitabilityData = Object.values(projectRevenue).map((project: any) => {
      const costs = project.revenue * 0.6 // 60% costs
      const profit = project.revenue - costs
      const roi = costs > 0 ? Math.round((profit / costs) * 100) : 0
      
      return {
        id: project.id,
        name: project.name,
        customer: project.customer,
        revenue: Math.round(project.revenue),
        costs: Math.round(costs),
        profit: Math.round(profit),
        roi,
        status: 'active' as const
      }
    }).sort((a, b) => b.revenue - a.revenue)

    // Calculate changes (compare with previous period)
    const periodLength = end.getTime() - start.getTime()
    const previousStart = new Date(start.getTime() - periodLength)
    const previousEnd = new Date(start.getTime() - 1)
    
    const previousTimeEntries = await prisma.timeEntry.findMany({
      where: {
        date: {
          gte: previousStart,
          lte: previousEnd
        },
        billable: true
      }
    })
    
    const previousRevenue = previousTimeEntries.reduce((sum, entry) => sum + entry.hours, 0) * standardHourlyRate
    const revenueChange = previousRevenue > 0 
      ? Math.round(((totalRevenue - previousRevenue) / previousRevenue) * 100)
      : 0

    return {
      totalRevenue: Math.round(totalRevenue),
      billableTime: Math.round(billableTime * 10) / 10,
      avgHourlyRate,
      profitability,
      revenueChange,
      revenueData,
      profitabilityData: profitabilityData.slice(0, 10) // Top 10 projects
    }

  } catch (error) {
    console.error('Financial report error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Laden des Finanzberichts'
    })
  }
})
