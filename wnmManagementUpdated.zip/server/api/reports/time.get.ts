import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  // Require staff authentication
  const user = await requireAuth()(event)
  
  // Check if user has required role
  if (!['ADMINISTRATOR', 'PROJEKTLEITER'].includes(user.role)) {
    throw createError({
      statusCode: 403,
      statusMessage: 'Keine Berechtigung für diese Aktion'
    })
  }
  
  const query = getQuery(event)
  const startDate = query.startDate as string
  const endDate = query.endDate as string
  
  if (!startDate || !endDate) {
    throw createError({
      statusCode: 400,
      statusMessage: 'Start- und Enddatum sind erforderlich'
    })
  }

  try {
    const start = new Date(startDate)
    const end = new Date(endDate)
    end.setHours(23, 59, 59, 999) // Include the end date

    // Get time entries for the period
    const timeEntries = await prisma.timeEntry.findMany({
      where: {
        date: {
          gte: start,
          lte: end
        }
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      }
    })

    // Calculate statistics
    const totalHours = timeEntries.reduce((sum, entry) => sum + entry.hours, 0)
    const billableHours = timeEntries
      .filter(entry => entry.billable)
      .reduce((sum, entry) => sum + entry.hours, 0)
    
    const productivity = totalHours > 0 ? Math.round((billableHours / totalHours) * 100) : 0
    
    // Calculate days in period
    const daysDiff = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24))
    const avgHoursPerDay = daysDiff > 0 ? totalHours / daysDiff : 0

    // Project distribution
    const projectDistribution = timeEntries.reduce((acc, entry) => {
      const projectName = entry.project?.name || 'Ohne Projekt'
      const existing = acc.find(p => p.name === projectName)
      
      if (existing) {
        existing.hours += entry.hours
      } else {
        acc.push({
          name: projectName,
          hours: entry.hours
        })
      }
      
      return acc
    }, [] as { name: string; hours: number }[])

    // Time trends (daily aggregation)
    const timeTrends = []
    const currentDate = new Date(start)
    
    while (currentDate <= end) {
      const dayStart = new Date(currentDate)
      const dayEnd = new Date(currentDate)
      dayEnd.setHours(23, 59, 59, 999)
      
      const dayEntries = timeEntries.filter(entry => {
        const entryDate = new Date(entry.date)
        return entryDate >= dayStart && entryDate <= dayEnd
      })
      
      const dayTotalHours = dayEntries.reduce((sum, entry) => sum + entry.hours, 0)
      const dayBillableHours = dayEntries
        .filter(entry => entry.billable)
        .reduce((sum, entry) => sum + entry.hours, 0)
      
      timeTrends.push({
        date: currentDate.toISOString().split('T')[0],
        hours: dayTotalHours,
        billableHours: dayBillableHours
      })
      
      currentDate.setDate(currentDate.getDate() + 1)
    }

    // Calculate changes (compare with previous period)
    const periodLength = end.getTime() - start.getTime()
    const previousStart = new Date(start.getTime() - periodLength)
    const previousEnd = new Date(start.getTime() - 1)
    
    const previousTimeEntries = await prisma.timeEntry.findMany({
      where: {
        date: {
          gte: previousStart,
          lte: previousEnd
        }
      }
    })
    
    const previousTotalHours = previousTimeEntries.reduce((sum, entry) => sum + entry.hours, 0)
    const previousBillableHours = previousTimeEntries
      .filter(entry => entry.billable)
      .reduce((sum, entry) => sum + entry.hours, 0)
    
    const timeChange = previousTotalHours > 0 
      ? Math.round(((totalHours - previousTotalHours) / previousTotalHours) * 100)
      : 0
    
    const billableChange = previousBillableHours > 0 
      ? Math.round(((billableHours - previousBillableHours) / previousBillableHours) * 100)
      : 0

    return {
      totalHours: Math.round(totalHours * 10) / 10,
      billableHours: Math.round(billableHours * 10) / 10,
      productivity,
      avgHoursPerDay: Math.round(avgHoursPerDay * 10) / 10,
      timeChange,
      billableChange,
      projectDistribution: projectDistribution.sort((a, b) => b.hours - a.hours),
      timeTrends
    }

  } catch (error) {
    console.error('Time report error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Laden des Zeitberichts'
    })
  }
})
