import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'
import ExcelJS from 'exceljs'
import PDFDocument from 'pdfkit'

export default defineEventHandler(async (event) => {
  // Require staff authentication
  const user = await requireAuth()(event)
  
  // Check if user has required role
  if (!['ADMINISTRATOR', 'PROJEKTLEITER'].includes(user.role)) {
    throw createError({
      statusCode: 403,
      statusMessage: 'Keine Berechtigung für diese Aktion'
    })
  }
  
  const query = getQuery(event)
  const format = query.format as string
  const reportType = query.reportType as string
  const startDate = query.startDate as string
  const endDate = query.endDate as string
  
  if (!format || !reportType || !startDate || !endDate) {
    throw createError({
      statusCode: 400,
      statusMessage: 'Format, Berichtstyp, Start- und Enddatum sind erforderlich'
    })
  }

  try {
    const start = new Date(startDate)
    const end = new Date(endDate)
    end.setHours(23, 59, 59, 999)

    let data: any = {}
    
    // Fetch data based on report type
    switch (reportType) {
      case 'time':
        data = await getTimeReportData(start, end)
        break
      case 'projects':
        data = await getProjectReportData(start, end)
        break
      case 'team':
        data = await getTeamReportData(start, end)
        break
      case 'financial':
        data = await getFinancialReportData(start, end)
        break
      default:
        throw createError({
          statusCode: 400,
          statusMessage: 'Ungültiger Berichtstyp'
        })
    }

    // Generate report based on format
    if (format === 'excel') {
      return await generateExcelReport(reportType, data, start, end, event)
    } else if (format === 'pdf') {
      return await generatePDFReport(reportType, data, start, end, event)
    } else {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ungültiges Format. Unterstützt: excel, pdf'
      })
    }

  } catch (error) {
    console.error('Export error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Exportieren des Berichts'
    })
  }
})

async function getTimeReportData(start: Date, end: Date) {
  const timeEntries = await prisma.timeEntry.findMany({
    where: {
      date: { gte: start, lte: end }
    },
    include: {
      user: true,
      project: true,
      task: true
    },
    orderBy: { date: 'desc' }
  })

  return {
    entries: timeEntries,
    totalHours: timeEntries.reduce((sum, entry) => sum + entry.hours, 0),
    billableHours: timeEntries.filter(e => e.billable).reduce((sum, entry) => sum + entry.hours, 0)
  }
}

async function getProjectReportData(start: Date, end: Date) {
  const projects = await prisma.project.findMany({
    include: {
      customer: true,
      timeEntries: {
        where: { date: { gte: start, lte: end } }
      },
      tasks: {
        include: {
          timeEntries: {
            where: { date: { gte: start, lte: end } }
          }
        }
      }
    }
  })

  return {
    projects: projects.map(project => ({
      ...project,
      totalHours: project.timeEntries.reduce((sum, entry) => sum + entry.hours, 0),
      completedTasks: project.tasks.filter((task: any) => task.status === 'ERLEDIGT').length,
      totalTasks: project.tasks.length
    }))
  }
}

async function getTeamReportData(start: Date, end: Date) {
  const users = await prisma.user.findMany({
    where: { role: { in: ['PROJEKTLEITER', 'ENTWICKLER', 'SUPPORTER'] } },
    include: {
      timeEntries: {
        where: { date: { gte: start, lte: end } }
      }
    }
  })

  return {
    members: users.map((user: any) => ({
      ...user,
      totalHours: user.timeEntries.reduce((sum: number, entry: any) => sum + entry.hours, 0),
      productivity: calculateProductivity(user.timeEntries),
      efficiency: calculateEfficiency(user.timeEntries)
    }))
  }
}

async function getFinancialReportData(start: Date, end: Date) {
  const timeEntries = await prisma.timeEntry.findMany({
    where: {
      date: { gte: start, lte: end },
      billable: true
    },
    include: {
      project: { include: { customer: true } }
    }
  })

  const standardRate = 85
  const totalRevenue = timeEntries.reduce((sum, entry) => sum + (entry.hours * standardRate), 0)

  return {
    totalRevenue,
    billableHours: timeEntries.reduce((sum, entry) => sum + entry.hours, 0),
    averageRate: standardRate,
    entries: timeEntries
  }
}

function calculateProductivity(timeEntries: any[]) {
  const totalHours = timeEntries.reduce((sum, entry) => sum + entry.hours, 0)
  const workDays = 22 // Average work days per month
  const expectedHours = workDays * 8
  return totalHours > 0 ? Math.round((totalHours / expectedHours) * 100) : 0
}

function calculateEfficiency(timeEntries: any[]) {
  const billableHours = timeEntries.filter(e => e.billable).reduce((sum, entry) => sum + entry.hours, 0)
  const totalHours = timeEntries.reduce((sum, entry) => sum + entry.hours, 0)
  return totalHours > 0 ? Math.round((billableHours / totalHours) * 100) : 0
}

async function generateExcelReport(reportType: string, data: any, start: Date, end: Date, event: any) {
  const workbook = new ExcelJS.Workbook()
  const worksheet = workbook.addWorksheet('Bericht')

  // Header styling
  const headerStyle = {
    font: { bold: true, color: { argb: 'FFFFFF' } },
    fill: { type: 'pattern', pattern: 'solid', fgColor: { argb: '366092' } } as any,
    alignment: { horizontal: 'center' } as any
  }

  // Add title
  worksheet.mergeCells('A1:F1')
  worksheet.getCell('A1').value = `${getReportTitle(reportType)} (${formatDate(start)} - ${formatDate(end)})`
  worksheet.getCell('A1').style = headerStyle

  // Add data based on report type
  let row = 3
  switch (reportType) {
    case 'time':
      const timeHeaderRow = worksheet.addRow(['Datum', 'Benutzer', 'Projekt', 'Aufgabe', 'Stunden', 'Abrechenbar'])
      timeHeaderRow.eachCell((cell) => {
        cell.font = { bold: true, color: { argb: 'FFFFFF' } }
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '366092' } } as any
        cell.alignment = { horizontal: 'center' } as any
      })
      data.entries.forEach((entry: any) => {
        worksheet.addRow([
          formatDate(entry.date),
          entry.user?.name || 'Unbekannt',
          entry.project?.name || 'Ohne Projekt',
          entry.task?.title || 'Ohne Aufgabe',
          entry.hours,
          entry.billable ? 'Ja' : 'Nein'
        ])
      })
      break
      
    case 'projects':
      const projectHeaderRow = worksheet.addRow(['Projekt', 'Kunde', 'Status', 'Stunden', 'Aufgaben erledigt', 'Aufgaben gesamt'])
      projectHeaderRow.eachCell((cell) => {
        cell.font = { bold: true, color: { argb: 'FFFFFF' } }
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '366092' } } as any
        cell.alignment = { horizontal: 'center' } as any
      })
      data.projects.forEach((project: any) => {
        worksheet.addRow([
          project.name,
          project.customer?.companyName || 'Unbekannt',
          project.status,
          project.totalHours,
          project.completedTasks,
          project.totalTasks
        ])
      })
      break
      
    case 'team':
      const teamHeaderRow = worksheet.addRow(['Name', 'E-Mail', 'Rolle', 'Stunden', 'Produktivität (%)', 'Effizienz (%)'])
      teamHeaderRow.eachCell((cell) => {
        cell.font = { bold: true, color: { argb: 'FFFFFF' } }
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '366092' } } as any
        cell.alignment = { horizontal: 'center' } as any
      })
      data.members.forEach((member: any) => {
        worksheet.addRow([
          member.name,
          member.email,
          member.role,
          member.totalHours,
          member.productivity,
          member.efficiency
        ])
      })
      break
      
    case 'financial':
      const financialHeaderRow = worksheet.addRow(['Datum', 'Projekt', 'Kunde', 'Stunden', 'Stundensatz', 'Umsatz'])
      financialHeaderRow.eachCell((cell) => {
        cell.font = { bold: true, color: { argb: 'FFFFFF' } }
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '366092' } } as any
        cell.alignment = { horizontal: 'center' } as any
      })
      data.entries.forEach((entry: any) => {
        worksheet.addRow([
          formatDate(entry.date),
          entry.project?.name || 'Ohne Projekt',
          entry.project?.customer?.companyName || 'Unbekannt',
          entry.hours,
          `€${data.averageRate}`,
          `€${entry.hours * data.averageRate}`
        ])
      })
      break
  }

  // Auto-fit columns
  worksheet.columns.forEach(column => {
    column.width = 15
  })

  const buffer = await workbook.xlsx.writeBuffer()
  
  setHeader(event, 'Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
  setHeader(event, 'Content-Disposition', `attachment; filename="${reportType}_bericht_${formatDate(start)}_${formatDate(end)}.xlsx"`)
  
  return buffer
}

async function generatePDFReport(reportType: string, data: any, start: Date, end: Date, event: any) {
  const doc = new PDFDocument()
  const chunks: Buffer[] = []

  doc.on('data', chunk => chunks.push(chunk))

  // Header
  doc.fontSize(20).text(`${getReportTitle(reportType)}`, { align: 'center' })
  doc.fontSize(12).text(`Zeitraum: ${formatDate(start)} - ${formatDate(end)}`, { align: 'center' })
  doc.moveDown(2)

  // Content based on report type
  switch (reportType) {
    case 'time':
      doc.fontSize(14).text(`Gesamtstunden: ${data.totalHours}`)
      doc.text(`Abrechenbare Stunden: ${data.billableHours}`)
      doc.moveDown()
      
      data.entries.slice(0, 20).forEach((entry: any) => {
        doc.fontSize(10)
        doc.text(`${formatDate(entry.date)} | ${entry.user?.name} | ${entry.project?.name || 'Ohne Projekt'} | ${entry.hours}h`)
      })
      break
      
    case 'projects':
      data.projects.slice(0, 15).forEach((project: any) => {
        doc.fontSize(12).text(project.name, { underline: true })
        doc.fontSize(10)
        doc.text(`Kunde: ${project.customer?.name || 'Unbekannt'}`)
        doc.text(`Status: ${project.status}`)
        doc.text(`Stunden: ${project.totalHours}`)
        doc.text(`Aufgaben: ${project.completedTasks}/${project.totalTasks}`)
        doc.moveDown()
      })
      break
      
    case 'team':
      data.members.forEach((member: any) => {
        doc.fontSize(12).text(member.name, { underline: true })
        doc.fontSize(10)
        doc.text(`E-Mail: ${member.email}`)
        doc.text(`Rolle: ${member.role}`)
        doc.text(`Stunden: ${member.totalHours}`)
        doc.text(`Produktivität: ${member.productivity}%`)
        doc.text(`Effizienz: ${member.efficiency}%`)
        doc.moveDown()
      })
      break
      
    case 'financial':
      doc.fontSize(14).text(`Gesamtumsatz: €${data.totalRevenue}`)
      doc.text(`Abrechenbare Stunden: ${data.billableHours}`)
      doc.text(`Durchschnittlicher Stundensatz: €${data.averageRate}`)
      doc.moveDown()
      break
  }

  doc.end()

  await new Promise<void>((resolve) => {
    doc.on('end', resolve)
  })

  const buffer = Buffer.concat(chunks)
  
  setHeader(event, 'Content-Type', 'application/pdf')
  setHeader(event, 'Content-Disposition', `attachment; filename="${reportType}_bericht_${formatDate(start)}_${formatDate(end)}.pdf"`)
  
  return buffer
}

function getReportTitle(reportType: string): string {
  const titles = {
    time: 'Zeiterfassung Bericht',
    projects: 'Projekt Bericht',
    team: 'Team Bericht',
    financial: 'Finanzbericht'
  }
  return titles[reportType as keyof typeof titles] || 'Bericht'
}

function formatDate(date: Date): string {
  return date.toLocaleDateString('de-DE')
}
