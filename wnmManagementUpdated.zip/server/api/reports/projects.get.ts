import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  // Require staff authentication
  const user = await requireAuth()(event)
  
  // Check if user has required role
  if (!['ADMINISTRATOR', 'PROJEKTLEITER'].includes(user.role)) {
    throw createError({
      statusCode: 403,
      statusMessage: 'Keine Berechtigung für diese Aktion'
    })
  }
  
  const query = getQuery(event)
  const startDate = query.startDate as string
  const endDate = query.endDate as string
  
  if (!startDate || !endDate) {
    throw createError({
      statusCode: 400,
      statusMessage: 'Start- und Enddatum sind erforderlich'
    })
  }

  try {
    const start = new Date(startDate)
    const end = new Date(endDate)
    end.setHours(23, 59, 59, 999)

    // Get projects with related data
    const projects = await prisma.project.findMany({
      include: {
        tasks: {
          include: {
            timeEntries: {
              where: {
                date: {
                  gte: start,
                  lte: end
                }
              }
            }
          }
        },
        customer: {
          select: {
            companyName: true
          }
        },
        members: {
          include: {
            user: {
              select: {
                firstName: true,
                lastName: true
              }
            }
          }
        }
      }
    })

    // Calculate project statistics
    const activeProjects = projects.filter(p => p.status === 'AKTIV').length
    const completedProjects = projects.filter(p => p.status === 'ABGESCHLOSSEN').length
    const overdueProjects = projects.filter(p => {
      return p.endDate && new Date(p.endDate) < new Date() && p.status !== 'ABGESCHLOSSEN'
    }).length

    // Calculate average project duration
    const completedProjectsWithDates = projects.filter(p => 
      p.status === 'ABGESCHLOSSEN' && p.startDate && p.endDate
    )
    
    const avgProjectDuration = completedProjectsWithDates.length > 0
      ? Math.round(
          completedProjectsWithDates.reduce((sum, p) => {
            const duration = (new Date(p.endDate!).getTime() - new Date(p.startDate!).getTime()) / (1000 * 60 * 60 * 24)
            return sum + duration
          }, 0) / completedProjectsWithDates.length
        )
      : 0

    // Project performance data
    const projectPerformance = projects.map(project => {
      const totalTimeEntries = project.tasks?.flatMap((task: any) => task.timeEntries) || []
      const actualHours = totalTimeEntries.reduce((sum: number, entry: any) => sum + entry.hours, 0)
      const estimatedHours = project.tasks?.reduce((sum: number, task: any) => sum + (task.estimatedHours || 0), 0) || 0
      
      return {
        name: project.name,
        estimatedHours: estimatedHours || 0,
        actualHours: actualHours || 0,
        efficiency: estimatedHours > 0 ? Math.round((estimatedHours / actualHours) * 100) : 0
      }
    }).filter(p => p.estimatedHours > 0 || p.actualHours > 0)

    // Project status distribution
    const statusCounts = projects.reduce((acc, project) => {
      acc[project.status] = (acc[project.status] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    const projectStatus = Object.entries(statusCounts).map(([status, count]) => ({
      status,
      count,
      color: getStatusColor(status)
    }))

    return {
      activeProjects,
      completedProjects,
      overdueProjects,
      avgProjectDuration,
      projectPerformance: projectPerformance.slice(0, 10), // Top 10
      projectStatus
    }

  } catch (error) {
    console.error('Project report error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Laden des Projektberichts'
    })
  }
})

function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    'GEPLANT': '#6B7280',
    'AKTIV': '#3B82F6',
    'PAUSIERT': '#F59E0B',
    'ABGESCHLOSSEN': '#10B981',
    'ABGEBROCHEN': '#EF4444'
  }
  return colors[status] || '#6B7280'
}
