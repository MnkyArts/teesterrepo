import { requireAuth, getCurrentUser } from '~/server/utils/auth'
import { DatabaseHelper } from '~/lib/database'

export default defineEventHandler(async (event) => {
  // Nur GET-Anfragen erlauben
  assertMethod(event, 'GET')

  try {
    // Authentifizierung erforderlich
    await requireAuth()(event)
    const user = getCurrentUser(event)

    // Dashboard-Statistiken holen
    const stats = await DatabaseHelper.getDashboardStats(user.id)

    return {
      success: true,
      data: stats
    }

  } catch (error: any) {
    if (error.statusCode) {
      throw error
    }

    console.error('Dashboard stats error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Serverfehler'
    })
  }
})
