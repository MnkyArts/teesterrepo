import { requireAuth, getCurrentUser } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  // Nur GET-Anfragen erlauben
  assertMethod(event, 'GET')

  try {
    // Authentifizierung erforderlich
    await requireAuth()(event)
    const user = getCurrentUser(event)

    const query = getQuery(event)
    const { limit = '5' } = query

    // Team-Aktivitäten der letzten 24 Stunden
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000)

    // Projekte abrufen in denen der User Mitglied ist
    const userProjects = await prisma.projectMember.findMany({
      where: { userId: user.id },
      select: { projectId: true }
    })

    const projectIds = userProjects.map(pm => pm.projectId)

    // Falls Admin, alle Team-Aktivitäten anzeigen
    const whereCondition = user.role === 'ADMINISTRATOR' 
      ? { createdAt: { gte: oneDayAgo } }
      : projectIds.length > 0 
        ? { 
            projectId: { in: projectIds },
            createdAt: { gte: oneDayAgo }
          }
        : { projectId: 'none' } // Keine Aktivitäten wenn keine Projekte

    const teamActivities = await prisma.activityLog.findMany({
      where: {
        ...whereCondition,
        userId: { not: user.id } // Eigene Aktivitäten ausschließen
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            avatar: true
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        },
        task: {
          select: {
            id: true,
            title: true,
            key: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      },
      take: parseInt(limit as string)
    })

    return {
      success: true,
      data: teamActivities
    }

  } catch (error: any) {
    if (error.statusCode) {
      throw error
    }

    console.error('Team activities error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Laden der Team-Aktivitäten'
    })
  }
})
