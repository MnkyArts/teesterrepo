import { requireAuth, getCurrentUser } from '~/server/utils/auth'
import { prisma } from '~/lib/database'
// Remove the TaskStatus import since it no longer exists

export default defineEventHandler(async (event) => {
  // Nur GET-Anfragen erlauben
  assertMethod(event, 'GET')

  try {
    // Authentifizierung erforderlich
    await requireAuth()(event)
    const user = getCurrentUser(event)

    const query = getQuery(event)
    const { limit = '5', status = ['GEPLANT', 'IN_BEARBEITUNG', 'TECHNISCHES_DESIGN', 'REVIEW', 'TESTING'] } = query

    // Get status enum IDs from keys
    const statusKeys = Array.isArray(status) ? status : [status]
    const statusEnums = await prisma.enumValue.findMany({
      where: {
        key: { 
          in: statusKeys 
        },
        category: {
          name: 'task_status'
        }
      }
    })
    
    const statusIds = statusEnums.map(s => s.id)

    // Eigene Tasks abrufen (nicht abgeschlossene) - optimized query
    const tasks = await prisma.task.findMany({
      where: {
        assigneeId: user.id,
        statusId: {
          in: statusIds
        }
      },
      select: {
        id: true,
        title: true,
        description: true,
        status: true,
        priority: true,
        dueDate: true,
        createdAt: true,
        project: {
          select: {
            id: true,
            name: true,
            key: true
          }
        }
      },
      orderBy: [
        {
          priority: {
            sortOrder: 'desc' // Higher priority values first
          }
        },
        {
          dueDate: 'asc'
        },
        {
          createdAt: 'desc'
        }
      ],
      take: parseInt(limit as string)
    })

    return {
      success: true,
      data: tasks
    }

  } catch (error: any) {
    if (error.statusCode) {
      throw error
    }

    console.error('My tasks error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Laden der Aufgaben'
    })
  }
})
