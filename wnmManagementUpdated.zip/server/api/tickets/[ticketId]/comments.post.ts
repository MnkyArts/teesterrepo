import { PrismaClient } from '@prisma/client'
import { requireAuth } from '~/server/utils/auth'
import { z } from 'zod'

const prisma = new PrismaClient()

// Validation schema
const commentSchema = z.object({
  content: z.string().min(1, 'Comment content is required').max(2000, 'Comment too long'),
  isInternal: z.boolean().optional().default(false),
  updateStatusId: z.string().optional()
})

export default defineEventHandler(async (event) => {
  try {
    // Verify authentication
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Unauthorized'
      })
    }

    const ticketId = getRouterParam(event, 'ticketId')
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ticket ID is required'
      })
    }

    // Parse and validate request body
    const body = await readBody(event)
    const validatedData = commentSchema.parse(body)

    // Get user details
    const currentUser = await prisma.user.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        role: true,
        firstName: true,
        lastName: true
      }
    })

    if (!currentUser) {
      throw createError({
        statusCode: 401,
        statusMessage: 'User not found'
      })
    }

    // Check if user is internal staff
    if (user.role === 'KUNDE') {
      throw createError({
        statusCode: 403,
        statusMessage: 'Access denied'
      })
    }

    // Check if ticket exists
    const ticket = await prisma.ticket.findUnique({
      where: { id: ticketId },
      include: {
        status: true
      }
    })

    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Ticket not found'
      })
    }

    // Create the comment
    const comment = await prisma.ticketComment.create({
      data: {
        content: validatedData.content,
        isInternal: validatedData.isInternal,
        ticketId: ticketId,
        authorId: user.id
      },
      include: {
        author: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            role: true
          }
        }
      }
    })

    // Update ticket status if specified or auto-update based on comment type
    let statusUpdated = false
    if (validatedData.updateStatusId) {
      // Explicit status update requested
      await prisma.ticket.update({
        where: { id: ticketId },
        data: { 
          statusId: validatedData.updateStatusId,
          updatedAt: new Date()
        }
      })
      statusUpdated = true
    } else if (ticket.status?.key === 'OFFEN' && !validatedData.isInternal) {
      // Auto-update: Open ticket gets staff response -> In Progress
      // Find "IN_BEARBEITUNG" status enum value
      const inProgressStatus = await prisma.enumValue.findFirst({
        where: {
          category: { name: 'ticket_status' },
          key: 'IN_BEARBEITUNG'
        }
      })
      
      if (inProgressStatus) {
        await prisma.ticket.update({
          where: { id: ticketId },
          data: { 
            statusId: inProgressStatus.id,
            updatedAt: new Date()
          }
        })
        statusUpdated = true
      }
    }

    // Log activity
    await prisma.activityLog.create({
      data: {
        action: 'TICKET_COMMENT_CREATED',
        description: `Comment added to ticket ${ticketId}`,
        userId: user.id,
        details: {
          ticketId: ticketId,
          commentId: comment.id,
          isInternal: validatedData.isInternal
        }
      }
    })

    return {
      success: true,
      message: statusUpdated 
        ? 'Comment added and status updated successfully' 
        : 'Comment added successfully',
      comment,
      statusUpdated
    }

  } catch (error: any) {
    console.error('Error creating ticket comment:', error)
    
    if (error.statusCode) {
      throw error
    }

    if (error.name === 'ZodError') {
      throw createError({
        statusCode: 400,
        statusMessage: 'Invalid input data',
        data: error.errors
      })
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Internal server error'
    })
  }
})
