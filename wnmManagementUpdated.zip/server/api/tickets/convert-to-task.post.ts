import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'
import { z } from 'zod'

// Validation Schema für Ticket-zu-Task Konvertierung
const conversionSchema = z.object({
  ticketId: z.string().min(1, 'Ticket-ID ist erforderlich'),
  projectId: z.string().min(1, 'Projekt ist erforderlich'),
  assigneeId: z.string().optional(),
  priorityId: z.string().optional(),
  estimatedHours: z.number().min(0).optional(),
  internalNotes: z.string().optional()
})

export default defineEventHandler(async (event) => {
  try {
    // Nur POST-Requests erlauben
    assertMethod(event, 'POST')
    
    // Request Body lesen
    const body = await readBody(event)
    
    // Schema-Validierung
    const validatedData = conversionSchema.parse(body)
    
    // Authentifizierung prüfen
    const decoded = await requireAuth()(event)
    
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Authentifizierung erforderlich'
      })
    }
    
    // Benutzer laden und Berechtigung prüfen
    const user = await prisma.user.findUnique({
      where: { id: decoded.id }
    })

    if (!user || !['ADMIN', 'PROJEKTLEITER', 'ENTWICKLER'].includes(user.role)) {
      throw createError({
        statusCode: 403,
        statusMessage: 'Keine Berechtigung für Ticket-Konvertierung'
      })
    }

    // Ticket laden und prüfen
    const ticket = await prisma.ticket.findUnique({
      where: { id: validatedData.ticketId },
      include: {
        customer: {
          include: {
            projects: true
          }
        },
        priority: true
      }
    })

    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Ticket nicht gefunden'
      })
    }

    // Prüfen ob Ticket bereits konvertiert wurde
    const existingTask = await prisma.task.findFirst({
      where: {
        description: {
          contains: `Ticket #${ticket.id}`
        }
      }
    })

    if (existingTask) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ticket wurde bereits in einen Task konvertiert'
      })
    }

    // Projekt laden und Berechtigung prüfen
    const project = await prisma.project.findUnique({
      where: { id: validatedData.projectId },
      include: {
        members: {
          where: { userId: decoded.id }
        }
      }
    })

    if (!project) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Projekt nicht gefunden'
      })
    }

    // Berechtigung für Projekt prüfen
    if (user.role !== 'ADMINISTRATOR' && project.members.length === 0) {
      throw createError({
        statusCode: 403,
        statusMessage: 'Keine Berechtigung für dieses Projekt'
      })
    }

    // Task-Key generieren
    const taskCount = await prisma.task.count({
      where: { projectId: validatedData.projectId }
    })
    const taskKey = `${project.key}-${(taskCount + 1).toString().padStart(3, '0')}`

    // Task-Beschreibung erstellen
    const taskDescription = `**Kundenanfrage von Ticket #${ticket.id}**

**Kunde:** ${ticket.customer.companyName}
**Abteilung:** ${ticket.department}
**Ursprüngliche Beschreibung:**
${ticket.description}

${validatedData.internalNotes ? `**Interne Notizen:**\n${validatedData.internalNotes}` : ''}

---
*Automatisch konvertiert von Ticket #${ticket.id} am ${new Date().toLocaleDateString('de-DE')}*`

    // Transaction für atomare Erstellung
    const result = await prisma.$transaction(async (tx) => {
      // Task erstellen
      // Get default enum values for task creation
      const taskTypeEnum = await tx.enumValue.findFirst({
        where: {
          category: { name: 'task_type' },
          key: 'AUFGABE'
        }
      })

      const taskStatusEnum = await tx.enumValue.findFirst({
        where: {
          category: { name: 'task_status' },
          key: 'GEPLANT'
        }
      })

      const newTask = await tx.task.create({
        data: {
          key: taskKey,
          title: `[Kunde] ${ticket.title}`,
          description: taskDescription,
          typeId: taskTypeEnum?.id,
          priorityId: validatedData.priorityId || ticket.priorityId,
          statusId: taskStatusEnum?.id,
          estimatedHours: validatedData.estimatedHours,
          projectId: validatedData.projectId,
          assigneeId: validatedData.assigneeId,
          creatorId: decoded.id
        }
      })

      // Ticket-Status auf "In Bearbeitung" setzen
      const ticketInProgressStatus = await tx.enumValue.findFirst({
        where: {
          category: { name: 'ticket_status' },
          key: 'IN_BEARBEITUNG'
        }
      })

      const updatedTicket = await tx.ticket.update({
        where: { id: ticket.id },
        data: {
          statusId: ticketInProgressStatus?.id,
          resolution: `Konvertiert zu Task ${taskKey}`
        }
      })

      // Activity Logs erstellen
      await tx.activityLog.createMany({
        data: [
          {
            action: 'TICKET_CONVERTED_TO_TASK',
            description: `Ticket "${ticket.title}" wurde zu Task ${taskKey} konvertiert`,
            userId: decoded.id,
            projectId: validatedData.projectId,
            taskId: newTask.id,
            details: {
              ticketId: ticket.id,
              ticketTitle: ticket.title,
              customerName: ticket.customer.companyName,
              department: ticket.department,
              originalPriority: ticket.priority?.label || 'Unbekannt',
              newTaskKey: taskKey
            }
          },
          {
            action: 'TASK_CREATED_FROM_TICKET',
            description: `Task ${taskKey} wurde aus Ticket #${ticket.id} erstellt`,
            userId: decoded.id,
            projectId: validatedData.projectId,
            taskId: newTask.id,
            details: {
              ticketId: ticket.id,
              customerName: ticket.customer.companyName,
              conversionUser: user.email
            }
          }
        ]
      })

      return { task: newTask, ticket: updatedTicket }
    })

    return {
      success: true,
      message: `Ticket wurde erfolgreich zu Task ${taskKey} konvertiert`,
      task: result.task,
      ticket: result.ticket
    }

  } catch (error: any) {
    console.error('Ticket conversion error:', error)
    
    if (error.statusCode) {
      throw error
    }
    
    if (error.name === 'ZodError') {
      throw createError({
        statusCode: 400,
        statusMessage: `Validierungsfehler: ${error.errors.map((e: any) => e.message).join(', ')}`
      })
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler bei der Ticket-Konvertierung'
    })
  }
})
