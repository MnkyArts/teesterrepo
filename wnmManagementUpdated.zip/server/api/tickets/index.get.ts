import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  try {
    // Authentifizierung prüfen
    const decoded = await requireAuth()(event)
    
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Authentifizierung erforderlich'
      })
    }
    
    // Benutzer laden und Berechtigung prüfen
    const user = await prisma.user.findUnique({
      where: { id: decoded.id }
    })

    if (!user || !['ADMINISTRATOR', 'PROJEKTLEITER', 'ENTWICKLER'].includes(user.role)) {
      throw createError({
        statusCode: 403,
        statusMessage: 'Keine Berechtigung für Ticket-Verwaltung'
      })
    }

    // Query-Parameter lesen
    const query = getQuery(event)
    const page = parseInt(query.page as string) || 1
    const limit = parseInt(query.limit as string) || 20
    const search = query.search as string
    const status = query.status as string
    const department = query.department as string
    const priority = query.priority as string

    // Filter-Bedingungen aufbauen
    const where: any = {}

    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
        { customer: { companyName: { contains: search, mode: 'insensitive' } } }
      ]
    }

    if (status) {
      where.status = {
        key: status
      }
    }

    if (department) {
      where.department = department
    }

    if (priority) {
      where.priority = {
        key: priority
      }
    }

    // Tickets mit Pagination laden
    const [tickets, total] = await Promise.all([
      prisma.ticket.findMany({
        where,
        include: {
          customer: {
            select: {
              id: true,
              companyName: true,
              contactName: true,
              email: true
            }
          },
          status: {
            select: {
              id: true,
              key: true,
              label: true,
              color: true,
              icon: true
            }
          },
          priority: {
            select: {
              id: true,
              key: true,
              label: true,
              color: true,
              icon: true
            }
          },
          type: {
            select: {
              id: true,
              key: true,
              label: true,
              color: true,
              icon: true
            }
          }
        },
        orderBy: {
          createdAt: 'desc'
        },
        take: limit,
        skip: (page - 1) * limit
      }),
      prisma.ticket.count({ where })
    ])

    // Transform tickets to flatten enum relationships
    const transformedTickets = tickets.map(ticket => ({
      ...ticket,
      status: ticket.status?.key || 'UNKNOWN',
      priority: ticket.priority?.key || 'MEDIUM',
      type: ticket.type?.key || 'GENERAL'
    }))

    // Statistiken für Dashboard
    const stats = await prisma.ticket.groupBy({
      by: ['statusId'],
      _count: {
        statusId: true
      }
    })

    return {
      tickets: transformedTickets,
      stats,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit)
      }
    }

  } catch (error: any) {
    console.error('Internal tickets error:', error)
    
    if (error.statusCode) {
      throw error
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Laden der Tickets'
    })
  }
})
