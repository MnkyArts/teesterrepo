import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'
import { z } from 'zod'

// Validation schema
const updateTicketSchema = z.object({
  title: z.string().min(1).max(255).optional(),
  description: z.string().optional(),
  statusId: z.string().optional(),
  priorityId: z.string().optional(),
  department: z.string().optional(),
  resolution: z.string().optional().nullable()
})

export default defineEventHandler(async (event) => {
  try {
    // Authentifizierung prüfen
    const decoded = await requireAuth()(event)
    
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Authentifizierung erforderlich'
      })
    }

    const ticketId = getRouterParam(event, 'ticketId')
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ticket-ID ist erforderlich'
      })
    }

    // Benutzer laden
    const user = await prisma.user.findUnique({
      where: { id: decoded.id }
    })

    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Benutzer nicht gefunden'
      })
    }

    // Berechtigung prüfen (nur interne Mitarbeiter können Tickets bearbeiten)
    if (!['ADMINISTRATOR', 'PROJEKTLEITER', 'ENTWICKLER'].includes(user.role)) {
      throw createError({
        statusCode: 403,
        statusMessage: 'Keine Berechtigung für Ticket-Bearbeitung'
      })
    }

    // Ticket existiert prüfen
    const existingTicket = await prisma.ticket.findUnique({
      where: { id: ticketId }
    })

    if (!existingTicket) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Ticket nicht gefunden'
      })
    }

    // Request Body validieren
    const body = await readBody(event)
    const validatedData = updateTicketSchema.parse(body)

    // Ticket aktualisieren
    const updatedTicket = await prisma.ticket.update({
      where: { id: ticketId },
      data: {
        ...validatedData,
        updatedAt: new Date()
      },
      include: {
        customer: {
          select: {
            id: true,
            companyName: true,
            contactName: true,
            email: true,
            phone: true,
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true
              }
            }
          }
        }
      }
    })

    return {
      success: true,
      message: 'Ticket erfolgreich aktualisiert',
      data: updatedTicket
    }

  } catch (error: any) {
    console.error('Fehler beim Aktualisieren des Tickets:', error)
    
    if (error.statusCode) {
      throw error
    }

    if (error.name === 'ZodError') {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ungültige Eingabedaten',
        data: error.errors
      })
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Serverfehler beim Aktualisieren des Tickets'
    })
  }
})
