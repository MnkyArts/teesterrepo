import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'
import { z } from 'zod'

// Validation schema
const createTicketSchema = z.object({
  title: z.string().min(1, 'Titel ist erforderlich').max(255, 'Titel zu lang'),
  description: z.string().min(1, 'Beschreibung ist erforderlich'),
  priority: z.enum(['NIEDRIG', 'NORMAL', 'HOCH', 'KRITISCH', 'BLOCKER']).default('NORMAL'),
  department: z.string().default('Allgemein'),
  customerId: z.string().optional() // Nur für interne Mitarbeiter
})

export default defineEventHandler(async (event) => {
  try {
    // Authentifizierung prüfen
    const decoded = await requireAuth()(event)
    
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Authentifizierung erforderlich'
      })
    }

    // Benutzer laden
    const user = await prisma.user.findUnique({
      where: { id: decoded.id }
    })

    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Benutzer nicht gefunden'
      })
    }

    // Request Body validieren
    const body = await readBody(event)
    const validatedData = createTicketSchema.parse(body)

    // Kunde bestimmen
    let customerId: string
    const isInternalStaff = ['ADMINISTRATOR', 'PROJEKTLEITER', 'ENTWICKLER'].includes(user.role)

    if (user.role === 'KUNDE') {
      // Kunden können nur Tickets für sich selbst erstellen
      // Prüfen ob der Benutzer einen Customer-Eintrag hat
      const customerRecord = await prisma.customer.findFirst({
        where: { userId: user.id }
      })
      
      if (!customerRecord) {
        throw createError({
          statusCode: 400,
          statusMessage: 'Kein Kundeneintrag für diesen Benutzer gefunden'
        })
      }
      
      customerId = customerRecord.id
    } else if (isInternalStaff) {
      // Interne Mitarbeiter können Tickets für Kunden erstellen
      if (validatedData.customerId) {
        // Prüfen ob angegebener Kunde existiert
        const customer = await prisma.customer.findUnique({
          where: { id: validatedData.customerId }
        })

        if (!customer) {
          throw createError({
            statusCode: 400,
            statusMessage: 'Ungültiger Kunde'
          })
        }
        
        customerId = validatedData.customerId
      } else {
        // Wenn kein Kunde angegeben, versuchen Customer-Eintrag für den Mitarbeiter zu finden
        const customerRecord = await prisma.customer.findFirst({
          where: { userId: user.id }
        })
        
        if (customerRecord) {
          customerId = customerRecord.id
        } else {
          throw createError({
            statusCode: 400,
            statusMessage: 'Kein Kunde angegeben und kein Kundeneintrag für Benutzer gefunden'
          })
        }
      }
    } else {
      throw createError({
        statusCode: 403,
        statusMessage: 'Keine Berechtigung zum Erstellen von Tickets'
      })
    }

    // Get default enum values
    const defaultPriority = await prisma.enumValue.findFirst({
      where: {
        category: { name: 'priority' },
        isDefault: true
      }
    })

    const defaultStatus = await prisma.enumValue.findFirst({
      where: {
        category: { name: 'ticket_status' },
        isDefault: true
      }
    })

    // Ticket erstellen
    const newTicket = await prisma.ticket.create({
      data: {
        title: validatedData.title,
        description: validatedData.description,
        priorityId: defaultPriority?.id,
        department: validatedData.department,
        statusId: defaultStatus?.id,
        customerId: customerId
      },
      include: {
        customer: {
          select: {
            id: true,
            companyName: true,
            contactName: true,
            email: true,
            phone: true,
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true
              }
            }
          }
        }
      }
    })

    return {
      success: true,
      message: 'Ticket erfolgreich erstellt',
      data: newTicket
    }

  } catch (error: any) {
    console.error('Fehler beim Erstellen des Tickets:', error)
    
    if (error.statusCode) {
      throw error
    }

    if (error.name === 'ZodError') {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ungültige Eingabedaten',
        data: error.errors
      })
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Serverfehler beim Erstellen des Tickets'
    })
  }
})
