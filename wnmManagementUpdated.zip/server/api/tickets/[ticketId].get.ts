import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  try {
    // Authentifizierung prüfen
    const decoded = await requireAuth()(event)
    
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Authentifizierung erforderlich'
      })
    }

    const ticketId = getRouterParam(event, 'ticketId')
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ticket-ID ist erforderlich'
      })
    }

    // Benutzer laden
    const user = await prisma.user.findUnique({
      where: { id: decoded.id }
    })

    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Benutzer nicht gefunden'
      })
    }

    // Ticket laden mit vollständigen Informationen
    const ticket = await prisma.ticket.findUnique({
      where: { id: ticketId },
      include: {
        customer: {
          select: {
            id: true,
            companyName: true,
            contactName: true,
            email: true,
            phone: true,
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true
              }
            }
          }
        },
        status: {
          select: {
            id: true,
            key: true,
            label: true,
            color: true,
            icon: true
          }
        },
        priority: {
          select: {
            id: true,
            key: true,
            label: true,
            color: true,
            icon: true
          }
        },
        type: {
          select: {
            id: true,
            key: true,
            label: true,
            color: true,
            icon: true
          }
        },
        comments: {
          include: {
            author: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                role: true
              }
            }
          },
          orderBy: {
            createdAt: 'asc'
          }
        }
      }
    })

    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Ticket nicht gefunden'
      })
    }

    // Zugriffsberechtigung prüfen
    const isCustomer = user.role === 'KUNDE'
    const isInternalStaff = ['ADMINISTRATOR', 'PROJEKTLEITER', 'ENTWICKLER'].includes(user.role)

    if (isCustomer) {
      // Kunden können nur ihre eigenen Tickets sehen
      if (ticket.customerId !== user.id) {
        // Für Kunden prüfen wir auch die Verbindung über customer.userId
        const customerBelongsToUser = ticket.customer.user?.id === user.id
        if (!customerBelongsToUser) {
          throw createError({
            statusCode: 403,
            statusMessage: 'Keine Berechtigung für dieses Ticket'
          })
        }
      }
      
      // Für Kunden: interne Kommentare filtern
      const filteredComments = ticket.comments.filter((comment: any) => !comment.isInternal)
      return {
        success: true,
        data: {
          ...ticket,
          status: ticket.status?.key || 'UNKNOWN',
          priority: ticket.priority?.key || 'MEDIUM',
          type: ticket.type?.key || 'GENERAL',
          comments: filteredComments
        }
      }
    } else if (!isInternalStaff) {
      throw createError({
        statusCode: 403,
        statusMessage: 'Keine Berechtigung für Ticket-Verwaltung'
      })
    }

    return {
      success: true,
      data: {
        ...ticket,
        status: ticket.status?.key || 'UNKNOWN',
        priority: ticket.priority?.key || 'MEDIUM',
        type: ticket.type?.key || 'GENERAL'
      }
    }

  } catch (error: any) {
    console.error('Fehler beim Laden des Tickets:', error)
    
    if (error.statusCode) {
      throw error
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Serverfehler beim Laden des Tickets'
    })
  }
})
