import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  try {
    const user = await requireAuth()(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Nicht authentifiziert'
      })
    }

    const query = getQuery(event)
    const userId = (query.userId as string) || user.id

    // Users can only see their own stats unless they're admin/projektleiter
    if (user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER' && userId !== user.id) {
      throw createError({
        statusCode: 403,
        statusMessage: 'Keine Berechtigung für diese Statistiken'
      })
    }

    // Get date ranges
    const today = new Date()
    const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate())
    const endOfToday = new Date(startOfToday)
    endOfToday.setDate(endOfToday.getDate() + 1)

    const startOfWeek = getStartOfWeek(today)
    const endOfWeek = new Date(startOfWeek)
    endOfWeek.setDate(startOfWeek.getDate() + 7)

    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)
    const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 1)

    // Get today's time entries
    const todayEntries = await prisma.timeEntry.findMany({
      where: {
        userId,
        date: {
          gte: startOfToday,
          lt: endOfToday
        }
      }
    })

    // Get this week's time entries
    const weekEntries = await prisma.timeEntry.findMany({
      where: {
        userId,
        date: {
          gte: startOfWeek,
          lt: endOfWeek
        }
      }
    })

    // Get this month's time entries
    const monthEntries = await prisma.timeEntry.findMany({
      where: {
        userId,
        date: {
          gte: startOfMonth,
          lt: endOfMonth
        }
      }
    })

    // Get project breakdown for this month
    const projectBreakdown = await prisma.timeEntry.groupBy({
      by: ['projectId'],
      where: {
        userId,
        date: {
          gte: startOfMonth,
          lt: endOfMonth
        }
      },
      _sum: {
        hours: true
      }
    })

    // Get project details for breakdown
    const projectIds = projectBreakdown.map(p => p.projectId)
    const projects = await prisma.project.findMany({
      where: {
        id: { in: projectIds }
      },
      select: {
        id: true,
        name: true,
        key: true
      }
    })

    // Calculate statistics
    const todayTotal = todayEntries.reduce((sum, entry) => sum + entry.hours, 0)
    const weekTotal = weekEntries.reduce((sum, entry) => sum + entry.hours, 0)
    const monthTotal = monthEntries.reduce((sum, entry) => sum + entry.hours, 0)
    
    const billableToday = todayEntries
      .filter(entry => entry.billable)
      .reduce((sum, entry) => sum + entry.hours, 0)
    
    const nonBillableToday = todayTotal - billableToday

    // Calculate project breakdown with percentages
    const totalMonthHours = monthTotal
    const projectBreakdownWithDetails = projectBreakdown.map(breakdown => {
      const project = projects.find(p => p.id === breakdown.projectId)
      const hours = breakdown._sum.hours || 0
      const percentage = totalMonthHours > 0 ? (hours / totalMonthHours) * 100 : 0

      return {
        projectId: breakdown.projectId,
        projectName: project?.name || 'Unbekanntes Projekt',
        projectKey: project?.key || '',
        hours: Math.round(hours * 100) / 100,
        percentage: Math.round(percentage * 10) / 10
      }
    }).sort((a, b) => b.hours - a.hours)

    const stats = {
      todayTotal: Math.round(todayTotal * 100) / 100,
      weekTotal: Math.round(weekTotal * 100) / 100,
      monthTotal: Math.round(monthTotal * 100) / 100,
      billableToday: Math.round(billableToday * 100) / 100,
      nonBillableToday: Math.round(nonBillableToday * 100) / 100,
      targetDailyHours: 8, // Default 8 hours target - can be made configurable
      projectBreakdown: projectBreakdownWithDetails
    }

    return {
      stats
    }

  } catch (error: any) {
    console.error('Error fetching time tracking stats:', error)
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || 'Fehler beim Laden der Zeiterfassungsstatistiken'
    })
  }
})

function getStartOfWeek(date: Date): Date {
  const d = new Date(date)
  const day = d.getDay()
  const diff = d.getDate() - day + (day === 0 ? -6 : 1) // Monday as first day
  return new Date(d.setDate(diff))
}
