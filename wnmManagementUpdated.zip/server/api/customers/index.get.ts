import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  // Better Auth authentication - only admins and project managers
  const user = await requireAuth('PROJEKTLEITER')(event)

  try {
    // Kunden auflisten (nur aktive)
    const customers = await prisma.customer.findMany({
      where: {
        isActive: true
      },
      select: {
        id: true,
        companyName: true,
        contactName: true,
        email: true,
        phone: true,
        city: true,
        country: true
      },
      orderBy: {
        companyName: 'asc'
      }
    })

    return {
      success: true,
      data: customers
    }

  } catch (error) {
    console.error('Fehler beim Laden der Kunden:', error)

    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Serverfehler'
    })
  }
})
