import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  // Better Auth authentication - only customers
  const user = await requireAuth('KUNDE')(event)

  try {
    // Kunden-ID aus dem User ermitteln
    const userData = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        customer: true
      }
    })

    if (!userData || !userData.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Kunde nicht gefunden'
      })
    }

    const customerId = userData.customer.id

    // Query-Parameter auslesen
    const query = getQuery(event)
    const limit = query.limit && typeof query.limit === 'string' ? parseInt(query.limit) : undefined
    const page = query.page && typeof query.page === 'string' ? parseInt(query.page) : 1
    const year = query.year && typeof query.year === 'string' ? parseInt(query.year) : undefined

    // Where-Klausel aufbauen
    const where: any = {
      customerId
    }

    if (query.status && typeof query.status === 'string') {
      // Validate that the status is a valid InvoiceStatus enum value
      const validStatuses = ['ENTWURF', 'VERSENDET', 'BEZAHLT', 'UEBERFAELLIG', 'STORNIERT']
      if (validStatuses.includes(query.status)) {
        where.status = query.status
      }
    }

    if (year) {
      where.issueDate = {
        gte: new Date(`${year}-01-01`),
        lt: new Date(`${year + 1}-01-01`)
      }
    }

    // Rechnungen laden mit Pagination
    const [invoices, total] = await Promise.all([
      prisma.invoice.findMany({
        where,
        orderBy: {
          issueDate: 'desc'
        },
        ...(limit && { take: limit }),
        ...(limit && page > 1 && { skip: (page - 1) * limit })
      }),
      prisma.invoice.count({ where })
    ])

    // Statistiken für den Filter-Bereich berechnen
    const stats = await prisma.invoice.groupBy({
      by: ['status'],
      where: { customerId },
      _count: {
        status: true
      },
      _sum: {
        totalAmount: true
      }
    })

    return {
      invoices,
      stats,
      pagination: {
        total,
        page,
        limit: limit || total,
        pages: limit ? Math.ceil(total / limit) : 1
      }
    }

  } catch (error) {
    console.error('Customer invoices error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Laden der Rechnungen'
    })
  }
})
