import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'
import { z } from 'zod'

// IBAN Validation Schema
const sepaSchema = z.object({
  iban: z.string()
    .min(15, 'IBAN muss mindestens 15 Zeichen lang sein')
    .max(34, 'IBAN darf maximal 34 Zeichen lang sein')
    .regex(/^[A-Z]{2}[0-9]{2}[A-Z0-9]+$/, 'Ungültiges IBAN-Format'),
  bic: z.string()
    .regex(/^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/, 'Ungültiges BIC-Format')
    .optional(),
  accountHolder: z.string()
    .min(2, 'Kontoinhaber muss mindestens 2 Zeichen lang sein')
    .max(100, 'Kontoinhaber darf maximal 100 Zeichen lang sein'),
  validUntil: z.string()
    .optional()
    .transform(str => str ? new Date(str) : undefined)
})

// IBAN Prüfziffer-Validierung
function validateIBAN(iban: string): boolean {
  // IBAN in Großbuchstaben umwandeln und Leerzeichen entfernen
  const normalizedIban = iban.toUpperCase().replace(/\s/g, '')
  
  // Längenprüfung für deutsche IBAN
  if (normalizedIban.startsWith('DE') && normalizedIban.length !== 22) {
    return false
  }
  
  // Rearrange: move first 4 characters to end
  const rearranged = normalizedIban.slice(4) + normalizedIban.slice(0, 4)
  
  // Replace letters with numbers (A=10, B=11, etc.)
  const numeric = rearranged.replace(/[A-Z]/g, char => 
    (char.charCodeAt(0) - 'A'.charCodeAt(0) + 10).toString()
  )
  
  // Mod 97 calculation
  let remainder = 0
  for (let i = 0; i < numeric.length; i++) {
    remainder = (remainder * 10 + parseInt(numeric[i])) % 97
  }
  
  return remainder === 1
}

// Mandats-ID generieren
function generateMandateId(customerCompany: string): string {
  const prefix = customerCompany.substring(0, 3).toUpperCase()
  const timestamp = Date.now().toString().slice(-6)
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0')
  return `${prefix}-${timestamp}-${random}`
}

export default defineEventHandler(async (event) => {
  try {
    // Nur POST-Requests erlauben
    assertMethod(event, 'POST')
    
    // Request Body lesen
    const body = await readBody(event)
    
    // Schema-Validierung
    const validatedData = sepaSchema.parse(body)
    
    // IBAN-Prüfziffer validieren
    if (!validateIBAN(validatedData.iban)) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ungültige IBAN-Prüfziffer'
      })
    }
    
    // Authentifizierung prüfen
    const decoded = await requireAuth()(event)
    
    if (!decoded) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Authentifizierung erforderlich'
      })
    }
    
    // Benutzer und Kundendaten laden
    const user = await prisma.user.findUnique({
      where: { id: decoded.id },
      include: {
        customer: {
          include: {
            sepaMandate: true
          }
        }
      }
    })

    if (!user || user.role !== 'KUNDE') {
      throw createError({
        statusCode: 404,
        statusMessage: 'Kunde nicht gefunden'
      })
    }

    if (!user.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Kundendaten nicht gefunden'
      })
    }

    const customerId = user.customer.id
    
    // Prüfen ob bereits ein Mandat existiert
    if (user.customer.sepaMandate) {
      // Bestehendes Mandat aktualisieren
      const updatedMandate = await prisma.sepaMandate.update({
        where: { customerId },
        data: {
          iban: validatedData.iban.toUpperCase().replace(/\s/g, ''),
          bic: validatedData.bic?.toUpperCase(),
          accountHolder: validatedData.accountHolder.trim(),
          validUntil: validatedData.validUntil,
          isActive: true,
          signedDate: new Date()
        }
      })

      // Activity Log erstellen
      await prisma.activityLog.create({
        data: {
          action: 'SEPA_MANDATE_UPDATED',
          description: `SEPA-Mandat wurde aktualisiert`,
          userId: decoded.id,
          details: {
            mandateId: updatedMandate.mandateId,
            iban: validatedData.iban.substring(0, 8) + '****', // Anonymisiert für Log
            accountHolder: validatedData.accountHolder
          }
        }
      })

      return {
        mandate: updatedMandate,
        message: 'SEPA-Mandat wurde erfolgreich aktualisiert'
      }
    } else {
      // Neues Mandat erstellen
      const mandateId = generateMandateId(user.customer.companyName)
      
      const newMandate = await prisma.sepaMandate.create({
        data: {
          mandateId,
          iban: validatedData.iban.toUpperCase().replace(/\s/g, ''),
          bic: validatedData.bic?.toUpperCase(),
          accountHolder: validatedData.accountHolder.trim(),
          validUntil: validatedData.validUntil,
          isActive: true,
          signedDate: new Date(),
          customerId
        }
      })

      // Activity Log erstellen
      await prisma.activityLog.create({
        data: {
          action: 'SEPA_MANDATE_CREATED',
          description: `SEPA-Mandat wurde erstellt`,
          userId: decoded.id,
          details: {
            mandateId: newMandate.mandateId,
            iban: validatedData.iban.substring(0, 8) + '****', // Anonymisiert für Log
            accountHolder: validatedData.accountHolder
          }
        }
      })

      return {
        mandate: newMandate,
        message: 'SEPA-Mandat wurde erfolgreich erstellt'
      }
    }

  } catch (error: any) {
    console.error('SEPA mandate create/update error:', error)
    
    if (error.statusCode) {
      throw error
    }
    
    if (error.name === 'ZodError') {
      throw createError({
        statusCode: 400,
        statusMessage: `Validierungsfehler: ${error.errors.map((e: any) => e.message).join(', ')}`
      })
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Erstellen/Aktualisieren des SEPA-Mandats'
    })
  }
})
