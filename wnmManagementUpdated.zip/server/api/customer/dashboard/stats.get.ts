import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  // Better Auth authentication
  const user = await requireAuth('KUNDE')(event)

  try {
    // Kunden-ID aus dem User ermitteln
    const userData = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        customer: true
      }
    })

    if (!userData || userData.role !== 'KUNDE') {
      throw createError({
        statusCode: 404,
        statusMessage: 'Kunde nicht gefunden'
      })
    }

    if (!userData.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Kundendaten nicht gefunden'
      })
    }

    const customerId = userData.customer.id

    // Statistiken parallel laden
    const [
      openTickets,
      pendingInvoices,
      totalInvoices
    ] = await Promise.all([
      // Offene Tickets zählen
      prisma.ticket.count({
        where: {
          customerId,
          status: {
            key: { 
              in: ['OFFEN', 'IN_BEARBEITUNG', 'WARTEN_AUF_KUNDE'] 
            }
          }
        }
      }),

      // Offene Rechnungen zählen
      prisma.invoice.count({
        where: {
          customerId,
          status: {
            in: ['VERSENDET', 'UEBERFAELLIG']
          }
        }
      }),

      // Gesamtzahl Rechnungen
      prisma.invoice.count({
        where: {
          customerId
        }
      })
    ])

    return {
      openTickets,
      pendingInvoices,
      totalInvoices,
      customerId
    }

  } catch (error) {
    console.error('Dashboard stats error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Laden der Dashboard-Statistiken'
    })
  }
})
