import { PrismaClient } from '@prisma/client'
import { requireAuth } from '~/server/utils/auth'
import { z } from 'zod'

const prisma = new PrismaClient()

// Validation schema
const commentSchema = z.object({
  content: z.string().min(1, 'Comment content is required').max(2000, 'Comment too long'),
  isInternal: z.boolean().optional().default(false)
})

export default defineEventHandler(async (event) => {
  try {
    // Verify authentication and get user with customer data
    const user = await requireAuth('KUNDE')(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Unauthorized'
      })
    }

    const ticketId = getRouterParam(event, 'ticketId')
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ticket ID is required'
      })
    }

    // Parse and validate request body
    const body = await readBody(event)
    const validatedData = commentSchema.parse(body)

    // Check if ticket exists and user has access
    const ticket = await prisma.ticket.findUnique({
      where: { id: ticketId },
      select: {
        id: true,
        customerId: true,
        status: true
      }
    })

    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Ticket not found'
      })
    }

    // Check access permissions
    if (user.role === 'KUNDE') {
      // Customer can only comment on their own tickets
      if (!user.customer || ticket.customerId !== user.customer.id) {
        throw createError({
          statusCode: 403,
          statusMessage: 'Access denied'
        })
      }
      
      // Customers can't create internal comments
      if (validatedData.isInternal) {
        throw createError({
          statusCode: 403,
          statusMessage: 'Customers cannot create internal comments'
        })
      }

      // Check if ticket is still open for customer comments
      if (ticket.status?.key === 'GESCHLOSSEN') {
        throw createError({
          statusCode: 400,
          statusMessage: 'Cannot comment on closed tickets'
        })
      }
    }

    // Create the comment
    const comment = await prisma.ticketComment.create({
      data: {
        content: validatedData.content,
        isInternal: validatedData.isInternal,
        ticketId: ticketId,
        authorId: user.id
      },
      include: {
        author: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            role: true
          }
        }
      }
    })

    // Update ticket status if needed
    if (user.role === 'KUNDE' && ticket.status?.key === 'WARTEN_AUF_KUNDE') {
      // Find the IN_BEARBEITUNG status enum value
      const inProgressStatus = await prisma.enumValue.findFirst({
        where: {
          key: 'IN_BEARBEITUNG',
          category: {
            name: 'ticket_status'
          }
        }
      })
      
      if (inProgressStatus) {
        await prisma.ticket.update({
          where: { id: ticketId },
          data: { 
            statusId: inProgressStatus.id,
            updatedAt: new Date()
          }
        })
      }
    }

    // Log activity
    await prisma.activityLog.create({
      data: {
        action: 'TICKET_COMMENT_CREATED',
        description: `Comment added to ticket ${ticketId}`,
        userId: user.id,
        details: {
          ticketId: ticketId,
          commentId: comment.id,
          isInternal: validatedData.isInternal
        }
      }
    })

    return {
      success: true,
      message: 'Comment added successfully',
      comment
    }

  } catch (error: any) {
    console.error('Error creating ticket comment:', error)
    
    if (error.statusCode) {
      throw error
    }

    if (error.name === 'ZodError') {
      throw createError({
        statusCode: 400,
        statusMessage: 'Invalid input data',
        data: error.errors
      })
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Internal server error'
    })
  }
})
