import { PrismaClient } from '@prisma/client'
import { requireAuth } from '~/server/utils/auth'

const prisma = new PrismaClient()

export default defineEventHandler(async (event) => {
  try {
    // Verify authentication and get user with customer data
    const user = await requireAuth('KUNDE')(event)
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: 'Unauthorized'
      })
    }

    const ticketId = getRouterParam(event, 'ticketId')
    if (!ticketId) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ticket ID is required'
      })
    }

    // Check if ticket exists and user has access
    const ticket = await prisma.ticket.findUnique({
      where: { id: ticketId },
      select: {
        id: true,
        customerId: true
      }
    })

    if (!ticket) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Ticket not found'
      })
    }

    // Check access permissions
    if (user.role === 'KUNDE') {
      // Customer can only access their own tickets
      if (!user.customer || ticket.customerId !== user.customer.id) {
        throw createError({
          statusCode: 403,
          statusMessage: 'Access denied'
        })
      }
    }
    // Internal users (ADMINISTRATOR, SUPPORTER, etc.) can access all tickets

    // Get comments with proper filtering based on user role
    const comments = await prisma.ticketComment.findMany({
      where: {
        ticketId: ticketId,
        // Customers can't see internal comments
        ...(user.role === 'KUNDE' ? { isInternal: false } : {})
      },
      include: {
        author: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            role: true
          }
        }
      },
      orderBy: {
        createdAt: 'asc'
      }
    })

    return comments

  } catch (error) {
    console.error('Error fetching ticket comments:', error)
    
    if ((error as any).statusCode) {
      throw error
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Internal server error'
    })
  }
})
