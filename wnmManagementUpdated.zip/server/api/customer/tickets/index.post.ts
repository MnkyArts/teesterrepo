import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

export default defineEventHandler(async (event) => {
  // Better Auth authentication - only customers can create tickets
  const user = await requireAuth('KUNDE')(event)

  try {
    // Kunden-ID aus dem User ermitteln
    const userData = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        customer: true
      }
    })

    if (!userData || !userData.customer) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Kunde nicht gefunden'
      })
    }

    const customerId = userData.customer.id

    // Request Body auslesen
    const body = await readBody(event)
    const { title, description, priority, department } = body

    // Validierung
    if (!title || !description || !department) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Titel, Beschreibung und Abteilung sind erforderlich'
      })
    }

    // Gültige Abteilungen
    const validDepartments = ['Support', 'Buchhaltung', 'Entwicklung', 'Vertrieb', 'Allgemein']
    if (!validDepartments.includes(department)) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ungültige Abteilung'
      })
    }

    // Gültige Prioritäten
    const validPriorities = ['NIEDRIG', 'NORMAL', 'HOCH', 'KRITISCH']
    if (priority && !validPriorities.includes(priority)) {
      throw createError({
        statusCode: 400,
        statusMessage: 'Ungültige Priorität'
      })
    }

    // Find the OFFEN status enum value
    const openStatus = await prisma.enumValue.findFirst({
      where: {
        key: 'OFFEN',
        category: {
          name: 'ticket_status'
        }
      }
    })

    if (!openStatus) {
      throw createError({
        statusCode: 500,
        statusMessage: 'Open status not found'
      })
    }

    // Find the priority enum value
    const priorityEnum = await prisma.enumValue.findFirst({
      where: {
        key: priority || 'NORMAL',
        category: {
          name: 'priority'
        }
      }
    })

    if (!priorityEnum) {
      throw createError({
        statusCode: 500,
        statusMessage: 'Priority not found'
      })
    }

    // Ticket erstellen
    const ticket = await prisma.ticket.create({
      data: {
        title: title.trim(),
        description: description.trim(),
        priorityId: priorityEnum.id,
        department,
        customerId,
        statusId: openStatus.id
      }
    })

    // Activity Log erstellen
    await prisma.activityLog.create({
      data: {
        action: 'TICKET_CREATED',
        description: `Ticket "${title}" wurde erstellt`,
        userId: user.id,
        details: {
          ticketId: ticket.id,
          department,
          priority: priority || 'NORMAL',
          customerCreated: true
        }
      }
    })

    return ticket

  } catch (error: any) {
    console.error('Create ticket error:', error)
    
    if (error.statusCode) {
      throw error
    }
    
    throw createError({
      statusCode: 500,
      statusMessage: 'Fehler beim Erstellen des Tickets'
    })
  }
})
