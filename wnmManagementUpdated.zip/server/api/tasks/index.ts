import { z } from 'zod'
import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

// Validation Schema für Task-Erstellung
const createTaskSchema = z.object({
  title: z.string().min(1, 'Titel ist erforderlich'),
  description: z.string().optional(),
  typeId: z.string().optional(),
  priorityId: z.string().optional(),
  statusId: z.string().optional(),
  projectId: z.string(),
  assigneeId: z.string().optional(),
  dueDate: z.string().optional(),
  estimatedHours: z.number().positive().optional(),
  remainingHours: z.number().positive().optional()
})

export default defineEventHandler(async (event) => {
  const method = getMethod(event)
  
  try {
    const user = await requireAuth()(event)

    if (method === 'GET') {
      // Tasks auflisten
      const query = getQuery(event)
      const {
        projectId,
        assigneeId,
        statusId,
        typeId,
        priorityId,
        search,
        page = '1',
        limit = '20',
        sortBy = 'createdAt',
        sortOrder = 'desc'
      } = query

      // Filter-Objekt aufbauen
      const where: any = {}

      if (projectId) {
        where.projectId = projectId as string
      }

      if (assigneeId) {
        where.assigneeId = assigneeId as string
      }

      if (statusId) {
        // Handle both array and single status values
        const statusArray = Array.isArray(statusId) ? statusId : [statusId]
        where.statusId = { 
          in: statusArray 
        }
      }

      if (typeId) {
        where.typeId = typeId as string
      }

      if (priorityId) {
        where.priorityId = priorityId as string
      }

      if (search) {
        where.OR = [
          { title: { contains: search as string, mode: 'insensitive' } },
          { description: { contains: search as string, mode: 'insensitive' } },
          { key: { contains: search as string, mode: 'insensitive' } }
        ]
      }

      // Berechtigung prüfen - nur Tasks aus Projekten wo der User Mitglied ist
      if (user.role !== 'ADMINISTRATOR') {
        const userProjects = await prisma.projectMember.findMany({
          where: { userId: user.id },
          select: { projectId: true }
        })

        const projectIds = userProjects.map(pm => pm.projectId)
        
        if (projectIds.length === 0) {
          return {
            tasks: [],
            total: 0,
            page: parseInt(page as string),
            totalPages: 0
          }
        }

        where.projectId = {
          in: projectIds
        }
      }

      // Pagination
      const pageNum = parseInt(page as string)
      const limitNum = parseInt(limit as string)
      const skip = (pageNum - 1) * limitNum

      // Tasks abrufen
      const [tasks, total] = await Promise.all([
        prisma.task.findMany({
          where,
          include: {
            project: {
              select: {
                id: true,
                name: true,
                key: true,
                customer: {
                  select: {
                    id: true,
                    companyName: true
                  }
                }
              }
            },
            assignee: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                avatar: true
              }
            },
            creator: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true
              }
            },
            type: {
              select: {
                id: true,
                key: true,
                label: true,
                color: true,
                icon: true
              }
            },
            priority: {
              select: {
                id: true,
                key: true,
                label: true,
                color: true,
                icon: true
              }
            },
            status: {
              select: {
                id: true,
                key: true,
                label: true,
                color: true,
                icon: true
              }
            },
            _count: {
              select: {
                comments: true,
                timeEntries: true,
                attachments: true
              }
            }
          },
          orderBy: {
            [sortBy as string]: sortOrder as 'asc' | 'desc'
          },
          skip,
          take: limitNum
        }),
        prisma.task.count({ where })
      ])

      const totalPages = Math.ceil(total / limitNum)

      return {
        tasks,
        total,
        page: pageNum,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrev: pageNum > 1
      }
    }

    if (method === 'POST') {
      // Task erstellen
      const body = await readBody(event)
      const validatedData = createTaskSchema.parse(body)

      // Prüfen ob Projekt existiert und User Berechtigung hat
      const project = await prisma.project.findUnique({
        where: { id: validatedData.projectId }
      })

      if (!project) {
        throw createError({
          statusCode: 404,
          statusMessage: 'Projekt nicht gefunden'
        })
      }

      // Berechtigung prüfen
      if (user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER') {
        const isMember = await prisma.projectMember.findFirst({
          where: {
            projectId: validatedData.projectId,
            userId: user.id
          }
        })

        if (!isMember) {
          throw createError({
            statusCode: 403,
            statusMessage: 'Keine Berechtigung Tasks in diesem Projekt zu erstellen'
          })
        }
      }

      // Task-Key generieren
      const taskCount = await prisma.task.count({
        where: { projectId: validatedData.projectId }
      })
      const taskKey = `${project.key}-${(taskCount + 1).toString().padStart(3, '0')}`

      // Task erstellen
      const newTask = await prisma.task.create({
        data: {
          key: taskKey,
          title: validatedData.title,
          description: validatedData.description,
          typeId: validatedData.typeId,
          priorityId: validatedData.priorityId,
          statusId: validatedData.statusId,
          projectId: validatedData.projectId,
          assigneeId: validatedData.assigneeId,
          creatorId: user.id,
          dueDate: validatedData.dueDate ? new Date(validatedData.dueDate) : null,
          estimatedHours: validatedData.estimatedHours,
          remainingHours: validatedData.remainingHours || validatedData.estimatedHours
        },
        include: {
          project: {
            select: {
              id: true,
              name: true,
              key: true
            }
          },
          assignee: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true
            }
          },
          creator: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true
            }
          }
        }
      })

      // Aktivitätslog erstellen
      await prisma.activityLog.create({
        data: {
          action: 'TASK_CREATED',
          description: `Aufgabe "${newTask.title}" wurde erstellt`,
          userId: user.id,
          projectId: newTask.projectId,
          taskId: newTask.id
        }
      })

      return newTask
    }

    throw createError({
      statusCode: 405,
      statusMessage: 'Methode nicht erlaubt'
    })

  } catch (error: any) {
    if (error.statusCode) {
      throw error
    }

    console.error('Tasks API Error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Server-Fehler'
    })
  }
})
