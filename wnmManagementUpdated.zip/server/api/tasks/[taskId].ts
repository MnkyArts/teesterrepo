import { z } from 'zod'
import { requireAuth } from '~/server/utils/auth'
import { prisma } from '~/lib/database'

// Validation Schema für Task-Erstellung
const createTaskSchema = z.object({
  title: z.string().min(1, 'Titel ist erforderlich'),
  description: z.string().optional(),
  typeId: z.string().optional(),
  priorityId: z.string().optional(),
  statusId: z.string().optional(),
  projectId: z.string(),
  assigneeId: z.string().optional(),
  dueDate: z.string().optional(),
  estimatedHours: z.number().positive().optional(),
  remainingHours: z.number().positive().optional()
})

// Validation Schema für Task-Updates
const updateTaskSchema = createTaskSchema.partial().omit({ projectId: true })

export default defineEventHandler(async (event) => {
  const method = getMethod(event)
  
  try {
    const user = await requireAuth()(event)

    const taskId = getRouterParam(event, 'taskId')
    
    if (method === 'GET') {
      // Task abrufen
      const task = await prisma.task.findUnique({
        where: { id: taskId },
        include: {
          project: {
            select: {
              id: true,
              name: true,
              key: true,
              customer: {
                select: {
                  id: true,
                  companyName: true
                }
              }
            }
          },
          assignee: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              avatar: true
            }
          },
          creator: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              avatar: true
            }
          },
          type: {
            select: {
              id: true,
              key: true,
              label: true,
              color: true,
              icon: true
            }
          },
          priority: {
            select: {
              id: true,
              key: true,
              label: true,
              color: true,
              icon: true
            }
          },
          status: {
            select: {
              id: true,
              key: true,
              label: true,
              color: true,
              icon: true
            }
          },
          comments: {
            include: {
              author: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  avatar: true
                }
              }
            },
            orderBy: { createdAt: 'desc' }
          },
          attachments: true,
          timeEntries: {
            include: {
              user: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true
                }
              }
            },
            orderBy: { createdAt: 'desc' }
          },
          _count: {
            select: {
              comments: true,
              timeEntries: true
            }
          }
        }
      })

      if (!task) {
        throw createError({
          statusCode: 404,
          statusMessage: 'Aufgabe nicht gefunden'
        })
      }

      // Berechtigung prüfen (Projektmitglied oder Admin)
      if (user.role !== 'ADMINISTRATOR') {
        const isMember = await prisma.projectMember.findFirst({
          where: {
            projectId: task.projectId,
            userId: user.id
          }
        })

        if (!isMember) {
          throw createError({
            statusCode: 403,
            statusMessage: 'Keine Berechtigung für diese Aufgabe'
          })
        }
      }

      return task
    }

    if (method === 'PUT') {
      // Task aktualisieren
      const body = await readBody(event)
      const validatedData = updateTaskSchema.parse(body)

      // Prüfen ob Task existiert
      const existingTask = await prisma.task.findUnique({
        where: { id: taskId },
        include: { project: true }
      })

      if (!existingTask) {
        throw createError({
          statusCode: 404,
          statusMessage: 'Aufgabe nicht gefunden'
        })
      }

      // Berechtigung prüfen
      if (user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER') {
        const isMember = await prisma.projectMember.findFirst({
          where: {
            projectId: existingTask.projectId,
            userId: user.id
          }
        })

        if (!isMember) {
          throw createError({
            statusCode: 403,
            statusMessage: 'Keine Berechtigung zum Bearbeiten dieser Aufgabe'
          })
        }
      }

      // Task aktualisieren
      try {
        const updatedTask = await prisma.task.update({
          where: { id: taskId },
          data: {
            ...validatedData,
            dueDate: validatedData.dueDate ? new Date(validatedData.dueDate) : undefined,
            updatedAt: new Date()
          },
          include: {
            project: {
              select: {
                id: true,
                name: true,
                key: true,
                customer: {
                  select: {
                    id: true,
                    companyName: true
                  }
                }
              }
            },
            assignee: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                avatar: true
              }
            },
            creator: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                avatar: true
              }
            },
            type: {
              select: {
                id: true,
                key: true,
                label: true,
                color: true,
                icon: true
              }
            },
            priority: {
              select: {
                id: true,
                key: true,
                label: true,
                color: true,
                icon: true
              }
            },
            status: {
              select: {
                id: true,
                key: true,
                label: true,
                color: true,
                icon: true
              }
            },
            _count: {
              select: {
                comments: true,
                timeEntries: true,
                attachments: true
              }
            }
          }
      })

      // Aktivitätslog erstellen
      await prisma.activityLog.create({
        data: {
          action: 'TASK_UPDATED',
          description: `Aufgabe "${updatedTask.title}" wurde aktualisiert`,
          userId: user.id,
          projectId: updatedTask.projectId,
          taskId: updatedTask.id
        }
      })

      return updatedTask
      } catch (dbError: any) {
        console.error('Database update error:', dbError.message)
        throw createError({
          statusCode: 500,
          statusMessage: 'Fehler beim Aktualisieren der Aufgabe'
        })
      }
    }

    if (method === 'DELETE') {
      // Task löschen
      const existingTask = await prisma.task.findUnique({
        where: { id: taskId }
      })

      if (!existingTask) {
        throw createError({
          statusCode: 404,
          statusMessage: 'Aufgabe nicht gefunden'
        })
      }

      // Nur Administratoren und Projektleiter können Tasks löschen
      if (user.role !== 'ADMINISTRATOR' && user.role !== 'PROJEKTLEITER') {
        throw createError({
          statusCode: 403,
          statusMessage: 'Keine Berechtigung zum Löschen von Aufgaben'
        })
      }

      await prisma.task.delete({
        where: { id: taskId }
      })

      // Aktivitätslog erstellen
      await prisma.activityLog.create({
        data: {
          action: 'TASK_DELETED',
          description: `Aufgabe "${existingTask.title}" wurde gelöscht`,
          userId: user.id,
          projectId: existingTask.projectId
        }
      })

      return { message: 'Aufgabe erfolgreich gelöscht' }
    }

    throw createError({
      statusCode: 405,
      statusMessage: 'Methode nicht erlaubt'
    })

  } catch (error: any) {
    if (error.statusCode) {
      throw error
    }

    console.error('Task API Error:', error)
    throw createError({
      statusCode: 500,
      statusMessage: 'Interner Server-Fehler'
    })
  }
})
