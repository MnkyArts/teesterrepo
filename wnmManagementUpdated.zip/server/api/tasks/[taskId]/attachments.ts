import { requireAuth } from '~/server/utils/auth'
import { PrismaClient } from '@prisma/client'
import { IncomingForm } from 'formidable'
import fs from 'fs/promises'
import path from 'path'

const prisma = new PrismaClient()

// Erlaubte Dateitypen und maximale Dateigröße
const ALLOWED_MIME_TYPES = [
  'image/jpeg',
  'image/png', 
  'image/gif',
  'image/webp',
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'text/plain',
  'text/csv',
  'application/zip',
  'application/x-rar-compressed'
]

const MAX_FILE_SIZE = 10 * 1024 * 1024 // 10MB

// Upload-Verzeichnis sicherstellen
const UPLOAD_DIR = path.join(process.cwd(), 'uploads', 'tasks')

async function ensureUploadDir() {
  try {
    await fs.access(UPLOAD_DIR)
  } catch {
    await fs.mkdir(UPLOAD_DIR, { recursive: true })
  }
}

export default defineEventHandler(async (event) => {
  const method = getMethod(event)
  const taskId = getRouterParam(event, 'taskId')

  if (!taskId) {
    throw createError({
      statusCode: 400,
      statusMessage: 'Task-ID ist erforderlich'
    })
  }

  // Authentifizierung prüfen
  const user = await requireAuth()(event)

  try {
    // Task existiert prüfen
    const task = await prisma.task.findUnique({
      where: {
        id: taskId
      }
    })

    if (!task) {
      throw createError({
        statusCode: 404,
        statusMessage: 'Task nicht gefunden'
      })
    }

    switch (method) {
      case 'GET':
        return await getAttachments(taskId)
      
      case 'POST':
        return await uploadAttachment(event, taskId, user.id)
      
      default:
        throw createError({
          statusCode: 405,
          statusMessage: 'Method not allowed'
        })
    }
  } catch (error: any) {
    console.error('Fehler bei Anhang-Operation:', error)
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || 'Interner Serverfehler'
    })
  }
})

async function getAttachments(taskId: string) {
  const attachments = await prisma.taskAttachment.findMany({
    where: { taskId },
    orderBy: { createdAt: 'desc' }
  })

  return attachments
}

async function uploadAttachment(event: any, taskId: string, userId: string) {
  await ensureUploadDir()

  const form = new IncomingForm({
    uploadDir: UPLOAD_DIR,
    keepExtensions: true,
    maxFileSize: MAX_FILE_SIZE,
    filter: ({ mimetype }) => {
      return ALLOWED_MIME_TYPES.includes(mimetype || '')
    }
  })

  return new Promise((resolve, reject) => {
    form.parse(event.node.req, async (err, fields, files) => {
      if (err) {
        reject(createError({
          statusCode: 400,
          statusMessage: `Upload-Fehler: ${err.message}`
        }))
        return
      }

      const file = Array.isArray(files.file) ? files.file[0] : files.file
      if (!file) {
        reject(createError({
          statusCode: 400,
          statusMessage: 'Keine Datei hochgeladen'
        }))
        return
      }

      try {
        // Eindeutigen Dateinamen generieren
        const timestamp = Date.now()
        const randomSuffix = Math.random().toString(36).substring(2, 8)
        const extension = path.extname(file.originalFilename || '')
        const filename = `${timestamp}_${randomSuffix}${extension}`
        const filePath = path.join(UPLOAD_DIR, filename)

        // Datei verschieben
        await fs.rename(file.filepath, filePath)

        // Datenbank-Eintrag erstellen
        const attachment = await prisma.taskAttachment.create({
          data: {
            filename,
            originalName: file.originalFilename || filename,
            mimeType: file.mimetype || 'application/octet-stream',
            size: file.size || 0,
            path: filePath,
            taskId
          }
        })

        // Aktivitätslog erstellen
        await prisma.activityLog.create({
          data: {
            action: 'ATTACHMENT_ADDED',
            description: `Datei "${attachment.originalName}" wurde hinzugefügt`,
            userId,
            taskId
          }
        })

        resolve(attachment)
      } catch (dbError: any) {
        console.error('Datenbank-Fehler:', dbError)
        reject(createError({
          statusCode: 500,
          statusMessage: 'Fehler beim Speichern der Datei'
        }))
      }
    })
  })
}
