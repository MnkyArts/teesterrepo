// Health Check API Endpoint für wenoma
// Für GitLab CI/CD Health Checks und Monitoring

export default defineEventHandler(async (event) => {
  try {
    // Basic health check
    const health: {
      status: string
      timestamp: string
      uptime: number
      environment: string
      version: string
      database?: string
      redis?: string
    } = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV || 'development',
      version: process.env.npm_package_version || '1.0.0'
    }

    // Check database connection if available
    try {
      // You can add database health check here
      // const db = await prisma.$queryRaw`SELECT 1`
      health.database = 'connected'
    } catch (error) {
      health.database = 'disconnected'
      health.status = 'unhealthy'
    }

    // Check Redis connection if available
    try {
      // You can add Redis health check here
      health.redis = 'connected'
    } catch (error) {
      health.redis = 'disconnected'
      health.status = 'unhealthy'
    }

    // Set appropriate status code
    setResponseStatus(event, health.status === 'healthy' ? 200 : 503)
    
    return health
  } catch (error) {
    setResponseStatus(event, 503)
    return {
      status: 'unhealthy',
      error: 'Health check failed',
      timestamp: new Date().toISOString()
    }
  }
})
