import { auth } from '~/lib/auth'
import type { EventHandler } from 'h3'
import type { UserRole } from '@prisma/client'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

/**
 * Get user with customer relation included
 */
export async function getUserWithCustomer(userId: string) {
  return await prisma.user.findUnique({
    where: { id: userId },
    include: {
      customer: {
        select: {
          id: true,
          companyName: true,
          email: true,
          contactName: true,
          phone: true,
          isActive: true
        }
      }
    }
  })
}

/**
 * Middleware zur Better Auth Authentifizierung
 */
export function requireAuth(requiredRole?: UserRole): EventHandler {
  return async (event) => {
    try {
      const session = await auth.api.getSession({
        headers: event.headers || {}
      })

      if (!session?.user) {
        throw createError({
          statusCode: 401,
          statusMessage: 'Authentifizierung erforderlich'
        })
      }

      // Get user with customer relationship if user is a customer
      const userWithCustomer = await getUserWithCustomer(session.user.id)

      if (!userWithCustomer) {
        throw createError({
          statusCode: 401,
          statusMessage: 'Benutzer nicht gefunden'
        })
      }

      // Rollenbasierte Berechtigung prüfen
      if (requiredRole && !hasPermission(userWithCustomer.role as UserRole, requiredRole)) {
        throw createError({
          statusCode: 403,
          statusMessage: 'Unzureichende Berechtigung'
        })
      }

      // Benutzer an Event-Context anhängen
      event.context.user = userWithCustomer
      event.context.session = session

      return userWithCustomer
    } catch (error: any) {
      if (error.statusCode) {
        throw error
      }
      throw createError({
        statusCode: 401,
        statusMessage: 'Authentifizierung fehlgeschlagen'
      })
    }
  }
}

/**
 * Hilfsfunktion zur Extraktion des Benutzers aus dem Event-Context
 */
export function getCurrentUser(event: any) {
  return event.context.user
}

/**
 * Hilfsfunktion zur Extraktion der Session aus dem Event-Context
 */
export function getCurrentSession(event: any) {
  return event.context.session
}

/**
 * Überprüft Berechtigung basierend auf Rolle
 */
export function hasPermission(userRole: UserRole, requiredRole: UserRole): boolean {
  const roleHierarchy: Record<UserRole, number> = {
    VIEWER: 1,
    KUNDE: 2,
    SUPPORTER: 3,
    ENTWICKLER: 4,
    PROJEKTLEITER: 5,
    ADMINISTRATOR: 6
  }
  
  const userRoleLevel = roleHierarchy[userRole] || 0
  const requiredRoleLevel = roleHierarchy[requiredRole] || 0
  
  return userRoleLevel >= requiredRoleLevel
}

/**
 * Überprüft ob Benutzer Administrator ist
 */
export function isAdmin(userRole: UserRole): boolean {
  return hasPermission(userRole, 'ADMINISTRATOR')
}

/**
 * Überprüft ob Benutzer Projektleiter oder höher ist
 */
export function isProjectManager(userRole: UserRole): boolean {
  return hasPermission(userRole, 'PROJEKTLEITER')
}
